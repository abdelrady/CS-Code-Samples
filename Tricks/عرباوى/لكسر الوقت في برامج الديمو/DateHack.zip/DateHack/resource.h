//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DateHack.rc
//
#define IDD_CONFIG                      101
#define IDD_SHORTCUTNAME                104
#define IDI_DATEHACK                    105
#define IDC_PARAM_CONSTRUCT             1000
#define IDC_MAKE_SC                     1001
#define IDC_QUIT                        1002
#define IDC_BEEP                        1003
#define IDC_BEEPCHK                     1003
#define IDC_EDIT2                       1004
#define IDC_PROGRAM                     1004
#define IDC_SEL_PROGRAM                 1005
#define IDC_PROGRAMSEL                  1005
#define IDC_PROGPARAMS                  1006
#define IDC_TIMEDELAY                   1007
#define IDC_TIMEDELAYSEL                1007
#define IDC_EDIT3                       1009
#define IDC_TIMEDELAYEDIT               1009
#define IDC_ABOUT                       1010
#define IDC_MONTHSEL                    1011
#define IDC_DAYSEL                      1012
#define IDC_SHORTCUTFILENAME            1012
#define IDC_YEARSEL                     1013
#define IDC_OK                          1013
#define IDC_CANCEL                      1014
#define IDC_COPYTOCLIPBOARD             1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
