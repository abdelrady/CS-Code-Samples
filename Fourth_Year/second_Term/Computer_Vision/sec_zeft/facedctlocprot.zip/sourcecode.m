% 
%Face Recognition based on Overlapping DCT
% 
% In order to obtain the complete source code for Face Recognition based on 
% Overlapping DCT please visit my website
% 
% http://www.advancedsourcecode.com/overlappingdct.asp
%
% 
% A small donation (just 250 Euros, less than 350 U.S. Dollars) is required.
% 
% Date           Release        Major features
% 20-10-2007         1.0        - Face recognition based on Overlapping DCT
%                               - Recognition rate of 99.2% with AT&T Database
%                               - Easy and intuitive GUI
%                               - Easy C/C++ implementation
%
% For any question please email me luigi.rosa@tiscali.it
%
% Luigi Rosa
% Via Centrale 35
% 67042 Civita di Bagno
% L'Aquila - ITALY 
% email  luigi.rosa@tiscali.it
% mobile +39 320 7214179
% web site http://www.advancedsourcecode.com
%
%
%