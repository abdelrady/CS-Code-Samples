<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkUseCpuId = New System.Windows.Forms.CheckBox
        Me.chkUseBiosId = New System.Windows.Forms.CheckBox
        Me.chkUseDiskId = New System.Windows.Forms.CheckBox
        Me.chkUseBaseId = New System.Windows.Forms.CheckBox
        Me.chkUseVideoId = New System.Windows.Forms.CheckBox
        Me.chkUseMacId = New System.Windows.Forms.CheckBox
        Me.txtFingerPrint = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Button1 = New System.Windows.Forms.Button
        Me.numLength = New System.Windows.Forms.NumericUpDown
        Me.optAll = New System.Windows.Forms.RadioButton
        Me.optLimit = New System.Windows.Forms.RadioButton
        Me.Label9 = New System.Windows.Forms.Label
        CType(Me.numLength, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkUseCpuId
        '
        Me.chkUseCpuId.AutoSize = True
        Me.chkUseCpuId.Checked = True
        Me.chkUseCpuId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseCpuId.Location = New System.Drawing.Point(13, 13)
        Me.chkUseCpuId.Name = "chkUseCpuId"
        Me.chkUseCpuId.Size = New System.Drawing.Size(82, 17)
        Me.chkUseCpuId.TabIndex = 0
        Me.chkUseCpuId.Text = "Use CPU Id"
        Me.chkUseCpuId.UseVisualStyleBackColor = True
        '
        'chkUseBiosId
        '
        Me.chkUseBiosId.AutoSize = True
        Me.chkUseBiosId.Checked = True
        Me.chkUseBiosId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseBiosId.Location = New System.Drawing.Point(13, 37)
        Me.chkUseBiosId.Name = "chkUseBiosId"
        Me.chkUseBiosId.Size = New System.Drawing.Size(82, 17)
        Me.chkUseBiosId.TabIndex = 1
        Me.chkUseBiosId.Text = "Use Bios ID"
        Me.chkUseBiosId.UseVisualStyleBackColor = True
        '
        'chkUseDiskId
        '
        Me.chkUseDiskId.AutoSize = True
        Me.chkUseDiskId.Checked = True
        Me.chkUseDiskId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseDiskId.Location = New System.Drawing.Point(13, 61)
        Me.chkUseDiskId.Name = "chkUseDiskId"
        Me.chkUseDiskId.Size = New System.Drawing.Size(109, 17)
        Me.chkUseDiskId.TabIndex = 2
        Me.chkUseDiskId.Text = "Use Hard Disk ID"
        Me.chkUseDiskId.UseVisualStyleBackColor = True
        '
        'chkUseBaseId
        '
        Me.chkUseBaseId.AutoSize = True
        Me.chkUseBaseId.Checked = True
        Me.chkUseBaseId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseBaseId.Location = New System.Drawing.Point(13, 85)
        Me.chkUseBaseId.Name = "chkUseBaseId"
        Me.chkUseBaseId.Size = New System.Drawing.Size(120, 17)
        Me.chkUseBaseId.TabIndex = 3
        Me.chkUseBaseId.Text = "Use Motherboard Id"
        Me.chkUseBaseId.UseVisualStyleBackColor = True
        '
        'chkUseVideoId
        '
        Me.chkUseVideoId.AutoSize = True
        Me.chkUseVideoId.Checked = True
        Me.chkUseVideoId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseVideoId.Location = New System.Drawing.Point(13, 109)
        Me.chkUseVideoId.Name = "chkUseVideoId"
        Me.chkUseVideoId.Size = New System.Drawing.Size(112, 17)
        Me.chkUseVideoId.TabIndex = 4
        Me.chkUseVideoId.Text = "Use Video Card Id"
        Me.chkUseVideoId.UseVisualStyleBackColor = True
        '
        'chkUseMacId
        '
        Me.chkUseMacId.AutoSize = True
        Me.chkUseMacId.Checked = True
        Me.chkUseMacId.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUseMacId.Location = New System.Drawing.Point(13, 133)
        Me.chkUseMacId.Name = "chkUseMacId"
        Me.chkUseMacId.Size = New System.Drawing.Size(151, 17)
        Me.chkUseMacId.TabIndex = 5
        Me.chkUseMacId.Text = "Use Network Card MAC Id"
        Me.chkUseMacId.UseVisualStyleBackColor = True
        '
        'txtFingerPrint
        '
        Me.txtFingerPrint.Location = New System.Drawing.Point(12, 192)
        Me.txtFingerPrint.Name = "txtFingerPrint"
        Me.txtFingerPrint.Size = New System.Drawing.Size(607, 20)
        Me.txtFingerPrint.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(10, 172)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(98, 17)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Finger Print:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 219)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(151, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Total Length was ? characters"
        Me.Label2.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(384, 107)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(132, 40)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "Find Finger Print"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'numLength
        '
        Me.numLength.Location = New System.Drawing.Point(384, 12)
        Me.numLength.Minimum = New Decimal(New Integer() {1, 0, 0, 0})
        Me.numLength.Name = "numLength"
        Me.numLength.Size = New System.Drawing.Size(80, 20)
        Me.numLength.TabIndex = 17
        Me.numLength.Value = New Decimal(New Integer() {16, 0, 0, 0})
        '
        'optAll
        '
        Me.optAll.AutoSize = True
        Me.optAll.Location = New System.Drawing.Point(308, 38)
        Me.optAll.Name = "optAll"
        Me.optAll.Size = New System.Drawing.Size(125, 17)
        Me.optAll.TabIndex = 19
        Me.optAll.Text = "Return All Characters"
        Me.optAll.UseVisualStyleBackColor = True
        '
        'optLimit
        '
        Me.optLimit.AutoSize = True
        Me.optLimit.Checked = True
        Me.optLimit.Location = New System.Drawing.Point(308, 12)
        Me.optLimit.Name = "optLimit"
        Me.optLimit.Size = New System.Drawing.Size(57, 17)
        Me.optLimit.TabIndex = 20
        Me.optLimit.TabStop = True
        Me.optLimit.Text = "Return"
        Me.optLimit.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(470, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(58, 13)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Characters"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(631, 250)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.optLimit)
        Me.Controls.Add(Me.optAll)
        Me.Controls.Add(Me.numLength)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtFingerPrint)
        Me.Controls.Add(Me.chkUseMacId)
        Me.Controls.Add(Me.chkUseVideoId)
        Me.Controls.Add(Me.chkUseBaseId)
        Me.Controls.Add(Me.chkUseDiskId)
        Me.Controls.Add(Me.chkUseBiosId)
        Me.Controls.Add(Me.chkUseCpuId)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Finger Print Class Test"
        CType(Me.numLength, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkUseCpuId As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseBiosId As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseDiskId As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseBaseId As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseVideoId As System.Windows.Forms.CheckBox
    Friend WithEvents chkUseMacId As System.Windows.Forms.CheckBox
    Friend WithEvents txtFingerPrint As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents numLength As System.Windows.Forms.NumericUpDown
    Friend WithEvents optAll As System.Windows.Forms.RadioButton
    Friend WithEvents optLimit As System.Windows.Forms.RadioButton
    Friend WithEvents Label9 As System.Windows.Forms.Label

End Class
