Public Class Form1

    Private WithEvents fp As JCS.FingerPrint = New JCS.FingerPrint

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        fp.UseCpuID = chkUseCpuId.Checked
        fp.UseBiosID = chkUseBiosId.Checked
        fp.UseBaseID = chkUseBaseId.Checked
        fp.UseDiskID = chkUseDiskId.Checked
        fp.UseVideoID = chkUseVideoId.Checked
        fp.UseMacID = chkUseMacId.Checked

        If optAll.Checked Then
            fp.ReturnLength = 0
        Else
            fp.ReturnLength = numLength.Value
        End If

        txtFingerPrint.Text = fp.Value
        Label2.Text = "Total Length was " & fp.TotalLength.ToString & " characters"
    End Sub

End Class
