//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PaPiC.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PAPIC_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDC_CHECK1                      1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON4                     1004
#define IDC_BUTTON5                     1005
#define IDC_BUTTON7                     1007
#define IDC_CHECK2                      1013
#define IDC_CHECK3                      1014
#define IDC_CHECK4                      1015
#define IDC_CHECK5                      1016
#define IDC_CHECK6                      1017
#define IDC_CHECK7                      1018
#define IDC_CHECK8                      1019
#define IDC_CHECK9                      1020
#define IDC_CHECK10                     1021
#define IDC_CHECK11                     1022
#define IDC_CHECK12                     1023
#define IDC_CHECK13                     1024
#define IDC_CHECK14                     1025
#define IDC_CHECK15                     1026
#define IDC_CHECK16                     1027
#define IDC_CHECK17                     1028
#define IDC_CHECK18                     1029
#define IDC_CHECK19                     1030
#define IDC_CHECK20                     1031
#define IDC_CHECK21                     1032
#define IDC_CHECK22                     1033
#define IDC_CHECK23                     1034
#define IDC_CHECK24                     1035
#define IDC_CHECK25                     1036
#define IDC_CHECK26                     1037
#define IDC_CHECK27                     1038
#define IDC_CHECK28                     1039
#define IDC_CHECK29                     1040
#define IDC_BUTTON8                     1041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
