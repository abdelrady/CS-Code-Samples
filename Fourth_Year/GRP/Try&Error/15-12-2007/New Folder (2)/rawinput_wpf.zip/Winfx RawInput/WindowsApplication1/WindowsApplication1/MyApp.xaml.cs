namespace WindowsApplication1
{
    /// <summary>
    /// Interaction logic for MyApp.xaml
    /// </summary>

    public partial class MyApp 
    {
    }
}