﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Baby Keyboard Bash")]
[assembly: AssemblyDescription("Let your baby hammer the keyboard")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Emma Burrows")]
[assembly: AssemblyProduct("Baby Keyboard Bash")]
[assembly: AssemblyCopyright("Copyright © Emma Burrows 2006")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b64fa194-9cd7-44be-a03d-c4d6b4e0e115")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
