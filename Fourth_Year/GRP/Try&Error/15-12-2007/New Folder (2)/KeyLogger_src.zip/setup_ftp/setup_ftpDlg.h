// setup_ftpDlg.h : header file
//

#pragma once
#include "afxwin.h"


// Csetup_ftpDlg dialog
class Csetup_ftpDlg : public CDialog
{
// Construction
public:
	Csetup_ftpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_SETUP_FTP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
private:
	BOOL RegWrite(char* szValueName, char* szValue); 
	CEdit m_url;
	CEdit m_port;
	CEdit m_user;
	CEdit m_password;
	CEdit m_file;
};
