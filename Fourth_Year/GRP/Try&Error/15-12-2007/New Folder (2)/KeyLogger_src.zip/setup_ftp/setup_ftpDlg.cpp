// setup_ftpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "setup_ftp.h"
#include "setup_ftpDlg.h"
#include ".\setup_ftpdlg.h"
#include "..\spy\consts.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// Csetup_ftpDlg dialog



Csetup_ftpDlg::Csetup_ftpDlg(CWnd* pParent /*=NULL*/)
	: CDialog(Csetup_ftpDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Csetup_ftpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_FTP_URL, m_url);
	DDX_Control(pDX, IDC_EDIT_FTP_PORT, m_port);
	DDX_Control(pDX, IDC_EDIT_FTP_USER, m_user);
	DDX_Control(pDX, IDC_EDIT_FTP_PASSWORD, m_password);
	DDX_Control(pDX, IDC_EDIT_FTP_FILE, m_file);
}

BEGIN_MESSAGE_MAP(Csetup_ftpDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// Csetup_ftpDlg message handlers

BOOL Csetup_ftpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	
	m_url.SetWindowText("127.0.0.1");
    m_port.SetWindowText("21");
    m_user.SetWindowText("guest");
	m_password.SetWindowText("guest");
	m_file.SetWindowText("report.txt");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Csetup_ftpDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Csetup_ftpDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

///////////////////////////////////////////////////////

BOOL Csetup_ftpDlg::RegWrite(char* szValueName, char* szValue) 
{
	HKEY hOpenedKey;

	if (RegCreateKeyEx(HKEY_LOCAL_MACHINE, SPY_REG_KEY, 0, NULL, 0, KEY_WRITE, NULL, &hOpenedKey, NULL) != ERROR_SUCCESS)
		return FALSE;

	if (RegSetValueEx(hOpenedKey, szValueName, 0, REG_SZ, (BYTE*)szValue, strlen(szValue) + 1) != ERROR_SUCCESS)
		return FALSE;

	RegCloseKey( hOpenedKey);
	
	return TRUE;
}

///////////////////////////////////////////////////////

void Csetup_ftpDlg::OnBnClickedOk()
{
	char szStr[255];

    m_url.GetWindowText(szStr, 255);
	RegWrite(REG_FTP_URL, szStr);

    m_port.GetWindowText(szStr, 255);
	RegWrite(REG_FTP_PORT, szStr);

	m_user.GetWindowText(szStr, 255);
	RegWrite(REG_FTP_USER, szStr);

	m_password.GetWindowText(szStr, 255);
	RegWrite(REG_FTP_PASSWORD, szStr);

	m_file.GetWindowText(szStr, 255);
	RegWrite(REG_FTP_FILE, szStr);

	OnOK();
}
