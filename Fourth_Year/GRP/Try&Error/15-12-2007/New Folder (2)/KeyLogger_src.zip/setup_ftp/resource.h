//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by setup_ftp.rc
//
#define IDD_SETUP_FTP_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_EDIT_FTP_URL                1000
#define IDC_EDIT_FTP_USER               1003
#define IDC_EDIT_FTP_PORT               1004
#define IDC_EDIT_FTP_URL4               1005
#define IDC_EDIT_FTP_FILE               1005
#define IDC_EDIT_FTP_PASSWORD           1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
