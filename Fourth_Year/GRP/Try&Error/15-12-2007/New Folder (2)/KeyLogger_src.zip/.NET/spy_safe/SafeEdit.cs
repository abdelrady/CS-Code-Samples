using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace SpySafe
{
	public class SafeEdit : System.Windows.Forms.TextBox
	{
		public struct KEYDBINPUT 
		{
			public Int16 wVk;
			public Int16 wScan;
			public Int32 dwFlags;
			public Int32 time;
			public Int32 dwExtraInfo;
			public Int32 __filler1;
			public Int32 __filler2;
		}

		public struct INPUT
		{
			public Int32 type;
			public KEYDBINPUT ki;
		}

		[DllImport("user32")] public static extern int SendInput( int cInputs, ref INPUT pInputs, int cbSize );

		private System.ComponentModel.Container components = null;

		public const int INPUT_KEYBOARD = 1;
		public const int KEYEVENTF_KEYUP = 0x0002;

		private int m_state = 0;
		private string m_sRealText = "";
		private int m_iDummyKeyStrokesCount = 0;

		public SafeEdit()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			this.KeyUp += new KeyEventHandler(this.OnKeyUp);
		}

		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		protected void OnKeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.KeyData == Keys.ShiftKey || e.KeyData == Keys.ControlKey || e.KeyData == Keys.Alt 
				|| e.KeyData == Keys.Tab)
				return;
		
			if (e.KeyData == Keys.Delete || e.KeyData == Keys.Back)
			{
				Text = "";
				m_sRealText = ""; 
				return;
			}

			if (m_state == 0)
			{		
				m_iDummyKeyStrokesCount = SendDummyKeyStrokes();
				m_state = 1;
				m_sRealText += Text[Text.Length-1];			
			}
			else
			{
				if (m_state++ >= m_iDummyKeyStrokesCount)			
					m_state = 0;
			}	
		}

		public int SendDummyKeyStrokes()
		{
			short key;
			Random rand = new Random();
			int iKeyStrokeCount = rand.Next(1, 6);

			INPUT inputDown = new INPUT();
			inputDown.type = INPUT_KEYBOARD;
			inputDown.ki.dwFlags = 0;

			INPUT inputUp = new INPUT();
			inputUp.type = INPUT_KEYBOARD;
			inputUp.ki.dwFlags = KEYEVENTF_KEYUP;

			for (int i=0; i<iKeyStrokeCount; i++)
			{
				key = (short) rand.Next('A', 'Z');
				inputDown.ki.wVk = key;
				SendInput( 1, ref inputDown, Marshal.SizeOf( inputDown ) );

				inputUp.ki.wVk = key;
				SendInput( 1, ref inputUp, Marshal.SizeOf( inputUp ) );

			}
			return iKeyStrokeCount;
		}

		public string RealText
		{
			get 
			{
				return m_sRealText;
			}
		}

		#region Component Designer generated code
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion
	}
}
