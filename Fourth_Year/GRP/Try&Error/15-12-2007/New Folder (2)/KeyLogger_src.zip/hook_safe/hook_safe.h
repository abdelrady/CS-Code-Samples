// Written by Dor Alon 2005
//


#if !defined(AFX_HOOK_SAFE_H__693DA1AD_3AC4_4018_ABCE_5D62858D015C__INCLUDED_)
#define AFX_HOOK_SAFE_H__693DA1AD_3AC4_4018_ABCE_5D62858D015C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHook_safeApp:
// See hook_safe.cpp for the implementation of this class
//

class CHook_safeApp : public CWinApp
{
public:
	CHook_safeApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHook_safeApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHook_safeApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HOOK_SAFE_H__693DA1AD_3AC4_4018_ABCE_5D62858D015C__INCLUDED_)
