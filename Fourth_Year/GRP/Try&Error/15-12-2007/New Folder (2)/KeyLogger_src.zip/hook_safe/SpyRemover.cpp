// Written by Dor Alon 2005
//

#include "stdafx.h"
#include <tlhelp32.h> 

#include "hook_safe.h"
#include "SpyRemover.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SpyRemover* SpyRemover::m_SpyRemover;

VOID SpyRemover::TimerProc(HWND hwnd, UINT uMsg, unsigned int idEvent, DWORD dwTime)
{
	m_SpyRemover->EnumModules();
}

//////////////////////////////////////////////////////////////////////

SpyRemover::SpyRemover(char* szAuthorizedList)
{
	m_SpyRemover = this;

	m_szAuthorizedList = " ";
	m_szAuthorizedList += szAuthorizedList;
	m_szAuthorizedList += " ";
    m_szAuthorizedList.MakeLower();

	::SetTimer(NULL, 0, 500, TimerProc);
}

//////////////////////////////////////////////////////////////////////

SpyRemover::~SpyRemover()
{
}

//////////////////////////////////////////////////////////////////////

void SpyRemover::EnumModules()
{
  DWORD dwPID = ::GetCurrentProcessId();
  HANDLE hModuleSnap = INVALID_HANDLE_VALUE; 
  MODULEENTRY32 me32; 
	
  //Take a snapshot of all modules in the process. 
  hModuleSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE, dwPID ); 
  if( hModuleSnap == INVALID_HANDLE_VALUE ) 
    return; 
 
  me32.dwSize = sizeof( MODULEENTRY32 ); 
 
  //Retrieve information about the first module (application.exe) 
  if( !Module32First( hModuleSnap, &me32 ) ) 
  { 
	  CloseHandle( hModuleSnap );     
	  return; 
  } 
  
  //Walk the module list of the process 
  do 
  { 
	  if (!IsModuleAuthorized(me32.szModule))
	  {
          HMODULE hmodule = me32.hModule;
		  CloseHandle(hModuleSnap); 
		  FreeLibrary(hmodule);
          return; 
	  }
	  
  } while( Module32Next( hModuleSnap, &me32 ) ); 
  
  CloseHandle(hModuleSnap); 
}

//////////////////////////////////////////////////////////////////////

bool SpyRemover::IsModuleAuthorized(char* szModuleName)
{
    char szModule[1024];
	sprintf(szModule, " %s ", szModuleName);
    strcpy(szModule, _strlwr(szModule));

	if (strstr(m_szAuthorizedList, szModule))
		return true;
	else
		return false;
}













