// Written by Dor Alon 2005
//


#if !defined(__SPYREMOVER_H__)
#define __SPYREMOVER_H__

class SpyRemover  
{
public:
	SpyRemover(char* szAuthorizedList);
	virtual ~SpyRemover();

private:
	bool IsModuleAuthorized(char* szModuleName); 
    void EnumModules();

	CString m_szAuthorizedList;

    static VOID CALLBACK TimerProc(HWND hwnd, UINT uMsg, unsigned int idEvent, DWORD dwTime);
    static SpyRemover* m_SpyRemover;
};

#endif // __SPYREMOVER_H__
