// Written by Dor Alon 2005
//
#include "stdafx.h"
#include "hook_safe.h"
#include "hook_safeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHook_safeDlg dialog

CHook_safeDlg::CHook_safeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CHook_safeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CHook_safeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_remover = new SpyRemover("ADVAPI32.dll IMM32.DLL LPK.DLL USP10.dll uxtheme.dll msctfime.ime COMCTL32.DLL GDI32.dll hook_safe.exe KERNEL32.dll MFC71.DLL MFC71ENU.DLL MSCTF.dll MSVCR71.dll msvcrt.dll ntdll.dll ole32.dll OLEAUT32.DLL RPCRT4.DLL SHLWAPI.dll USER32.dll");
}

CHook_safeDlg::~CHook_safeDlg()
{
 delete m_remover;
}

void CHook_safeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CHook_safeDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CHook_safeDlg, CDialog)
	//{{AFX_MSG_MAP(CHook_safeDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHook_safeDlg message handlers

BOOL CHook_safeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
    
//	::SetTimer(m_hWnd, 0, 500, NULL);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CHook_safeDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CHook_safeDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

///////////////////////////////////////////////////////////////////////////////////////////

void CHook_safeDlg::OnTimer(UINT nIDEvent) 
{	
//	m_remover->EnumModules();
	CDialog::OnTimer(nIDEvent);
}
