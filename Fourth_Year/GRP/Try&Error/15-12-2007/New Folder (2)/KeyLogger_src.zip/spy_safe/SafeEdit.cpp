// Written by Dor Alon 2005
//

#include "stdafx.h"
#include "spy_safe.h"
#include "SafeEdit.h"


BEGIN_MESSAGE_MAP(CSafeEdit, CEdit)
	//{{AFX_MSG_MAP(CSafeEdit)
	ON_WM_KEYUP()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

CSafeEdit::CSafeEdit()
{
	m_sRealText = "";
	m_state = 0;
}

CSafeEdit::~CSafeEdit()
{
}


/////////////////////////////////////////////////////////////////////////////
// CSafeEdit message handlers

void CSafeEdit::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	if (nChar == VK_SHIFT || nChar == VK_CONTROL || nChar == VK_MENU || nChar == VK_TAB)
		return;

	if (nChar == VK_DELETE || nChar == VK_BACK)
	{
		SetWindowText("");
		m_sRealText = ""; 
		return;
	}

	if (m_state == 0)
	{
		m_iDummyKeyStrokesCount = SendDummyKeyStrokes();

		m_state = 1;

		CString text;
		GetWindowText(text);

		m_sRealText += text.Right(1);			
	}
	else
	{
		if (m_state++ >= m_iDummyKeyStrokesCount)			
			m_state = 0;
	}


	CEdit::OnKeyUp(nChar, nRepCnt, nFlags);
}

/////////////////////////////////////////////////////////////////////////////

CString CSafeEdit::GetRealText()
{
	return m_sRealText;
}

/////////////////////////////////////////////////////////////////////////////

int CSafeEdit::SendDummyKeyStrokes()
{
	srand((unsigned)::GetTickCount());
	int iKeyStrokeCount = rand() % 5 + 1;

	int key;
	INPUT inp[2];
	inp[0].type = INPUT_KEYBOARD;	
	inp[0].ki.dwExtraInfo = ::GetMessageExtraInfo();
	inp[0].ki.dwFlags = 0;
	inp[0].ki.time = 0;

	for (int i=0; i<iKeyStrokeCount; i++)
	{
		key = rand() % ('Z'-'A') + 'A';
		inp[0].ki.wScan = key;
		inp[0].ki.wVk = key;

		inp[1] = inp[0];
		inp[1].ki.dwFlags = KEYEVENTF_KEYUP;

		SendInput(2, inp, sizeof(INPUT));	
	}

	return iKeyStrokeCount;
}
