// Written by Dor Alon 2005
//

#if !defined(__SAFEEDIT_H__)
#define __SAFEEDIT_H__

/////////////////////////////////////////////////////////////////////////////
// CSafeEdit window

class CSafeEdit : public CEdit
{
// Construction
public:
	CSafeEdit();
	virtual ~CSafeEdit();
    CString GetRealText();

	// Generated message map functions
protected:
	int SendDummyKeyStrokes();
	CString m_sRealText;
	int m_iDummyKeyStrokesCount;
	int m_state;

	//{{AFX_MSG(CSafeEdit)
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // __SAFEEDIT_H__
