// Written by Dor Alon 2005
//


#include "stdafx.h"
#include "spy_safe.h"
#include "spy_safeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSpy_safeDlg dialog

CSpy_safeDlg::CSpy_safeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSpy_safeDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSpy_safeDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSpy_safeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSpy_safeDlg)
	DDX_Control(pDX, IDC_EDIT_REG, m_regEdit);
	DDX_Control(pDX, IDC_EDIT_SAFE, m_safeEdit);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSpy_safeDlg, CDialog)
	//{{AFX_MSG_MAP(CSpy_safeDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_REG, OnBtnReg)
	ON_BN_CLICKED(IDC_BTN_SAFE, OnBtnSafe)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSpy_safeDlg message handlers

BOOL CSpy_safeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSpy_safeDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSpy_safeDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSpy_safeDlg::OnBtnReg() 
{
	CString text;
	m_regEdit.GetWindowText(text);
	MessageBox(text, "CEdit");
}

void CSpy_safeDlg::OnBtnSafe() 
{
	CString text = m_safeEdit.GetRealText();
	MessageBox(text, "CSafeEdit");	
}
