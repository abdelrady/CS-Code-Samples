Title: CueCat BarCode Decoder
Description: Radio Shack is currently giving away a CueCat BarCode reader to work with software they have procuded. The purpose of their software is to order their products over the web.
I did not install there software, but used the basrcode reader to read in codes. I have ported a perl script to VB, inorder to use the barcode reader.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=11168&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
