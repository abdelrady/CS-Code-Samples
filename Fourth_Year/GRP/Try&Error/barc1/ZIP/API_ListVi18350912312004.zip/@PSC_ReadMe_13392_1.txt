Title: API ListView Autosize Width of Column Headers (based on widest row)
Description: API call to autosize the columns in a ListView control. I made this example because I could only find mediocre examples that worked by getting the Len() of every row, multiplying it by something, and comparing it to the column width. This uses only one command to do the actual resizing and is definately faster.
Update (12/07/2000 20:52 CST): Corrected typo, better screenshot.
Update (04/27/2002 15:00 CST): Moved code into one form, Added LVSCW_AUTOSIZE_USEHEADER, Added COMMCTL32.DLL known bug with fix, Added individual bold item known bug with fix.
Update (12/31/2004 22:00 CST): Updated website, Released under GPL, PNG screenshot.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13392&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
