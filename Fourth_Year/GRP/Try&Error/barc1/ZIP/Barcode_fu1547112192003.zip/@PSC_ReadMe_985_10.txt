Title: Barcode function EAN8 / EAN13
Description: After I read the "Code of the Day" of 2004/Feb/02 about barcode functions, I remembered about an old function of mine to draw EAN (8 and 13) barcodes.
So I updated this code to work on .NET
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=985&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
