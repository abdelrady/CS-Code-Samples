Title: barcode
Description: I looked high and low for some type of code snip that showed how to create a barcode (none where available except the ones for sale). So here is one way to print a code 39 barcode in VB. It has worked for me, although very little testing was done.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7686&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
