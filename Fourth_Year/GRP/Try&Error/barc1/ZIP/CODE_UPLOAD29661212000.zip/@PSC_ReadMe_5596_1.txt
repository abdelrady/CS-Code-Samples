Title: Is BARCODE Valid?
Description: If you like to know the meaning of those BARCODES you see
and generate your own legal BARCODES, legal meaning it is 
validly read by standard BARCODE readers, then this program
is yours to appreciate. The encryption is fairly simple
and short.         Comento: linda.69@mailcity.com

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5596&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
