Title: PostNet Barcode Generator
Description: BAS module that allows you to print
PostNet (aka 3 of 5) barcodes used
by the US Postal Service. Can output
to printer or screen (i.e. form,
picturebox, etc.) No DLL/OCX/TTF used.
All code.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=9091&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
