Title: barcode 128b
Description: This dotnet solution developed in c# can be used to create a barcode 128b from an alphanumeric string.
--&gt; input: string
--&gt; output: imagestream or imagefile

-- compile as windows application to see the example application
-- compile as class library to use as a dll in another dotnet application

Feel free to use this code in your applications.	
Enjoy!
Curi0uS
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4005&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
