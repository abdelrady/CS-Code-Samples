Curi0uSBarcode128b
****************
------------------------------------------------------------
developed by Curi0uS
mailto: Curi0uS.programmer@gmail.com 
------------------------------------------------------------

This dotnet solution developed in c# can be used to create a barcode 128b from an alphanumeric string.

--> input: string
--> output: imagestream or imagefile


-- compile as windows application to see the example application
-- compile as class library to use as a dll in another dotnet application


Feel free to use this code in your applications.	
Please include this readme with it and the programmers information with it.

Enjoy!

Curi0uS

**************************************************************************************

Remember that this code is for free. You may use this code in commercial applications.
But the programmer is not responsible for any bugs in this code.

