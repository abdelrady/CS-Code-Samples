Change user feature will only work if the
compiled executable of the program is run.

Please read readme.rtf and help.rtf file
for more information about the program.

The project is created using Visual Basic 6
of the Visual Studio 6.0 Enterprise Edition.

The project is tested and free from visible
errors (not those which are really called
bugs), so if you run the project and some
usual or maybe unusual errors occur on parts
of the source code is not my fault. Maybe
it is because of the different Visual Basic
versions, languages and updates that are
available today. I noticed this because some
users experience no errors while some do not
which explains my very point. Understand?

So enjoy, have fun, and learn.