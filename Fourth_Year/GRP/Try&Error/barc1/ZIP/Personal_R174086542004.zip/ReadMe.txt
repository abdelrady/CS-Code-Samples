Thanks for downloading! I hope you find this program useful. Please vote for me.

I wanna say thanks to Lavolpe and Hamed Oveisi for their wonderful submissions and to all other programmers out there who share their knowledge and skills. Please see the about box.

These are the required ocx and dll by this project:
Plese register these files before running the project to avoid error.
To register, put these files in your system folder then Click Start>Run then type
regsvr32 LVButtons.ocx then hit return. Do the same for arpro2.dll.

1. LVButtons.ocx
2. arpro2.dll

These files are in ActiveXControl.zip archive. All other files inside the archive are not required but can be useful especially when editing or creating new report.

You can make sure that the database and pictures the user is connecting to is the network server by enabling the IsValidServerPath function inside the modMain module. This is useful when setting up this project in a network.

This program supports Windows XP controls when compiled on a Windows XP machine and then run on a Windows XP machine.

These are the default username / password for each terminals. You can change these settings in the options panel:

Accounting - username:acctng password: [blank]
Bookstore - username:bkstore password: [blank]
Canteen - username:canteen password: [blank]

That's all. If something goes wrong with this project, please email me. Thank you.

Mamerto Fabian Jr.
junwebhead@hotmail.com