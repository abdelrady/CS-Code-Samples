Title: Personal Reloadable Card System (Complete)
Description: This is a complete point of sale program that uses reloadable card (which can be the user's ID) instead of cash. This program supports three terminals: Accounting (reloading and managing accounts), Bookstore and Canteen (actual sales transaction). You can also use a barcode scanner in inputting ID no of the account or itemcodes. The reports uses data dynamics reporting engine (now included in the zip file). This is my first submission. I hope someone can learn from this program. I'm also looking forward for your comments and suggestion to improve my programming skills. All of your votes and comments are highly appreciated. Please vote. Thank you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=53551&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
