Title: BarcodeDB
Description: Created for a barcode scanner. it stores the price, barcode and product name for an item. You can do a search for items by product name or by barcode. Also has an attempt at a registration enabled program which requires a valid username and password to register the program.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30945&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
