Title: Serial Comms with Windows API
Description: When I started with Serial Comms and the API's I tried to find a piece of code as an example... I couldn't , so I wrote my own .. and here it is. Any suggestions to better the code will be great. This little program will open a COM port and read from it as well as write to it. Try this on any serial comm's device like a Modem, barcode scanner, Comm Printer etc.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3367&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
