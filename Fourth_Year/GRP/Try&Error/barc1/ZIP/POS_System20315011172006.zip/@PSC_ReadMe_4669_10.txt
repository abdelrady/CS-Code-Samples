Title: POS System
Description: This is a point of system for small business that i developed for my college project. It include the login screen,transaction screen to record daily sales, an item master screen to record your item/products detail and these details will be auto retrieve in the transaction screen when u key in the item code or can be used with barcode scanner. Sales report available in this program. 
please comment on it :D
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=4669&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
