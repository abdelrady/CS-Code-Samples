Title: Code 39 Barcoder
Description: Draws a image of a bar code and saves it to disk. From there you can use it in crystal reports, or any printing application. I have tested this with dot matrix printers, lasers and ink jet. Works great. You should place only upper case characters and numerics in the string for render.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31323&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
