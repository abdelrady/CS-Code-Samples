Title: Easiest ever Barcode Encoder
Description: This encoder actually works (ie produces a valid barcode that will return the inputted text when scanned), and it's really really (REALLY) short & simple!
It uses the Code 128 symbology so can accept any alpha-numeric characters as well as some special characters.
All feedback and comments are welcome and your votes are appreciated if you find the code useful.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50256&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
