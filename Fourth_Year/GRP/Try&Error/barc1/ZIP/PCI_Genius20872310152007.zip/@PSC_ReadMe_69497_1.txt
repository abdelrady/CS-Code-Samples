Title: PCI GeniusBus Card
Description: This is mostly for Controls Engineers that need to access a GeniusBus network and have a PCI Genius Card. For the rest, this is an example of how to map hardware memory with API (in this case dual port ram) and access that memory directly using memory offsets (indirectly mimics C++ pointers). This also shows how to mimic a C++ IOCTL Macro. Has a basic I/O handshaking setup that can port into other device communication protcols.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69497&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
