Title: UPC-A
Description: This code was developed to create UPC-A images for a DVD Database collection. This allows the owner of the database to create a scannable UPC code to be printed on any receipts that may be generated. Could not find any other programs to generate the UPC-A barcode properly so I created my own. There is probably a faster way then what I have done, but creativity is spawned by necessity. There may be ideas and concepts intermixed within my module that are derivatives of others codes, possibly found on PSC. Not sure, its been over a year. If any are found, then I thank whomever they originally came from; however, I think that this headache was mine.
Purely an example and not a complete project. Feel free to use within your own code.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68740&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
