Message from the Author:(Walter A. Narvasa of WANCOM SYSTEMS)
URL:http://www.walter@wancom.freeservers.com
EMAIL:walter@wancomsystems.freeservers.com

Before you begin to open this project install the font "3OF9.TTF" to
"c:\windows\fonts" directory after you have done that you may open 
the project in Microsoft Visual Basic 6.


Thats all....