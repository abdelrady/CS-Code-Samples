Title: BarCode 39 (3 of 9) Generator 1.0
Description: I always looking for a barcode generator but I didn't find any. So, I decided to make a barcode generator myself instead. I would like to credit someone from PSC but I can't remember his name. This code can generate barcode 39 (3 of 9) and you have 3 options: 1. Copy to clipboard and paste in to come graphic application. 2. Save the barcode as an image file and print when you need it. 3. Print the generated barcode immediately. Comments are welcomed. Please Vote for my work.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=48268&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
