Title: MS Office Bar Code Macros for Excel and Access
Description: The macros (which consist of VBA code and functions) will generate check digits, add the start and stop characters and format the return string for barcode fonts such as POSTNET, 4-State, Code 128, Interleaved 2 of 5, MSI, UPC/EAN and Code 39. The macros can be easily integrated into your application for automation purposes and you don't have to be a programmer to use them. The barcode macros and functions are easy enough for intermediate and advanced users of Excel or Access.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=8250&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
