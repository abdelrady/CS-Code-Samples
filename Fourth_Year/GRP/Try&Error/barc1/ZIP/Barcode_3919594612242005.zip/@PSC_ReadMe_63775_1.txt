Title: Barcode 39 maker - evolution..
Description: Hi,
it's an evolution of the code submitted by Paul Bahlawan (http://www.planet-source-code.com/vb/scripts/ShowCode.asp?txtCodeId=57042&amp;lngWId=1)
It's now in a class in order tu use it with other progs.
it's my first submission (half one because not my whole creation) Don't vote, but any remarks , bugs or ideas are welcome..
thanks for PSC users and uploaders.
Driss

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63775&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
