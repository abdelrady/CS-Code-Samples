Title: IP_Barcode
Description: IP-Baracode is an application used to bypass proxy server firewall or package filtering any way it`s change the normal IP Address to IP Barcode number and then use it for web browsing in any internet explorer as normal web address and it`s it, Enjoy using this small application.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=45853&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
