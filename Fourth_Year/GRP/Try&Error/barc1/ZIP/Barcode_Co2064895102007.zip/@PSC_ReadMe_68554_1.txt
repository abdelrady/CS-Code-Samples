Title: Barcode Code128 Generator without using fonts
Description: A barcode generator. Right now only accepts a subset of Code128B (A-Z &amp; 0-9) but can print all that is required by the Code128 check character.
Output is verified correct using my Argox barcode scanner.
If you want to test it, do a print screen and paste the generated barcode into MS Word. Then print using Word's "High Quality" print setting
Doesn't use any barcode fonts, just the Line statement.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=68554&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
