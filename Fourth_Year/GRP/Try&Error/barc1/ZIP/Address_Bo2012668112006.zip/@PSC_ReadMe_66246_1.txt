Title: Address Book/Barcode/Print Preview
Description: Address book using MS access and ability to generate barcode and print preview it. Printing is just for sample. Ability to import Excel file and write it to access database. Ability to go into any access database. don't know what to describe, it's just an address book that need to capture data from excel and generate barcode for each of the name inside the database.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66246&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
