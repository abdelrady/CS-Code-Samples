Title: USB Data Reader
Description: Reads i any USB drive is attached to the system.
Displays the attached USB drive information and lists down the files that are located on the drive. This could further be extended to include all the files and folders on the drive but at the moment the sample is limited to showing only the files on the root level.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=6108&lngWId=10

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
