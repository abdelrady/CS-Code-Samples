Title: Dining Hall Attendance System
Description: It's an application to help record students' dining hall attendance..can also be used with a barcode scanner..just a simple one..but nice. Uses Access as its database..erm, just lotsa basic database operations. Should be a good jump start for beginners. Cheers!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56371&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
