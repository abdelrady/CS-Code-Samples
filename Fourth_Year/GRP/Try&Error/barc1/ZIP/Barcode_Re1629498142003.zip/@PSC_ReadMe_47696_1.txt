Title: Barcode Reader/Scanner ...
Description: Read or Scan Barcodes with this few line of codes.. No (API/OCX/DLL) required ...
This works well with barcode scanner/reader connected to serial comm1 port, it supports Code 39/128/UPC/EAN/etc... dnt know much about this terms :))
No need for votes.. I just post this for refference, i hope this could help you, especially those who code in a POS related business..
Note: 
Doenst work with some barcode reader/scanner, check your mannual/driver for other type of reader/scanner.. :D
For comments/questions/suggestions email @ richard_2k03@yahoo.com

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=47696&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
