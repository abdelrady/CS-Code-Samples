Title: Library Circlulation
Description: This code is the beginning of a library circulation program. Two of my freinds and I woked on this. It doesn;t have many of the feature implemented, but Take a look, show different was of accessing databases. 
Login:David Smith
Pass:98022
The Use Administration >Books to get barcode numbers
And use Administration > Patrons to get patron Numbers
Then Use Signout.
Try double clicking on a book
Please send any comments to the feedback or daveismith@hotmail.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=13801&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
