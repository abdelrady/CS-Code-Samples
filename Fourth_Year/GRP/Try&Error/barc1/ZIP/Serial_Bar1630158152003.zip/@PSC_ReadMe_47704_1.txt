Title: Serial Barcode Reader
Description: This project allows you to get a barcode from a serial barcode reader and put it into your applications, or another application using sendkeys. It uses the MSComm control and the OnComm event to read each individual character passed to the serial port, it detects the finished barcode from the carriage return sent by the barcode reader. This could be useful in epos programs or just to get data from the serial port.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=47704&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
