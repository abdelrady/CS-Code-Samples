Title: caver daves 3 of 9 Barcode Creator
Description: Title:- 3 of 9 Barcode Creator
Very simple custom barcode generator using a free barcde font ( free 3 of 9 extended) included in the zip file.
Allows you to create the barcode and see what you have done then resize the viewport to better fit the barcode then preview and save the barcode in bitmap format, ready to use in most graphics programs.
Place the font after extracting it from the zip file in the windows font folder
Credits:
Initial barcode code from vb.general.discussion newsgroup posting
Bend this code break it use it how ever you will but if you do use it please vote and
leave a comment
regards caver dave
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=69137&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
