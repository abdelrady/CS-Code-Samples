using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Threading;

namespace Serial_Demo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox rtfTerminal;
		private System.Windows.Forms.Button btn_dial;
		
		private AxMSCommLib.AxMSComm com;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox txt_phoneno;
		private System.Windows.Forms.Button btn_disconnect;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txt_sendmessage;
		private System.Windows.Forms.Button btn_sendmessage;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label Message;
		private System.Windows.Forms.Panel panel1;
		
		public Form1()
		{
			InitializeComponent();	
			// Initialize the COM Port control
			InitComPort();
		}

		
		private void InitComPort()
		{
			// Set the com port to be 1
			com.CommPort = 1;
    
			// This port is already open, then close.
			if (com.PortOpen) 
			com.PortOpen=false;
			    
			// Trigger the OnComm event whenever data is received
			com.RThreshold = 1;  
    
			// Set the port to 9600 baud, no parity bit, 8 data bits, 1 stop bit (all standard)
			com.Settings = "9600,n,8,1";

			// Force the DTR line high, used sometimes to hang up modems
			//com.DTREnable = true;

			com.RTSEnable=true;
    
			// No handshaking is used
			com.Handshaking = MSCommLib.HandshakeConstants.comNone;

			// Use this line instead for byte array input, best for most communications
			com.InputMode = MSCommLib.InputModeConstants.comInputModeText;
    
			// Read the entire waiting data when com.Input is used
			com.InputLen = 0;

			// Don't discard nulls, 0x00 is a useful byte
			com.NullDiscard = false;
    
			// Attach the event handler
			com.OnComm += new System.EventHandler(this.OnComm);

			com.PortOpen = true;  
		}

		private void OnComm(object sender, EventArgs e)  //  MSCommLib OnComm Event Handler
		{
			
			// Wait for Some mili-seconds then process 
			// The response.

			Thread.Sleep(200);

			if (com.InBufferCount > 0) 
			{
				try
				{
					// If you want to receive data in Binary mode
					// Remove below 2 comment lines
					// And comment lines for Process response in 
					// Text mode.

					//byte[] b1=(byte[])com.Input;
					//ProcessResponseBinary(b1);

					// Process response in Text mode.
					string response=(string)com.Input;
					ProcessResponseText(response);
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.Message, this.Text,
						MessageBoxButtons.OK,MessageBoxIcon.Information);
				}
			}
		}

		// If you receive binary data as response.
		private void ProcessResponseBinary(byte[] response)
		{
			for(int i=0; i< response.Length; i++)
			{
				rtfTerminal.AppendText(response[i].ToString() + " ");
			}
			rtfTerminal.AppendText("\n");
			
		}

		// If you receive Text data as response
		private void ProcessResponseText(string input)
		{
			// Send incoming data to a Rich Text Box

			if( input.Trim().Equals("RING"))
			{
				Message.Text="Ring...";
			}
			else
			if( input.Trim().Equals("CONNECT 9600"))
			{
				MessageBox.Show(input.Trim(), this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Information);
			}
			else
			{
				MessageBox.Show(input.Trim(), this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Information);
				Message.Text=input.Trim();
			}

			// Append output response to RichText Box
			rtfTerminal.AppendText(input + "\n");
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.rtfTerminal = new System.Windows.Forms.RichTextBox();
			this.btn_dial = new System.Windows.Forms.Button();
			this.com = new AxMSCommLib.AxMSComm();
			this.label6 = new System.Windows.Forms.Label();
			this.txt_phoneno = new System.Windows.Forms.TextBox();
			this.btn_disconnect = new System.Windows.Forms.Button();
			this.Message = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.txt_sendmessage = new System.Windows.Forms.TextBox();
			this.btn_sendmessage = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.com)).BeginInit();
			this.panel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// rtfTerminal
			// 
			this.rtfTerminal.Location = new System.Drawing.Point(0, 136);
			this.rtfTerminal.Name = "rtfTerminal";
			this.rtfTerminal.Size = new System.Drawing.Size(280, 112);
			this.rtfTerminal.TabIndex = 1;
			this.rtfTerminal.Text = "";
			// 
			// btn_dial
			// 
			this.btn_dial.Location = new System.Drawing.Point(8, 72);
			this.btn_dial.Name = "btn_dial";
			this.btn_dial.TabIndex = 8;
			this.btn_dial.Text = "Dial";
			this.btn_dial.Click += new System.EventHandler(this.btn_dial_Click);
			// 
			// com
			// 
			this.com.Enabled = true;
			this.com.Location = new System.Drawing.Point(160, 104);
			this.com.Name = "com";
			this.com.Size = new System.Drawing.Size(38, 38);
			this.com.TabIndex = 14;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.ForeColor = System.Drawing.SystemColors.Highlight;
			this.label6.Location = new System.Drawing.Point(8, 8);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(64, 23);
			this.label6.TabIndex = 15;
			this.label6.Text = "GSM No:";
			// 
			// txt_phoneno
			// 
			this.txt_phoneno.Location = new System.Drawing.Point(88, 8);
			this.txt_phoneno.Name = "txt_phoneno";
			this.txt_phoneno.Size = new System.Drawing.Size(168, 20);
			this.txt_phoneno.TabIndex = 16;
			this.txt_phoneno.Text = "";
			// 
			// btn_disconnect
			// 
			this.btn_disconnect.Location = new System.Drawing.Point(184, 72);
			this.btn_disconnect.Name = "btn_disconnect";
			this.btn_disconnect.TabIndex = 17;
			this.btn_disconnect.Text = "Disconnect";
			this.btn_disconnect.Click += new System.EventHandler(this.btn_disconnect_Click);
			// 
			// Message
			// 
			this.Message.BackColor = System.Drawing.Color.Transparent;
			this.Message.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Message.ForeColor = System.Drawing.Color.MidnightBlue;
			this.Message.Location = new System.Drawing.Point(0, 248);
			this.Message.Name = "Message";
			this.Message.Size = new System.Drawing.Size(280, 23);
			this.Message.TabIndex = 18;
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.ForeColor = System.Drawing.SystemColors.Highlight;
			this.label7.Location = new System.Drawing.Point(8, 40);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(72, 32);
			this.label7.TabIndex = 19;
			this.label7.Text = "Message:";
			// 
			// txt_sendmessage
			// 
			this.txt_sendmessage.Location = new System.Drawing.Point(88, 40);
			this.txt_sendmessage.Name = "txt_sendmessage";
			this.txt_sendmessage.Size = new System.Drawing.Size(168, 20);
			this.txt_sendmessage.TabIndex = 20;
			this.txt_sendmessage.Text = "";
			// 
			// btn_sendmessage
			// 
			this.btn_sendmessage.Location = new System.Drawing.Point(96, 72);
			this.btn_sendmessage.Name = "btn_sendmessage";
			this.btn_sendmessage.TabIndex = 21;
			this.btn_sendmessage.Text = "Send";
			this.btn_sendmessage.Click += new System.EventHandler(this.btn_sendmessage_Click);
			// 
			// label8
			// 
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.ForeColor = System.Drawing.SystemColors.Highlight;
			this.label8.Location = new System.Drawing.Point(0, 112);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(160, 24);
			this.label8.TabIndex = 22;
			this.label8.Text = "Received messages:";
			// 
			// panel1
			// 
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.btn_dial);
			this.panel1.Controls.Add(this.btn_disconnect);
			this.panel1.Controls.Add(this.txt_phoneno);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.txt_sendmessage);
			this.panel1.Controls.Add(this.btn_sendmessage);
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(280, 104);
			this.panel1.TabIndex = 23;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(280, 269);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.rtfTerminal);
			this.Controls.Add(this.com);
			this.Controls.Add(this.Message);
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Serial Demo";
			((System.ComponentModel.ISupportInitialize)(this.com)).EndInit();
			this.panel1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btn_dial_Click(object sender, System.EventArgs e)
		{
			
			if( txt_phoneno.Text.Trim().Equals(""))
			{
				MessageBox.Show("Please Specify Phone Number", this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Information);
				txt_phoneno.Focus();
				return;
			}
		
			if(! com.PortOpen )
				com.PortOpen=true;

			// GSM Command Dial a Modem
			// ATD<phonenumber>\n

			string gsm_command="ATD";				
			string phone_number=txt_phoneno.Text.Trim();
			string command1=gsm_command + phone_number + "\n";
			byte[] command_to_dial=System.Text.ASCIIEncoding.Default.GetBytes(command1);
			com.Output=command_to_dial;	

			Message.Text="Dialing...";
						
		}

		private void btn_disconnect_Click(object sender, System.EventArgs e)
		{
			// If com port is open then close it 
			// to disconnect connection

			if( com.PortOpen )
			{
				com.PortOpen=false;
				MessageBox.Show("Disconnected...", this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Information);
				Message.Text="";
				rtfTerminal.Text="";
			}
		}

		private void btn_sendmessage_Click(object sender, System.EventArgs e)
		{
		
			string msg="";

			if( txt_sendmessage.Text.Trim().Equals(""))
			{
				MessageBox.Show("Please Specify Command", this.Text,
					MessageBoxButtons.OK,MessageBoxIcon.Information);
				txt_sendmessage.Focus();
				return;
			}

			if(! com.PortOpen )
				com.PortOpen=true;

			// To send text messages 

			// If you are using GSM Modem and you want to send
			// Command then use GetByes of your message
			// To send Byte data from com port
			
			msg=txt_sendmessage.Text.Trim() + "\n";
			com.Output = System.Text.ASCIIEncoding.Default.GetBytes(msg);
			
			// Or Else If systems are connected with Serial 
			// Cable, Output simple text directly
			// com.Output= txt_sendmessage.Text;

			Message.Text="Message Sent....";
		}
	
	}
}
