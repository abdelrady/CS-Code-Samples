//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by VideoNet.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VIDEONET_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       129
#define IDD_DIALOG1                     130
#define IDD_DIALOG2                     133
#define IDD_DIALOG3                     135
#define IDC_BUTTON1                     1000
#define IDC_EDIT1                       1001
#define IDC_MESG                        1002
#define IDC_LIST1                       1003
#define IDREJECT                        1004
#define IDC_LOCALVIDEO                  1005
#define IDC_REMOTEVIDEO                 1006
#define IDC_LOCALBORDER                 1007
#define IDC_REMOTEBORDER                1008
#define IDC_SLIDER1                     1009
#define IDC_SLIDER2                     1010
#define ID_CONFERENCE_CONNECT           32771
#define CONF_CONNECT                    32772
#define CONF_DISCONNECT                 32773
#define CONF_EXIT                       32774
#define VIEW_LOCAL                      32775
#define VIEW_REMOTE                     32776
#define HELP_ABOUT                      32777
#define AUDIO_CONTROL                   32778
#define AUDIO_SEND                      32779
#define AUDIO_RECEIVE                   32781
#define VIDEO_SEND                      32782
#define VIDEO_RECEIVE                   32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
