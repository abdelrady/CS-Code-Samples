Techniques demonstrated in this project
---------------------------------------
-Using the MCIWnd Class from VB
-Creating a window based on a Win32 Class
-A demo of controlling AVI files 
-Can be applied to ANY MCI device (MPG, MOV, CD-Audio, etc...)



Useful (or just interesting) functions in mKidnap.bas
--------------------------------
MCIWndRegisterClass (Win32 API)
CreateWindowEx (Win32 API)



You may freely use and modify the source code contained in this 
product.  You may also freely distribute any application that uses this 
sample code or derivations thereof.  However, you may not redistribute 
any part of this archive or in any way derive financial gain from 
this sample without the express permission of it's author - Ray Mercer 
<raymer@shrinkwrapvb.com>

Use this product at your own risk!

Please see the licensing and distribution section of the Shrinkwrap
Visual Basic website for more information.

Copyright (c) 1998-2000, Ray Mercer all rights reserved

Another exclusive free product from Shrinkwrap Visual Basic(tm)!
http://www.shrinkwrapvb.com