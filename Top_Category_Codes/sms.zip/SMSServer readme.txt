www.smsdriver.com
Made by Agile Telecom Srl
Made using VB 6.0 of Microsoft
Double click smsserver.vbp


