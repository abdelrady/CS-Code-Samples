function checkForm(formName)
{
  errors="";
  d=document.forms[formName];
  for(i=0; i<d.elements.length; i++)
  {
    if(d.elements[i].value==""){errors+="- No "+d.elements[i].name+" was Entered\n";}
  }
  if(errors!="")
  {
    alert("The Following Errors Occurred:\n"+errors);
    return false;
  }
  return true;
}

function setErrorMsg(err)
{
  document.all.forms[0].theError.value=err;
}