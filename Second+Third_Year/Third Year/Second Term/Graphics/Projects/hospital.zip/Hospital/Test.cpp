//#include <iostream.h>
#include <conio.h>
#include "RFS.h"
#include "Patient.h"

/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
//              Functions header
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
void CleanScreen(void);
int  ShowMenu(void);
bool AddPatient(RFS * Hospital);
bool RemovePatient(RFS * Hospital);
bool UpdatePatient(RFS * Hospital);
bool SearchForPatient(RFS * Hospital);
bool SearchForPatientId(RFS * Hospital);

//bool Sort(RFS * Hospital);
char againYON();
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
void main (void)
{
	RFS Hospital(sizeof(Patient),"Hospital.db");
	  
	char again;  //a flag to indicate do selected option again
	int choice;  //user selected option
	bool exit=false;  // falg to terminate excution
	while(true) //loop forever
	{
		CleanScreen();
		choice=ShowMenu(); //show menu and get user option
		switch(choice)  //handling user input
		{
		case 1: // Adding a new Patient to the Hospital
			again='Y';
			while(again=='Y') //loop as user wants to continue
			{
				if(AddPatient(&Hospital))
				{
					cout<<"a New Patient has been successfuly added\n";
					cout<<"Do you want to add another (y/n)?";
					again=againYON();
				}
				else //failed to add a Patient to library
				{
					again='N';
					cout<<"couldn't add a New Patient\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;
		case 2: //remove a Patient from the Hospital
			again='Y';
			while(again=='Y')
			{
				if(RemovePatient(&Hospital))
				{
					cout<<"a Patient has been successfuly removed\n";
					cout<<"Do you want to remove another (y/n)?";
					again=againYON();
				}
				else // failed to remove a Patient from Hospital
				{
					again='N';
					cout<<"couldn't remove a Patient\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;
		case 3:  // modify Patient data
			again='Y';
			while(again=='Y')
			{
				if(UpdatePatient(&Hospital))
				{
					cout<<"a Patient has been successfuly modified\n";
					cout<<"Do you want to modify another (y/n)?";
					again=againYON();
				}
				else  // failed to modify Patient data
				{
					again='N';
					cout<<"couldn't modify a Patient\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;
		case 4: // search for a Patient by name(the first matched will be displayed)
			again='Y';
			while(again=='Y')
			{
				if(SearchForPatient(&Hospital))
				{
					cout<<"Do you want to search for another (y/n)?";
					again=againYON();
				}
				else // failed to find a matching Patient name
				{
					again='N';
					cout<<"couldn't find specified Patient\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;/*
		case 5: // Sort Patient according to a certain subject results and display Patients data
			again='Y';
			while(again=='Y')
			{
				if(Sort(&Hospital))
				{
					cout<<"Do you want to do another Sort (y/n)?";
					again=againYON();
				}
				else // failed to sort Patients
				{
					again='N';
					cout<<"couldn't do Sort\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;*/
			case 7: // search for a Patient by name(the first matched will be displayed)
			again='Y';
			while(again=='Y')
			{
				if(SearchForPatientId(&Hospital))
				{
					cout<<"Do you want to search for another (y/n)?";
					again=againYON();
				}
				else // failed to find a matching Patient name
				{
					again='N';
					cout<<"couldn't find specified Patient\n";
					cout<<"Press any key to continue";
					_getch();
				}
			}
			break;
		case 6: // terminate excution
			exit=true; //set exit falg
			break;
		}
		// break infinite loop to terminate excution
		if(exit)
			break;
		
	}
	
}
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
char againYON()
{
	char again=0;
	while((again!='Y')&&(again!='N'))
	{
		again=_getch();
		again=toupper(again);
	}
	return again;
}
