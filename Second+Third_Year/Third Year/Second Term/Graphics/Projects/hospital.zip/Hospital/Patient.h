 // Patient.h: interface for the CPatient class.
//
//////////////////////////////////////////////////////////////////////
#if !defined PatientInclude
#define PatientInclude
#include "RFS.h"

 
struct Person
{
	
	char PersonName[100];
	char PersonAddress[100];
	char PersonTelNumber[15];
	bool LazyDelete;
	float PersonAge;
	long PersonId;
	enum PersonGender{male,female};
	IsActive()
	{
		LazyDelete=true;
	}


	 
};
struct Status
{
	char BloodPreasure[50];
	int TempretureDegree;

	int Palse ;
	char  RespRate[50];
};

class Patient : public Record 
{
public:
	Person PersonPatient;

	enum PatientDeparment{eyes,women};
	char PatientEnteranceDate[100];
	Status PatientStatus;
	//Account PatientAccount;
	int PatientRoomNumber;
	bool PatientLazyDelete;
public: 
	Patient();
	virtual ~Patient();
};

#endif 
