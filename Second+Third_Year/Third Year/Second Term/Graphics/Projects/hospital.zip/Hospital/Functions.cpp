//#include <iostream>
//#include <conio.h>
#include "RFS.h"
#include "Patient.h"


/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
//              Clean Screen Function
// print an empty 25 lines
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
void CleanScreen(void)
{
	cin.ignore();
	cout.flush();
	for(int i=0;i<25;i++)
		cout<<endl;
}
bool SearchForId(RFS * Hospital,long number);
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
//              Show Menu Function
// print the menu options and get user input
// return user input to calling function for processing
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\*/
int ShowMenu(void)
{
	int choice;
	cout<<"\t\t\t\t MainMenu\n\n";
	cout<<"\t\t\t   (1) Add New Patient.\n";
	cout<<"\t\t\t   (2) Remove Patient.\n";
	cout<<"\t\t\t   (3) Update Patient Data.\n";
	cout<<"\t\t\t   (4) Search for a Patient.\n";
	//cout<<"\t\t\t   (5) Sort by Subject Results.\n";
	cout<<"\t\t\t   (6) Exit.\n\n";
	cout<<"\t\t\t   (7) Search for a Patient by ID.\n";
	cout<<"\t\t   Enter your choice (1...7) : ";
	cin>>choice;
	return choice;
}
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/
//              Add New Patient Function
// getting new Patient data and add the new Patient to Hospital
/*/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/*/
bool AddPatient(RFS * Hospital)
{
    
	Patient NewPatient;
	CleanScreen();
	cout<<"\t\t\tAdding New Patient\n\n";
	 //cout<<"Patient Number : ";
	 bool s=true;
	long number;	
	while(s)
	{
	cout<<"Patient Number : ";

	cin>>number  ;cin.ignore();
	s=SearchForId(Hospital,number); 
	}
	NewPatient.PersonPatient .PersonId=number;
	//cin>>NewPatient.PersonPatient.PersonId; cin.ignore();
	cout<<"Patient Name : ";
	

	cin.getline(NewPatient.PersonPatient.PersonName,100);
	cout<<"enter person age";
	cin>>NewPatient.PersonPatient.PersonAge; cin.ignore();

	 
	return(Hospital->put(&NewPatient)); //append new Patient to Hospital
}
/*
/*
//              Remove Patient Function
// remove Patient from Hospital.
// this function removes the first occurence of the Patient number
/**/
bool RemovePatient(RFS * Hospital)
{
	Patient NewPatient;
	unsigned int number,i;
	CleanScreen();
	cout<<"\t\t\tRemove Patient\n\n";
	cout<<"Enter Patient Nnumber to be removed : ";
	cin>>number;  //get Patient number
	i=0;
	if(!Hospital->get(&NewPatient,i++))
		return false;
	//loop if not inteded Patient or Patient is deleted
	while((number!=NewPatient.PersonPatient.PersonId)||(!NewPatient.isActive()))
	{
		if(!Hospital->get(&NewPatient,i++))
			return false;
	}
	// at this point the CPatient object holds the inteded Patient
	// otherwise if the Patient isn't exist the function fails
	return(Hospital->del(&NewPatient)); //now remove the Patient from Hospital
}
/*/ 
*/
//              Update Patient Function
// Update Patient data.the function displays old data
// and asks for new one. then it updates the data

bool UpdatePatient(RFS * Hospital)
{
	Patient NewPatient;
	unsigned int number,location;
	CleanScreen();
	cout<<"\t\t\tUpdateing Patient\n\n";
	cout<<"Enter Patient Nnumber to be modified : ";
	cin>>number; //get Patient number to be modified
	location=0;
	if(!Hospital->get(&NewPatient,location++))
		return false;
	//loop if not inteded Patient or Patient is deleted
	while((number!=NewPatient.PersonPatient.PersonId)||(!NewPatient.isActive()))
	{
		if(!Hospital->get(&NewPatient,location++))
			return false;
	}
	location--;
	// the CPatient object holds the intended Patient to be modified
	cout<<"Old Number : "<<NewPatient.PersonPatient.PersonId<<endl;
	cout<<"New Number : ";
	cin>>NewPatient.PersonPatient.PersonId;
	cout<<"Old Patient Name : "<<NewPatient.PersonPatient.PersonName<<endl;
	cout<<"New Patient Name and then press $ : ";
	cout.flush();
	cout.flush();
	cout.flush();
	cout.flush();
	cout.flush();

	 
	

	cin.get(NewPatient.PersonPatient.PersonName,100,'$');
	cout.flush();
	cout.flush();
	cout.flush();

	cout<<"hello";
	
	return(Hospital->put(&NewPatient,location));// update Patient data
}
/*/ 
//              Search for Patient Function
// search for the first matched Patient name and displays its data
/*/ 
bool SearchForPatient(RFS * Hospital)
{
	Patient NewPatient;
	unsigned int location;
	char name[100];
	CleanScreen();
	cout<<"\t\t\tSearch for Patient\n\n";
	cout<<"Enter Patient Name to Search for : ";
	cin.getline(name,100);
	location=0;
	if(!Hospital->get(&NewPatient,location++))
		return false;
	//loop if not inteded Patient or Patient is deleted
	while((strcmp(name,NewPatient.PersonPatient.PersonName))||(!NewPatient.PersonPatient.IsActive()))

	{
		if(!Hospital->get(&NewPatient,location++))
			return false;
	}
	location--;
	// CPatient object holds inteded Patient
	// display Patient data on screen
	cout<<"Patient Number : "<<NewPatient.PersonPatient.PersonId<<endl;
	cout<<"Patient Name : "<<NewPatient.PersonPatient.PersonName<<endl;
	 return true;
}

bool SearchForPatientId(RFS * Hospital)
{
	Patient NewPatient;
	unsigned int location;
	long number;
	CleanScreen();
	cout<<"\t\t\tSearch for Patient by ID\n\n";
	cout<<"Enter Patient ID to Search for : ";
	cin>>number;

	location=0;
	if(!Hospital->get(&NewPatient,location++))
		return false;
	//loop if not inteded Patient or Patient is deleted
	while(((NewPatient.PersonPatient.PersonId !=number))||(!NewPatient.PersonPatient.IsActive()))

	{
		if(!Hospital->get(&NewPatient,location++))
			return false;
	}
	location--;
	// CPatient object holds inteded Patient
	// display Patient data on screen
	cout<<"Patient Number : "<<NewPatient.PersonPatient.PersonId<<endl;
	cout<<"Patient Name : "<<NewPatient.PersonPatient.PersonName<<endl;
	 return true;
}
/*
/*/ 
//		             Sort Function
// sort Patients according to their results in a specified subject
// sorting is done using bubble sort (the most easy algorithm)
// Note: deleted records (Patients) will be moved to the end of file
/* 
bool Sort(RFS * Hospital)
{
	CPatient Patient1,Patient2;
	unsigned int Subject,Loc1,Loc2;
	unsigned int NRecords;
	CleanScreen();
	cout<<"\t\t\t\tSort\n\n";
	cout<<"Enter Subject Number to sort according to : ";
	cin>>Subject;
	Subject--;
	NRecords=Hospital->GetNumberOfRecords();
	cout<<"Sorting ...\n";
	for(Loc1=0;Loc1<NRecords-1;Loc1++)
	{
		
		for(Loc2=Loc1+1;Loc2<NRecords;Loc2++)
		{
			if(!Hospital->get(&Patient1,Loc1))  return false;
			if(!Hospital->get(&Patient2,Loc2))	return false;
			if(!Patient2.isActive())	continue;
			if((!Patient1.isActive())||(Patient2.m_SubjectGrade[Subject]>Patient1.m_SubjectGrade[Subject]))
			{
				Hospital->put(&Patient2,Loc1);
				Hospital->put(&Patient1,Loc2);
			}
		}
	}
	cout<<"Sroting completed.\n";
	Loc1=0;
	while((Hospital->get(&Patient1,Loc1++))&&(Patient1.isActive()))
	{
		cout<<"Patient Number : "<<Patient1.m_Number;
		cout<<"\t\tPatient Name : "<<Patient1.m_Name<<endl;
		cout<<"\t\t\t% Grade of Subjects\n";
		for(Subject=0;Subject<10;Subject++)
			cout<<" # "<<Subject+1<< "\t";
		cout<<endl;
		for(Subject=0;Subject<10;Subject++)
			cout<<Patient1.m_SubjectGrade[Subject]<<"\t";
		cout<<endl;
		cout.flush();
		cout.width(5);
	}
	return true;
}*/


bool SearchForId(RFS * Hospital,long number)
{
	Patient NewPatient;
	unsigned int location;
	 
	 
	location=0;
	if(!Hospital->get(&NewPatient,location++))
		return false;
	//loop if not inteded Patient or Patient is deleted
	while(((NewPatient.PersonPatient.PersonId !=number))||(!NewPatient.PersonPatient.IsActive()))

	{
		if(!Hospital->get(&NewPatient,location++))
			return false;
	}
	location--;
	  return true;
}