#include"Ccom.h"
//=========================================================
Ccom::Ccom()
{
	strcpy(m_comname,"");
	strcpy(m_headname,"");
	m_phonenum=0;
	m_mobilenum=0;
	strcpy(m_address,"");

}

Ccom::~Ccom()
{

}
