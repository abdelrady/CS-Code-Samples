import javax.swing.*;
import java.awt.*;

public class pop 
{  
public static void main(String args[])
{
	int z=0;
	int y;
	char c;
	char t='p';
	String k;
	String pl="";
	String f="";
	String  s="";
	String h="";
    String arr[]=new String[36];
		arr[0]="*-";
		arr[1]="-***";
		arr[2]="-*-*";
		arr[3]="-**";
		arr[4]="*";
		arr[5]="**-*";
		arr[6]="--*";
		arr[7]="****";
		arr[8]="**";
		arr[9]="*---";
		arr[10]="-*-";
		arr[11]="*-**";
		arr[12]="--";
		arr[13]="-*";
		arr[14]="---";
		arr[15]="******";
		arr[16]="--*-";
		arr[17]="*-*";
		arr[18]="***";
		arr[19]="-";
		arr[20]="**-";
		arr[21]="***-";
		arr[22]="*--";
		arr[23]="-**-";
		arr[24]="-*--";
		arr[25]="--**";
		arr[26]="*----";
		arr[27]="**---";
		arr[28]="***--"; 
		arr[29]="****-";
		arr[30]="*****";
		arr[31]="-****";
		arr[32]="--***";
		arr[33]="---**";
		arr[34]="----*";
		arr[35]="-----";
		char asd[]=new char[36];
		asd[0]='a';
		asd[1]='b';
		asd[2]='c';
		asd[3]='d';
		asd[4]='e';
		asd[5]='f';
		asd[6]='g';
		asd[7]='h';
		asd[8]='i';
		asd[9]='j';
		asd[10]='k';
		asd[11]='l';
		asd[12]='m';
		asd[13]='n';
		asd[14]='o';
		asd[15]='p';
		asd[16]='q';
		asd[17]='r';
		asd[18]='s';
		asd[19]='t';
		asd[20]='u';
		asd[21]='v';
		asd[22]='w';
		asd[23]='x';
		asd[24]='y';
		asd[25]='z';
		asd[26]='1';
		asd[27]='2';
		asd[28]='3';
		asd[29]='4';
		asd[30]='5';
		asd[31]='6';
		asd[32]='7';
		asd[33]='8';
		asd[34]='9';
		asd[35]='0';
	int x=0;
	while(t!='n')
	{
		k=JOptionPane.showInputDialog("enter 1 for alphapitical mode \n enter 2 for moris mode"); 	
	x=Integer.parseInt(k);
	if(x==1)
	{
		s=JOptionPane.showInputDialog("enter the character");
		 y=s.length();
		for(int i=0;i<y;i++)
		{    c=s.charAt(i);
			for(int r=0;r<36;r++)
			{   
				if(c==asd[r])
				{f+=arr[r];
				f+="   ";
			    }
		     }
		    if (c==' ')
		    {
			    f+='#';
			    f+=' ';
			   }
	   }
    
    JOptionPane.showMessageDialog(null,f);
    f="";
    }
    else
    {
    	s=JOptionPane.showInputDialog("enter the character");
    	s+=' ';
		y=s.length();
		for(int i=0;i<y;i++)
		{  
		if(s.charAt(i) !=' ')
			{
				h+=s.charAt(i);
			    z=0;
		     }
		
		  else
		  {
		  z++;
		     if(z>2)
		      f+=' ';
		     else if(z==1);
			{
			for(int o=0;o<36;o++)
			{
			if(h.compareTo(arr[o])==0)
			 f+=asd[o];
			 }
			 h="";
             }
          }
        }
        JOptionPane.showMessageDialog(null,f);
        f="";
    }
    pl=JOptionPane.showInputDialog("do you want to do it again");
    t=pl.charAt(0);
}

System.exit(0);
}
}
             

    