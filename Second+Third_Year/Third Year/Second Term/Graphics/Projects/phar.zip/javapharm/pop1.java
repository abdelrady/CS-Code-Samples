import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class pop1 extends JFrame
{
	JPanel gh=new JPanel(); 
	JPanel gh1=new JPanel();
	JLabel joj=new JLabel("");
	Icon fahad1=new ImageIcon("fa1.gif");
	JLabel he,mc,cm;
	texthandler handler=new texthandler(); 
	JTextField t1,t2;
	public static String arr[];
	public static char asd[];
	JRadioButton b3;
	public pop1()
	{
		super("Fahad morse program");
		gh.setLayout(new GridLayout(1,4));
		Container cont=getContentPane();
		cont.setLayout(new GridLayout(4,4));
		joj.setIcon(fahad1);
		he=new JLabel("Fahad Morse Program");
		he.setForeground(Color.yellow);
		he.setToolTipText("Wellcome in fahad program");
		mc=new JLabel(" Enter the morse code here");
		mc.setToolTipText("Enter the morse code here");
		cm=new JLabel(" Enter the alphabitical code here");
		cm.setToolTipText("Enter the alphabitical code here");
		he.setFont(new Font("fahad",Font.BOLD,35));
		t1=new JTextField();
		cm.setFont(new Font("fahad",Font.BOLD,20));
		mc.setFont(new Font("fahad",Font.BOLD,20));
		mc.setForeground(Color.cyan);
		cm.setForeground(Color.cyan);
		t1.setFont(new Font("lol",Font.BOLD,19));
		t2=new JTextField();
		t2.setFont(new Font("lol",Font.BOLD,19));
		b3=new JRadioButton("Close");
		b3.setToolTipText("Prees to close the application");
		gh.add(b3);
	
		b3.addActionListener(handler);
		t1.addActionListener(handler);
		t2.addActionListener(handler);	
		b3.setBackground(Color.black);
		b3.setFont(new Font("lol",Font.BOLD,14));
		b3.setForeground(Color.white);
		gh1.setLayout(new GridLayout(1,2));
		gh1.add(joj);
		
		gh1.setBackground(Color.black);
		cont.add(gh1);
		cont.add(he);
		cont.add(mc);
	    cont.add(t2);
		cont.add(cm);
		cont.add(t1);
		cont.add(gh);
		gh.setBackground(Color.black);
		
		
    	cont.setBackground(Color.black);
        setSize(600,600);  
		setVisible(true);
	}
	///////////////////////////////////////////////////////////
	public static void main(String args[])
    {
    	pop1 fahad=new pop1();
    	fahad.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    ///////////////////////////////////////////////////////////
     public  class texthandler  implements ActionListener
		{
		
		char c;
		int y=0;
		int z=0;
			public void actionPerformed(ActionEvent event)
			{
				String arr[]=new String[36];
		arr[0]="*-";
		arr[1]="-***";
		arr[2]="-*-*";
		arr[3]="-**";
		arr[4]="*";
		arr[5]="**-*";
		arr[6]="--*";
		arr[7]="****";
		arr[8]="**";
		arr[9]="*---";
		arr[10]="-*-";
		arr[11]="*-**";
		arr[12]="--";
		arr[13]="-*";
		arr[14]="---";
		arr[15]="******";
		arr[16]="--*-";
		arr[17]="*-*";
		arr[18]="***";
		arr[19]="-";
		arr[20]="**-";
		arr[21]="***-";
		arr[22]="*--";
		arr[23]="-**-";
		arr[24]="-*--";
		arr[25]="--**";
		arr[26]="*----";
		arr[27]="**---";
		arr[28]="***--"; 
		arr[29]="****-";
		arr[30]="*****";
		arr[31]="-****";
		arr[32]="--***";
		arr[33]="---**";
		arr[34]="----*";
		arr[35]="-----";
	    char asd[]=new char[36];
		asd[0]='a';
		asd[1]='b';
		asd[2]='c';
		asd[3]='d';
		asd[4]='e';
		asd[5]='f';
		asd[6]='g';
		asd[7]='h';
		asd[8]='i';
		asd[9]='j';
		asd[10]='k';
		asd[11]='l';
		asd[12]='m';
		asd[13]='n';
		asd[14]='o';
		asd[15]='p';
		asd[16]='q';
		asd[17]='r';
		asd[18]='s';
		asd[19]='t';
		asd[20]='u';
		asd[21]='v';
		asd[22]='w';
		asd[23]='x';
		asd[24]='y';
		asd[25]='z';
		asd[26]='1';
		asd[27]='2';
		asd[28]='3';
		asd[29]='4';
		asd[30]='5';
		asd[31]='6';
		asd[32]='7';
		asd[33]='8';
		asd[34]='9';
		asd[35]='0';
		String s="";
		String h="";
		String f="";
	if(t1==event.getSource())	  
	     {
		      s=t1.getText();
		      y=s.length();
		for(int i=0;i<y;i++)
		{    c=s.charAt(i);
			for(int r=0;r<36;r++)
			{   
				if(c==asd[r])
				{f+=arr[r];
				f+=' ';
			    }
		     }
		    if (c==' ')
		    {
			    f+=' ';
			    f+=' ';
			    f+=' ';
			   }
		}
		t2.setText(f);
		if(f=="")
		JOptionPane.showMessageDialog(null,"Please Enter an Alphabitical code");
		f="";
	}
		else if(t2==event.getSource())
	{
		s=t2.getText();
		s+=' ';
		y=s.length();
		for(int i=0;i<y;i++)
		{  
		if(s.charAt(i) !=' ')
			{
				h+=s.charAt(i);
			    z=0;
		     }
		
		  else
		  {
		  z++;
		     if(z>2)
		     {h+=s.charAt(i);
		     h="";
		      f+=' ';
		  }
		     else if(z==1);
			{
			for(int o=0;o<36;o++)
			{
			if(h.compareTo(arr[o])==0)
			 f+=asd[o];
			 }
			 h="";
             }
          }
		}
		t1.setText(f);
		if(f=="")
		JOptionPane.showMessageDialog(null,"Please Enter a Morse code");
		f="";
	}
		else if(b3==event.getSource())
	    {
		System.exit(0);
	     }
	}
}
}