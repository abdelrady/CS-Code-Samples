

import java.util.*;

public class AlphaBetaPlayer extends CheckerPlayer implements CheckerBoardConstants {

	public AlphaBetaPlayer(String name){
		super(name);
	}

	public void calculateMove(int[][] bs, int whosTurn){

		// your code should go here

	}

}