/* Code example on page 323 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
   Shows how to imitate pass by name in C
   using function "thunks".
*/

#include <stdio.h>
int i,j;

int i_plus_j(void)
{ return i+j; }

int p(int (*y)(void))
{ int j = y();
  i++;
  return j+y();
}

void q(void)
{ j = 2;
  i = 0;
  printf("%d\n", p(i_plus_j));
}

main()
{ q();
  return 0;
}
