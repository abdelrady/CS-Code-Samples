/* Code of Figure 8.1, page 322 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>
int i;

int p(int y)
{ int j = y;
  i++;
  return j+y;
}

void q(void)
{ int j = 2;
  i = 0;
  printf("%d\n", p(i + j));
}

main()
{ q();
  return 0;
}
