-- Denotational semantics of the small language
-- example of Chapter 13 expressed in Haskell
-- as given in Section 13.3.7, pages 603-604 of
-- Kenneth C. Louden, Programming Languages
-- Principles and Practice 2nd Edition
-- Copyright (C) Brooks-Cole/ITP, 2003

data Expr = Val Int | Ident String | Plus Expr Expr 
                    | Minus Expr Expr | Times Expr Expr

-- Extra goodies to get correct compilation
-- of code from text
type Environment = [(String,Int)]

lookUp ((name,val):xs) a = if name == a then val
                           else lookUp xs a
-- end extra goodies

exprE :: Expr -> Environment -> Int
exprE (Plus e1 e2) env = (exprE e1 env) + (exprE e2 env)
exprE (Minus e1 e2) env = (exprE e1 env) - (exprE e2 env)
exprE (Times e1 e2) env = (exprE e1 env) * (exprE e2 env)
exprE (Val n) env = n

-- changed lookup to lookUp to avoid conflict
-- with standard lookup
exprE (Ident a) env = lookUp env a

