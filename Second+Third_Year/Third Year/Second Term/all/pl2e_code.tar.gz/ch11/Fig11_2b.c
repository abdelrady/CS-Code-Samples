/* Code of Figure 11.2(b), page 476 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int sum( int i, int j)
{ if (i > j) return 0;
  else return i + sum(i+1, j);
}

main()
{ int u, v, x;
  scanf("%d %d",&u,&v);
  x = sum(u,v);
  printf("%d\n",x);
  return 0;
}
