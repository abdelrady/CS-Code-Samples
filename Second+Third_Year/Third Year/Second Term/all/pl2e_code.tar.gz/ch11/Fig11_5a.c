/* Code of Figure 11.5(a), page 480 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int intArrayMax ( int a[], int size)
/* size must be > 0 */
{  int i, max = a[0];
   for (i = 1; i < size; i++)
      if (max < a[i]) max = a[i];
   return max;
}

main()
{ int a[] = {1,4,7,2,3,5};
  printf("%d\n",intArrayMax(a,6));
  return 0;
}
