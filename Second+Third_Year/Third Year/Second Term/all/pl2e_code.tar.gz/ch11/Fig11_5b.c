/* Code of Figure 11.5(b), page 481 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int intMax (int x, int y)
{ return x > y ? x : y;
}

int intArrayMax1 ( int a[], int size, int sofar )
{ if (size == 0) return sofar;
  else
    return intArrayMax1(a, size-1,intMax(sofar,a[size-1]));
}

int intArrayMax ( int a[], int size )
/* size must be > 0 */
{ return intArrayMax1(a,size-1,a[size-1]);
}

main()
{ int a[] = {1,4,7,2,3,5};
  printf("%d\n",intArrayMax(a,6));
  return 0;
}
