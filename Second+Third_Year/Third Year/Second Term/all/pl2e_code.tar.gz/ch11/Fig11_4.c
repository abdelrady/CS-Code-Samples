/* Code of Figure 11.4, page 477 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int sum1(int i, int j, int sumSoFar)
{ if (i > j) return sumSoFar;
  else
    return sum1(i+1,j,sumSoFar+i);
};

int sum(int i, int j)
{ return sum1(i,j,0);
}

main()
{ int u, v, x;
  scanf("%d %d",&u,&v);
  x = sum(u,v);
  printf("%d\n",x);
  return 0;
}
