/* Code of Figure 11.2(a), page 476 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int sum( int i, int j)
{ int k, temp;
  temp = 0;
  for(k = i; k <= j; k++)
    temp += k;
  return temp;
}

main()
{ int u, v, x;
  scanf("%d %d",&u,&v);
  x = sum(u,v);
  printf("%d\n",x);
  return 0;
}
