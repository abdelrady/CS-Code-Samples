/* Code of Figure 11.1(b), page 474 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int gcd ( int u,  int v)
{ if (v == 0) return u;
  else return gcd(v, u % v);
}

main()
{ int u, v, x;
  scanf("%d %d",&u,&v);
  x = gcd(u,v);
  printf("%d\n",x);
  return 0;
}
