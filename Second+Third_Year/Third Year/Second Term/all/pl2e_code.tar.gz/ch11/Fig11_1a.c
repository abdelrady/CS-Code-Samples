/* Code of Figure 11.1(a), page 474 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

void gcd ( int u, int v, int* x)
{ int y, t, z;
  z = u ; y = v;
  while (y != 0)
  { t = y;
    y = z % y;
    z = t;
  }
  *x = z;
}

main()
{ int u, v, x;
  scanf("%d %d",&u,&v);
  gcd(u,v,&x);
  printf("%d\n",x);
  return 0;
}
