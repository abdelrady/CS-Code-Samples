/* Code of Figure 5.14, page 148 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

struct
{ int a;
  char b;
  double c;
} x = {1,'a',2.5};

void p(void)
{ struct
  { double a;
    int b;
    char c;
  } y = {1.2,2,'b'};
  printf("%d, %c, %g\n",x.a,x.b,x.c);
  printf("%f, %d, %c\n",y.a,y.b,y.c);
}

main()
{ p();
  return 0;
}

