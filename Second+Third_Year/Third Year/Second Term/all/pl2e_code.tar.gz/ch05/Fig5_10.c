/* Code of Figure 5.10, pages 143-144 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int x = 1;
char y = 'a';

void p(void)
{ double x = 2.5;
  printf("%c\n",y);
  { int y[10];
  }
}

void q(void)
{ int y = 42;
  printf("%d\n",x);
  p();
}

main()
{ char x = 'b';
  q();
  return 0;
}
