/* Code of the alias example on page 176
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

class ArrTest
{ public static void main(String[] args)
  { int[] x = {1,2,3};
    int[] y = x;
    x[0] = 42;
    System.out.println(y[0]);
  }
}
