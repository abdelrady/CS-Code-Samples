/* Code of Figure 5.23, page 158 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

/* Adapted from Arnold, Gosling, and 
   Holmes [2000], p. 153 */
class A
{  A A(A A)
   {  A:
       for(;;)
       {  if (A.A(A) == A) break A; }
       return A;
   }
}
