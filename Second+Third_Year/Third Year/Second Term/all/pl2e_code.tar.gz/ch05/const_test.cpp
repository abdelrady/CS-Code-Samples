/* Code of the example on page 172,
   expanded to a runnable C++ (but not C)
   program.
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <iostream>
#include <ctime>

using namespace std;

const int a = 2;
const int b = 27+2*2;
const int c = (int) time(0); /* warning - illegal C code! */

int f( int x)
{ const int d = x+1;
  return b+c;
}

int main()
{ cout << f(2) << endl;
  return 0;
}
