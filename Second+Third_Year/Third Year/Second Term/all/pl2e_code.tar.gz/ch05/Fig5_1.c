/* Code of Figure 5.1, pages 134-135 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

int x;

void p(void)
{ char y;
  /* ... */
} /* p */

void q(void)
{ double z;
  /* ... */
} /* q */

main()
{ int w[10];
  /* ... */
}
