/* Code of Figure 5.28, page 173 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/
import java.util.Date;

class PrintDate
{  public static void main(String[] args)
   {  System.out.println(now);
   }
   static final Date now = new Date();
}
