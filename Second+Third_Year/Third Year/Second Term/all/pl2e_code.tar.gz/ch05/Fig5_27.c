/* Code of Figure 5.27, page 167 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

int p(void)
{ static int p_count = 0; 
	/* initialized only once - not each call! */
  p_count += 1;
  return p_count;
}

main()
{ int i;
  for (i = 0; i < 10; i++)
  { if (p() % 3) printf("%d\n",p());
  }
  return 0;
}

