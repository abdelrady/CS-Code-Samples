/* Code of C++ example on pages 137-138 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/
/* C++ example of class declaration similar	to previous 
   Java example */
class IntWithGcd 
{ 
public:
  /* local declaration of intValue function -	code for 
   intValue() is not provided */
  int intValue();  

  int gcd ( int v ); /* local declaration of gcd */

private:
  int value; /* local declaration of value member */
};

/* use scope resolution to give actual definition of 
 intValue */
int IntWithGcd::intValue()  
{ return value;
}
