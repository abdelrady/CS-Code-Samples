/* Code of the alias example on page 174
   (with code added to make it executable)
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>
#include <stdlib.h>

main()
{ int *x, *y;
  x = (int *) malloc(sizeof(int));
  *x = 1;
  y = x;    /* *x and *y now aliases */
  *y = 2;
  printf("%d\n",*x);
  return 0;
}
