/* Code of dangling reference example on page 177
   (with code added to make it executable)
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

main()
{  int * x;
  { int y;
    y = 2;
    x = &y;
  }
  /* *x is now a dangling reference */
  printf("%d\n",*x);
  return 0;
}

