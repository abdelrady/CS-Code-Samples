/* Code of Figure 5.29, page 173 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

int gcd( int u, int v)
{ if (v == 0) return u;
   else return gcd(v, u % v);
}

int (*fun_var)(int,int) = gcd;

main()
{ printf("%d\n", fun_var(15,10));
  return 0;
}
