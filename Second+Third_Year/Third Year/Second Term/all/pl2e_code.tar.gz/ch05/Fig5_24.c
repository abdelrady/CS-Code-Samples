/* Code of Figure 5.24, pages 159-160 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

main() /* added to get compilable program */
{
A: {  int x;
      char y;
      /* ... */
   B: {  double x;
         int a;
         /* ... */
      } /* end B */
   C: {  char y;
         int b;
         /* ... */
      D: {  int x;
            double y; 
            /* ... */
         } /* end D */
         /* ... */
      } /* end C */
      /* ... */
   } /* end A */
  return 0;
}
