/* Code of Figure 14.4, page 630 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <parallel/parallel.h>
#define SIZE 100
#define NUMPROCS 10

shared int a[SIZE][SIZE],b[SIZE][SIZE], c[SIZE][SIZE];

void multiply(void)
{ int i, j, k;
  for (i = m_get_myid( ); i < SIZE; i += NUMPROCS)
   for (j = 0; j < SIZE; j++)
    for (k = 0 ; k < SIZE; k++)
        c[i][j] += a[i][k] * b[k][j];
}

main()
{ int err;
  /* code to read in the matrices a and b goes here */
  m_set_procs(NUMPROCS);
  m_fork(multiply);
  m_kill_procs( );
  /* code to write out the matrix c goes here */
  return 0;
}
