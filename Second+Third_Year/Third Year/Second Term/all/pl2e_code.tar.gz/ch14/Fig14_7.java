/* Code of Figure 14.7, page 644 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

class Semaphore
{ private int count;

  public Semaphore(int initialCount)
  { count = initialCount; }

  public synchronized void delay() 
              throws InterruptedException
  { while (count <= 0) wait();
    count--;
  }

  public synchronized void signal()
  { count++;
    notify();
  }
}

