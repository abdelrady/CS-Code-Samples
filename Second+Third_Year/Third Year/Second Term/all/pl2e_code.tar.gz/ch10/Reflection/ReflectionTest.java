/* Code of ReflectionTest, pages 460-461, from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

class Funny
{}

class Funnier extends Funny
{}

public class ReflectionTest
{ public static void main(String[] args)
  { Funny x = new Funnier();
    System.out.println(x.getClass().getName());
  }
}

