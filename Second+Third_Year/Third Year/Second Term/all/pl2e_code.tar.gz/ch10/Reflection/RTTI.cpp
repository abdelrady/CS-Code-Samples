/* Code of C++ RTTI test, page 461, from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <typeinfo>
#include <iostream>

using namespace std;

class Funny
{ public: virtual void f() {}
};

class Funnier : public Funny
{ public: void f() {}
};

int main()
{ Funny* x = new Funnier;
  cout << typeid(*x).name() << endl;
  return 0;
}
