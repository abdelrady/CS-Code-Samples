/* Code of BorderedRectangle class of page 432 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

class BorderedRectangle extends Rectangle
{  public BorderedRectangle 
                  (Point c, double w, double h, double b)
   {  super(c,w,h);
      border = b;
   }
   // ...
   public double area()
   // Should call accessor functions width() and height()
   // -- OR Rectangle can make width and height protected
   {  return (width+2*border) * (height+2*border);
   }

   private double border;
}

