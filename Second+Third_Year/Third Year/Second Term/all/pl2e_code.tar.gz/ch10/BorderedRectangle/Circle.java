/* Code of Circle class of 
   Figure 10.5, pages 423-424 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Circle extends ClosedFigure
{ public Circle( Point c, double r)
  { super(c);
    radius = r;
  }
  // ...
  public double area()
  { return Math.PI * radius * radius; }

  private double radius;
}

