/* Code of ClosedFigure class on page 423 of 
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public abstract class ClosedFigure
{  public ClosedFigure (Point c)
   {  center = c; }
   // ... 

   public abstract double area();

   private Point center;
}
