/* Code to test the BorderedRectangle class 
   of page 432 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class User
{ public static void main(String[] args)
  { 
    Rectangle r = 
       new BorderedRectangle(new Point(1,1),3,4,0.5);
    System.out.println(r.area());
  }
}
