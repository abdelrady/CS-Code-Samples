/* Code to test the closed figure classes 
   of Figure 10.5 from page 425 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class User
{ public static void main(String[] args)
  { Point x,y;
    ClosedFigure f;
    Rectangle r;
    Circle c;

    x = new Point(0,0);
    y = new Point(1,-1);
    r = new Rectangle(x,1,1);
    c = new Circle(y,1);
    f = r;
    System.out.println(f.area());
    f = c;
    System.out.println(f.area());
  }
}
