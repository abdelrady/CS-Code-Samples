/* Code of Rectangle class of 
   Figure 10.5, pages 423-424 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Rectangle extends ClosedFigure
{ public Rectangle (Point c, double w, double h)
  { super(c);
    width = w;
    height = h;
  }
  // ...
  public double area()
  { return width * height; }

  private double width;
  private double height;
}
