/* Code of Figure 10.13, pages 442-443 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
   Alternate code from the bottom of page 443
   also added.
*/

#include <iostream>
using std::cout;

class A
{ 
public:
  void p()
  { cout << "A::p\n" ;
  }   

  virtual void q()
  { cout << "A::q\n" ;
  }

  void f()
  { p();
    q();
  }
};

class B : public A
{
public:
  void p()
  { cout << "B::p\n" ;
  }

  void q()
  { cout << "B::q\n" ;
  }
};

int main()
{ A a;
  B b;
  a.f();
  b.f();
  a = b;
  a.f();
  // alternate code from the bottom of page 443
  { A* a = new A;
    B* b = new B;
    a->f();
    b->f();
    a = b;
    a->f();
  }
  return 0;
}
