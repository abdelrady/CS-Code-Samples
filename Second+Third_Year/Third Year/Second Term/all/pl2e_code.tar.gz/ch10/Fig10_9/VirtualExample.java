/* Code of Figure 10.9, pages 432-433 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

class A
{ void p()
  { System.out.println("A.p");
  }   

  void q()
  { System.out.println("A.q");
  }

  void f()
  { p();
    q();
  }
}

class B extends A
{ void p()
  { System.out.println("B.p");
  }

  void q()
  { System.out.println("B.q");
    super.q();
  }
}

public class VirtualExample
{ public static void main(String[] args)
  { A a = new A();
    a.f();
    a = new B();
    a.f();
  }
}
