/* Code of Point class of 
   Figure 10.4, pages 422-423 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Point
{  public Point (double x, double y)
   {  this.x = x;
      this.y = y;
   }
   // ...
   private double x;
   private double y;
}
