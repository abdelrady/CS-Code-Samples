/* Code of Circle class of 
   Figure 10.4, pages 422-423 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Circle
{  public Circle( Point c, double r)
   { center = c;
      radius = r;
   }
   //...

   public double area()
   {  return Math.PI * radius * radius; }

   private Point center;
   private double radius;
}

