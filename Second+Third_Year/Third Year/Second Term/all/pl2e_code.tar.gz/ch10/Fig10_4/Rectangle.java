/* Code of Rectangle class of 
   Figure 10.4, pages 422-423 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Rectangle
{  public Rectangle (Point c, double w, double h)
   {  center = c;
      width = w;
      height = h;
   }
   // ... 
   public double area()
   { return width * height; }

   private Point center;
   private double width;
   private double height;
}
