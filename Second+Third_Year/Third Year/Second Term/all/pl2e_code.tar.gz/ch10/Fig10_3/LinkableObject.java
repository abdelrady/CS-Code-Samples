/* Code of Figure 10.3, page 417 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class LinkableObject
{  public LinkableObject()
   { link = null; }
   public LinkableObject(LinkableObject link)
   { this.link = link; }
   public LinkableObject next()
   { return link; }
   public void linkTo( LinkableObject p)
   { link = p; }
   private LinkableObject link;
}

