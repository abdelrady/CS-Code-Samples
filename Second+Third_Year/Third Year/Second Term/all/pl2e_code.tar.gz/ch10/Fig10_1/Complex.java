/* Code of Figure 10.1, page 414 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Complex
{ public Complex()
  { re = 0; im = 0; }

  public Complex (double realpart, double imagpart)
  { re = realpart; im = imagpart; }

  public double realpart()
  { return re; }

  public double imaginarypart()
  { return im; }

  public Complex add( Complex c )
  { return new Complex(re + c.realpart(), 
                       im + c.imaginarypart());
  }
  public Complex multiply (Complex c)
  { return new 
      Complex(re * c.realpart() - im * c.imaginarypart(), 
              re * c.imaginarypart() + im * c.realpart());
  }

  private double re, im;
}
