/* Code of Figure 10.2, pages 415-416 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Complex
{  public Complex()
   { radius = 0; angle = 0; }
   
   public Complex (double realpart, double imagpart)
   { radius = Math.sqrt(realpart*realpart + imagpart*imagpart);
     angle = Math.atan2(imagpart,realpart);
   }

   public double realpart()
   { return radius * Math.cos(angle); }
   
   public double imaginarypart()
   { return radius * Math.sin(angle); }

   public Complex add( Complex c )
   { return new Complex(realpart() + c.realpart(), 
                        imaginarypart() + c.imaginarypart());
   }
   public Complex multiply (Complex c)
   { return new 
       Complex(realpart() * c.realpart()
                - imaginarypart() * c.imaginarypart(), 
               realpart() * c.imaginarypart() 
                + imaginarypart() * c.realpart());
   }

   private double radius, angle;
}
