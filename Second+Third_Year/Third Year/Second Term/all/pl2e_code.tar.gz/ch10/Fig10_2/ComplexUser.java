/* Code on page 416 to test Complex class from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class ComplexUser
{ public static void main(String[] args)
  { Complex z,w;
    z = new Complex (1,2);
    w = new Complex (-1,1);
    z = z.add(w).multiply(z);
    System.out.println(z.realpart());
    System.out.println(z.imaginarypart());
  }
}
