/* Code to test Figures 7 and 8 from
   pages 428 and 429 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
   ADDED code from page 422 WITH CORRECTION
*/

public class User
{ public static void main(String[] args)
  { LinkableObject r = new LinkableObject(new Double(1.2));
    LinkableObject i = new LinkableObject(new Integer(42));
    LinkableObject c = new LinkableObject(new Complex(1,-1));
    Queue q = new Queue();
    q.enqueue(r);
    q.enqueue(i);
    q.enqueue(c);
    q.dequeue();
    System.out.println(q.front().data()); // prints 42
  }
}
