/* Code of Figure 10.7, page 428 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class LinkableObject
{ public LinkableObject( Object d )
  { link = null;
    item = d;
  }

  public LinkableObject( Object d, LinkableObject link)
  { this.link = link;
    item = d;
  }

  public LinkableObject next()
  { return link; }

  public void linkTo( LinkableObject p)
  { link = p; }

  public Object data()
  { return item; }

  private LinkableObject link;
  private Object item;
}
