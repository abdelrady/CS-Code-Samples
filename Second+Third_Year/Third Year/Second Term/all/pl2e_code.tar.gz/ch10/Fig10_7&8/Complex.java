/* Code of Figure 10.1, page 414 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
   ADDED code from page 422 WITH CORRECTION
*/

public class Complex
{ public Complex()
  { re = 0; im = 0; }

  public Complex (double realpart, double imagpart)
  { re = realpart; im = imagpart; }

  public double realpart()
  { return re; }

  public double imaginarypart()
  { return im; }

  public Complex add( Complex c )
  { return new Complex(re + c.realpart(), 
                       im + c.imaginarypart());
  }
  public Complex multiply (Complex c)
  { return new 
      Complex(re * c.realpart() - im * c.imaginarypart(), 
              re * c.imaginarypart() + im * c.realpart());
  }

  // Corrected from p. 422
  public boolean equals ( Object obj )
  { Complex c = (Complex) obj; // cast to Complex -- only works for these objects
    return re == c.realpart() 
                 && im == c.imaginarypart();
  }

  public String toString()
  { return re + " + " + im + "i"; }

  private double re, im;
}
