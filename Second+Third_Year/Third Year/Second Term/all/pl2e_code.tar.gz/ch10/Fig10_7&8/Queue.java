/* Code of Figure 10.8, pages 428-429 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

public class Queue
{ public Queue()
  { rear = null; }

  public boolean empty()
  { return rear == null; }

  public LinkableObject front()
  { return rear.next(); }

  public void dequeue()
  { if (front() == rear) rear = null;
    else rear.linkTo(front().next());
  }

  public void enqueue( LinkableObject item)
  { if (empty())
    { rear = item;
      rear.linkTo(item);
    }
    else
    { item.linkTo(front());
      rear.linkTo(item);
      rear = item;
    }
  }

  private LinkableObject rear;
}
