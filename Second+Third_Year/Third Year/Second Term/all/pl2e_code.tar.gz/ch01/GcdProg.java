/* Code of Figure 1.9, page 27 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

import java.io.*;

class IntWithGcd
{ public IntWithGcd( int val ) { value = val; }
  public int getValue() { return value; }
  public int gcd ( int v )
  { int z = value;
    int y = v;
    while ( y != 0 )
    { int t = y;
      y = z % y;
      z = t;
    }
    return z;
  }
  private int value;
}

class GcdProg
{ public static void main (String args[])
  { System.out.println("Input two integers:");
    BufferedReader in =
      new BufferedReader(new InputStreamReader(System.in));
    try
    { IntWithGcd x = new IntWithGcd(Integer.parseInt(in.readLine()));
      int y = Integer.parseInt(in.readLine());
      System.out.print("The gcd of " + x.getValue()
                        + " and " + y + " is ");
      System.out.println(x.gcd(y));
    }
    catch ( Exception e)
    { System.out.println(e);
      System.exit(1);
    }
  }
}
