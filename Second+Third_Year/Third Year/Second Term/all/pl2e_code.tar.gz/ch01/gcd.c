/* Code of Figure 1.7, page 26 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int gcd(int u, int v)
{	if (v == 0) return u;
	else return gcd (v, u % v);
}

main()
{  int x, y;
   printf("Input two integers:\n");
   scanf("%d%d",&x,&y);
   printf("The gcd of %d and %d is %d\n",x,y,gcd(x,y));
   return 0;
}
