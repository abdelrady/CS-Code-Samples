/* Code of Figure 4.1, page 82 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/
#include <ctype.h>
#include <stdio.h>

/* the tokens as an enumerated type */
typedef enum {PLUS,TIMES,LPAREN,RPAREN,
	EOL,NUMBER,ERROR} TokenType;

int numval; /* computed numeric value of a NUMBER token */
int curr_char; /* current character */

TokenType getToken(void)
{ while ((curr_char = getchar()) == ' '); /* skip blanks */
  if (isdigit(curr_char)) /* recognize a NUMBER token */
  { numval = 0;
    while (isdigit(curr_char))
    { /* compute numeric value */
      numval = 10 * numval + curr_char - '0';
      curr_char = getchar();
    }
    /* put back last character onto input */
    ungetc(curr_char,stdin);
    return NUMBER;
  }
  else /* recognize a special symbol */
  { switch (curr_char)
    { case '(': return LPAREN; break;
      case ')': return RPAREN; break;
      case '+': return PLUS; break;
      case '*': return TIMES; break;
      case '\n': return EOL; break;
      default: return ERROR; break;
    }
  }
}

main()
{ TokenType token;
  do
  { token = getToken();
    switch (token)
    { case PLUS: printf("PLUS\n"); break;
      case TIMES: printf("TIMES\n"); break;
      case LPAREN: printf("LPAREN\n"); break;
      case RPAREN: printf("RPAREN\n"); break;
      case EOL: printf("EOL\n"); break;
      case NUMBER: printf("NUMBER: %d\n", numval); break;
      case ERROR: printf("ERROR: %c\n", curr_char); break;
    }
  } while (token != EOL);
  return 0;
}

