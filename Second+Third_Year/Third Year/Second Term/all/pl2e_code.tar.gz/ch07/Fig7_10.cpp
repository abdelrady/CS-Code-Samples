/* Code of Figure 7.10, page 292 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <iostream>

using namespace std;

struct Tree
{  int data;
   Tree * left;
   Tree * right;
};

void fnd (Tree* p, int i) // helper procedure
{ if (p != 0)
     if (i == p->data) throw p;
     else if (i < p->data) fnd(p->left,i);
     else fnd(p->right,i);
}

Tree * find (Tree* p, int i)
{  try
    { fnd(p,i);
    }
    catch(Tree* q)
    {  return q;
    }
    return 0;
}

Tree * maketree()
{ Tree * p = new Tree;
  p->data = 4;
  p->left = new Tree;
  p->right = NULL;
  p->left->data = 2;
  p->left->left = NULL;
  p->left->right = NULL;
  return p;
}

int main()
{ Tree* p = maketree();
  Tree* q;
  q = find(p,2);
  if(q) cout << q->data << endl;
  else cout << "not found" << endl;
  q = find(p,3);
  if(q) cout << q->data << endl;
  else cout << "not found" << endl;
  q = find(p,4);
  if(q) cout << q->data << endl;
  else cout << "not found" << endl;
  return 0;
}
