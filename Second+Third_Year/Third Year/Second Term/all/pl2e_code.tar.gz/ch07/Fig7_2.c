/* Code of Figure 7.2, page 274 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

main()
{ int x,y=0,z=0;
  scanf("%d",&x);
  switch (x - 1)
  { case 0 :
      y = 0;
      z = 2;
      break;
    case 2:
    case 3:
    case 4:
    case 5:
    y = 3;
    z = 1;
    break;
  case 7:
  case 9:
    z = 10;
    break;
  default:
    /* do nothing */
    break;
  }
  printf("x = %d, y = %d, z = %d\n",x,y,z);
  return 0;
}
