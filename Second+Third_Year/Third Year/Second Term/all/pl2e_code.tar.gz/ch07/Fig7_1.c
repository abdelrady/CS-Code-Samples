/* Code of Figure 7.1, page 264 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

int x = 1;

int f(void)
{ x += 1;
  return x;
}

int p( int a, int b)
{ return a + b;
}

main()
{ printf("%d\n",p(x,f()));
  return 0;
}

