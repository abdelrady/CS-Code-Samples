/* Code of Figure 9.7, page 374 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <iostream>
#include "queue2.h"

using std::endl;
using namespace MyQueue;

main()
{  int *x = new int;
   int *y = new int;
   int *z;
   // explicit qualification unnecessary
   // but permitted
   Queue q = MyQueue::createq();
   *x = 2;
   *y = 3;
   q = enqueue(q,x);
   q = enqueue(q,y);
   z = (int*) frontq(q);
   // explicit qualification needed for cout
   std::cout << *z << endl; // prints 2
   q = dequeue(q);
   z = (int*) frontq(q);
   std::cout << *z << endl; // prints 3
}
