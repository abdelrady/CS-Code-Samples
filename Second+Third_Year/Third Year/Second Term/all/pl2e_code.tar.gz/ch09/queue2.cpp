/* Code of Figure 9.4, pages 369-370 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
   Adapted for C++
*/

#include "queue2.h"

namespace MyQueue
{

struct Queuerep
{ void* data;
  Queue next;
};

Queue createq(void)
{ return 0;
}

Queue enqueue(Queue q, void* elem)
{ Queue temp = new Queuerep;
  temp->data = elem;
  if (q)
  { temp->next = q->next;
    q->next = temp;
    q = temp;
  }
  else
  { q = temp;
    q->next = temp;
  }
  return q;
}

void* frontq(Queue q)
{ return q->next->data;
}

Queue dequeue(Queue q)
{ Queue temp;
  if (q == q->next)
  { temp = q;
    q = 0;
  }
  else
  { temp = q->next;
    q->next = q->next->next;
  }
  delete temp;  
  return q;
}

bool emptyq(Queue q)
{ return q == 0;
}

} // end namespace MyQueue
