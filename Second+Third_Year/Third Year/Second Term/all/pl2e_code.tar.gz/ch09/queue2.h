/* Code of Figure 9.6, page 373 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#ifndef QUEUE_H
#define QUEUE_H

namespace MyQueue
{  struct Queuerep;
   typedef Queuerep * Queue; 
             // struct no longer needed in C++
  Queue createq();
  Queue enqueue(Queue q, void* elem);
  void* frontq(Queue q);
  Queue dequeue(Queue q);
  bool emptyq(Queue q);
}

#endif
