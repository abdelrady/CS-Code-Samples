/* Code of Figure 9.3, page 369 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#ifndef QUEUE_H
#define QUEUE_H

struct Queuerep;
typedef struct Queuerep * Queue;

Queue createq(void);
Queue enqueue(Queue q, void* elem);
void* frontq(Queue q);
Queue dequeue(Queue q);
int emptyq(Queue q);

#endif

