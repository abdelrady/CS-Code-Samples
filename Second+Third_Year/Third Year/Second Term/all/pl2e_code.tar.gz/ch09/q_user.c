/* Code of Figure 9.5, page 370 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdlib.h>
#include <stdio.h>
#include "queue.h"

main()
{  int *x = malloc(sizeof(int));
   int *y = malloc(sizeof(int));
   int *z;
   Queue q = createq();
   *x = 2;
   *y = 3;
   q = enqueue(q,x);
   q = enqueue(q,y);
   z = (int*) frontq(q);
   printf("%d\n",*z); /* prints 2 */
   q = dequeue(q);
   z = (int*) frontq(q);
   printf("%d\n",*z); /* prints 3 */
   return 0;
}
