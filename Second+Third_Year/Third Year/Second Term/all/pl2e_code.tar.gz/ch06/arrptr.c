/* Code demonstrating array/pointer duality
   in C from page 213 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

main()
{ int a[] = {1,2,3,4,5}; /* array of size 5, a[0] = 1, etc. */
  int* p = a; /* p points to first component of a */
  printf("%d\n", *p); /* prints value of a[0], so 1 */
  printf("%d\n", *(p+2)); /* prints value of a[2], so 3 */
  printf("%d\n", *(a+2)); /* also prints 3 */
  printf("%d\n", 2[a]); /* also prints 3! */
  return 0;
}
