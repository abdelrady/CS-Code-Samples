/* Example of function types and variables
   in C on page 210 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

typedef int (*IntFunction)(int);

int square(int x) { return x*x; }

IntFunction f = square;

int evaluate(IntFunction g, int value)
{ return g(value); }

main()
{ printf("%d\n", evaluate(f,3)); /* prints 9 */
  return 0;
}


