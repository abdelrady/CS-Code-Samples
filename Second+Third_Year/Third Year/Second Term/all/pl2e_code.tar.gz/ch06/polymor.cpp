/* Example of polymorphism and type checking
   in C++ from pages 247-248 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <iostream>

using std::cout;
using std::endl;

template <typename T>
T max (T x, T y, bool (*gt)(T,T))
{ return gt(x,y) ? x : y ;
}

bool gti (int x, int y)
{ return x > y; }

int larger = max(2,3,gti); // larger is now 3

template <typename T>
T max (T x, T y)
{ return x > y ? x : y ; }

int larger_i = max(2,3); // larger_i is now 3
double larger_d = max(3.1,2.9); // larger_d is now 3.1

int main()
{ cout << larger << endl;
  cout << larger_i << endl;
  cout << larger_d << endl;
  return 0;
}
