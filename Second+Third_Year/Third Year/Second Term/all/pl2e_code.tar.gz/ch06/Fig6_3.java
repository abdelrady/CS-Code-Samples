/* Code of Figure 6.3, pages 207-208 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

import java.io.*;

class ArrayTest
{ static int array_max (int[] a) // note location of []
  { int temp;
    temp = a[0];
    // size is part of a
    for (int i = 1; i < a.length; i++)
    { if (a[i] > temp) temp = a[i];
    }
    return temp;
  }

  public static void main (String args[]) 
  // this placement of [] also allowed
  { System.out.print("Input a positive integer: ");
    // Java code to get formatted input
    BufferedReader in =
      new BufferedReader(new InputStreamReader(System.in));
    try // must catch exceptions
    { int u = Integer.parseInt(in.readLine());
      int [] x = new int[u] ; // Dynamic array allocation
      for (int i = 0; i < x.length; i++) x[i] = i;
      System.out.println(array_max(x));
    }
    catch ( IOException e)
    { System.out.println("Invalid input.");  }
    catch (NumberFormatException e)
    { System.out.println("Invalid input.");  }
  }
}
