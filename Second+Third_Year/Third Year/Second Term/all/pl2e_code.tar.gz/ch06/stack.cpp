/* Polymorphic stack example
   in C++ from pages 246-247 of
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <iostream>

using namespace std;

template <typename T>
struct StackNode
{ T data;
  StackNode<T> * next;
};

template <typename T>
struct Stack
{ StackNode<T> * theStack;
};

template <typename T>
T top (Stack<T> s)
{ return s.theStack->data;
}

int main()
{ Stack<int> s;
  s.theStack = new StackNode<int>;
  s.theStack->data = 3;
  s.theStack->next = 0;
  int t = top(s); //  t is now 3
  cout << t << endl;
  return 0;
}
