/* Code of Figure 6.2, page 198 from
   Kenneth C. Louden, Programming Languages
   Principles and Practice 2nd Edition
   Copyright (C) Brooks-Cole/ITP, 2003
*/

#include <stdio.h>

enum Color {Red,Green,Blue};
enum NewColor {NewRed = 3, NewGreen = 2, NewBlue = 2};

main()
{ enum Color x = Green; /* x is actually 1 */
  enum NewColor y = NewBlue; /* y is actually 2 */
  x++; /* x is now 2, or Blue */
  y--; /* y is now 1 -- not even in the enum */
  printf("%d\n",x); /* prints 2 */
  printf("%d\n",y); /* prints 1 */
  return 0;
}

