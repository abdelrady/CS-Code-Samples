using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace WindowsApplicationTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private FileSystemWatcher watcher = new FileSystemWatcher();
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button2;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(56, 93);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(72, 24);
			this.button1.TabIndex = 0;
			this.button1.Text = "Validate";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(40, 40);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(216, 20);
			this.textBox1.TabIndex = 3;
			this.textBox1.Text = "";
			this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(152, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Enter a Credit Card Number:";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(40, 67);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(184, 16);
			this.label2.TabIndex = 5;
			// 
			// button2
			// 
			this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.button2.Location = new System.Drawing.Point(168, 93);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(72, 24);
			this.button2.TabIndex = 6;
			this.button2.Text = "Cancel";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 134);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "Validate Credit Card";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.label2.ForeColor = System.Drawing.Color.Red;
			string creditCardNumber = this.textBox1.Text;
			if(this.textBox1.Text.Trim().Length > 0)
			{
				Regex CreditCardPattern = new Regex("[^0-9]");
				if(!CreditCardPattern.IsMatch(creditCardNumber))
				{
					if (ValidateCreditCardNumber(creditCardNumber))
					{
						this.label2.ForeColor = System.Drawing.Color.Black;
						this.label2.Text = "This credit card number is valid";
					}
					else
						this.label2.Text = "This credit card number is invalid";
				}
				else
					this.label2.Text = "Please enter numbers only";
			}
			else
				this.label2.Text = "Enter a credit card number";
		}

		/// <summary>
		/// Mod 10 check to validate credit card number
		/// </summary>
		/// <param name="creditCardNumber">Creditcard number</param>
		/// <returns></returns>
		private bool ValidateCreditCardNumber(string creditCardNumber)
		{
			//Replace any character other than 0-9 with ""
			int cardSize = creditCardNumber.Length;
			//Creditcard number length must be between 13 and 16
			if (cardSize >= 13 && cardSize <= 16)
			{
				int odd = 0;
				int even = 0;
				char[] cardNumberArray = new char[cardSize];
				//Read the creditcard number into an array
				cardNumberArray = creditCardNumber.ToCharArray();
				//Reverse the array
				Array.Reverse(cardNumberArray, 0, cardSize);
				//Multiply every second number by two and get the sum. Get the sum of the rest of the numbers.
				for (int i = 0; i < cardSize; i++)
				{
					if (i%2 ==0)
					{
						odd += (Convert.ToInt32(cardNumberArray.GetValue(i))-48);				
					}
					else
					{
						int temp = (Convert.ToInt32(cardNumberArray[i]) - 48) * 2;
						//if the value is greater than 9, substract 9 from the value
						if (temp > 9)
						{
							temp = temp-9;
						}
						even += temp;
					}
				}
				if ((odd+even)%10 == 0)
					
					return true;
				else
					return false;
			}
			else
				return false;
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void textBox1_TextChanged(object sender, System.EventArgs e)
		{
			this.label2.Text = "";
		}		
	}
}
