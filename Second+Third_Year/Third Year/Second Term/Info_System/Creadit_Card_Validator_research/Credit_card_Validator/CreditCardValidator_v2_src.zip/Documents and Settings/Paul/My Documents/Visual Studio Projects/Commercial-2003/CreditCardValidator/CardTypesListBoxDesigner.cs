using System;
using System.Web.UI.Design;

namespace Etier.CreditCard
{
	public class CardTypesListBoxDesigner : ControlDesigner
	{
		public CardTypesListBoxDesigner()
		{
		}
	}
}
