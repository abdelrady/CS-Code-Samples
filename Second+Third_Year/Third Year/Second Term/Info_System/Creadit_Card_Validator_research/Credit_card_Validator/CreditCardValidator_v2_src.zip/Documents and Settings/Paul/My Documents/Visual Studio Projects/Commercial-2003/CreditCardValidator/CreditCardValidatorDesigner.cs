using System;
using System.Web.UI.Design.WebControls;
using System.Web.UI.Design;

namespace Etier.CreditCard
{
	public class CreditCardValidatorDesigner : BaseValidatorDesigner
	{
		public CreditCardValidatorDesigner()
		{
		}
	}
}