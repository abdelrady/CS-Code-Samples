Title: Maze traversal ARRAYS!
Description: this is a simple maze traversal program. It was produced using a 2d array, its not a very graphical program but technically it is very good.
Jamie Lutzuver.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2133&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
