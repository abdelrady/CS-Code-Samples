// clear screen


void clrscreen()			// custom made function, very cleaver clears screen
{
	cout << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl << endl;
	cout << endl << endl << endl << endl << endl << endl << endl << endl << endl;	
}
