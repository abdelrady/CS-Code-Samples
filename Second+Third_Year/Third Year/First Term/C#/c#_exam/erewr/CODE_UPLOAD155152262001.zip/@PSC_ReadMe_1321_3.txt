Title: RAT IN A MAZE SIMPLE AI AND COLISION DETECTION
Description: This is a nice little program for you guys who make ascii games has colison detection and some simple AI. It also shows you how to search matrixs
Me and A Freind Wrote This Code So TEll US what you think
WE WANT TO THANK RICK MANSFIELD AGIN FOR HIS COLOR CODING
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=1321&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
