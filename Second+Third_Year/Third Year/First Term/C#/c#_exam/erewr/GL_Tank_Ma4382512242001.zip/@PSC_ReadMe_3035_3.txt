Title: GL Tank Maze 2001
Description: Take command of a multi-level environment. The player works to capture all the point spheres to advance to the next level. The game involves two tanks: the player tank and the opponent tank. Each side can choose to shoot or avoid each other. The player can even destroy the walls or objects that are presented as an obstacle. More environments will be built in future releases.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3035&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
