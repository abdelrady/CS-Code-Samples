using System;
using System.IO;

namespace Nevermoney
{
	/// <summary>
	/// NSE Money File Class
	/// </summary>
	public class MoneyFile
	{
		private struct Payment
		{
			public float amount;
            public bool credit;
			public string time;
			public string description;

			public void init()
			{
				amount = 0;
				credit = false;
				time = DateTime.Today.ToShortDateString();
				description = "null transaction";
			}
		}

		private struct FinancialPeriod
		{
			public string starts;
			public string ends;
			public Payment[] TR;
			public string description;

			public void init()
			{
				TR = new Payment[1];
				starts = DateTime.Today.ToShortTimeString();
				ends = DateTime.Today.AddYears(1).ToShortDateString();
				description = "new time span";
			}

			public void addTR()
			{
				if(TR==null)
				{
					TR = new Payment[1];
				}
				else
				{
					Payment[] temp = TR;
					TR = new Payment[TR.Length + 1];
					temp.CopyTo(TR, 0);
				}
			}
		}

		private FinancialPeriod[] FP = null;
		public string Filename;
		private int iFP;
		private int iTR;

		private const string SEPARATOR = "`";
		private const string SEPARATOR2 = "�";

		// Constructor Logic

		public MoneyFile()
		{
			Filename = "newaccounts";
			FP = new FinancialPeriod[1];
			FP[0].init();
			FP[0].TR[0].init();
			iFP = 0;
			iTR = 0;
		}

		public MoneyFile(string filename)
		{
			BinaryReader FileReader;
			FileStream infile;

			try	
			{
				infile = new FileStream(filename, FileMode.Open);
			}
			catch(FileNotFoundException e)
			{
				System.Windows.Forms.MessageBox.Show(e.FileName, "File Not Found");
				return;
			}

			FileReader = new BinaryReader(infile);

			Filename = filename;

			bool Reading = true;
			string tmp = "";

			while(Reading)
			{
				try{
					tmp = String.Concat(tmp, FileReader.ReadString());
				}
				catch(EndOfStreamException u){
					Reading = false;
				}
			}
			
			string[] FPExp = tmp.Split(SEPARATOR2.ToCharArray());

			FP = new FinancialPeriod[FPExp.Length - 1];

			for(int i=0; i<FPExp.Length; i++)
				if(FPExp[i] != "")
					FP[i] = ParseTimeSpanExpression(FPExp[i]);

			FileReader.Close();
		}

		public void AddFinancialPeriod(string starts, string ends, string description)
		{
			FinancialPeriod[] tmp = FP;
			FP = new FinancialPeriod[FP.Length + 1];
			tmp.CopyTo(FP, 0);
			iFP = FP.Length - 1;
			FP[iFP].init();
			FP[iFP].description = description;
			FP[iFP].starts = starts;
			FP[iFP].ends = ends;
			FP[iFP].TR[0].init();
			iTR = 0;
		}

		public void SetFinancialPeriod(int jFP, string starts, string ends, string description)
		{
			FP[jFP].starts = starts;
			FP[jFP].ends = ends;
			FP[jFP].description = description;
		}

		public void DeleteFinancialPeriod(int jFP)
		{
			FinancialPeriod[] tmp = FP;
			FP = new FinancialPeriod[FP.Length - 1];
			int j = 0;

			for(int i=0; i<tmp.Length; i++)
				if(i!=jFP)
					FP[j++] = tmp[i];
		}

		public void AddTransaction(float amount, bool credit, string time, string description)
		{
			FP[iFP].addTR();
			iTR++;
			FP[iFP].TR[iTR].amount = amount;
			FP[iFP].TR[iTR].credit = credit;
			FP[iFP].TR[iTR].time = time;
			FP[iFP].TR[iTR].description = description;
		}

		public void SetTransaction(int jFP, int jTR, float amount, bool credit, string time, string description)
		{
			FP[jFP].TR[jTR].amount = amount;
			FP[jFP].TR[jTR].credit = credit;
			FP[jFP].TR[jTR].time = time;
			FP[jFP].TR[jTR].description = description;
		}

		public void DeleteTransaction(int jFP, int jTR)
		{
			Payment[] tmp = FP[jFP].TR;
			FP[jFP].TR = new Payment[tmp.Length - 1];

			int j=0;

			for(int i=0; i<tmp.Length; i++)
				if(i != jTR)
					FP[jFP].TR[j++] = tmp[i];
		}

		public int Num_FinancialPeriods()				{return FP.Length;}
		public int Num_Transactions(int jFP)			{return FP[jFP].TR.Length;}

		public string GetFPDescription(int jFP)			{return FP[jFP].description;}
		public string GetFPStart(int jFP)				{return FP[jFP].starts;}
		public string GetFPEnd(int jFP)					{return FP[jFP].ends;}

		public float GetTRAmount(int jFP, int jTR)		{return FP[jFP].TR[jTR].amount;}
		public bool GetTRCredit(int jFP, int jTR)		{return FP[jFP].TR[jTR].credit;}
		public string GetTRTime(int jFP, int jTR)		{return FP[jFP].TR[jTR].time;}
		public string GetTRDescription(int jFP, int jTR){return FP[jFP].TR[jTR].description;}

		public void SaveFile()
		{
			BinaryWriter FileWriter;
			FileStream infile;

			try	
			{
				infile = new FileStream(Filename, FileMode.Create);
			}
			catch(FileNotFoundException e)
			{
				System.Windows.Forms.MessageBox.Show(e.FileName, "File Not Found");
				return;
			}

			FileWriter = new BinaryWriter(infile);

			for(int i=0; i<FP.Length; i++)
				FileWriter.Write(Expression_TimeSpan(i));

			FileWriter.Close();
		}

		private string Expression_TimeSpan(int iFP)
		{
			string tmp;
			string[] payment_expressions = new string[FP[iFP].TR.Length];

			for(int i=0; i<FP[iFP].TR.Length; i++)
				payment_expressions[i] = String.Concat(FP[iFP].TR[i].amount.ToString(), SEPARATOR, FP[iFP].TR[i].credit.ToString(), SEPARATOR, FP[iFP].TR[i].time, SEPARATOR, FP[iFP].TR[i].description, SEPARATOR);

			tmp = String.Concat(SEPARATOR, FP[iFP].starts, SEPARATOR, FP[iFP].ends, SEPARATOR, FP[iFP].description, SEPARATOR, String.Concat(payment_expressions), SEPARATOR2);
			return tmp;
		}

		private FinancialPeriod ParseTimeSpanExpression(string Exp)
		{
			FinancialPeriod tmp = new FinancialPeriod();

			string[] SubExp = Exp.Split(SEPARATOR.ToCharArray());
			int k = (SubExp[0]=="" ? 1 : 0);

			tmp.starts = DateTime.Parse(SubExp[0+k]).ToShortDateString().ToString();
			tmp.ends = DateTime.Parse(SubExp[1+k]).ToShortDateString().ToString();
			tmp.description = SubExp[2+k];

			int j = 0;

			for(int i=3+k; i<SubExp.Length; i+=4)
			{
				if(SubExp[i]!="")
				{
					tmp.addTR();
					tmp.TR[j].amount = Convert.ToSingle(SubExp[i]);
					tmp.TR[j].credit = (SubExp[i + 1] == "True" ? true : false);
					tmp.TR[j].time = DateTime.Parse(SubExp[i + 2]).ToShortDateString().ToString();
					tmp.TR[j++].description = SubExp[i + 3];
				}
			}

		return tmp;
		}
	}
}
