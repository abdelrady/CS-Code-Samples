using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Nevermoney
{
	/// <summary>
	/// GUI for NSE Academic Money 2005
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.ListBox lstTS;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtTSDescription;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.DateTimePicker dtTSstarts;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ListBox lstTRAmount;
		private System.Windows.Forms.ListBox lstTRTime;
		private System.Windows.Forms.ListBox lstTRDescription;
		private System.Windows.Forms.DateTimePicker dtTSends;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtTRDescription;
		private System.Windows.Forms.CheckBox chkTRCredit;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtTRAmount;
		private System.Windows.Forms.DateTimePicker dtTRTime;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.lstTS = new System.Windows.Forms.ListBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.dtTSends = new System.Windows.Forms.DateTimePicker();
			this.dtTSstarts = new System.Windows.Forms.DateTimePicker();
			this.label2 = new System.Windows.Forms.Label();
			this.txtTSDescription = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.txtTRAmount = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.chkTRCredit = new System.Windows.Forms.CheckBox();
			this.txtTRDescription = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.lstTRDescription = new System.Windows.Forms.ListBox();
			this.label6 = new System.Windows.Forms.Label();
			this.lstTRTime = new System.Windows.Forms.ListBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.lstTRAmount = new System.Windows.Forms.ListBox();
			this.dtTRTime = new System.Windows.Forms.DateTimePicker();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.button10 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.button7 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem14});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem11,
																					  this.menuItem8,
																					  this.menuItem9,
																					  this.menuItem12,
																					  this.menuItem13,
																					  this.menuItem10,
																					  this.menuItem6,
																					  this.menuItem7});
			this.menuItem1.Text = "File";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem3,
																					  this.menuItem4,
																					  this.menuItem5});
			this.menuItem2.Text = "&New";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 0;
			this.menuItem3.Text = "&Accounts";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.Text = "&Period";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 2;
			this.menuItem5.Text = "&Payment";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 1;
			this.menuItem11.Text = "-";
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 2;
			this.menuItem8.Text = "&Open";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 3;
			this.menuItem9.Text = "&Save";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 4;
			this.menuItem12.Text = "S&ave As";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 5;
			this.menuItem13.Text = "-";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 6;
			this.menuItem10.Text = "&Close";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 7;
			this.menuItem6.Text = "-";
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 8;
			this.menuItem7.Text = "E&xit";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 1;
			this.menuItem14.Text = "&About";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// lstTS
			// 
			this.lstTS.Location = new System.Drawing.Point(8, 24);
			this.lstTS.Name = "lstTS";
			this.lstTS.Size = new System.Drawing.Size(240, 199);
			this.lstTS.TabIndex = 0;
			this.lstTS.SelectedIndexChanged += new System.EventHandler(this.lstTS_SelectedIndexChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.button3,
																					this.button2,
																					this.button1,
																					this.label3,
																					this.dtTSends,
																					this.dtTSstarts,
																					this.label2,
																					this.txtTSDescription,
																					this.label1,
																					this.lstTS});
			this.groupBox1.Location = new System.Drawing.Point(8, 128);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(256, 336);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Time Periods";
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(176, 304);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(72, 24);
			this.button3.TabIndex = 8;
			this.button3.Text = "Remove";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(96, 304);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(72, 24);
			this.button2.TabIndex = 7;
			this.button2.Text = "Add";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 304);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(80, 24);
			this.button1.TabIndex = 6;
			this.button1.Text = "Update";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(64, 280);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "Ending at";
			// 
			// dtTSends
			// 
			this.dtTSends.Location = new System.Drawing.Point(120, 280);
			this.dtTSends.Name = "dtTSends";
			this.dtTSends.Size = new System.Drawing.Size(128, 20);
			this.dtTSends.TabIndex = 4;
			// 
			// dtTSstarts
			// 
			this.dtTSstarts.Location = new System.Drawing.Point(120, 256);
			this.dtTSstarts.Name = "dtTSstarts";
			this.dtTSstarts.Size = new System.Drawing.Size(128, 20);
			this.dtTSstarts.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(64, 264);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(56, 16);
			this.label2.TabIndex = 3;
			this.label2.Text = "Starting at";
			// 
			// txtTSDescription
			// 
			this.txtTSDescription.Location = new System.Drawing.Point(72, 232);
			this.txtTSDescription.Name = "txtTSDescription";
			this.txtTSDescription.Size = new System.Drawing.Size(176, 20);
			this.txtTSDescription.TabIndex = 2;
			this.txtTSDescription.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 232);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(64, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Description";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.txtTRAmount,
																					this.label9,
																					this.button6,
																					this.button5,
																					this.button4,
																					this.label8,
																					this.chkTRCredit,
																					this.txtTRDescription,
																					this.label7,
																					this.lstTRDescription,
																					this.label6,
																					this.lstTRTime,
																					this.label5,
																					this.label4,
																					this.lstTRAmount,
																					this.dtTRTime});
			this.groupBox2.Location = new System.Drawing.Point(272, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(408, 456);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Transactions throughout Time Period";
			// 
			// txtTRAmount
			// 
			this.txtTRAmount.Location = new System.Drawing.Point(232, 392);
			this.txtTRAmount.Name = "txtTRAmount";
			this.txtTRAmount.Size = new System.Drawing.Size(160, 20);
			this.txtTRAmount.TabIndex = 15;
			this.txtTRAmount.Text = "";
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(200, 392);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(32, 16);
			this.label9.TabIndex = 14;
			this.label9.Text = "Sum";
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(152, 424);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(56, 24);
			this.button6.TabIndex = 13;
			this.button6.Text = "Remove";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(88, 424);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(56, 24);
			this.button5.TabIndex = 12;
			this.button5.Text = "Add";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(16, 424);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(64, 24);
			this.button4.TabIndex = 11;
			this.button4.Text = "Update";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(40, 392);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(32, 16);
			this.label8.TabIndex = 10;
			this.label8.Text = "Time";
			// 
			// chkTRCredit
			// 
			this.chkTRCredit.Location = new System.Drawing.Point(344, 368);
			this.chkTRCredit.Name = "chkTRCredit";
			this.chkTRCredit.Size = new System.Drawing.Size(56, 16);
			this.chkTRCredit.TabIndex = 8;
			this.chkTRCredit.Text = "Credit";
			// 
			// txtTRDescription
			// 
			this.txtTRDescription.Location = new System.Drawing.Point(72, 368);
			this.txtTRDescription.Name = "txtTRDescription";
			this.txtTRDescription.Size = new System.Drawing.Size(264, 20);
			this.txtTRDescription.TabIndex = 7;
			this.txtTRDescription.Text = "";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(8, 368);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(64, 16);
			this.label7.TabIndex = 6;
			this.label7.Text = "Description";
			// 
			// lstTRDescription
			// 
			this.lstTRDescription.Location = new System.Drawing.Point(184, 40);
			this.lstTRDescription.Name = "lstTRDescription";
			this.lstTRDescription.Size = new System.Drawing.Size(216, 316);
			this.lstTRDescription.TabIndex = 5;
			this.lstTRDescription.SelectedIndexChanged += new System.EventHandler(this.lstTRDescription_SelectedIndexChanged);
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(192, 24);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(96, 16);
			this.label6.TabIndex = 4;
			this.label6.Text = "Description";
			// 
			// lstTRTime
			// 
			this.lstTRTime.Location = new System.Drawing.Point(96, 40);
			this.lstTRTime.Name = "lstTRTime";
			this.lstTRTime.Size = new System.Drawing.Size(88, 316);
			this.lstTRTime.TabIndex = 3;
			this.lstTRTime.SelectedIndexChanged += new System.EventHandler(this.lstTRTime_SelectedIndexChanged);
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(96, 24);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(80, 16);
			this.label5.TabIndex = 2;
			this.label5.Text = "Date";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 24);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(96, 16);
			this.label4.TabIndex = 1;
			this.label4.Text = "Payment";
			// 
			// lstTRAmount
			// 
			this.lstTRAmount.Location = new System.Drawing.Point(8, 40);
			this.lstTRAmount.Name = "lstTRAmount";
			this.lstTRAmount.Size = new System.Drawing.Size(88, 316);
			this.lstTRAmount.TabIndex = 0;
			this.lstTRAmount.SelectedIndexChanged += new System.EventHandler(this.lstTRAmount_SelectedIndexChanged);
			// 
			// dtTRTime
			// 
			this.dtTRTime.Location = new System.Drawing.Point(72, 392);
			this.dtTRTime.Name = "dtTRTime";
			this.dtTRTime.Size = new System.Drawing.Size(128, 20);
			this.dtTRTime.TabIndex = 9;
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.Filter = "Parsimoney Accounts (*.nac)|*.nac|All files (*.*)|*.*\"";
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "newaccounts.nac";
			this.saveFileDialog1.Filter = "Parsimoney Accounts (*.nac)|*.nac|All files (*.*)|*.*\"";
			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(136, 96);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(128, 24);
			this.button10.TabIndex = 12;
			this.button10.Text = "Save Accounts";
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(8, 96);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(120, 24);
			this.button9.TabIndex = 11;
			this.button9.Text = "Close Accounts";
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(136, 64);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(128, 24);
			this.button8.TabIndex = 10;
			this.button8.Text = "Load Accounts";
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(24, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(224, 56);
			this.pictureBox1.TabIndex = 9;
			this.pictureBox1.TabStop = false;
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(8, 64);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(120, 24);
			this.button7.TabIndex = 8;
			this.button7.Text = "New Accounts";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(688, 465);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button10,
																		  this.button9,
																		  this.button8,
																		  this.pictureBox1,
																		  this.button7,
																		  this.groupBox2,
																		  this.groupBox1});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "frmMain";
			this.Text = "Ni-Star Enterprises - Parsimoney";
			this.groupBox1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		const string TITLE = "NSE Parsimoney";

		MoneyFile Accounts = null;
		int TimeSpan;
		int Payment;

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;
            
			Accounts = new MoneyFile();
			TimeSpan = 0;
			Payment = 0;
			UpdateTSView();
			UpdateTRView();
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.AddFinancialPeriod(DateTime.Today.ToString(), DateTime.Today.ToString(), "New Financial Period");
			UpdateTSView();
			Payment = 0;
			UpdateTRView();
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.AddTransaction(0, false, DateTime.Now.ToString(), "New payment");
			UpdateTSView();
			Payment = 0;
			UpdateTRView();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			if(Accounts!=null)
			{
				if(MessageBox.Show("Do you wish to abandon the current Accounts and exit ?", TITLE, MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
					Application.Exit();
			}
			else
				Application.Exit();
		}

		private void UpdateTSView()
		{

			if(String.Concat("Ni-Star Enterprises - Parsimoney - Accounts: ", Accounts.Filename) != ActiveForm.Text)
				ActiveForm.Text = String.Concat("Ni-Star Enterprises - Parsimoney - Accounts: ", Accounts.Filename); 

			lstTS.Items.Clear();

			for(int i = 0; i<Accounts.Num_FinancialPeriods(); i++)
                lstTS.Items.Add(Accounts.GetFPDescription(i));

			txtTSDescription.Text = Accounts.GetFPDescription(TimeSpan);
			dtTSstarts.Value = DateTime.Parse(Accounts.GetFPStart(TimeSpan));
			dtTSends.Value = DateTime.Parse(Accounts.GetFPEnd(TimeSpan));
		}

		private void UpdateTRView()
		{
			lstTRAmount.Items.Clear();
			lstTRTime.Items.Clear();
			lstTRDescription.Items.Clear();

			for(int i=0; i<Accounts.Num_Transactions(TimeSpan); i++)
			{
				lstTRAmount.Items.Add(String.Concat( (Accounts.GetTRCredit(TimeSpan, i) ? "+" : "-") ,Accounts.GetTRAmount(TimeSpan, i).ToString()));
				lstTRTime.Items.Add(Accounts.GetTRTime(TimeSpan, i));
				lstTRDescription.Items.Add(Accounts.GetTRDescription(TimeSpan, i));
			}

			dtTRTime.Value = DateTime.Parse(Accounts.GetTRTime(TimeSpan, Payment));
			txtTRAmount.Text = Accounts.GetTRAmount(TimeSpan, Payment).ToString();
			chkTRCredit.Checked = Accounts.GetTRCredit(TimeSpan, Payment);
			txtTRDescription.Text = Accounts.GetTRDescription(TimeSpan, Payment);
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.SetFinancialPeriod(TimeSpan, dtTSstarts.Value.ToString(), dtTSends.Value.ToString(), txtTSDescription.Text);
			UpdateTSView();
			Payment = 0;
			UpdateTRView();
		}

		private void lstTS_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			TimeSpan = lstTS.SelectedIndex;
			
			txtTSDescription.Text = Accounts.GetFPDescription(TimeSpan);
			dtTSstarts.Value = DateTime.Parse(Accounts.GetFPStart(TimeSpan));
			dtTSends.Value = DateTime.Parse(Accounts.GetFPEnd(TimeSpan));

			Payment = 0;
			UpdateTRView();
		}

		private void lstTRAmount_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Payment = lstTRAmount.SelectedIndex;
			lstTRTime.SelectedIndex = Payment;
			lstTRDescription.SelectedIndex = Payment;

			dtTRTime.Value = DateTime.Parse(Accounts.GetTRTime(TimeSpan, Payment));
			txtTRAmount.Text = Accounts.GetTRAmount(TimeSpan, Payment).ToString();
			chkTRCredit.Checked = Accounts.GetTRCredit(TimeSpan, Payment);
			txtTRDescription.Text = Accounts.GetTRDescription(TimeSpan, Payment);
		}

		private void lstTRTime_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Payment = lstTRTime.SelectedIndex;
			lstTRAmount.SelectedIndex = Payment;
			lstTRDescription.SelectedIndex = Payment;

			dtTRTime.Value = DateTime.Parse(Accounts.GetTRTime(TimeSpan, Payment));
			txtTRAmount.Text = Accounts.GetTRAmount(TimeSpan, Payment).ToString();
			chkTRCredit.Checked = Accounts.GetTRCredit(TimeSpan, Payment);
			txtTRDescription.Text = Accounts.GetTRDescription(TimeSpan, Payment);
		}

		private void lstTRDescription_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			Payment = lstTRDescription.SelectedIndex;
			lstTRTime.SelectedIndex = Payment;
			lstTRAmount.SelectedIndex = Payment;

			dtTRTime.Value = DateTime.Parse(Accounts.GetTRTime(TimeSpan, Payment));
			txtTRAmount.Text = Accounts.GetTRAmount(TimeSpan, Payment).ToString();
			chkTRCredit.Checked = Accounts.GetTRCredit(TimeSpan, Payment);
			txtTRDescription.Text = Accounts.GetTRDescription(TimeSpan, Payment);
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.AddFinancialPeriod(dtTSstarts.Value.ToShortDateString(), dtTSends.Value.ToShortDateString(), txtTSDescription.Text);
			TimeSpan++;
			UpdateTSView();
			Payment = 0;
			UpdateTRView();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			if(MessageBox.Show(String.Concat("Do you wish to remove the selected Financial Period with ", Accounts.Num_Transactions(TimeSpan).ToString(), " transactions?"), TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				Accounts.DeleteFinancialPeriod(TimeSpan);

			TimeSpan = 0;
			UpdateTSView();
			Payment = 0;
			UpdateTRView();
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			float Amount;

			try	{
				Amount = Convert.ToSingle(txtTRAmount.Text);
				Accounts.AddTransaction((txtTRAmount.Text == "" ? 0.0f : Convert.ToSingle(txtTRAmount.Text)), chkTRCredit.Checked, dtTRTime.Value.ToShortDateString(), txtTRDescription.Text);
			}
			catch(FormatException l){
				System.Windows.Forms.MessageBox.Show(String.Concat("'", txtTRAmount.Text, "' is an invalid format. Please enter a decimal number"), TITLE);
			}
				
			UpdateTRView();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			float Amount;

			try	
			{
				Amount = Convert.ToSingle(txtTRAmount.Text);
				Accounts.SetTransaction(TimeSpan, Payment, (txtTRAmount.Text == "" ? 0.0f : Convert.ToSingle(txtTRAmount.Text)), chkTRCredit.Checked, dtTRTime.Value.ToShortDateString(), txtTRDescription.Text);
			}
			catch(FormatException l)
			{
				System.Windows.Forms.MessageBox.Show(String.Concat("'", txtTRAmount.Text, "' is an invalid format. Please enter a decimal number"), TITLE);
			}

			UpdateTRView();
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.DeleteTransaction(TimeSpan, Payment);
			UpdateTRView();
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;
            
			Accounts = new MoneyFile();
			TimeSpan = 0;
			Payment = 0;
			UpdateTSView();
			UpdateTRView();
		}

		private void button8_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;

			openFileDialog1.FileName = "";
			openFileDialog1.Title = TITLE;
			openFileDialog1.ShowDialog();

			if(openFileDialog1.FileName == "")
				return;

			Accounts = new MoneyFile(openFileDialog1.FileName);
			TimeSpan = 0;
			Payment = 0;
			UpdateTSView();
			UpdateTRView();
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;

			openFileDialog1.FileName = "";
			openFileDialog1.Title = TITLE;
			openFileDialog1.ShowDialog();

			if(openFileDialog1.FileName == "")
				return;

			Accounts = new MoneyFile(openFileDialog1.FileName);
			TimeSpan = 0;
			Payment = 0;
			UpdateTSView();
			UpdateTRView();
		}

		private void button10_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.SaveFile();
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;

			Accounts = null;

			TimeSpan = 0;
			Payment = 0;
			lstTS.Items.Clear();
			lstTRAmount.Items.Clear();
			lstTRTime.Items.Clear();
			lstTRDescription.Items.Clear();
		}

		private void button9_Click(object sender, System.EventArgs e)
		{
			if(Accounts != null)
				if(MessageBox.Show("Do you wish to abandon the current Accounts?", TITLE, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
					return;

			Accounts = null;

			TimeSpan = 0;
			Payment = 0;
			lstTS.Items.Clear();
			lstTRAmount.Items.Clear();
			lstTRTime.Items.Clear();
			lstTRDescription.Items.Clear();
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			saveFileDialog1.DefaultExt = ".nac";
			saveFileDialog1.Title = TITLE;
			saveFileDialog1.FileName = Accounts.Filename;
			saveFileDialog1.ShowDialog();
			Accounts.Filename = saveFileDialog1.FileName;

			Accounts.SaveFile();
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			if(Accounts==null)
				return;

			Accounts.SaveFile();
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			Form abt = new about();
			abt.Show();
		}
	}
}
