Title: Maze Artificial Intelligence
Description: You can create any maze and this program wil solve it. It can figure out if there is no solution as well. It is animated using AVIs and was created using MFC. Create your own maze for it to solve or load and edit mazes. This is a good lesson for using STACKs. Also there were animations in the intro and About box but were too large to include in this zip. If you are interested in seeing them my ICQ is 9823848
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=2859&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
