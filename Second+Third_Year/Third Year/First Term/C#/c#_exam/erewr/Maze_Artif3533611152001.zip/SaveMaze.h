#if !defined(AFX_SAVEMAZE_H__A4C8EAC3_0F3E_4603_B25C_88034335FDDA__INCLUDED_)
#define AFX_SAVEMAZE_H__A4C8EAC3_0F3E_4603_B25C_88034335FDDA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SaveMaze.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// SaveMaze dialog

