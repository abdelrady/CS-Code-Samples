
COPYRIGHT NOTICE: Copyright 2002 Per Soderlind - per@soderlind.no

GeoIP.asp is free for non-commercial use. Any commercial usage  requires a
licensing agreement from the author who may be  contacted at the following
email address: per@soderlind.no

DISCLAIMER:

GeoIP.asp is provided as free software, in the hope that it will be useful. 
It is provided "as-is", without warranty of any kind, either expressed or
implied,  including, but not limited to, the implied warranties of
merchantability and fitness  for a particular purpose. The entire risk as to
determining the suitability, quality  and performance of GeoIP.asp are with
you. Should GeoIP.asp prove defective, the  full cost of repair, servicing,
or correction lies with you.


PREREQUESIT:
You must be running ADO 2.5 or later, GeoIP.asp uses ADO Stream 
to access the GeoIP.dat database.

INSTALL:

1) Download the GeoIP.dat database from MaxMind
   http://www.maxmind.com/app/free
2) Put GeoIP.asp, example.asp and GeoIP.dat in a catalog on your web server.
3) Test the installation by accessing the example.asp page
   http://yourserver/path/example.asp
   
   i.e: http://soderlind.no/s/geoip/


METHODS and PROPERTIES:

Properties:
	GeoIPDataBase - Sets the path and filename to GeoIP.dat
	ErrNum - Returns the error number (if <> 0, there's an error)
Methods:
	lookupCountryName - Find an IPs country name
	example:
		strCountryName = oGeoIP.lookupCountryName(strIP)
		
	lookupCountryCode - Find an IPs country code
	example:
		strCountryCode = oGeoIP.lookupCountryCode(strIP)
		
EXAMPLE:

<!--#include file="GeoIP.asp"-->                   
<%                                                  
Dim oGeoIP,strErrMsg
Dim strIP,strCountryName,strCountryCode             
                                                    
Set oGeoIP = New CountryLookup                      
oGeoIP.GeoIPDataBase = Server.MapPath("GeoIP.dat")  
If oGeoIP.ErrNum(strErrMsg) <> 0 Then               
    Response.Write(strErrMsg)                       
Else                                                
    strIP = request.ServerVariables("REMOTE_ADDR")  
    strCountryName = oGeoIP.lookupCountryName(strIP)
    strCountryCode = oGeoIP.lookupCountryCode(strIP)
End If                                              
Set oGeoIP = Nothing                                
%>                             
