BOOT DELETER V1.00
==================
  Author  : Joseph Cox
  Website : http://www.tnk-bootblock.co.uk
  Forum   : http://www.tnk-bootblock.co.uk/forum
  Released: 9th February, 2005.


PURPOSE
-------
Boot Deleter is an application that adds itself to the
Windows Explorer (shell) context menu and allows you to
mark files and folders to be deleted when Windows next
restarts. This allows you to delete items that are locked
by running programs. Items can also be marked for deletion
by passing the file/folder as a command-line argument or
by dropping the item onto the Boot Deleter executable icon.

Boot Deleter was created at the request of Skywalka in
the Software Requests area of the TNK-BootBlock forum.


INSTALLATION
------------
Simply extract the archive to any location and then
double-click on the Boot Deleter.exe file to run
it.


USAGE
-----
Once loaded, click on the Integrate with Windows Shell
button for Boot Deleter to add itself to the Explorer
context menu.

To mark a file or folder for deletion, right-click on
any file/folder and then select Delete at Windows Start.
A new window will appear asking you to confirm your action;
click Accept for Boot Deleter to tell Windows that the
selected item should be deleted when Windows next starts.


COMMAND LINE
------------
If you would like Boot Deleter.exe to mark a file or folder
for deletion via the command line for when Windows next
restarts, you can use the following syntax:

  "Boot Deleter.exe" myfile.txt

Passing a file or folder causes Boot Deleter to ask if the specified
item should be marked for deletion. Automating the Accept/Cancel
process will be available in a new version.

If you would like Boot Deleter to outright delete a file
(just like using the DEL command), then do the following:

  "Boot Deleter.exe" DELETE myfile.txt

Calling Boot Deleter.exe without any parameters will cause the
main interface to appear as normal.


UNINSTALLATION
--------------
Run Boot Deleter and click on the Remove from Windows Shell
button to remove the Delete at Windows Start item from the
Explorer context menu.

Once done, quit the Boot Deleter.exe application and just
delete the Boot Deleter directory to remove the entire
program from your system.


TROUBLE-SHOOTING
----------------
If you get an error when you start the program (about a file missing
or whatever), then you will need to download the VB Runtimes pack:
  http://www.tnk-bootblock.co.uk/?id=vbruntimes

Joseph Cox
(AKA BootBlock)


HISTORY
-------
v1.00 - 9th February, 2005.
  - Initial release.
