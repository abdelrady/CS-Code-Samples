/*****************************************************************
*
*  Application.:  MinesweeperHOOK.dll
*  Module......:  MinesweeperHook.cpp
*  Compiler....:  MS Visual C++
*  Written by..:  Mumtaz Zaheer
*
******************************************************************/

#define WIN32_LEAN_AND_MEAN
#define STRICT

#include <windows.h>
#include <windowsx.h>

extern HINSTANCE	g_hThisDll;
HHOOK				g_hShellHook;
WNDPROC				pfnWndProc;
HWND				g_hwndToMineWindow;

void APIENTRY ShellDll_Hook();
void APIENTRY ShellDll_Unhook();
LRESULT CALLBACK ShellDll_MainHook(int nCode, WPARAM wParam, LPARAM lParam);

LRESULT WINAPI MineSweeper_SubClassWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
