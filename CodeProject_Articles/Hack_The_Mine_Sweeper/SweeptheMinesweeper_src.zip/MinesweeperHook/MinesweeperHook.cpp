#ifdef _MSC_VER
#pragma comment(lib, "kernel32.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "shell32.lib")
#endif

#include "MinesweeperHook.h"

HINSTANCE g_hThisDll;

int APIENTRY DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		g_hThisDll = hInstance;
		break;
	case DLL_PROCESS_DETACH:
		{
			if(pfnWndProc)
			{
				if(IsWindowUnicode(g_hwndToMineWindow))
				{
					SetWindowLongW(g_hwndToMineWindow, GWL_WNDPROC, 
						(LPARAM)(WNDPROC)pfnWndProc);
				}
				else
				{
					SetWindowLongA(g_hwndToMineWindow, GWL_WNDPROC, 
						(LPARAM)(WNDPROC)pfnWndProc);
				}
			}
		}
	}

return TRUE;
}


// Sets up a hook to detect when Minesweeper starts
void APIENTRY ShellDll_Hook()
{
	g_hShellHook = SetWindowsHookEx(WH_CBT, ShellDll_MainHook, g_hThisDll, 0);
}


void APIENTRY ShellDll_Unhook()
{
	if(g_hShellHook != NULL)
		UnhookWindowsHookEx(g_hShellHook);
}


LRESULT CALLBACK ShellDll_MainHook(int nCode, WPARAM wParam, LPARAM lParam)
{
	TCHAR szClass[MAX_PATH] = {0};

	if(nCode < 0)
		return CallNextHookEx(g_hShellHook, nCode, wParam, lParam);

	if(nCode == HCBT_CREATEWND)
	{
		// Get the HWND of the window
		HWND hwndToNewWindow = reinterpret_cast<HWND>(wParam);

		GetClassName(hwndToNewWindow, szClass, MAX_PATH);
		if(!lstrcmpi(szClass, __TEXT("Minesweeper")))
		{
			g_hwndToMineWindow = hwndToNewWindow;

			if(IsWindowUnicode(g_hwndToMineWindow))
			{
				pfnWndProc = (WNDPROC)SetWindowLongW(g_hwndToMineWindow, GWL_WNDPROC, 
					(LPARAM)(WNDPROC)MineSweeper_SubClassWndProc);
			}
			else
			{
				pfnWndProc = (WNDPROC)SetWindowLongA(g_hwndToMineWindow, GWL_WNDPROC, 
					(LPARAM)(WNDPROC)MineSweeper_SubClassWndProc);
			}
		}
	}

	return CallNextHookEx(g_hShellHook, nCode, wParam, lParam);
}

//Minesweeper Subclass wndproc
LRESULT WINAPI MineSweeper_SubClassWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	BOOL bCallDefProc = TRUE;
	LRESULT lResult = 0;
	switch(uMsg)
	{
	case WM_TIMER:
		{
			bCallDefProc = FALSE;		
		}
		break;
	default:
		break;
	}
	if(bCallDefProc)
	{
		if(IsWindowUnicode(hwnd))
		{
			lResult = CallWindowProcW((WNDPROC) (DWORD)pfnWndProc, hwnd, uMsg, wParam, lParam);
		}
		else
		{
			lResult = CallWindowProcA((WNDPROC) (DWORD)pfnWndProc, hwnd, uMsg, wParam, lParam);
		}
	}
	return lResult;
}