Imports System.Data.Odbc
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports System.Configuration
Imports System.Text
Imports System.Collections

'This is an extension of the functionality provided by the Data access application block.
' Works for SQLClient, OLEDB and ODBC providers
Public NotInheritable Class ParameterCache
    Private Sub New()
    End Sub

    Private Shared paramCache As Hashtable = Hashtable.Synchronized(New Hashtable)

    Private Shared Function DiscoverSpParameterSet(ByVal connectionString As String, _
                                                ByVal provider As EnumProviders, _
                                               ByVal spName As String, _
                                               ByVal ParamArray parameterValues() As Object) As IDbDataParameter()

        Dim cn As IDbConnection = ProviderFactory.GetConnection(connectionString, provider)
        Dim cmd As IDbCommand = ProviderFactory.GetCommand(provider)
        Dim discoveredParameters() As IDbDataParameter

        Try
            cn.Open()
            cmd.Connection = cn
            cmd.CommandText = spName
            cmd.CommandType = CommandType.StoredProcedure
            Dim paramType As Type

            Select Case provider
                Case EnumProviders.ODBC
                    OdbcCommandBuilder.DeriveParameters(cmd)
                    paramType = GetType(OdbcParameter)
                Case EnumProviders.SQLClient
                    SqlCommandBuilder.DeriveParameters(cmd)
                    paramType = GetType(SqlParameter)
                Case EnumProviders.OLEDB
                    OleDbCommandBuilder.DeriveParameters(cmd)
                    paramType = GetType(OleDbParameter)
            End Select
            discoveredParameters = Array.CreateInstance(paramType, cmd.Parameters.Count - 1)
            cmd.Parameters.RemoveAt(0)
            cmd.Parameters.CopyTo(discoveredParameters, 0)
        Finally
            cmd.Dispose()
            cn.Dispose()
        End Try

        Return discoveredParameters

    End Function

    Private Shared Function CloneParameters(ByVal originalParameters() As IDbDataParameter) As IDbDataParameter()

        Dim i As Short
        Dim j As Short = originalParameters.Length - 1
        Dim clonedParameters(j) As IDbDataParameter

        For i = 0 To j
            clonedParameters(i) = CType(CType(originalParameters(i), ICloneable).Clone, IDbDataParameter)
        Next

        Return clonedParameters
    End Function


#Region "caching functions"

    ' add parameter array to the cache
    Public Shared Sub CacheParameterSet(ByVal connectionString As String, _
                                    ByVal commandText As String, _
                                    ByVal ParamArray commandParameters() As IDbDataParameter)
        Dim hashKey As String = connectionString + ":" + commandText

        paramCache(hashKey) = commandParameters
    End Sub 'CacheParameterSet

    ' retrieve a parameter array from the cache

    Public Shared Function GetCachedParameterSet(ByVal connectionString As String, ByVal commandText As String) As IDbDataParameter()
        Dim hashKey As String = connectionString + ":" + commandText
        Dim cachedParameters As IDbDataParameter() = CType(paramCache(hashKey), IDbDataParameter())

        If cachedParameters Is Nothing Then
            Return Nothing
        Else
            Return CloneParameters(cachedParameters)
        End If
    End Function 'GetCachedParameterSet

#End Region

    'This is an extension of the functionality provided by the Data access application block.
#Region "Parameter Discovery Functions"


    Public Overloads Shared Function GetSpParameterSet(ByVal connectionString As String, _
                                                   ByVal spName As String, _
                                                    ByVal Provider As EnumProviders _
                                                   ) As IDbDataParameter()

        Dim cachedParameters() As IDbDataParameter
        Dim hashKey As String

        hashKey = connectionString + ":" + spName

        cachedParameters = CType(paramCache(hashKey), IDbDataParameter())

        If (cachedParameters Is Nothing) Then
            paramCache(hashKey) = DiscoverSpParameterSet(connectionString, Provider, spName)
            cachedParameters = CType(paramCache(hashKey), IDbDataParameter())

        End If

        Return CloneParameters(cachedParameters)

    End Function
#End Region

End Class 
