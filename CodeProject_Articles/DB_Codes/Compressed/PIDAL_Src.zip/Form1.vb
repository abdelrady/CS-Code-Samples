Imports DAL
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.Button3 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(48, 24)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 32)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Dataset"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(48, 72)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(88, 32)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Out Params"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(48, 120)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(88, 32)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Cache"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(184, 189)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' This is a simple usage of the data access component to update the changes made to the dataset back to the DB. Here, the Save Dataset method is used
    ' in an ADO.NET transaction.
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim ds As New DataSet
        Dim DAL As New DAL.DataAccess
        Try
            ' I am providing the provider and connn string here. It can also be provided thru config
            DAL.ConnectionString = "server=(local);database=pubs;integrated security=SSPI"
            DAL.Provider = EnumProviders.SQLClient
            DAL.CmdTimeout = 1
            'Start the transaction
            DAL.BeginTrans(IsolationLevel.ReadCommitted)
            'Get the dataset ( I hope some records exist in the DB!)
            ds = DAL.ExecDataSet("Select * from Orders", CommandType.Text)
            ds.Tables(0).TableName = "Orders"

            'Updating an existing record
            ds.Tables(0).Rows(1).Item("CustomerName") = "New Customer"

            'Delete an existing record
            ds.Tables(0).Rows(2).Delete()

            'Add a new record
            Dim dt As DataTable = ds.Tables(0)
            Dim drow As DataRow = ds.Tables(0).NewRow()
            drow.Item(1) = "A new customer"
            drow.Item(2) = "Some Address"
            dt.Rows.Add(drow)


            ' Create the param collection
            'Insert SP param collection
            Dim pmi() As DAL.ParamStruct = New DAL.ParamStruct(2) {}
            pmi(0).direction = ParameterDirection.Output
            pmi(0).ParamName = "@OrderId"
            pmi(0).DataType = DbType.Int16
            pmi(0).sourceColumn = "OrderId"

            pmi(1).direction = ParameterDirection.Input
            pmi(1).ParamName = "@CustomerName"
            pmi(1).DataType = DbType.String
            pmi(1).sourceColumn = "CustomerName"

            pmi(2).direction = ParameterDirection.Input
            pmi(2).ParamName = "@ShippingAddress"
            pmi(2).DataType = DbType.String
            pmi(2).sourceColumn = "ShippingAddress"

            'Update SP param collection
            Dim pmu() As DAL.ParamStruct = New DAL.ParamStruct(2) {}
            pmu(0).direction = ParameterDirection.Input
            pmu(0).ParamName = "@OrderId"
            pmu(0).DataType = DbType.Int16
            pmu(0).sourceColumn = "OrderId"

            pmu(1).direction = ParameterDirection.Input
            pmu(1).ParamName = "@CustomerName"
            pmu(1).DataType = DbType.String
            pmu(1).sourceColumn = "CustomerName"

            pmu(2).direction = ParameterDirection.Input
            pmu(2).ParamName = "@ShippingAddress"
            pmu(2).DataType = DbType.String
            pmu(2).sourceColumn = "ShippingAddress"

            'Delete SP param collection
            Dim pmd() As DAL.ParamStruct = New DAL.ParamStruct(0) {}
            pmd(0).direction = ParameterDirection.Input
            pmd(0).ParamName = "@OrderId"
            pmd(0).DataType = DbType.Int16
            pmd(0).sourceColumn = "OrderId"

            ds.Tables(0).TableName = "Table"
            'Save the records and commit
            DAL.SaveDataSet(ds, "InsertOrder", "DeleteOrder", "UpdateOrder", pmi, pmd, pmu)
            DAL.CommitTrans()


        Catch ex As Exception
            'Abort in case of failure
            DAL.AbortTrans()
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    ' This is a sample which uses the ExecPreparedSQL method. The objective of this method is to return a collection of out params from the SP
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim pmi() As DAL.ParamStruct = New DAL.ParamStruct(1) {}
        pmi(0).direction = ParameterDirection.Output
        pmi(0).ParamName = "@Char1"
        pmi(0).size = 1
        pmi(0).DataType = DbType.AnsiStringFixedLength
        pmi(0).value = DBNull.Value

        pmi(1).direction = ParameterDirection.Output
        pmi(1).size = 1
        pmi(1).ParamName = "@Char2"
        pmi(1).DataType = DbType.AnsiStringFixedLength
        pmi(1).value = DBNull.Value

        Dim DAL As New DAL.DataAccess
        DAL.Provider = EnumProviders.OLEDB
        DAL.ConnectionString = "provider=SQLOLEDB;server=(local);database=pubs;integrated security=SSPI"

        Dim arr As ArrayList = DAL.ExecPreparedSQL("TestCharOut", CommandType.StoredProcedure, pmi)

        MessageBox.Show(CType(arr.Item(0), Char))

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'Way to retrive parameters from the cache. This is just a sample (The dataaccess class does not have methods to take in parameters of type IDBDataParameter.)
        Dim params As IDbDataParameter() = ParameterCache.GetSpParameterSet("provider=SQLOLEDB;server=(local);database=pubs;integrated security=SSPI", "InsertOrder", EnumProviders.OLEDB)
    End Sub

   
End Class




