SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


Create PROCEDURE DeleteOrder
(@OrderId int
)AS
delete from Orders where OrderId = @OrderId 


GO


SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO



CREATE    PROCEDURE InsertOrder
(@OrderId int output,
 @CustomerName varchar(50),
 @ShippingAddress varchar(50)
)
 AS

INSERT INTO Orders (CustomerName, ShippingAddress)
VALUES
(@CustomerName, @ShippingAddress)

SELECT @OrderId=@@IDENTITY


GO

SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO


CREATE      PROCEDURE UpdateOrder
(@OrderId int output,
 @CustomerName varchar(50),
 @ShippingAddress varchar(50)
)
AS


update Orders set 
CustomerName  = @CustomerName ,
ShippingAddress  = @ShippingAddress 
where
OrderId = @OrderId 

GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

Create proc testCharOut
(
	@Char1 VARCHAR(1) OUT,
	@Char2 VARCHAR(1) OUT
)
as 
Begin
	SET @Char1 ='Y'	
	SET @Char1 ='N'


End

GO

