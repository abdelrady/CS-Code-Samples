using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string LoopAgain;
            string EmpName;
            string PropName;
            string PropVal;
            do
            {
                System.Collections.Hashtable EmpProps = new System.Collections.Hashtable();
                Console.WriteLine("Enter Employees Name:");
                EmpName = Console.ReadLine();
                do
                {
                    Console.WriteLine("Enter Property Name:");
                    PropName = Console.ReadLine();
                    Console.WriteLine(string.Format("Enter value for {0}:",PropName));
                    PropVal = Console.ReadLine();
                    EmpProps.Add(PropName, PropVal);
                    Console.WriteLine("Add another Property?");
                    LoopAgain = Console.ReadLine();
                }
                while (LoopAgain.ToUpper() == "Y");
                int RowsAdded = Demo1_DAL.DataSet1.InsertEmployee(EmpName, EmpProps);
                Console.WriteLine(string.Format("{0} records added.",RowsAdded.ToString()));
                Console.WriteLine("Add another Employee?");
                LoopAgain = Console.ReadLine();
            }
            while (LoopAgain.ToUpper() == "Y");
        }
    }
}
