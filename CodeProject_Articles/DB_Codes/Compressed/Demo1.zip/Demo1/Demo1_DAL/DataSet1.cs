﻿namespace Demo1_DAL
{
    partial class DataSet1
    {
        public static int InsertEmployee(string pName, System.Collections.Hashtable pProps)
        {
            int myReturnValue = 0;  // Rows affected
            // Create Table Adapters
            DataSet1TableAdapters.EMPLOYEESTableAdapter taEmp = new DataSet1TableAdapters.EMPLOYEESTableAdapter();
            DataSet1TableAdapters.EMP_PROPERTIESTableAdapter taProps = new DataSet1TableAdapters.EMP_PROPERTIESTableAdapter();
            // Open a Connection on one of the adapters and 
            // Make sure All Adapters are using the same connection.
            taEmp.Connection.Open();
            taProps.Connection = taEmp.Connection;
            // Start a Transaction on the Open Connection
            System.Data.SqlClient.SqlTransaction myTrans = taEmp.Connection.BeginTransaction();
            // Assign the Transaction to our Table Adpaters Command objects
            taEmp.AttachTransaction(myTrans);
            taProps.AttachTransaction(myTrans);
            // Process Updates
            try
            {
                //Retrieve SCOPE_IDENTITY() of new Employee
                int myEmpID = System.Convert.ToInt32(taEmp.InsertScalar(pName)); 
                myReturnValue += 1;
                foreach (System.Collections.DictionaryEntry de in pProps)
                {
                    taProps.Insert(de.Key.ToString(), de.Value.ToString(), myEmpID);
                    myReturnValue += 1;
                }
                // Commit Updates
                myTrans.Commit();
            }
            catch
            {
                // Rollback on any Exception
                myTrans.Rollback();
                myReturnValue = 0;
            }
            finally
            {
                // Dispose of unmanaged resources
                myTrans.Dispose();
                taProps.Dispose();
                taEmp.Dispose();
            }
            return myReturnValue;
        }
    }
}
namespace Demo1_DAL.DataSet1TableAdapters
{
    partial class EMPLOYEESTableAdapter
    {
        public void AttachTransaction(System.Data.SqlClient.SqlTransaction t)
        {
            this.Adapter.InsertCommand.Transaction = t;
            this.Adapter.UpdateCommand.Transaction = t;
            this.Adapter.DeleteCommand.Transaction = t;
            foreach (System.Data.SqlClient.SqlCommand cmd in this.CommandCollection)
            {
                cmd.Transaction = t;
            }
        }
    }
    partial class EMP_PROPERTIESTableAdapter
    {
        public void AttachTransaction(System.Data.SqlClient.SqlTransaction t)
        {
            this.Adapter.InsertCommand.Transaction = t;
            this.Adapter.UpdateCommand.Transaction = t;
            this.Adapter.DeleteCommand.Transaction = t;
            foreach (System.Data.SqlClient.SqlCommand cmd in this.CommandCollection)
            {
                cmd.Transaction = t;
            }
        }
    }
}