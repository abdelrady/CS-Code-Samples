// Disclaimer and Copyright Information
// ADOApp.cs : Implementation of Windows Form Application
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//	2/22/2001	Added support for New/Modify/Delete buttons
//

namespace KSADOApp
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;
    using System.Data;
	using System.Diagnostics;

	using KSDataAccess;
	using KSDiagnostics;

    /// <summary>
    ///    Summary description for Form1.
    /// </summary>
    public class ADOAppMainForm : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.TextBox m_wndCompanyName;
		private System.WinForms.Label label9;
		private System.WinForms.TextBox m_wndTitle;
		private System.WinForms.Label label8;
		private System.WinForms.ToolTip m_wndToolTip;
		private System.WinForms.Button m_wndDeleteBtn;
		private System.WinForms.Button m_wndEditBtn;
		private System.WinForms.Button m_wndCloseBtn;
		private System.WinForms.Button m_wndNewAddBtn;
		private System.WinForms.MenuItem m_wndAboutMenuItem;
		private System.WinForms.MenuItem menuItem1;
		private System.WinForms.MainMenu m_wndMainMenu;
		private System.WinForms.NumericUpDown m_wndRecordUpDown;
		private System.WinForms.TextBox m_wndCountry;
		private System.WinForms.TextBox m_wndZip;
		private System.WinForms.TextBox m_wndState;
		private System.WinForms.TextBox m_wndCity;
		private System.WinForms.TextBox m_wndStreet;
		private System.WinForms.TextBox m_wndContactName;
		private System.WinForms.TextBox m_wndCustID;
		private System.WinForms.Label label7;
		private System.WinForms.Label label6;
		private System.WinForms.Label label5;
		private System.WinForms.Label label4;
		private System.WinForms.Label label3;
		private System.WinForms.GroupBox groupBox1;
		private System.WinForms.Label label2;
		private System.WinForms.Label label1;
		private System.WinForms.GroupBox m_wndCustRecGroup;

        public ADOAppMainForm()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
			InitDB ();

			// Initialize the controls on the form.
			InitControls ();
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager (typeof(ADOAppMainForm));
			this.components = new System.ComponentModel.Container ();
			this.m_wndZip = new System.WinForms.TextBox ();
			this.m_wndCustRecGroup = new System.WinForms.GroupBox ();
			this.m_wndCustID = new System.WinForms.TextBox ();
			this.m_wndNewAddBtn = new System.WinForms.Button ();
			this.m_wndStreet = new System.WinForms.TextBox ();
			this.label2 = new System.WinForms.Label ();
			this.m_wndToolTip = new System.WinForms.ToolTip (this.components);
			this.groupBox1 = new System.WinForms.GroupBox ();
			this.m_wndState = new System.WinForms.TextBox ();
			this.m_wndCountry = new System.WinForms.TextBox ();
			this.m_wndRecordUpDown = new System.WinForms.NumericUpDown ();
			this.m_wndMainMenu = new System.WinForms.MainMenu ();
			this.m_wndEditBtn = new System.WinForms.Button ();
			this.menuItem1 = new System.WinForms.MenuItem ();
			this.m_wndContactName = new System.WinForms.TextBox ();
			this.label4 = new System.WinForms.Label ();
			this.label5 = new System.WinForms.Label ();
			this.label6 = new System.WinForms.Label ();
			this.m_wndTitle = new System.WinForms.TextBox ();
			this.m_wndAboutMenuItem = new System.WinForms.MenuItem ();
			this.label8 = new System.WinForms.Label ();
			this.label9 = new System.WinForms.Label ();
			this.label7 = new System.WinForms.Label ();
			this.m_wndCity = new System.WinForms.TextBox ();
			this.m_wndCompanyName = new System.WinForms.TextBox ();
			this.label3 = new System.WinForms.Label ();
			this.m_wndDeleteBtn = new System.WinForms.Button ();
			this.label1 = new System.WinForms.Label ();
			this.m_wndCloseBtn = new System.WinForms.Button ();
			m_wndRecordUpDown.BeginInit ();
			//@this.TrayHeight = 90;
			//@this.TrayLargeIcon = false;
			//@this.SetLocalizable (true);
			//@this.TrayAutoArrange = true;
			m_wndZip.Location = (System.Drawing.Point) resources.GetObject ("m_wndZip.Location");
			m_wndZip.TabIndex = (int) resources.GetObject ("m_wndZip.TabIndex");
			m_wndZip.Size = (System.Drawing.Size) resources.GetObject ("m_wndZip.Size");
			m_wndCustRecGroup.Location = (System.Drawing.Point) resources.GetObject ("m_wndCustRecGroup.Location");
			m_wndCustRecGroup.TabIndex = (int) resources.GetObject ("m_wndCustRecGroup.TabIndex");
			m_wndCustRecGroup.TabStop = false;
			m_wndCustRecGroup.Text = (string) resources.GetObject ("m_wndCustRecGroup.Text");
			m_wndCustRecGroup.Size = (System.Drawing.Size) resources.GetObject ("m_wndCustRecGroup.Size");
			m_wndCustID.Location = (System.Drawing.Point) resources.GetObject ("m_wndCustID.Location");
			m_wndCustID.TabIndex = (int) resources.GetObject ("m_wndCustID.TabIndex");
			m_wndCustID.Size = (System.Drawing.Size) resources.GetObject ("m_wndCustID.Size");
			m_wndNewAddBtn.Location = (System.Drawing.Point) resources.GetObject ("m_wndNewAddBtn.Location");
			m_wndToolTip.SetToolTip (m_wndNewAddBtn, (string) resources.GetObject ("m_wndNewAddBtn.ToolTip"));
			m_wndNewAddBtn.Size = (System.Drawing.Size) resources.GetObject ("m_wndNewAddBtn.Size");
			m_wndNewAddBtn.TabIndex = (int) resources.GetObject ("m_wndNewAddBtn.TabIndex");
			m_wndNewAddBtn.Text = (string) resources.GetObject ("m_wndNewAddBtn.Text");
			m_wndNewAddBtn.Click += new System.EventHandler (this.OnNewAdd);
			m_wndStreet.Location = (System.Drawing.Point) resources.GetObject ("m_wndStreet.Location");
			m_wndStreet.Multiline = true;
			m_wndStreet.TabIndex = (int) resources.GetObject ("m_wndStreet.TabIndex");
			m_wndStreet.Size = (System.Drawing.Size) resources.GetObject ("m_wndStreet.Size");
			label2.Location = (System.Drawing.Point) resources.GetObject ("label2.Location");
			label2.Text = (string) resources.GetObject ("label2.Text");
			label2.Size = (System.Drawing.Size) resources.GetObject ("label2.Size");
			label2.TabIndex = (int) resources.GetObject ("label2.TabIndex");
			//@m_wndToolTip.SetLocation (new System.Drawing.Point (134, 7));
			m_wndToolTip.Active = true;
			groupBox1.Location = (System.Drawing.Point) resources.GetObject ("groupBox1.Location");
			groupBox1.TabIndex = (int) resources.GetObject ("groupBox1.TabIndex");
			groupBox1.TabStop = false;
			groupBox1.Text = (string) resources.GetObject ("groupBox1.Text");
			groupBox1.Size = (System.Drawing.Size) resources.GetObject ("groupBox1.Size");
			m_wndState.Location = (System.Drawing.Point) resources.GetObject ("m_wndState.Location");
			m_wndState.TabIndex = (int) resources.GetObject ("m_wndState.TabIndex");
			m_wndState.Size = (System.Drawing.Size) resources.GetObject ("m_wndState.Size");
			m_wndCountry.Location = (System.Drawing.Point) resources.GetObject ("m_wndCountry.Location");
			m_wndCountry.Text = (string) resources.GetObject ("m_wndCountry.Text");
			m_wndCountry.TabIndex = (int) resources.GetObject ("m_wndCountry.TabIndex");
			m_wndCountry.Size = (System.Drawing.Size) resources.GetObject ("m_wndCountry.Size");
			m_wndRecordUpDown.Value = new decimal (1);
			m_wndRecordUpDown.Location = (System.Drawing.Point) resources.GetObject ("m_wndRecordUpDown.Location");
			m_wndRecordUpDown.Size = (System.Drawing.Size) resources.GetObject ("m_wndRecordUpDown.Size");
			m_wndRecordUpDown.ThousandsSeparator = true;
			m_wndToolTip.SetToolTip (m_wndRecordUpDown, (string) resources.GetObject ("m_wndRecordUpDown.ToolTip"));
			m_wndRecordUpDown.TabIndex = (int) resources.GetObject ("m_wndRecordUpDown.TabIndex");
			m_wndRecordUpDown.ValueChanged += new System.EventHandler (this.OnUpdownValueChange);
			//@m_wndMainMenu.SetLocation (new System.Drawing.Point (7, 7));
			m_wndMainMenu.MenuItems.All = new System.WinForms.MenuItem[1] {this.menuItem1};
			m_wndEditBtn.Location = (System.Drawing.Point) resources.GetObject ("m_wndEditBtn.Location");
			m_wndToolTip.SetToolTip (m_wndEditBtn, (string) resources.GetObject ("m_wndEditBtn.ToolTip"));
			m_wndEditBtn.Size = (System.Drawing.Size) resources.GetObject ("m_wndEditBtn.Size");
			m_wndEditBtn.TabIndex = (int) resources.GetObject ("m_wndEditBtn.TabIndex");
			m_wndEditBtn.Text = (string) resources.GetObject ("m_wndEditBtn.Text");
			m_wndEditBtn.Click += new System.EventHandler (this.OnEditRecord);
			menuItem1.Text = (string) resources.GetObject ("menuItem1.Text");
			menuItem1.Index = 0;
			menuItem1.MenuItems.All = new System.WinForms.MenuItem[1] {this.m_wndAboutMenuItem};
			m_wndContactName.Location = (System.Drawing.Point) resources.GetObject ("m_wndContactName.Location");
			m_wndContactName.TabIndex = (int) resources.GetObject ("m_wndContactName.TabIndex");
			m_wndContactName.Size = (System.Drawing.Size) resources.GetObject ("m_wndContactName.Size");
			label4.Location = (System.Drawing.Point) resources.GetObject ("label4.Location");
			label4.Text = (string) resources.GetObject ("label4.Text");
			label4.Size = (System.Drawing.Size) resources.GetObject ("label4.Size");
			label4.TabIndex = (int) resources.GetObject ("label4.TabIndex");
			label5.Location = (System.Drawing.Point) resources.GetObject ("label5.Location");
			label5.Text = (string) resources.GetObject ("label5.Text");
			label5.Size = (System.Drawing.Size) resources.GetObject ("label5.Size");
			label5.TabIndex = (int) resources.GetObject ("label5.TabIndex");
			label6.Location = (System.Drawing.Point) resources.GetObject ("label6.Location");
			label6.Text = (string) resources.GetObject ("label6.Text");
			label6.Size = (System.Drawing.Size) resources.GetObject ("label6.Size");
			label6.TabIndex = (int) resources.GetObject ("label6.TabIndex");
			m_wndTitle.Location = (System.Drawing.Point) resources.GetObject ("m_wndTitle.Location");
			m_wndTitle.TabIndex = (int) resources.GetObject ("m_wndTitle.TabIndex");
			m_wndTitle.Size = (System.Drawing.Size) resources.GetObject ("m_wndTitle.Size");
			m_wndAboutMenuItem.Text = (string) resources.GetObject ("m_wndAboutMenuItem.Text");
			m_wndAboutMenuItem.Shortcut = (System.WinForms.Shortcut) resources.GetObject ("m_wndAboutMenuItem.Shortcut");
			m_wndAboutMenuItem.Index = 0;
			m_wndAboutMenuItem.Click += new System.EventHandler (this.OnAboutClick);
			label8.Location = (System.Drawing.Point) resources.GetObject ("label8.Location");
			label8.Text = (string) resources.GetObject ("label8.Text");
			label8.Size = (System.Drawing.Size) resources.GetObject ("label8.Size");
			label8.TabIndex = (int) resources.GetObject ("label8.TabIndex");
			label9.Location = (System.Drawing.Point) resources.GetObject ("label9.Location");
			label9.Text = (string) resources.GetObject ("label9.Text");
			label9.Size = (System.Drawing.Size) resources.GetObject ("label9.Size");
			label9.TabIndex = (int) resources.GetObject ("label9.TabIndex");
			label7.Location = (System.Drawing.Point) resources.GetObject ("label7.Location");
			label7.Text = (string) resources.GetObject ("label7.Text");
			label7.Size = (System.Drawing.Size) resources.GetObject ("label7.Size");
			label7.TabIndex = (int) resources.GetObject ("label7.TabIndex");
			m_wndCity.Location = (System.Drawing.Point) resources.GetObject ("m_wndCity.Location");
			m_wndCity.TabIndex = (int) resources.GetObject ("m_wndCity.TabIndex");
			m_wndCity.Size = (System.Drawing.Size) resources.GetObject ("m_wndCity.Size");
			m_wndCompanyName.Location = (System.Drawing.Point) resources.GetObject ("m_wndCompanyName.Location");
			m_wndCompanyName.TabIndex = (int) resources.GetObject ("m_wndCompanyName.TabIndex");
			m_wndCompanyName.Size = (System.Drawing.Size) resources.GetObject ("m_wndCompanyName.Size");
			label3.Location = (System.Drawing.Point) resources.GetObject ("label3.Location");
			label3.Text = (string) resources.GetObject ("label3.Text");
			label3.Size = (System.Drawing.Size) resources.GetObject ("label3.Size");
			label3.TabIndex = (int) resources.GetObject ("label3.TabIndex");
			m_wndDeleteBtn.Location = (System.Drawing.Point) resources.GetObject ("m_wndDeleteBtn.Location");
			m_wndToolTip.SetToolTip (m_wndDeleteBtn, (string) resources.GetObject ("m_wndDeleteBtn.ToolTip"));
			m_wndDeleteBtn.Size = (System.Drawing.Size) resources.GetObject ("m_wndDeleteBtn.Size");
			m_wndDeleteBtn.TabIndex = (int) resources.GetObject ("m_wndDeleteBtn.TabIndex");
			m_wndDeleteBtn.Text = (string) resources.GetObject ("m_wndDeleteBtn.Text");
			m_wndDeleteBtn.Click += new System.EventHandler (this.OnDeleteRecord);
			label1.Location = (System.Drawing.Point) resources.GetObject ("label1.Location");
			label1.Text = (string) resources.GetObject ("label1.Text");
			label1.Size = (System.Drawing.Size) resources.GetObject ("label1.Size");
			label1.TabIndex = (int) resources.GetObject ("label1.TabIndex");
			m_wndCloseBtn.Location = (System.Drawing.Point) resources.GetObject ("m_wndCloseBtn.Location");
			m_wndToolTip.SetToolTip (m_wndCloseBtn, (string) resources.GetObject ("m_wndCloseBtn.ToolTip"));
			m_wndCloseBtn.DialogResult = System.WinForms.DialogResult.Cancel;
			m_wndCloseBtn.Size = (System.Drawing.Size) resources.GetObject ("m_wndCloseBtn.Size");
			m_wndCloseBtn.TabIndex = (int) resources.GetObject ("m_wndCloseBtn.TabIndex");
			m_wndCloseBtn.Text = (string) resources.GetObject ("m_wndCloseBtn.Text");
			m_wndCloseBtn.Click += new System.EventHandler (this.OnClose);
			this.Text = (string) resources.GetObject ("$this.Text");
			this.MaximizeBox = (bool) resources.GetObject ("$this.MaximizeBox");
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.CancelButton = this.m_wndCloseBtn;
			this.HelpButton = (bool) resources.GetObject ("$this.HelpButton");
			this.Menu = this.m_wndMainMenu;
			this.ClientSize = (System.Drawing.Size) resources.GetObject ("$this.ClientSize");
			this.Controls.Add (this.m_wndDeleteBtn);
			this.Controls.Add (this.m_wndEditBtn);
			this.Controls.Add (this.m_wndCloseBtn);
			this.Controls.Add (this.m_wndNewAddBtn);
			this.Controls.Add (this.m_wndRecordUpDown);
			this.Controls.Add (this.m_wndCustRecGroup);
			m_wndCustRecGroup.Controls.Add (this.m_wndCompanyName);
			m_wndCustRecGroup.Controls.Add (this.label9);
			m_wndCustRecGroup.Controls.Add (this.m_wndTitle);
			m_wndCustRecGroup.Controls.Add (this.label8);
			m_wndCustRecGroup.Controls.Add (this.m_wndContactName);
			m_wndCustRecGroup.Controls.Add (this.m_wndCustID);
			m_wndCustRecGroup.Controls.Add (this.groupBox1);
			m_wndCustRecGroup.Controls.Add (this.label2);
			m_wndCustRecGroup.Controls.Add (this.label1);
			groupBox1.Controls.Add (this.m_wndCountry);
			groupBox1.Controls.Add (this.m_wndZip);
			groupBox1.Controls.Add (this.m_wndState);
			groupBox1.Controls.Add (this.m_wndCity);
			groupBox1.Controls.Add (this.m_wndStreet);
			groupBox1.Controls.Add (this.label7);
			groupBox1.Controls.Add (this.label6);
			groupBox1.Controls.Add (this.label5);
			groupBox1.Controls.Add (this.label4);
			groupBox1.Controls.Add (this.label3);
			m_wndRecordUpDown.EndInit ();
		}

		/// <summary>
		/// Message handler for click on Close button
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnClose (object sender, System.EventArgs e)
		{

		}

		/// <summary>
		/// Message handler for click on Delete button.
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnDeleteRecord (object sender, System.EventArgs e)
		{
			m_bNewButtonActive = true;

			// Get the ID of record. Make sure that its not empty.
			string strID = m_wndCustID.Text;
			if (0 == strID.Length)
			{
				return;
			}

			// Create a new instance of data access class.
			KSCustomerDataAccess data = new KSCustomerDataAccess ();

			try
			{
				// Initialize the connection.
				data.Intialize ();

				int nStatus = 0;
				if (false == data.DeleteRecord (strID, out nStatus))
				{
					// If delete action failed, check the status parameter to
					// get reason of failure.
					MessageBox.Show ("Failed to delete the record");
				}
			}
			finally
			{
				// Makes sure that we have shut down the database connection.
				data.ShutDown ();
			}

			UpdateControlsStatus ();
		}

		/// <summary>
		/// Message handler for click on Edit button
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnEditRecord (object sender, System.EventArgs e)
		{
			m_bNewButtonActive = true;
			KSCustomerRecord record = new KSCustomerRecord ();
			KSAddress addr = new KSAddress ();
			record.ID = m_wndCustID.Text;
			record.ContactName = m_wndContactName.Text;
			record.CompanyName = m_wndCompanyName.Text;
			record.ContactTitle = m_wndTitle.Text;
			addr.Address = m_wndStreet.Text;
			addr.City = m_wndCity.Text;
			addr.State = m_wndState.Text;
			addr.Zip = m_wndZip.Text;
			addr.Country = m_wndCountry.Text;
			record.Address = addr;

			KSCustomerDataAccess dataAccess = null;
			int nStatus = 0;

			try
			{
				dataAccess = new KSCustomerDataAccess ();

				// Initialize the database connection.
				dataAccess.Intialize ();
				if (true == dataAccess.Initialized)
				{
					if (false == dataAccess.EditRecord ((KSRecord)record, out nStatus))
					{
						MessageBox.Show ("Failed to Edit Record");
					}
				}

			}
			finally
			{
				if (null != dataAccess && true == dataAccess.Initialized)
				{
					dataAccess.ShutDown ();
				}
			}

			UpdateControlsStatus ();
		}

		/// <summary>
		/// Message handler for click on New button.
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnNewAdd (object sender, System.EventArgs e)
		{
			if (m_bNewButtonActive)
			{
				m_wndCustID.Text = "";
				m_wndContactName.Text = "";
				m_wndCompanyName.Text = "";
				m_wndTitle.Text = "";
				m_wndStreet.Text = "";
				m_wndCity.Text = "";
				m_wndState.Text = "";
				m_wndZip.Text = "";
				m_wndCountry.Text = "";
			}
			else
			{
				int nStatus = 0;
				KSCustomerRecord record = new KSCustomerRecord ();
				KSAddress addr = new KSAddress ();

				record.ID = m_wndCustID.Text;
				record.ContactName = m_wndContactName.Text;
				record.CompanyName = m_wndCompanyName.Text;
				record.ContactTitle = m_wndTitle.Text;

				addr.Address = m_wndStreet.Text;
				addr.City = m_wndCity.Text;
				addr.State = m_wndState.Text;
				addr.Zip = m_wndZip.Text;
				addr.Country = m_wndCountry.Text;

				record.Address = addr;

				// Create a new instance of data access class.
				KSCustomerDataAccess data = new KSCustomerDataAccess ();

				try
				{
					// Initialize the connection.
					data.Intialize ();

					// Get all the customer records from database.
					if (false == data.AddRecord (record, out nStatus))
					{
						MessageBox.Show ("Failed to add record");
					}
				}
				finally
				{
					// Makes sure that we have shut down the database connection.
					data.ShutDown ();
				}
				
				
			}
			m_bNewButtonActive = !m_bNewButtonActive;
			UpdateControlsStatus ();
		}

		/// <summary>
		/// Even handler for click on About menu item in Help menu.
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnAboutClick (object sender, System.EventArgs e)
		{
			m_bNewButtonActive = !m_bNewButtonActive;
			About abt = new About ();
			abt.ShowDialog ();
		}

		/// <summary>
		/// Event handler for click in UpDown control.
		/// </summary>
		/// <param name="sender"> </param>
		/// <param name="e"> </param>
		protected void OnUpdownValueChange (object sender, System.EventArgs e)
		{
			UpdateControlValues (m_wndRecordUpDown.Value.ToInt32 () - 1);
		}

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static void Main(string[] args) 
        {
			Trace.Listeners.Clear();
			KSTraceListener myListener = new KSTraceListener ("Logfile.log", true);
			Trace.Listeners.Add(myListener);
			Trace.Write ("Starting ADO Application");
            Application.Run(new ADOAppMainForm());
			Trace.Write ("Closing ADO Application");
			myListener.Close ();
        }

		/// <summary>
		/// Function intiates the database connection and then make a call to
		/// get all the customer records from DB.
		/// </summary>
		private void InitDB ()
		{
			// Create a new instance of data access class.
			KSCustomerDataAccess data = new KSCustomerDataAccess ();

			try
			{
				// Initialize the connection.
				data.Intialize ();

				// Get all the customer records from database.
				if (-1 == data.GetRecords (out m_CustRecords))
				{
					MessageBox.Show (data.LastErrorMsg);
				}
			}
			finally
			{
				// Makes sure that we have shut down the database connection.
				data.ShutDown ();
			}
		}

		private void InitControls ()
		{
			// Makes ure that we have atleast one record to show.
			if (m_CustRecords.Count == 0)
			{
				return;
			}

			// Set the flag for New button to be active.
			m_bNewButtonActive = true;

			// Set the min & max limit valus for updown control..
			m_wndRecordUpDown.Minimum = 1;
			m_wndRecordUpDown.Maximum = m_CustRecords.Count;
			// Set the increment value for click.
			m_wndRecordUpDown.Increment = 1;
			// Set the initial value to 1.
			m_wndRecordUpDown.Value = 1;

			// UpdateValues in the edit controls.
			UpdateControlValues (m_wndRecordUpDown.Value.ToInt32 () - 1);
		}

		/// <summary>
		/// Function updates the staus of all controls on the dialog box
		/// depeneding on the current status of the updown control and
		/// other record values.
		/// </summary>
		private void UpdateControlsStatus ()
		{
			m_wndNewAddBtn.Text = (m_bNewButtonActive == true) ? "New" : "Add";
		}

		/// <summary>
		///	Function will update the values in all the edit controls showing
		///	different record attributes & values. 
		///
		/// </summary>
		/// <param name="nIdx"> Zero based index of record in collection</param>
		private void UpdateControlValues (int nIdx)
		{
			KSCustomerRecord record = m_CustRecords.Item (nIdx);
			m_wndCustID.Text = record.ID;
			m_wndContactName.Text = record.ContactName;
			m_wndCompanyName.Text = record.CompanyName;
			m_wndTitle.Text = record.ContactTitle;
			m_wndStreet.Text = record.Address.Address;
			m_wndCity.Text = record.Address.City;
			m_wndState.Text = record.Address.State;
			m_wndZip.Text = record.Address.Zip;
			m_wndCountry.Text = record.Address.Country;
		}

		private bool m_bNewButtonActive;
		private KSCustomerRecords m_CustRecords;
    }
}
