namespace KSADOApp
{
    using System;
    using System.Drawing;
    using System.Collections;
    using System.ComponentModel;
    using System.WinForms;

    /// <summary>
    ///    Summary description for About.
    /// </summary>
    public class About : System.WinForms.Form
    {
        /// <summary>
        ///    Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components;
		private System.WinForms.LinkLabel linkLabel1;
		private System.WinForms.Label label1;
		private System.WinForms.TextBox textBox1;

        public About()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        ///    Clean up any resources being used.
        /// </summary>
        public override void Dispose()
        {
            base.Dispose();
            components.Dispose();
        }

        /// <summary>
        ///    Required method for Designer support - do not modify
        ///    the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container ();
			this.label1 = new System.WinForms.Label ();
			this.linkLabel1 = new System.WinForms.LinkLabel ();
			this.textBox1 = new System.WinForms.TextBox ();
			//@this.TrayHeight = 0;
			//@this.TrayLargeIcon = false;
			//@this.TrayAutoArrange = true;
			label1.Location = new System.Drawing.Point (12, 12);
			label1.Text = "Tutorial Showing ADO.NET USe For Accessing Data From a Database.";
			label1.Size = new System.Drawing.Size (332, 23);
			label1.TabIndex = 1;
			linkLabel1.Text = "naveenkohli@netzero.net";
			linkLabel1.Size = new System.Drawing.Size (132, 20);
			linkLabel1.TabIndex = 2;
			linkLabel1.TabStop = true;
			linkLabel1.Location = new System.Drawing.Point (114, 248);
			textBox1.Location = new System.Drawing.Point (8, 56);
			textBox1.ReadOnly = true;
			textBox1.Text = "Disclaimer and Copyright Information\nAll rights reserved.\nWritten by Naveen K Kohli (naveenkohli@netzero.net)\nVersion 1.0\n\n Distribute freely, except: don't remove my name from the source or documentation (don't take credit for my work), mark your changes (don't get me blamed for your possible bugs), don't alter or remove this notice. No warrantee of any kind, express or implied, is included with this software; use at your own risk, responsibility for damages (if any) to anyone resulting from the use of this software rests entirely with the user.\n Send bug reports, bug fixes, enhancements, requests, flames, etc. to naveenkohli@netzero.net";
			textBox1.Multiline = true;
			textBox1.BorderStyle = System.WinForms.BorderStyle.FixedSingle;
			textBox1.TabIndex = 0;
			textBox1.Size = new System.Drawing.Size (336, 180);
			this.Text = "About ADO.Net Tutorial";
			this.AutoScaleBaseSize = new System.Drawing.Size (5, 13);
			this.ClientSize = new System.Drawing.Size (360, 281);
			this.Controls.Add (this.linkLabel1);
			this.Controls.Add (this.label1);
			this.Controls.Add (this.textBox1);
		}
    }
}
