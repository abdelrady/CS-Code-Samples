// Disclaimer and Copyright Information
// KSCommunicationInfo.cs : Implementation of KSCommunicationInfo class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/23/2001	Initial Creation
//
namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public class KSCommunicationInfo
    {
		protected string m_strHomePhone;
		protected string m_strHomeFax;
		protected string m_strWorkPhone;
		protected string m_strWorkFax;
		protected string m_strPager;
		protected string m_strMobile;
		protected string m_strHomeEmail1;
		protected string m_strHomeEmail2;
		protected string m_strWorkEmail;
		protected string m_strOtherEmail;
        public KSCommunicationInfo()
        {
            m_strHomePhone = "";
		 	m_strHomeFax = "";
		 	m_strWorkPhone = "";
		 	m_strWorkFax = "";
		 	m_strPager = "";
		 	m_strMobile = "";
		 	m_strHomeEmail1 = "";
		 	m_strHomeEmail2 = "";
		 	m_strWorkEmail = "";
		 	m_strOtherEmail = "";
        }

		public string HomePhone
		{
			get
			{
			
				return m_strHomePhone;
			}
			set
			{
				m_strHomePhone = value;
			}
		}

		public string HomeFax
		{
			get
			{
			
				return m_strHomeFax;
			}
			set
			{
				m_strHomeFax = value;
			}
		}

		public string WorkPhone
		{
			get
			{
			
				return m_strWorkPhone;
			}
			set
			{
				m_strWorkPhone = value;
			}
		}

		public string WorkFax
		{
			get
			{
			
				return m_strWorkFax;
			}
			set
			{
				m_strWorkFax = value;
			}
		}

		public string Pager
		{
			get
			{
			
				return m_strPager;
			}
			set
			{
				m_strPager = value;
			}
		}

		public string MobilePhone
		{
			get
			{
			
				return m_strMobile;
			}
			set
			{
				m_strMobile = value;
			}
		}

		public string HomeEmail1
		{
			get
			{
			
				return m_strHomeEmail1;
			}
			set
			{
				m_strHomeEmail1 = value;
			}
		}

		public string HomeEmail2
		{
			get
			{
			
				return m_strHomeEmail2;
			}
			set
			{
				m_strHomeEmail2 = value;
			}
		}

		public string WorkEmail
		{
			get
			{
			
				return m_strWorkEmail;
			}
			set
			{
				m_strWorkEmail = value;
			}
		}

		public string OtherEmail
		{
			get
			{
			
				return m_strOtherEmail;
			}
			set
			{
				m_strOtherEmail = value;
			}
		}
    }
}
