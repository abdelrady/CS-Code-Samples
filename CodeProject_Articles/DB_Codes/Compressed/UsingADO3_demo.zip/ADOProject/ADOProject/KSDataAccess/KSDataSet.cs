namespace KSDataAccess
{
    using System;
	using System.Data;
	using KSDiagnostics;
	using System.Diagnostics;	// required for Trace/Debug classes.
	using System.ComponentModel;

    /// <summary>
    ///    Base class for data set objects
    /// </summary>
    public class KSDataSet
{
        public KSDataSet()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
        }

		public static void SetEventHandlers (DataSet dataSet)
		{
			
		}
		public static void PropertyChangedEvtHandler (object sender, PropertyChangedEventArgs args)
		{
			Trace.Write ("Property Change Notification: " + args.PropertyName);
		}
    }
}
