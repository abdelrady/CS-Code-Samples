namespace KSDiagnostics
{
    using System;
	using System.Data.ADO;

    /// <summary>
    ///    
    /// </summary>
    public class KSErrorHandler
    {
        public KSErrorHandler()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
        }

		public static String GenerateErrorMsg (ADOException ex)
		{
			String msg = "";

			// Get the count of erros generated.
			ADOErrors errors = ex.Errors;
			int nCount = errors.Count;
			for (int i = 0; i < nCount; i++)
			{
				msg += "Error: ";
				msg += (i + 1).ToString ();
				msg += "\n";

				// Add the short description of the error.
				msg += "Message: " + errors[i].Message;
				msg += "\n";
				
				// Add thr name of the source that generated the error.
				msg += "Source: " + errors[i].Source;
				msg += "\n";

				// Add the database specific error information.
				msg += "Native: " + errors[i].NativeError.ToString();
				msg += "\n";

				// Add the five-character error code following the ANSI SQL
				// standard for the database.
				msg += "SQL: " + errors[i].SQLState;
				msg += "\n";
			}
			return msg;
		}
    }
}
