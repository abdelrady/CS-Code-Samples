namespace KSDataAccess
{
    using System;
	using System.Collections;

    /// <summary>
    ///    
    /// </summary>
    public class KSProductRecords : IEnumerable
    {
		private ArrayList m_Records;
        public KSProductRecords()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
			m_Records = new ArrayList ();
        }

		public long Count
		{
			get
			{
				return m_Records.Count;
			}
		}

		public int Add (KSProductRecord record)
		{
			return m_Records.Add (record);
		}

		public void Clear ()
		{
			m_Records.Clear ();
		}

		public KSProductRecord Item (int nIdx)
		{
			if (nIdx > 0 || nIdx < Count)
			{
				return (KSProductRecord)m_Records[nIdx];
			}

			return null;
		}

		public IEnumerator GetEnumerator ()
		{
			return new KSProductsEnumerator (this);
		}

		private class KSProductsEnumerator : IEnumerator
		{
			private int nPosition = -1;
			private KSProductRecords m_Records;

			public KSProductsEnumerator (KSProductRecords records)
			{
				this.m_Records = records;
			}

			public void Reset ()
			{
				nPosition = -1;
			}

			public bool MoveNext ()
			{
				if (nPosition < m_Records.Count - 1)
				{
					nPosition++;
					return true;
				}
				return false;
			}

			public Object Current
			{
				get
				{
					return m_Records.m_Records[nPosition];
				}
			}

		}
    }
}
