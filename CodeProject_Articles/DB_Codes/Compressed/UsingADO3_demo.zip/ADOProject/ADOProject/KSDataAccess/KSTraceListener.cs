// Disclaimer and Copyright Information
// KSTraceListener.cs : Implementation of KSTraceListener class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/23/2001	Initial Creation
//

namespace KSDiagnostics
{
    using System;
	using System.IO;			// required for file IO
	using System.Diagnostics;	// required for Trace/Debug classes.

    /// <summary>
    ///    
    /// </summary>
    public class KSTraceListener : System.Diagnostics.TextWriterTraceListener
    {
		protected bool m_bFileNameInitialized;
		protected string m_strLogFile;
		protected FileStream m_File;
		protected StreamWriter m_StreamWriter;
 
  		public KSTraceListener (string strFileName, bool bNew)
		{
			// File name should not be empty.
			m_bFileNameInitialized = false;
			Debug.Assert (0 != strFileName.Length);
			if (0 == strFileName.Length)
			{
				throw new Exception ("Empty File Name Provided");
			}
			m_strLogFile = strFileName;

			// Create the file to log the messages.
			try
			{
				m_File = new FileStream (strFileName, FileMode.OpenOrCreate, FileAccess.Write);
				m_StreamWriter = new StreamWriter (m_File);
				// Set the file pointer to the end.
				m_StreamWriter.BaseStream.Seek (0, SeekOrigin.End);

				m_StreamWriter.Write (this.GetTimeStamp ());
				m_StreamWriter.WriteLine ("************* Log File Started *************");
				m_StreamWriter.WriteLine ();

				// Update underlying file
				m_StreamWriter.Flush();
			}
			catch
			{
				m_bFileNameInitialized = false;
				throw new Exception ("Failed to create log file");
			}

			m_bFileNameInitialized = true;
		}

		override public void Close ()
		{
			if (true == m_bFileNameInitialized)
			{
				m_StreamWriter.WriteLine ();
				m_StreamWriter.Write (this.GetTimeStamp ());
				m_StreamWriter.WriteLine ("************* Log File Closed **************");

				// Update underlying file
				m_StreamWriter.Flush(); 

				// Close the StreamWriter.
				m_StreamWriter.Close ();
			}
		}

		override public void Write (string strMsg)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + strMsg);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}
		}

		override public void Write (Object obj)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + obj.ToString ());
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}
		}

		override public void Write (Object obj, string strCatgory)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + obj.ToString () + ":" + strCatgory);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}	
		}

		override public void Write (string strCat, string strMsg)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + strCat + ":" + strMsg);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}	
		}

		override public void WriteLine (string strMsg)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + strMsg);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}
		}

		override public void WriteLine (Object obj)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + obj.ToString ());
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}
		}

		override public void WriteLine (Object obj, string strCatgory)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + obj.ToString () + ":" + strCatgory);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}	
		}

		override public void WriteLine (string strCat, string strMsg)
		{
			Debug.Assert (null != m_StreamWriter);
			try
			{
				m_StreamWriter.WriteLine (this.GetTimeStamp () + strCat + ":" + strMsg);
				m_StreamWriter.Flush();
			}
			catch (IOException excpt)
			{
				Console.Write (excpt.Message);
			}	
		}

		private string GetTimeStamp ()
		{
			DateTime tm = DateTime.Now;
			return tm.ToString () + "->";
		}
    }
}
