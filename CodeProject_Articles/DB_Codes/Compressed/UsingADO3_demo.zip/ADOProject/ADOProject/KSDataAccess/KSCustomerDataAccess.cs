// Disclaimer and Copyright Information
// KSCustomerDataAccess.cs : Implementation of KSCustomerDataAccess class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/22/2001	Initial Creation
//	2/23/2001	Added functionality for Add/Delete/Edit record

namespace KSDataAccess
{
    using System;
	using System.Data;
	using System.Data.ADO;

	using System.Runtime.InteropServices;
	using Microsoft.ComServices;			// Required Transactional Attribute

	using System.Diagnostics;
	using KSDiagnostics;

    /// <summary>
    ///    
    /// </summary>
    /// 
	[Transaction]
    public class KSCustomerDataAccess : KSDataAccess.KSDBAccess
    {
        public KSCustomerDataAccess()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
        }

		public int GetRecords (out KSCustomerRecords custRecords)
		{
			// Makes sure that out parameter gets assigned to some value.
			// Otherwise, CS0177 error will be raisewd by compiler.
			custRecords = null;
			int nCount = 0;
			ADODataReader dataReader = null;

			// Check if the database connection has been initilaized or not.
			if (!this.Initialized)
			{
				return -1;
			}

			try
			{
				string strStatement = "SELECT * FROM Customers";
				ADOCommand sqlCmd = new ADOCommand (strStatement, m_ADOConnection);
				
				// Execute the command.
				sqlCmd.Execute (out dataReader);
				Object field = null;

				// Clear the collection object.
				custRecords = new KSCustomerRecords ();

				// Iterate over the dataReader object and store each record
				// inot the collection object.
				while (dataReader.Read ())
				{
					KSCustomerRecord custRecord = new KSCustomerRecord ();
					KSAddress custAddress = new KSAddress ();
					KSCommunicationInfo commInfo = new KSCommunicationInfo ();

					field = dataReader["CustomerId"];
					custRecord.ID = field.ToString ();

					field = dataReader["ContactName"];
					custRecord.ContactName = field.ToString ();

					field = dataReader["CompanyName"];
					custRecord.CompanyName = field.ToString ();

					field = dataReader["ContactTitle"];
					custRecord.ContactTitle = field.ToString ();

					field = dataReader["Address"];
					custAddress.Address = field.ToString ();

					field = dataReader["City"];
					custAddress.City = field.ToString ();

					field = dataReader["Region"];
					custAddress.State = field.ToString ();

					field = dataReader["PostalCode"];
					custAddress.Zip = field.ToString ();

					field = dataReader["Country"];
					custAddress.Country = field.ToString ();

					field = dataReader["Phone"];
					commInfo.WorkPhone = field.ToString ();

					field = dataReader["Fax"];
					commInfo.WorkFax = field.ToString ();

					custRecord.Address = custAddress;
					custRecord.CommunicationInfo = commInfo;

					custRecords.Add (custRecord);
					nCount++;
				}
			}
			catch (ADOException exception)
			{
				m_strLastErrorMsg = KSErrorHandler.GenerateErrorMsg (exception);
				Trace.Write (m_strLastErrorMsg);
				nCount = -1;
			}
			finally
			{
				// Always call Close when done reading. Otherwise you will
				// get exception thrown when you try to close the connection.
				dataReader.Close();
			}
   
			Trace.Write ("Total Records Fetched: " + nCount.ToString ());
			return nCount;
		}

		[AutoComplete]
		override public bool AddRecord (KSRecord record, out int nStatus)
		{
			Trace.Write ("Adding record");
			nStatus = -1;

			Trace.Assert (null != record);

			KSCustomerRecord custRecord = (KSCustomerRecord)record;
			Trace.Assert (0 != record.ID.Length);
			if (0 == record.ID.Length)
			{
				Trace.Write ("Empty ID in the record");
				Trace.Write ("Add record operation aborted");
			}
			Trace.Assert (0 != custRecord.CompanyName.Length);
			if (0 == custRecord.CompanyName.Length)
			{
				Trace.Write ("Empty compnay name in the record");
				Trace.Write ("Add record operation aborted");
			}

			try
			{
				string strStatement = "SELECT * FROM Customers";
				ADOCommand command = new ADOCommand (strStatement, m_ADOConnection);
				ADODataSetCommand addCmd = new ADODataSetCommand ();
				addCmd.SelectCommand = command;

				DataSet customerDataSet = new DataSet ("Customers");

				addCmd.FillDataSet (customerDataSet, "Customers");

				TablesCollection tables = customerDataSet.Tables;
				DataTable customerTable = tables[0];
				KSDataTable.SetEventHandlers (customerTable);

				// Create a new row in the table.
				DataRow customer = customerTable.NewRow ();

				customer["CustomerID"] = custRecord.ID;
				customer["CompanyName"] = custRecord.CompanyName;
				customer["ContactName"] = custRecord.ContactName;
				customer["ContactTitle"] = custRecord.ContactTitle;
				customer["Address"] = custRecord.Address.Address;
				customer["City"] = custRecord.Address.City;
				customer["Region"] = custRecord.Address.State;
				customer["PostalCode"] = custRecord.Address.Zip;
				customer["Country"] = custRecord.Address.Country;

				// Now add this newly created row to the table.
				customerTable.Rows.Add (customer);

				// Update the database.
				addCmd.Update (customerDataSet, "Customers");
			}
			catch (ADOException except)
			{
				m_strLastErrorMsg = KSErrorHandler.GenerateErrorMsg (except);
				Trace.Write (m_strLastErrorMsg);
				nStatus = -1;
				return false;
			}

			Trace.Write ("Finshed adding record");
			return true;
		}

		[AutoComplete]
		override public bool DeleteRecord (string strRecordID, out int nStatus)
		{
			Trace.Write ("Deleting record : " + strRecordID);

			nStatus = -1;
			string strStatement = "SELECT * FROM Customers WHERE CustomerId = '";
			strStatement += strRecordID;
			strStatement += "'";

			ADOCommand command = new ADOCommand (strStatement, m_ADOConnection);
			ADODataSetCommand deleteCmd = new ADODataSetCommand ();
			deleteCmd.SelectCommand = command;

			DataSet customerDataSet = new DataSet ("Customers");
			try
			{
				deleteCmd.FillDataSet (customerDataSet, "Customers");
			}
			catch (ADOException myException)
			{
				m_strLastErrorMsg = KSErrorHandler.GenerateErrorMsg (myException);
				Trace.Write (m_strLastErrorMsg);
				nStatus = -1;
				return false;
			}

			TablesCollection tables = customerDataSet.Tables;
			DataTable customerTable = tables[0];
			KSDataTable.SetEventHandlers (customerTable);

			try
			{
				customerTable.Rows[0].Delete ();
				deleteCmd.Update (customerDataSet, "Customers");
			}
			catch (ADOException myException)
			{
				m_strLastErrorMsg = KSErrorHandler.GenerateErrorMsg (myException);
				Trace.Write (m_strLastErrorMsg);
				nStatus = -1;
				return false;
			}
			
			return true;
		}

		[AutoComplete]
		override public bool EditRecord (KSRecord record, out int nStatus)
		{
			nStatus = -1;
			Debug.Assert (null != record);
			KSCustomerRecord cusRecord = (KSCustomerRecord)record;
			Trace.Write ("Starting Edit Record : " + record.ID);

			// Make sure that compnay name field is not empty.
			if (0 == cusRecord.CompanyName.Length)
			{
				Trace.Write ("Compnay Name Field is empty");
				nStatus = -1;
				return false;
			}
			string strStatement = "SELECT * FROM Customers WHERE CustomerId = '";
			strStatement += record.ID;
			strStatement += "'";

			ADOCommand command = new ADOCommand (strStatement, m_ADOConnection);
			ADODataSetCommand editCmd = new ADODataSetCommand ();
			editCmd.SelectCommand = command;

			DataSet customerDataSet = new DataSet ("Customers");
			try
			{
				editCmd.FillDataSet (customerDataSet, "Customers");
				TablesCollection tables = customerDataSet.Tables;
				DataTable customerTable = tables[0];
				KSDataTable.SetEventHandlers (customerTable);
				customerTable.Rows[0]["CompanyName"] = cusRecord.CompanyName;
				customerTable.Rows[0]["ContactName"] = cusRecord.ContactName;
				customerTable.Rows[0]["ContactTitle"] = cusRecord.ContactTitle;
				customerTable.Rows[0]["Address"] = cusRecord.Address.Address;
				customerTable.Rows[0]["City"] = cusRecord.Address.City;
				customerTable.Rows[0]["Region"] = cusRecord.Address.State;
				customerTable.Rows[0]["PostalCode"] = cusRecord.Address.Zip;
				customerTable.Rows[0]["Country"] = cusRecord.Address.Country;

				editCmd.Update (customerDataSet, "Customers");
			}
			catch (ADOException myException)
			{
				nStatus = -1;
				m_strLastErrorMsg = KSErrorHandler.GenerateErrorMsg (myException);
				Trace.Write (m_strLastErrorMsg);
				Trace.Write ("Failed to edit record");
				return false;
			}
			
			Trace.Write ("Finished editing record");
			return true;
		}
    }
}
