namespace KSDataAccess
{
    using System;
	using System.Data;
	using System.Diagnostics;

    /// <summary>
    ///    
    /// </summary>
    public class KSDataTable
{
        public KSDataTable()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //

			// Add all the event handlers.
			
        }

		public static void SetEventHandlers (DataTable table)
		{
			table.ColumnChanging += new DataColumnChangeEventHandler (ColumnChangingEvtHandler);
			table.RowChanging += new DataRowChangeEventHandler (RowChangingEvtHandler);
			table.RowChanged += new DataRowChangeEventHandler (RowChangedEvtHandler);
			table.RowDeleting += new DataRowChangeEventHandler (RowDeletingEvtHandler);
			table.RowDeleted += new DataRowChangeEventHandler (RowDeletedEvtHandler);
		}

		public static void RowChangingEvtHandler (object sender, DataRowChangeEventArgs args)
		{
			Trace.Write ("Row Changing: " + args.Row.ToString ());
		}

		public static void RowChangedEvtHandler (object sender, DataRowChangeEventArgs args)
		{
			Trace.Write ("Row Changed: " + args.Row.ToString ());
		}

		public static void RowDeletingEvtHandler (object sender, DataRowChangeEventArgs args)
		{
			Trace.Write ("Row Deleting: " + args.Row.ToString ());
		}

		public static void RowDeletedEvtHandler (object sender, DataRowChangeEventArgs args)
		{
			Trace.Write ("Row Deleted: " + args.Row.ToString ());
		}

		public static void ColumnChangingEvtHandler (object sender, DataColumnChangeEventArgs args)
		{
			Trace.Write ("Column Changing: " + args.Column.ColumnName);
		}
    }
}
