namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public class KSProductsDataSet : KSDataAccess.KSDataSet
    {
        public KSProductsDataSet()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
//			this.DataSetName = "Products";
        }
    }
}
