namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public class KSCustomerDataSet : KSDataAccess.KSDataSet
	{
        public KSCustomerDataSet()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
//			this.DataSetName = "Customers";
        }
    }
}
