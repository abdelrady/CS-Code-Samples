// Disclaimer and Copyright Information
// KSRecord.cs : Implementation of KSRecord class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//

namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public abstract class KSRecord
{
        public KSRecord()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
			m_strID = "";
        }

		public string ID
		{
			get
			{
			
				return m_strID;
			}
			set
			{
				m_strID = value;
			}
		}

		public string m_strID;
    }
}
