// Disclaimer and Copyright Information
// KSAddress.cs : Implementation of KSAddress class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//

namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public class KSAddress
    {
        public KSAddress()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
			m_strAddress = " ";
			m_strCity = " ";
			m_strState = " ";
			m_strZip = " ";
			m_strCountry = "USA";
        }

		public string Address
		{
			get
			{
			
				return m_strAddress;
			}
			set
			{
				m_strAddress = value;
			}
		}

		public string City
		{
			get
			{
			
				return m_strCity;
			}
			set
			{
				m_strCity = value;
			}
		}

		public string State
		{
			get
			{
			
				return m_strState;
			}
			set
			{
				m_strState = value;
			}
		}

		public string Zip
		{
			get
			{
			
				return m_strZip;
			}
			set
			{
				m_strZip = value;
			}
		}

		public string Country
		{
			get
			{
			
				return m_strCountry;
			}
			set
			{
				m_strCountry = value;
			}
		}

		protected string m_strAddress;
		protected string m_strCity;
		protected string m_strState;
		protected string m_strZip;
		protected string m_strCountry;
    }
}
