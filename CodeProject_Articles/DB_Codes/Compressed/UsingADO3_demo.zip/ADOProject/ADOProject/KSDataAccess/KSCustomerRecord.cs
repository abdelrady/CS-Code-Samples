// Disclaimer and Copyright Information
// KSCustomerRecord.cs : Implementation of KSCustomerRecord class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//
//	2/23/2001	Added communication info field.
//

namespace KSDataAccess
{
    using System;

    /// <summary>
    ///    
    /// </summary>
    public class KSCustomerRecord : KSDataAccess.KSRecord
    {
        public KSCustomerRecord()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
			m_Address = null;
			m_CommInfo = null;
        }

		public KSAddress Address
		{
			get
			{
				return m_Address;
			}
			set
			{
				m_Address = value;
			}
		}

		public KSCommunicationInfo CommunicationInfo
		{
			get
			{
				return m_CommInfo;
			}
			set
			{
				m_CommInfo = value;
			}
		}

		public string ContactName
		{
			get
			{
				return m_strContactName;
			}
			set
			{
				m_strContactName = value;
			}
		}

		public string CompanyName
		{
			get
			{
				return m_strCompanyName;
			}
			set
			{
				m_strCompanyName = value;
			}
		}

		public string ContactTitle
		{
			get
			{
				return m_strContactTitle;
			}
			set
			{
				m_strContactTitle = value;
			}
		}

		protected KSAddress m_Address;
		protected KSCommunicationInfo m_CommInfo;
		protected string m_strContactName;
		protected string m_strCompanyName;
		protected string m_strContactTitle;
    }
}
