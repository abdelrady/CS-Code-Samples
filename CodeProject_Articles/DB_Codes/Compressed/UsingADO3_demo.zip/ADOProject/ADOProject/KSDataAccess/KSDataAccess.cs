// Disclaimer and Copyright Information
// KSDataAccess.cs : Implementation of DBAccess class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//	2/22/2001	Added virtual functions for Add/Delete/Edit record
//

namespace KSDataAccess
{
    using System;
	using System.Data;
	using System.Data.ADO;
	using System.Data.SQL;

	using System.Diagnostics;

    /// <summary>
    ///    Summary description for Class1.
    /// </summary>
    public abstract class KSDBAccess
    {
        public KSDBAccess()
        {
            //
            // TODO: Add Constructor Logic here
            //
        }

		public bool Intialize ()
		{
			// Open connection to SQL Server DataBase.
			// To accomplish this, call create a new instance of SQLConnection
			// object.
			String strConnection = "Provider= SQLOLEDB.1; Data Source=SULTAN; uid=nkk; pwd=; Initial Catalog=ksdata";
			m_ADOConnection = new ADOConnection (strConnection);
			m_ADOConnection.InfoMessage += new ADOInfoMessageEventHandler (OnInfoMessageFromConnection);
			m_ADOConnection.StateChange += new StateChangeEventHandler (OnStateChange);
			try
			{
				m_ADOConnection.Open ();
				Trace.Write ("ADO Connection Opened");
			}
			catch (ADOException myException)
			{
				Trace.Write ("Failed to open ADO Connection");
				Trace.Write (myException.Message);
				m_ConnectionState = DBObjectState.Closed;
				return false;
			}

			// Get the state of the connection.
			m_ConnectionState = m_ADOConnection.State;
			return true;
		}

		public bool ShutDown ()
		{
			if ((m_ConnectionState & DBObjectState.Open) != 0)
			{
				Trace.Write ("ADO Connection Closed");
				m_ADOConnection.Close ();
				m_ConnectionState = m_ADOConnection.State;
			}
			
			return true;
		}

		protected static void OnInfoMessageFromConnection (object sender, ADOInfoMessageEventArgs args)
		{
			Trace.Write ("Info Message Recieved From Server");
			Trace.Write (args.Message);
			Trace.Write ("End Of Message From Server");
		}

		/// Object representing opened connection to SQL Server Database.
		protected ADOConnection m_ADOConnection;
		/// State of the connection. Flag indicating if its open or not.
		protected DBObjectState  m_ConnectionState;
		/// Detailed description of last error occured.
		protected string m_strLastErrorMsg;

		public bool Initialized
		{
			get
			{
				return ((m_ConnectionState & DBObjectState.Open) != 0);
			}
		}

		public abstract bool AddRecord (KSRecord record, out int nStatus);
		public abstract bool DeleteRecord (string strRecordID, out int nStatus);
		public abstract bool EditRecord (KSRecord record, out int nStatus);

		public string LastErrorMsg
		{
			get
			{
				return m_strLastErrorMsg;
			}
		}

		protected static void OnStateChange(object sender, StateChangeEventArgs e)
		{
			PrintEventArgs(e);
		}

		protected static void PrintEventArgs(StateChangeEventArgs args)
		{
			Trace.WriteLine("OnStateChange");
			Trace.WriteLine("  event args: ("+
				"originalState=" + args.OriginalState +
				" currentState=" + args.CurrentState +")");
		}

    }
}
