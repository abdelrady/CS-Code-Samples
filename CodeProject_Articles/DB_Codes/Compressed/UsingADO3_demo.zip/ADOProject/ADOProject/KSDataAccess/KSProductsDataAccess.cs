namespace KSDataAccess
{
    using System;
	using System.Data;
	using System.Data.ADO;

	using System.Runtime.InteropServices;
	using Microsoft.ComServices;			// Required Transactional Attribute

	using System.Diagnostics;

    /// <summary>
    ///    
    /// </summary>
    public class KSProductsDataAccess : KSDataAccess.KSDBAccess
    {
        public KSProductsDataAccess()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
        }

		[AutoComplete]
		override public bool AddRecord (KSRecord record, out int nStatus)
		{
			nStatus = -1;
			return true;
		}

		[AutoComplete]
		override public bool DeleteRecord (string strRecordID, out int nStatus)
		{
			nStatus = -1;
			return true;
		}

		[AutoComplete]
		override public bool EditRecord (KSRecord record, out int nStatus)
		{
			nStatus = -1;
			return true;
		}

		/// <summary>
		/// Method adds Products table to the database. New table is created.
		/// And then column for each field is created and added to the created
		/// table.
		/// Schema for Products table looks like.
		///		ProductID			Int32
		///		ProductName			String
		///		SupplierID			Int32
		///		CategoryID			Int32
		///		QuantitiyPerUnit	String
		///		UnitPrice			Currency
		///		UnitsInStock		Int16
		///		UnitsOnOrder		Int16
		///		ReorderLevel		Int16
		///		Discontinued		Bool
		/// </summary>
		[AutoComplete]
		public bool AddTableToDB (out int nStatus)
		{
			nStatus = -1;

			try
			{
				// After adding all the columns to the table, we need to add the table to dataset.
				DataSet dataSet = new DataSet ("Products");
//				dataSet.Tables.Add (tbProducts);
				ADOCommand newTableCmd = new ADOCommand ("CREATE TABLE PRODUCTS ( ProductID integer PRIMARY KEY, ProductName varchar(50) )", m_ADOConnection );
				newTableCmd.ExecuteNonQuery();

//				dataSet.AcceptChanges ();

//				ADOCommand cmd = new ADOCommand( "SELECT * FROM Products", m_ADOConnection );
//				string strCmd = "CREATE TABLE Products ( ProductID integer PRIMARY KEY, ProductName varchar(50) )";
//				string strCmd = "SELECT * FROM Products";
				ADODataSetCommand cmd = new ADODataSetCommand ();
				cmd.InsertCommand = newTableCmd;
				cmd.FillDataSet (dataSet, "Products");

				// Create instance of a new table.
//				DataTable tbProducts = new DataTable ("Products");
				DataTable tbProducts = dataSet.Tables[0];

				// We need to create new instances of columns for each field
				// in the schema of Products table.
//				DataColumn colData = new DataColumn ("ProductID", typeof (System.Int32));
				DataColumn colData = tbProducts.Columns["ProductID"];
				// Since ID of every product is going to be unique, set the
				// Unique property for this column.
				colData.Unique = true;
				// Set the auto increment property for this column so that everytime
				// a record is added, it gets incremented by the autoincrment value.
				colData.AutoIncrement = true;
				// Set the initial seed value for this column.
				colData.AutoIncrementSeed = 1;
				// Set the autoincrement value for this column.
				colData.AutoIncrementStep = 1;
				// Add the newly created column to table object.
//				tbProducts.Columns.Add (colData);

				// Create column for ProductName field.
//				colData = new DataColumn ("ProductName", typeof (System.String));
//				tbProducts.Columns.Add (colData);

				// Create column for SupplierID field.
				colData = new DataColumn ("SupplierID", typeof (System.Int32));
				tbProducts.Columns.Add (colData);

				// Create column for CategoryID field.
				colData = new DataColumn ("CategoryID", typeof (System.Int32));
				tbProducts.Columns.Add (colData);

				// Create column for QuantitiyPerUnit field.
				colData = new DataColumn ("QuantitiyPerUnit", typeof (System.String));
				tbProducts.Columns.Add (colData);

				// Create column for UnitPrice field.
				colData = new DataColumn ("UnitPrice", typeof (System.Double));
				// Set the default value of product to 0.0
				colData.DefaultValue = 0.0;
				tbProducts.Columns.Add (colData);

				// Create column for UnitsInStock field.
				colData = new DataColumn ("UnitsInStock", typeof (System.Int16));
				colData.DefaultValue = 0;
				tbProducts.Columns.Add (colData);

				// Create column for UnitsOnOrder field.
				colData = new DataColumn ("UnitsOnOrder", typeof (System.Int16));
				colData.DefaultValue = 0;
				tbProducts.Columns.Add (colData);

				// Create column for ReorderLevel field.
				colData = new DataColumn ("ReorderLevel", typeof (System.Int16));
				colData.DefaultValue = 0;
				tbProducts.Columns.Add (colData);

				// Create column for Discontinued field.
				colData = new DataColumn ("Discontinued", typeof (System.Boolean));
				colData.DefaultValue = false;
				tbProducts.Columns.Add (colData);

				// Now we will create primary key for this table. This key is
				// very important if we want to sort the records or create
				// relations of other tables with this one.
				// To keep things simple, just make the ProductID column as the
				// primary key.
				DataColumn [] keyDataColumn =new DataColumn [] {tbProducts.Columns["ProductID"]};
				tbProducts.PrimaryKey = keyDataColumn;

				// After adding all the columns to the table, we need to add the table to dataset.
//				DataSet dataSet = new DataSet ();
//				dataSet.Tables.Add (tbProducts);
//				ADOCommand newTableCmd = new ADOCommand ("CREATE TABLE PRODUCTS ( ProductID integer PRIMARY KEY, ProductName varchar(50) )", m_ADOConnection );
//				newTableCmd.ExecuteNonQuery();

//				dataSet.AcceptChanges ();

//				ADOCommand cmd = new ADOCommand( "SELECT * FROM Products", m_ADOConnection );
//				string strCmd = "CREATE TABLE Products ( ProductID integer PRIMARY KEY, ProductName varchar(50) )";
//				string strCmd = "CREATE TABLE PRODUCTS()";
//				ADODataSetCommand cmd = new ADODataSetCommand (strCmd, m_ADOConnection);
//				cmd.FillDataSet (dataSet, "Products");
//				dataSet.Tables.Add (tbProducts);
//				dataSet.AcceptChanges ();
				cmd.Update (dataSet, "Products");
			}
			catch (ADOException excpt)
			{
				Trace.Write (excpt.Message);
			}

			return true;
		}
    }
}
