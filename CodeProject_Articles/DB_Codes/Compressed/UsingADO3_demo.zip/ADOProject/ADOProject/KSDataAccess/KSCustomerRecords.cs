// Disclaimer and Copyright Information
// KSCustomerRecords.cs : Implementation of KSCustomerRecords class
//
// All rights reserved.
//
// Written by Naveen K Kohli (naveenkohli@netzero.net)
// Version 1.0
//
// Distribute freely, except: don't remove my name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// naveenkohli@netzero.net
///////////////////////////////////////////////////////////////////////////////
///

// Revision History:
//	2/21/2001	Initial Creation
//

namespace KSDataAccess
{
    using System;
	using System.Collections;

    /// <summary>
    ///    
    /// </summary>
    public class KSCustomerRecords : IEnumerable
    {
		private ArrayList m_Records;
        public KSCustomerRecords()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
			m_Records = new ArrayList ();
        }

		public long Count
		{
			get
			{
				return m_Records.Count;
			}
		}

		public int Add (KSCustomerRecord record)
		{
			return m_Records.Add (record);
		}

		public void Clear ()
		{
			m_Records.Clear ();
		}

		public KSCustomerRecord Item (int nIdx)
		{
			if (nIdx > 0 || nIdx < Count)
			{
				return (KSCustomerRecord)m_Records[nIdx];
			}

			return null;
		}

		public IEnumerator GetEnumerator ()
		{
			return new KSCustomerEnumerator (this);
		}

		private class KSCustomerEnumerator : IEnumerator
		{
			private int nPosition = -1;
			private KSCustomerRecords m_Records;

			public KSCustomerEnumerator (KSCustomerRecords records)
			{
				this.m_Records = records;
			}

			public void Reset ()
			{
				nPosition = -1;
			}

			public bool MoveNext ()
			{
				if (nPosition < m_Records.Count - 1)
				{
					nPosition++;
					return true;
				}
				return false;
			}

			public Object Current
			{
				get
				{
					return m_Records.m_Records[nPosition];
				}
			}

		}
    }
}
