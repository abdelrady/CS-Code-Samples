namespace KSDataAccess
{
    using System;


    /// <summary>
    ///    
    /// </summary>
    public class KSProductRecord : KSDataAccess.KSRecord
    {
        public KSProductRecord()
        {
            // 
	        // TODO: Add Constructor Logic here
	        //
        }
    }
}
