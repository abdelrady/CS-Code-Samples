/*
 * 
 * Created on 5/10/2004 at 11:45 AM
 *
 * REVISION HISTORY
 *
 * Author		Date		changes
 * GBaseke		5/10/2004 	Initial Revision
 */
using System;
using System.Windows.Forms;

namespace SA
{
	/// <summary>
	/// Description of MainForm.	
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MenuItem ReportMenu;
		private System.Windows.Forms.MenuItem jobStock;
		private System.Windows.Forms.MenuItem jobDelete;
		private System.Windows.Forms.MenuItem filePrint;
		private System.Windows.Forms.MenuItem jobDefinition;
		private System.Windows.Forms.MenuItem configureMachine;
		private System.Windows.Forms.MenuItem configureEmployee;
		private System.Windows.Forms.MenuItem fileMenu;
		private System.Windows.Forms.MenuItem JobMenu;
		private System.Windows.Forms.MenuItem fileOpen;
		private System.Windows.Forms.MenuItem menuItem;
		private System.Windows.Forms.MainMenu mainMenu;
		private System.Windows.Forms.MenuItem jobSequence;
		private System.Windows.Forms.MenuItem jobForm;
		private System.Windows.Forms.MenuItem jobStyle;
		private System.Windows.Forms.MenuItem helpAbout;
		private System.Windows.Forms.MenuItem filePrintSetup;
		private System.Windows.Forms.MenuItem helpMenu;
		private System.Windows.Forms.MenuItem reportRuntime;
		private System.Windows.Forms.MenuItem configureMenu;
		private System.Windows.Forms.MenuItem fileExit;
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.fileExit = new System.Windows.Forms.MenuItem();
			this.configureMenu = new System.Windows.Forms.MenuItem();
			this.reportRuntime = new System.Windows.Forms.MenuItem();
			this.helpMenu = new System.Windows.Forms.MenuItem();
			this.filePrintSetup = new System.Windows.Forms.MenuItem();
			this.helpAbout = new System.Windows.Forms.MenuItem();
			this.jobStyle = new System.Windows.Forms.MenuItem();
			this.jobForm = new System.Windows.Forms.MenuItem();
			this.jobSequence = new System.Windows.Forms.MenuItem();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.menuItem = new System.Windows.Forms.MenuItem();
			this.fileOpen = new System.Windows.Forms.MenuItem();
			this.JobMenu = new System.Windows.Forms.MenuItem();
			this.fileMenu = new System.Windows.Forms.MenuItem();
			this.configureEmployee = new System.Windows.Forms.MenuItem();
			this.configureMachine = new System.Windows.Forms.MenuItem();
			this.jobDefinition = new System.Windows.Forms.MenuItem();
			this.filePrint = new System.Windows.Forms.MenuItem();
			this.jobDelete = new System.Windows.Forms.MenuItem();
			this.jobStock = new System.Windows.Forms.MenuItem();
			this.ReportMenu = new System.Windows.Forms.MenuItem();
			// 
			// fileExit
			// 
			this.fileExit.Index = 3;
			this.fileExit.Text = "Exit";
			this.fileExit.Click += new System.EventHandler(this.OnExit);
			// 
			// configureMenu
			// 
			this.configureMenu.Index = 3;
			this.configureMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.configureMachine,
						this.configureEmployee});
			this.configureMenu.Text = "Configure";
			// 
			// reportRuntime
			// 
			this.reportRuntime.Index = 0;
			this.reportRuntime.Text = "Find";
			// 
			// helpMenu
			// 
			this.helpMenu.Index = 4;
			this.helpMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.helpAbout});
			this.helpMenu.Text = "Help";
			// 
			// filePrintSetup
			// 
			this.filePrintSetup.Index = 1;
			this.filePrintSetup.Text = "Create DSN";
			this.filePrintSetup.Click += new System.EventHandler(this.OnCreateDsn);
			// 
			// helpAbout
			// 
			this.helpAbout.Index = 0;
			this.helpAbout.Text = "About System Administrator";
			// 
			// jobStyle
			// 
			this.jobStyle.Index = 3;
			this.jobStyle.Text = "Paste";
			// 
			// jobForm
			// 
			this.jobForm.Index = 1;
			this.jobForm.Text = "Redo";
			// 
			// jobSequence
			// 
			this.jobSequence.Index = 2;
			this.jobSequence.Text = "Copy";
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.fileMenu,
						this.JobMenu,
						this.ReportMenu,
						this.configureMenu,
						this.helpMenu});
			// 
			// menuItem
			// 
			this.menuItem.Index = 1;
			this.menuItem.Text = "Find Next";
			// 
			// fileOpen
			// 
			this.fileOpen.Index = 0;
			this.fileOpen.Text = "Open Database";
			this.fileOpen.Click += new System.EventHandler(this.OnOpen);
			// 
			// JobMenu
			// 
			this.JobMenu.Index = 1;
			this.JobMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.jobStock,
						this.jobForm,
						this.jobSequence,
						this.jobStyle,
						this.jobDefinition,
						this.jobDelete});
			this.JobMenu.Text = "Edit";
			// 
			// fileMenu
			// 
			this.fileMenu.Index = 0;
			this.fileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.fileOpen,
						this.filePrintSetup,
						this.filePrint,
						this.fileExit});
			this.fileMenu.Text = "File";
			// 
			// configureEmployee
			// 
			this.configureEmployee.Index = 1;
			this.configureEmployee.Text = "Customize..";
			// 
			// configureMachine
			// 
			this.configureMachine.Index = 0;
			this.configureMachine.Text = "Option...";
			// 
			// jobDefinition
			// 
			this.jobDefinition.Index = 4;
			this.jobDefinition.Text = "Cut";
			// 
			// filePrint
			// 
			this.filePrint.Index = 2;
			this.filePrint.Text = "Print";
			// 
			// jobDelete
			// 
			this.jobDelete.Index = 5;
			this.jobDelete.Text = "Delete";
			// 
			// jobStock
			// 
			this.jobStock.Index = 0;
			this.jobStock.Text = "Undo";
			// 
			// ReportMenu
			// 
			this.ReportMenu.Index = 2;
			this.ReportMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
						this.reportRuntime,
						this.menuItem});
			this.ReportMenu.Text = "Search";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(528, 325);
			this.IsMdiContainer = true;
			this.Menu = this.mainMenu;
			this.Name = "MainForm";
			this.Text = "System Administrator";
		}
		#endregion
		void OnOpen(object sender, System.EventArgs e)
		{
			DSN dlg = new DSN();
			dlg.ShowDialog();
		}
		
		void OnCreateDsn(object sender, System.EventArgs e)
		{
			ODBCCP32 obj = new ODBCCP32();
			obj.CreateDatasource(this.Handle, "Fake DSN");
		}
		
		void OnExit(object sender, System.EventArgs e)
		{
			Application.Exit();
		}
		
	}
}
