using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace DbValidator
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Main1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			//open db
			Database db = DatabaseFactory.CreateDatabase();

			//Get object list
			string getObjSql = "select name, OBJECTPROPERTY(id, 'ExecIsQuotedIdentOn') as quoted_ident_on, OBJECTPROPERTY(id, 'ExecIsAnsiNullsOn') as ansi_nulls_on, user_name(o.uid) owner from sysobjects o where type in ('P', 'V', 'FN') and category = 0";
			DBCommandWrapper cmd = db.GetSqlStringCommandWrapper(getObjSql);
			DataSet procDs = db.ExecuteDataSet(cmd);

			//for each object get the command text and execute the command
			foreach (DataRow procRow in procDs.Tables[0].Rows)
			{
				string objectName = procRow["Name"].ToString();
				string quoted_ident = Convert.ToBoolean(procRow["quoted_ident_on"]) ? "ON" : "OFF";
				string ansi_nulls_on = Convert.ToBoolean(procRow["ansi_nulls_on"]) ? "ON" : "OFF";
				string owner = procRow["owner"].ToString();
				
				//call sp_helptext to the create command
				string getObjTextSql = string.Format("exec sp_helptext '{1}.{0}'", objectName, owner);
				DBCommandWrapper objTextCmd = db.GetSqlStringCommandWrapper(getObjTextSql);

				SqlDataReader textRdr = null;
				try
				{
					textRdr = (SqlDataReader)db.ExecuteReader(objTextCmd);
				}
				catch(SqlException ex)
				{
					string errText = string.Format("{0} COULD NOT BE READ : {1}", objectName, ex.ToString()).Replace("\r", " ").Replace("\n", " ");;
					Console.WriteLine(errText);
					Debug.WriteLine(errText);
					continue;
				}

				//loop through the command text and build up the command string
				StringBuilder sb = new StringBuilder(8000);
				using (textRdr)
				{
					while (textRdr.Read())
					{	
						string thisText = textRdr["text"].ToString();
						sb.Append(thisText);
						

					}
				}
				string procText = sb.ToString();
				
				//execute the command
				try
				{
					SqlConnection cnExec = (SqlConnection)db.GetConnection();
					using (cnExec)
					{
						cnExec.Open();
						SqlCommand sqlCmd = new SqlCommand("set noexec on", cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();
						
						sqlCmd = new SqlCommand("SET QUOTED_IDENTIFIER " + quoted_ident, cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand("SET ANSI_NULLS " + ansi_nulls_on, cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand(procText, cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand("SET QUOTED_IDENTIFIER OFF ", cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand("SET ANSI_NULLS ON", cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand("set noexec off", cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

						sqlCmd = new SqlCommand("set parseonly off", cnExec);
						sqlCmd.CommandType = CommandType.Text;
						sqlCmd.ExecuteNonQuery();

					}

				}
				catch(SqlException ex)
				{
					string errText = string.Format("{0} FAILED : {1}", objectName, ex.ToString()).Replace("\r", " ").Replace("\n", " ");
					Console.WriteLine(errText);
					Console.WriteLine();
					Debug.WriteLine(errText);
					continue;
				}

					
			}

		}
	}
}
