using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Finisar.SQLite;
using System.Drawing.Printing;
using System.Diagnostics;

namespace SQLiteGUI
{
    public partial class GUI : Form
    {
        private string DB_NAME = null;
        private SQLiteDataAdapter dataAdapter = null;
        private DataSet dataSet = null;
        private DataGridViewPrinter userDataGridViewPrinter = null;

        //<summary>
        //Constructor
        //</summary>
        public GUI()
        {
            InitializeComponent();
            typecombo.Items.Add("TEXT");
            typecombo.Items.Add("NUMERIC");
            typecombo.Items.Add("INTEGER");
            typecombo.SelectedIndex = 0;
        }

        //<summary>
            //Connect to the existing DB
        //</summary>
        private void tlstrpbtnconnect_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                opnfiledlg.CheckPathExists = true;
                opnfiledlg.CheckFileExists = true;
                opnfiledlg.Filter = "DB Files (*.db)|*.db|All Files(*.*)|*.*";
                opnfiledlg.Multiselect = false;
                opnfiledlg.Title = "Select SQLite Database File";

                if (opnfiledlg.ShowDialog() == DialogResult.OK)
                {
                    //Connects To SQLiteDatabase

                    lblconnected.Text = "YES";

                    DB_NAME = opnfiledlg.FileName;

                    reload_tables();
                }
            }
            catch (SQLiteException sqliteex)
            {
                MessageBox.Show(sqliteex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //<summary>
        //Create and connect to the new DB
        //</summary>
        private void tlStpbtnnew_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();
                savefileDlg.Filter = "DB Files(*.db)|*.db|All Files (*.*)|*.*";
                savefileDlg.DefaultExt = ".db";
                savefileDlg.AddExtension = true;

                if (savefileDlg.ShowDialog() == DialogResult.OK)
                {
                    DB_NAME = savefileDlg.FileName;
                    
                    string connString = String.Format("Data Source={0};New=True;Version=3", DB_NAME);

                    SQLiteConnection sqlconn = new SQLiteConnection(connString);

                    sqlconn.Open();

                    lblconnected.Text = "YES";
                    
                    sqlconn.Close();
                }
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //<summary>
        //Delete a table from the DB
        //</summary>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);

                sqlconn.Open();

                string CommandText = String.Format("drop table {0};", tablecombobox.Text);

                SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
                SQLiteCommand.ExecuteNonQuery();

                sqlconn.Close();

                reload_tables();

                MessageBox.Show("Deleted Table.", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
         

            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //<summary>
        //Reload the tables in the Combo Box
        //</summary>
        private void reload_tables()
        {
            try
            {
                tablecombobox.Items.Clear();

                DataSet ds = new DataSet();

                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);

                sqlconn.Open();

                string CommandText = "Select name from sqlite_master;";

                SQLiteDataAdapter dataAdapter = new SQLiteDataAdapter(CommandText, sqlconn);
                dataAdapter.Fill(ds);

                DataRowCollection dataRowCol = ds.Tables[0].Rows;

                foreach (DataRow dr in dataRowCol)
                {
                    tablecombobox.Items.Add(dr["name"]);
                }

                if (tablecombobox.Items.Count > 0)
                {
                    tablecombobox.SelectedIndex = 0;
                    btnDelete.Enabled = true;
                }
                else
                {
                    tablecombobox.Text = " ";
                    btnDelete.Enabled = false;
                }

                sqlconn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return;
        }

        //<summary>
        //Create a new table in the DB
        //</summary>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                StringBuilder query = new StringBuilder();

                if (txttablename.Enabled)
                {
                    if (txttablename.Text.Length <= 0)
                    {
                        MessageBox.Show("Table Name cannot be empty!!!");
                        return;
                    }

                    rchtxtCreate.Text = "";
                    string createStr = String.Format("Create table {0}( ", txttablename.Text);
                    query.Append(createStr);
                }
                else
                {
                    query.Append(",");
                }

                txttablename.Enabled = false;

                query.Append(txtcolumnname.Text);
                query.Append(" ");
                query.Append(typecombo.Text);

                if (chkprimary.Enabled)
                {
                    if (chkprimary.CheckState == CheckState.Checked)
                    {
                        query.Append(" primary key");
                        chkprimary.Enabled = false;
                    }
                }

                rchtxtCreate.Text += query.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //<summary>
        //Create a new table in the DB
        //</summary>
        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
               
                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                rchtxtCreate.Text += ");";

                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);

                sqlconn.Open();

                string CommandText = String.Format("{0}",rchtxtCreate.Text);

                SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
                SQLiteCommand.ExecuteNonQuery();

                sqlconn.Close();

                txttablename.Enabled = true;

                reload_tables();

                MessageBox.Show("Table Created", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
         
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtcolumnname.Text = "";
            txttablename.Text = "";
            typecombo.SelectedIndex = 0;
            rchtxtCreate.Clear();
            txttablename.Enabled = true;
            chkprimary.Enabled = true;
            chkprimary.CheckState = CheckState.Checked;
        }

        //<summary>
        //Executes a custom Query
        //</summary>
        private void btnExecute_Click(object sender, EventArgs e)
        {
            try
            {

                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);

                sqlconn.Open();

                string CommandText = String.Format("{0}", rchtxtQuery.Text);

                SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
                SQLiteCommand.ExecuteNonQuery();

                sqlconn.Close();

                MessageBox.Show("Query Executed","SQLite GUI",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //<summary>
        //Displays the contents of the table in the DataGridView
        //</summary>
        private void tablecombobox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                this.dataSet = new DataSet();
                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);
                sqlconn.Open();
                
                string CommandText = String.Format("Select * from {0};", tablecombobox.Text);

                this.dataAdapter = new SQLiteDataAdapter(CommandText, sqlconn);
                SQLiteCommandBuilder builder = new SQLiteCommandBuilder(this.dataAdapter);

                this.dataAdapter.Fill(this.dataSet, tablecombobox.Text);

                userDataGridView.DataSource = this.dataSet;
                userDataGridView.DataMember = tablecombobox.Text;

            }
            catch (SQLiteException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //<summary>
        //Update the changes in the DataGridView to the DB through the Datset and Data Adapter
        //</summary>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                if (this.dataSet.HasChanges())
                {
                    this.dataAdapter.Update(this.dataSet, tablecombobox.Text);
                    MessageBox.Show("Changes Updated", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
           
                }
                else
                {
                    MessageBox.Show("No changes to update!!");
                }
            }
            catch (InvalidOperationException invalidex)
            {
                MessageBox.Show(invalidex.Message +"\nRefer Help -> topics -> Help 1" );
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        //<summary>
        //Close the connected DB
        //</summary>
        private void closeDBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DB_NAME = null;
            lblconnected.Text = "NO";
        }

        //<summary>
        //About Box
        //</summary>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.ShowDialog();
        }

        //<summary>
        //Prints the data in the DataGridView
        //summary>
        private void tlstrpprint_Click(object sender, EventArgs e)
        {
            try
            {
                if (SetupThePrinting())
                {
                    PrintPreviewDialog MyPrintPreviewDialog = new PrintPreviewDialog();
                    MyPrintPreviewDialog.Document = userPrintDocument;
                    MyPrintPreviewDialog.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool SetupThePrinting()
        {
            try
            {
                PrintDialog MyPrintDialog = new PrintDialog();
                MyPrintDialog.AllowCurrentPage = false;
                MyPrintDialog.AllowPrintToFile = false;
                MyPrintDialog.AllowSelection = false;
                MyPrintDialog.AllowSomePages = false;
                MyPrintDialog.PrintToFile = false;
                MyPrintDialog.ShowHelp = false;
                MyPrintDialog.ShowNetwork = false;

                if (MyPrintDialog.ShowDialog() != DialogResult.OK)
                    return false;

                userPrintDocument.DocumentName = "Table Report";
                userPrintDocument.PrinterSettings = MyPrintDialog.PrinterSettings;
                userPrintDocument.DefaultPageSettings = MyPrintDialog.PrinterSettings.DefaultPageSettings;
                userPrintDocument.DefaultPageSettings.Margins = new Margins(40, 40, 40, 40);

                userDataGridViewPrinter = new DataGridViewPrinter(userDataGridView, userPrintDocument, false, true, "Table", new Font("Verdana", 18, FontStyle.Bold, GraphicsUnit.Point), Color.Black, true);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //<summary>
        //Displays the schema for the available tables in the DB
        //</summary>
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = new DataSet();

                if (DB_NAME == null)
                {
                    MessageBox.Show("Open an existing database or Create a new database");
                    return;
                }

                string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

                SQLiteConnection sqlconn = new SQLiteConnection(connString);

                sqlconn.Open();

                string CommandText = "Select * from sqlite_master;";

                SQLiteDataAdapter dataAdapter = new SQLiteDataAdapter(CommandText, sqlconn);
                dataAdapter.Fill(ds);

                DataRowCollection dataRowCol = ds.Tables[0].Rows;

                rchtxtSchema.Clear();

                foreach (DataRow dr in dataRowCol)
                {
                    rchtxtSchema.Text += "\n________________________________________________\n";

                    rchtxtSchema.Text += "\nType :";
                    rchtxtSchema.Text += dr["type"];

                    rchtxtSchema.Text += "\nTable Name :";
                    rchtxtSchema.Text += dr["name"];

                    rchtxtSchema.Text += "\nSQL :";
                    rchtxtSchema.Text += dr["sql"];

                    rchtxtSchema.Text += "\n________________________________________________\n";

                }

                sqlconn.Close();
            }
            catch (SQLiteException sqliteex)
            {
                MessageBox.Show(sqliteex.Message);
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnRefreshdb_Click(object sender, EventArgs e)
        {
            if (DB_NAME == null)
            {
                MessageBox.Show("Open an existing database or Create a new database");
                return;
            }

            reload_tables();
        }
           
        //<summary>
        //Implemented for Altering Table, Currently not supported :-(
        //</summary>

        //private void llblRename_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    lblAll.Visible = true;
        //    txtAll.Visible = true;
        //    txtAll.Text = " ";
        //    btnAll.Text = "Rename Table";
        //    btnAll.Visible = true;

        //}

        //private void llbladdcol_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    lblAll.Visible = true;
        //    txtAll.Visible = true;
        //    txtAll.Text = " ";
        //    btnAll.Text = "Add Column";
        //    btnAll.Visible = true;
        //}

        //private void llbldelcol_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        //{
        //    lblAll.Visible = true;
        //    txtAll.Visible = true;
        //    txtAll.Text = " ";
        //    btnAll.Text = "Delete Column";
        //    btnAll.Visible = true;
        //}

        //private void btnAll_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        if (DB_NAME == null)
        //        {
        //            MessageBox.Show("Open an existing database or Create a new database");
        //            return;
        //        }

        //        if (btnAll.Text.Contains("Rename Table"))
        //        {
        //            string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

        //            SQLiteConnection sqlconn = new SQLiteConnection(connString);

        //            sqlconn.Open();

        //            string CommandText = String.Format("alter table udhay.{0} rename to {1};",tablecombobox.Text,txtAll.Text);

        //            SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
        //            SQLiteCommand.ExecuteNonQuery();

        //            sqlconn.Close();

        //            reload_tables();

        //            MessageBox.Show("Table Renamed.", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        }
        //        else if (btnAll.Text.Contains("Add Column"))
        //        {
        //            string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

        //            SQLiteConnection sqlconn = new SQLiteConnection(connString);

        //            sqlconn.Open();

        //            string CommandText = String.Format("alter table {0} add column {1};", tablecombobox.Text,txtAll.Text);

        //            SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
        //            SQLiteCommand.ExecuteNonQuery();

        //            sqlconn.Close();

        //            reload_tables();

        //            MessageBox.Show("Column Added.", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        }
        //        else if (btnAll.Text.Contains("Delete Column"))
        //        {
        //            string connString = String.Format("Data Source={0};New=False;Version=3", DB_NAME);

        //            SQLiteConnection sqlconn = new SQLiteConnection(connString);

        //            sqlconn.Open();

        //            string CommandText = String.Format("alter table {0} drop column {1};", tablecombobox.Text,txtAll.Text);

        //            SQLiteCommand SQLiteCommand = new SQLiteCommand(CommandText, sqlconn);
        //            SQLiteCommand.ExecuteNonQuery();

        //            sqlconn.Close();

        //            reload_tables();

        //            MessageBox.Show("Column Deleted.", "SQLite GUI", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //        }

        //        lblAll.Visible = false;
        //        txtAll.Visible = false;
        //        txtAll.Text = " ";
        //        btnAll.Text = " ";
        //        btnAll.Visible = false;

        //    }
        //    catch (SQLiteException sqlex)
        //    {
        //        lblAll.Visible = false;
        //        txtAll.Visible = false;
        //        txtAll.Text = " ";
        //        btnAll.Text = " ";
        //        btnAll.Visible = false;
        //        MessageBox.Show(sqlex.Message);
        //    }
        //    catch (Exception ex)
        //    {
        //        lblAll.Visible = false;
        //        txtAll.Visible = false;
        //        txtAll.Text = " ";
        //        btnAll.Text = " ";
        //        btnAll.Visible = false;
        //        MessageBox.Show(ex.Message);
        //    }
        //}

        //<summary>
        //Displays the help
        //</summary>
        private void toolStripHelp_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + "\\Help\\SQLite_Gui_Help.html");
        }

        private void userPrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            bool more = userDataGridViewPrinter.DrawDataGridView(e.Graphics);
            if (more == true)
                e.HasMorePages = true;
        }
    }
}