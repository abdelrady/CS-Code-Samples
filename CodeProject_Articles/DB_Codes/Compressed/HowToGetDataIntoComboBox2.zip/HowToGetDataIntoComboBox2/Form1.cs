/* This is the second version of "how to populate the data 
 * from a table in a ComboBox" program.
 * here is used : 
	-TableMapping mechanism 
	 which controls how data adapters copy tables and columns of data
	 from a physical data source to ADO.NET in-memory objects
	-DataViewManager 
	 which binds a control to more than one table of a DataSet
	
	
 * H�seyin Altindag 18.07.2004
 */

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data;


namespace HowToGetDataIntoComboBox2
{
	/// <summary>
	/// Summary description for Form2.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
	
		private OleDbConnection		 myConn;
		private OleDbDataAdapter	 dAdapter;
		private DataViewManager		 dviewmanager;
		private DataSet				 dset;
	
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			fnGetConnectedToDatabase(); 
			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		  this.comboBox1 = new System.Windows.Forms.ComboBox();
		  this.label1 = new System.Windows.Forms.Label();
		  this.textBox1 = new System.Windows.Forms.TextBox();
		  this.textBox2 = new System.Windows.Forms.TextBox();
		  this.textBox3 = new System.Windows.Forms.TextBox();
		  this.label2 = new System.Windows.Forms.Label();
		  this.label3 = new System.Windows.Forms.Label();
		  this.label4 = new System.Windows.Forms.Label();
		  this.label5 = new System.Windows.Forms.Label();
		  this.SuspendLayout();
		  // 
		  // comboBox1
		  // 
		  this.comboBox1.BackColor = System.Drawing.Color.Pink;
		  this.comboBox1.Location = new System.Drawing.Point(120, 48);
		  this.comboBox1.Name = "comboBox1";
		  this.comboBox1.Size = new System.Drawing.Size(120, 21);
		  this.comboBox1.TabIndex = 1;
		  this.comboBox1.Text = "-Select a StudentID-";
		  // 
		  // label1
		  // 
		  this.label1.Location = new System.Drawing.Point(120, 32);
		  this.label1.Name = "label1";
		  this.label1.Size = new System.Drawing.Size(120, 16);
		  this.label1.TabIndex = 5;
		  this.label1.Text = "Select a StudentID";
		  // 
		  // textBox1
		  // 
		  this.textBox1.BackColor = System.Drawing.Color.White;
		  this.textBox1.Enabled = false;
		  this.textBox1.Location = new System.Drawing.Point(120, 120);
		  this.textBox1.Name = "textBox1";
		  this.textBox1.Size = new System.Drawing.Size(64, 20);
		  this.textBox1.TabIndex = 6;
		  this.textBox1.Text = "";
		  // 
		  // textBox2
		  // 
		  this.textBox2.BackColor = System.Drawing.Color.White;
		  this.textBox2.Enabled = false;
		  this.textBox2.Location = new System.Drawing.Point(120, 152);
		  this.textBox2.Name = "textBox2";
		  this.textBox2.Size = new System.Drawing.Size(128, 20);
		  this.textBox2.TabIndex = 7;
		  this.textBox2.Text = "";
		  // 
		  // textBox3
		  // 
		  this.textBox3.BackColor = System.Drawing.Color.White;
		  this.textBox3.Enabled = false;
		  this.textBox3.Location = new System.Drawing.Point(120, 184);
		  this.textBox3.Name = "textBox3";
		  this.textBox3.Size = new System.Drawing.Size(144, 20);
		  this.textBox3.TabIndex = 8;
		  this.textBox3.Text = "";
		  // 
		  // label2
		  // 
		  this.label2.Location = new System.Drawing.Point(32, 120);
		  this.label2.Name = "label2";
		  this.label2.Size = new System.Drawing.Size(56, 16);
		  this.label2.TabIndex = 9;
		  this.label2.Text = "StudentID";
		  // 
		  // label3
		  // 
		  this.label3.Location = new System.Drawing.Point(32, 152);
		  this.label3.Name = "label3";
		  this.label3.Size = new System.Drawing.Size(88, 16);
		  this.label3.TabIndex = 10;
		  this.label3.Text = "Student Subject";
		  // 
		  // label4
		  // 
		  this.label4.Location = new System.Drawing.Point(32, 184);
		  this.label4.Name = "label4";
		  this.label4.Size = new System.Drawing.Size(80, 16);
		  this.label4.TabIndex = 11;
		  this.label4.Text = "Student Name";
		  // 
		  // label5
		  // 
		  this.label5.Location = new System.Drawing.Point(16, 248);
		  this.label5.Name = "label5";
		  this.label5.Size = new System.Drawing.Size(256, 16);
		  this.label5.TabIndex = 11;
		  this.label5.Text = "WS:Winter Semester           SS:Summer Semester";
		  // 
		  // Form1
		  // 
		  this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		  this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(128)), ((System.Byte)(255)), ((System.Byte)(128)));
		  this.ClientSize = new System.Drawing.Size(302, 271);
		  this.Controls.Add(this.label4);
		  this.Controls.Add(this.label3);
		  this.Controls.Add(this.label2);
		  this.Controls.Add(this.textBox3);
		  this.Controls.Add(this.textBox2);
		  this.Controls.Add(this.textBox1);
		  this.Controls.Add(this.label1);
		  this.Controls.Add(this.comboBox1);
		  this.Controls.Add(this.label5);
		  this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
		  this.MaximizeBox = false;
		  this.Name = "Form1";
		  this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		  this.Text = "How to get  data into a ComboBox 2 ";
		  this.ResumeLayout(false);

		}
		#endregion
		
		[STAThread]
		static void Main() 
		{
		   Application.EnableVisualStyles();
			Application.Run(new Form1());
		}
		
		private void fnGetConnectedToDatabase() 
		{
			string conStr="Provider=Microsoft.Jet.OLEDB.4.0; Data Source=..\\..\\studentDB.mdb"; 			
			try 
			{
				//open the connection to the database
				myConn = new OleDbConnection(conStr);
				myConn.Open();			
			}
			catch(OleDbException ex) 
			{
				MessageBox.Show("Error in connection ..."+ex.Message);
			}
			
			string sqlStr ="SELECT * FROM studentTable;";
			
			//Instantiate a DataAdapter by passing the sqlStr and Connection.
			//now data is in raw form
			dAdapter = new OleDbDataAdapter(sqlStr,myConn);

			//Instantiate a DataSet
			dset = new DataSet();
			
			//Gets a collection that provides the master mapping
			// between a source table and a DataTable
			dAdapter.TableMappings.Add("Table", "studentTable");
						
			/*A data adapter object utilizes the Fill method 
			to populate a DataSet or a DataTable object with data 
			retrieved by a SELECT command. */
			dAdapter.Fill(dset);	
			//When binding a DataSet, .NET automatically uses the corresponding
			//DataViewManager provided through the DataSet.DefaultViewManager property	
			this.dviewmanager=dset.DefaultViewManager;						
			
			this.comboBox1.DataSource=this.dviewmanager;
			//display "studentTable.StudentID" in the ComboBox
			this.comboBox1.DisplayMember="studentTable.StudentID";
			
			//DataBinding for the TextBox controls
			this.textBox1.DataBindings.Add("Text", this.dviewmanager,"studentTable.StudentID");
			this.textBox2.DataBindings.Add("Text", this.dviewmanager, "studentTable.StudentSubject");
			this.textBox3.DataBindings.Add("Text", this.dviewmanager, "studentTable.StudentName");
			
			// Close the connection to the database.
			this.myConn.Close();
		}		
		
	}
}