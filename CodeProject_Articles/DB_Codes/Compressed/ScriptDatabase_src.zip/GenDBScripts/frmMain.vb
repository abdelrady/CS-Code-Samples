Option Strict On

Imports System.Data.SqlClient
Imports System.IO

Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdGenerate As System.Windows.Forms.Button
    Friend WithEvents txtBuildObjects As System.Windows.Forms.TextBox
    Friend WithEvents txtTableInsertStatements As System.Windows.Forms.TextBox
    Friend WithEvents txtImportBlobValues As System.Windows.Forms.TextBox
    Friend WithEvents tabMain As System.Windows.Forms.TabControl
    Friend WithEvents tabpageConnectionInfo As System.Windows.Forms.TabPage
    Friend WithEvents tabpageBuildObjects As System.Windows.Forms.TabPage
    Friend WithEvents tabpageTableInsertStatements As System.Windows.Forms.TabPage
    Friend WithEvents tabpageImportBlobValues As System.Windows.Forms.TabPage
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents lblServer As System.Windows.Forms.Label
    Friend WithEvents txtServerName As System.Windows.Forms.TextBox
    Friend WithEvents txtDatabase As System.Windows.Forms.TextBox
    Friend WithEvents lblDatabase As System.Windows.Forms.Label
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents chkTableInsertStatements As System.Windows.Forms.CheckBox
    Friend WithEvents tabpageCreateDatabaseScript As System.Windows.Forms.TabPage
    Friend WithEvents txtCreateDatabaseScript As System.Windows.Forms.TextBox
    Friend WithEvents txtOutputFolderPath As System.Windows.Forms.TextBox
    Friend WithEvents lblOutputFolderPath As System.Windows.Forms.Label
    Friend WithEvents groupDatabaseObjects As System.Windows.Forms.GroupBox
    Friend WithEvents chkDatabaseRoles As System.Windows.Forms.CheckBox
    Friend WithEvents chkUsers As System.Windows.Forms.CheckBox
    Friend WithEvents chkUserDefinedDataTypes As System.Windows.Forms.CheckBox
    Friend WithEvents chkUserDefinedFunctions As System.Windows.Forms.CheckBox
    Friend WithEvents chkRules As System.Windows.Forms.CheckBox
    Friend WithEvents chkDefaults As System.Windows.Forms.CheckBox
    Friend WithEvents chkTables As System.Windows.Forms.CheckBox
    Friend WithEvents chkViews As System.Windows.Forms.CheckBox
    Friend WithEvents chkStoredProcedures As System.Windows.Forms.CheckBox
    Friend WithEvents cmdSelectAll As System.Windows.Forms.Button
    Friend WithEvents cmdSelectNone As System.Windows.Forms.Button
    Friend WithEvents groupConnectionMethod As System.Windows.Forms.GroupBox
    Friend WithEvents lblConnectionMethod As System.Windows.Forms.Label
    Friend WithEvents radioWindows As System.Windows.Forms.RadioButton
    Friend WithEvents radioSQLServer As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.cmdGenerate = New System.Windows.Forms.Button
        Me.txtBuildObjects = New System.Windows.Forms.TextBox
        Me.txtTableInsertStatements = New System.Windows.Forms.TextBox
        Me.txtImportBlobValues = New System.Windows.Forms.TextBox
        Me.tabMain = New System.Windows.Forms.TabControl
        Me.tabpageConnectionInfo = New System.Windows.Forms.TabPage
        Me.groupConnectionMethod = New System.Windows.Forms.GroupBox
        Me.radioSQLServer = New System.Windows.Forms.RadioButton
        Me.radioWindows = New System.Windows.Forms.RadioButton
        Me.lblConnectionMethod = New System.Windows.Forms.Label
        Me.txtUsername = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtDatabase = New System.Windows.Forms.TextBox
        Me.lblDatabase = New System.Windows.Forms.Label
        Me.txtServerName = New System.Windows.Forms.TextBox
        Me.lblServer = New System.Windows.Forms.Label
        Me.txtPassword = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.groupDatabaseObjects = New System.Windows.Forms.GroupBox
        Me.cmdSelectNone = New System.Windows.Forms.Button
        Me.cmdSelectAll = New System.Windows.Forms.Button
        Me.chkStoredProcedures = New System.Windows.Forms.CheckBox
        Me.chkViews = New System.Windows.Forms.CheckBox
        Me.chkTables = New System.Windows.Forms.CheckBox
        Me.chkDefaults = New System.Windows.Forms.CheckBox
        Me.chkRules = New System.Windows.Forms.CheckBox
        Me.chkUserDefinedFunctions = New System.Windows.Forms.CheckBox
        Me.chkUserDefinedDataTypes = New System.Windows.Forms.CheckBox
        Me.chkUsers = New System.Windows.Forms.CheckBox
        Me.chkDatabaseRoles = New System.Windows.Forms.CheckBox
        Me.chkTableInsertStatements = New System.Windows.Forms.CheckBox
        Me.txtOutputFolderPath = New System.Windows.Forms.TextBox
        Me.lblOutputFolderPath = New System.Windows.Forms.Label
        Me.tabpageCreateDatabaseScript = New System.Windows.Forms.TabPage
        Me.txtCreateDatabaseScript = New System.Windows.Forms.TextBox
        Me.tabpageBuildObjects = New System.Windows.Forms.TabPage
        Me.tabpageTableInsertStatements = New System.Windows.Forms.TabPage
        Me.tabpageImportBlobValues = New System.Windows.Forms.TabPage
        Me.cmdClose = New System.Windows.Forms.Button
        Me.tabMain.SuspendLayout()
        Me.tabpageConnectionInfo.SuspendLayout()
        Me.groupConnectionMethod.SuspendLayout()
        Me.groupDatabaseObjects.SuspendLayout()
        Me.tabpageCreateDatabaseScript.SuspendLayout()
        Me.tabpageBuildObjects.SuspendLayout()
        Me.tabpageTableInsertStatements.SuspendLayout()
        Me.tabpageImportBlobValues.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdGenerate
        '
        Me.cmdGenerate.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdGenerate.Location = New System.Drawing.Point(349, 408)
        Me.cmdGenerate.Name = "cmdGenerate"
        Me.cmdGenerate.Size = New System.Drawing.Size(112, 24)
        Me.cmdGenerate.TabIndex = 0
        Me.cmdGenerate.Text = "Generate"
        '
        'txtBuildObjects
        '
        Me.txtBuildObjects.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtBuildObjects.Location = New System.Drawing.Point(5, 5)
        Me.txtBuildObjects.Multiline = True
        Me.txtBuildObjects.Name = "txtBuildObjects"
        Me.txtBuildObjects.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtBuildObjects.Size = New System.Drawing.Size(566, 356)
        Me.txtBuildObjects.TabIndex = 1
        Me.txtBuildObjects.Text = ""
        '
        'txtTableInsertStatements
        '
        Me.txtTableInsertStatements.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtTableInsertStatements.Location = New System.Drawing.Point(5, 5)
        Me.txtTableInsertStatements.Multiline = True
        Me.txtTableInsertStatements.Name = "txtTableInsertStatements"
        Me.txtTableInsertStatements.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtTableInsertStatements.Size = New System.Drawing.Size(566, 356)
        Me.txtTableInsertStatements.TabIndex = 2
        Me.txtTableInsertStatements.Text = ""
        '
        'txtImportBlobValues
        '
        Me.txtImportBlobValues.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtImportBlobValues.Location = New System.Drawing.Point(5, 5)
        Me.txtImportBlobValues.Multiline = True
        Me.txtImportBlobValues.Name = "txtImportBlobValues"
        Me.txtImportBlobValues.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtImportBlobValues.Size = New System.Drawing.Size(566, 356)
        Me.txtImportBlobValues.TabIndex = 3
        Me.txtImportBlobValues.Text = ""
        '
        'tabMain
        '
        Me.tabMain.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.tabMain.Controls.Add(Me.tabpageConnectionInfo)
        Me.tabMain.Controls.Add(Me.tabpageCreateDatabaseScript)
        Me.tabMain.Controls.Add(Me.tabpageBuildObjects)
        Me.tabMain.Controls.Add(Me.tabpageTableInsertStatements)
        Me.tabMain.Controls.Add(Me.tabpageImportBlobValues)
        Me.tabMain.Location = New System.Drawing.Point(6, 8)
        Me.tabMain.Name = "tabMain"
        Me.tabMain.SelectedIndex = 0
        Me.tabMain.Size = New System.Drawing.Size(584, 392)
        Me.tabMain.TabIndex = 4
        '
        'tabpageConnectionInfo
        '
        Me.tabpageConnectionInfo.Controls.Add(Me.groupConnectionMethod)
        Me.tabpageConnectionInfo.Controls.Add(Me.groupDatabaseObjects)
        Me.tabpageConnectionInfo.Controls.Add(Me.chkTableInsertStatements)
        Me.tabpageConnectionInfo.Controls.Add(Me.txtOutputFolderPath)
        Me.tabpageConnectionInfo.Controls.Add(Me.lblOutputFolderPath)
        Me.tabpageConnectionInfo.Location = New System.Drawing.Point(4, 22)
        Me.tabpageConnectionInfo.Name = "tabpageConnectionInfo"
        Me.tabpageConnectionInfo.Size = New System.Drawing.Size(576, 366)
        Me.tabpageConnectionInfo.TabIndex = 0
        Me.tabpageConnectionInfo.Text = "Connection Info"
        '
        'groupConnectionMethod
        '
        Me.groupConnectionMethod.Controls.Add(Me.radioSQLServer)
        Me.groupConnectionMethod.Controls.Add(Me.radioWindows)
        Me.groupConnectionMethod.Controls.Add(Me.lblConnectionMethod)
        Me.groupConnectionMethod.Controls.Add(Me.txtUsername)
        Me.groupConnectionMethod.Controls.Add(Me.Label2)
        Me.groupConnectionMethod.Controls.Add(Me.txtDatabase)
        Me.groupConnectionMethod.Controls.Add(Me.lblDatabase)
        Me.groupConnectionMethod.Controls.Add(Me.txtServerName)
        Me.groupConnectionMethod.Controls.Add(Me.lblServer)
        Me.groupConnectionMethod.Controls.Add(Me.txtPassword)
        Me.groupConnectionMethod.Controls.Add(Me.Label3)
        Me.groupConnectionMethod.Location = New System.Drawing.Point(8, 8)
        Me.groupConnectionMethod.Name = "groupConnectionMethod"
        Me.groupConnectionMethod.Size = New System.Drawing.Size(296, 240)
        Me.groupConnectionMethod.TabIndex = 12
        Me.groupConnectionMethod.TabStop = False
        Me.groupConnectionMethod.Text = "Connection info"
        '
        'radioSQLServer
        '
        Me.radioSQLServer.Location = New System.Drawing.Point(24, 136)
        Me.radioSQLServer.Name = "radioSQLServer"
        Me.radioSQLServer.Size = New System.Drawing.Size(160, 16)
        Me.radioSQLServer.TabIndex = 10
        Me.radioSQLServer.Text = "SQL Server Authentication"
        '
        'radioWindows
        '
        Me.radioWindows.Checked = True
        Me.radioWindows.Location = New System.Drawing.Point(24, 114)
        Me.radioWindows.Name = "radioWindows"
        Me.radioWindows.Size = New System.Drawing.Size(160, 16)
        Me.radioWindows.TabIndex = 9
        Me.radioWindows.TabStop = True
        Me.radioWindows.Text = "Windows Authentication"
        '
        'lblConnectionMethod
        '
        Me.lblConnectionMethod.AutoSize = True
        Me.lblConnectionMethod.Location = New System.Drawing.Point(8, 88)
        Me.lblConnectionMethod.Name = "lblConnectionMethod"
        Me.lblConnectionMethod.Size = New System.Drawing.Size(80, 16)
        Me.lblConnectionMethod.TabIndex = 8
        Me.lblConnectionMethod.Text = "Connect using:"
        '
        'txtUsername
        '
        Me.txtUsername.Location = New System.Drawing.Point(152, 165)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(112, 20)
        Me.txtUsername.TabIndex = 5
        Me.txtUsername.Text = "sa"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 167)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 16)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Username:"
        '
        'txtDatabase
        '
        Me.txtDatabase.Location = New System.Drawing.Point(112, 50)
        Me.txtDatabase.Name = "txtDatabase"
        Me.txtDatabase.Size = New System.Drawing.Size(152, 20)
        Me.txtDatabase.TabIndex = 3
        Me.txtDatabase.Text = ""
        '
        'lblDatabase
        '
        Me.lblDatabase.AutoSize = True
        Me.lblDatabase.Location = New System.Drawing.Point(8, 52)
        Me.lblDatabase.Name = "lblDatabase"
        Me.lblDatabase.Size = New System.Drawing.Size(56, 16)
        Me.lblDatabase.TabIndex = 2
        Me.lblDatabase.Text = "Database:"
        '
        'txtServerName
        '
        Me.txtServerName.Location = New System.Drawing.Point(112, 24)
        Me.txtServerName.Name = "txtServerName"
        Me.txtServerName.Size = New System.Drawing.Size(152, 20)
        Me.txtServerName.TabIndex = 1
        Me.txtServerName.Text = "(local)"
        '
        'lblServer
        '
        Me.lblServer.AutoSize = True
        Me.lblServer.Location = New System.Drawing.Point(8, 26)
        Me.lblServer.Name = "lblServer"
        Me.lblServer.Size = New System.Drawing.Size(74, 16)
        Me.lblServer.TabIndex = 0
        Me.lblServer.Text = "Server Name:"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(152, 192)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(112, 20)
        Me.txtPassword.TabIndex = 7
        Me.txtPassword.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(69, 194)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 16)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Password:"
        '
        'groupDatabaseObjects
        '
        Me.groupDatabaseObjects.Controls.Add(Me.cmdSelectNone)
        Me.groupDatabaseObjects.Controls.Add(Me.cmdSelectAll)
        Me.groupDatabaseObjects.Controls.Add(Me.chkStoredProcedures)
        Me.groupDatabaseObjects.Controls.Add(Me.chkViews)
        Me.groupDatabaseObjects.Controls.Add(Me.chkTables)
        Me.groupDatabaseObjects.Controls.Add(Me.chkDefaults)
        Me.groupDatabaseObjects.Controls.Add(Me.chkRules)
        Me.groupDatabaseObjects.Controls.Add(Me.chkUserDefinedFunctions)
        Me.groupDatabaseObjects.Controls.Add(Me.chkUserDefinedDataTypes)
        Me.groupDatabaseObjects.Controls.Add(Me.chkUsers)
        Me.groupDatabaseObjects.Controls.Add(Me.chkDatabaseRoles)
        Me.groupDatabaseObjects.Location = New System.Drawing.Point(312, 8)
        Me.groupDatabaseObjects.Name = "groupDatabaseObjects"
        Me.groupDatabaseObjects.Size = New System.Drawing.Size(216, 296)
        Me.groupDatabaseObjects.TabIndex = 11
        Me.groupDatabaseObjects.TabStop = False
        Me.groupDatabaseObjects.Text = "Database objects to script"
        '
        'cmdSelectNone
        '
        Me.cmdSelectNone.Location = New System.Drawing.Point(106, 254)
        Me.cmdSelectNone.Name = "cmdSelectNone"
        Me.cmdSelectNone.Size = New System.Drawing.Size(88, 24)
        Me.cmdSelectNone.TabIndex = 10
        Me.cmdSelectNone.Text = "Select None"
        '
        'cmdSelectAll
        '
        Me.cmdSelectAll.Location = New System.Drawing.Point(10, 254)
        Me.cmdSelectAll.Name = "cmdSelectAll"
        Me.cmdSelectAll.Size = New System.Drawing.Size(88, 24)
        Me.cmdSelectAll.TabIndex = 9
        Me.cmdSelectAll.Text = "Select All"
        '
        'chkStoredProcedures
        '
        Me.chkStoredProcedures.Checked = True
        Me.chkStoredProcedures.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkStoredProcedures.Location = New System.Drawing.Point(13, 220)
        Me.chkStoredProcedures.Name = "chkStoredProcedures"
        Me.chkStoredProcedures.Size = New System.Drawing.Size(152, 16)
        Me.chkStoredProcedures.TabIndex = 8
        Me.chkStoredProcedures.Text = "Stored Procedures"
        '
        'chkViews
        '
        Me.chkViews.Checked = True
        Me.chkViews.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkViews.Location = New System.Drawing.Point(13, 196)
        Me.chkViews.Name = "chkViews"
        Me.chkViews.Size = New System.Drawing.Size(152, 16)
        Me.chkViews.TabIndex = 7
        Me.chkViews.Text = "Views"
        '
        'chkTables
        '
        Me.chkTables.Checked = True
        Me.chkTables.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkTables.Location = New System.Drawing.Point(13, 172)
        Me.chkTables.Name = "chkTables"
        Me.chkTables.Size = New System.Drawing.Size(152, 16)
        Me.chkTables.TabIndex = 6
        Me.chkTables.Text = "Tables"
        '
        'chkDefaults
        '
        Me.chkDefaults.Checked = True
        Me.chkDefaults.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDefaults.Location = New System.Drawing.Point(13, 148)
        Me.chkDefaults.Name = "chkDefaults"
        Me.chkDefaults.Size = New System.Drawing.Size(152, 16)
        Me.chkDefaults.TabIndex = 5
        Me.chkDefaults.Text = "Defaults"
        '
        'chkRules
        '
        Me.chkRules.Checked = True
        Me.chkRules.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkRules.Location = New System.Drawing.Point(13, 124)
        Me.chkRules.Name = "chkRules"
        Me.chkRules.Size = New System.Drawing.Size(152, 16)
        Me.chkRules.TabIndex = 4
        Me.chkRules.Text = "Rules"
        '
        'chkUserDefinedFunctions
        '
        Me.chkUserDefinedFunctions.Checked = True
        Me.chkUserDefinedFunctions.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUserDefinedFunctions.Location = New System.Drawing.Point(13, 100)
        Me.chkUserDefinedFunctions.Name = "chkUserDefinedFunctions"
        Me.chkUserDefinedFunctions.Size = New System.Drawing.Size(152, 16)
        Me.chkUserDefinedFunctions.TabIndex = 3
        Me.chkUserDefinedFunctions.Text = "User Defined Functions"
        '
        'chkUserDefinedDataTypes
        '
        Me.chkUserDefinedDataTypes.Checked = True
        Me.chkUserDefinedDataTypes.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUserDefinedDataTypes.Location = New System.Drawing.Point(13, 76)
        Me.chkUserDefinedDataTypes.Name = "chkUserDefinedDataTypes"
        Me.chkUserDefinedDataTypes.Size = New System.Drawing.Size(152, 16)
        Me.chkUserDefinedDataTypes.TabIndex = 2
        Me.chkUserDefinedDataTypes.Text = "User Defined Data Types"
        '
        'chkUsers
        '
        Me.chkUsers.Checked = True
        Me.chkUsers.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkUsers.Location = New System.Drawing.Point(13, 52)
        Me.chkUsers.Name = "chkUsers"
        Me.chkUsers.Size = New System.Drawing.Size(152, 16)
        Me.chkUsers.TabIndex = 1
        Me.chkUsers.Text = "Users"
        '
        'chkDatabaseRoles
        '
        Me.chkDatabaseRoles.Checked = True
        Me.chkDatabaseRoles.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDatabaseRoles.Location = New System.Drawing.Point(13, 28)
        Me.chkDatabaseRoles.Name = "chkDatabaseRoles"
        Me.chkDatabaseRoles.Size = New System.Drawing.Size(152, 16)
        Me.chkDatabaseRoles.TabIndex = 0
        Me.chkDatabaseRoles.Text = "Database Roles"
        '
        'chkTableInsertStatements
        '
        Me.chkTableInsertStatements.Checked = True
        Me.chkTableInsertStatements.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkTableInsertStatements.Location = New System.Drawing.Point(312, 320)
        Me.chkTableInsertStatements.Name = "chkTableInsertStatements"
        Me.chkTableInsertStatements.Size = New System.Drawing.Size(216, 24)
        Me.chkTableInsertStatements.TabIndex = 10
        Me.chkTableInsertStatements.Text = "Generate Table Insert Statements"
        '
        'txtOutputFolderPath
        '
        Me.txtOutputFolderPath.Location = New System.Drawing.Point(8, 278)
        Me.txtOutputFolderPath.Name = "txtOutputFolderPath"
        Me.txtOutputFolderPath.Size = New System.Drawing.Size(288, 20)
        Me.txtOutputFolderPath.TabIndex = 9
        Me.txtOutputFolderPath.Text = "D:\DatabaseScripts\"
        '
        'lblOutputFolderPath
        '
        Me.lblOutputFolderPath.AutoSize = True
        Me.lblOutputFolderPath.Location = New System.Drawing.Point(8, 262)
        Me.lblOutputFolderPath.Name = "lblOutputFolderPath"
        Me.lblOutputFolderPath.Size = New System.Drawing.Size(63, 16)
        Me.lblOutputFolderPath.TabIndex = 8
        Me.lblOutputFolderPath.Text = "Output path"
        '
        'tabpageCreateDatabaseScript
        '
        Me.tabpageCreateDatabaseScript.Controls.Add(Me.txtCreateDatabaseScript)
        Me.tabpageCreateDatabaseScript.DockPadding.All = 5
        Me.tabpageCreateDatabaseScript.Location = New System.Drawing.Point(4, 22)
        Me.tabpageCreateDatabaseScript.Name = "tabpageCreateDatabaseScript"
        Me.tabpageCreateDatabaseScript.Size = New System.Drawing.Size(576, 366)
        Me.tabpageCreateDatabaseScript.TabIndex = 4
        Me.tabpageCreateDatabaseScript.Text = "Create Database Script"
        '
        'txtCreateDatabaseScript
        '
        Me.txtCreateDatabaseScript.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtCreateDatabaseScript.Location = New System.Drawing.Point(5, 5)
        Me.txtCreateDatabaseScript.Multiline = True
        Me.txtCreateDatabaseScript.Name = "txtCreateDatabaseScript"
        Me.txtCreateDatabaseScript.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtCreateDatabaseScript.Size = New System.Drawing.Size(566, 356)
        Me.txtCreateDatabaseScript.TabIndex = 2
        Me.txtCreateDatabaseScript.Text = ""
        '
        'tabpageBuildObjects
        '
        Me.tabpageBuildObjects.Controls.Add(Me.txtBuildObjects)
        Me.tabpageBuildObjects.DockPadding.All = 5
        Me.tabpageBuildObjects.Location = New System.Drawing.Point(4, 22)
        Me.tabpageBuildObjects.Name = "tabpageBuildObjects"
        Me.tabpageBuildObjects.Size = New System.Drawing.Size(576, 366)
        Me.tabpageBuildObjects.TabIndex = 1
        Me.tabpageBuildObjects.Text = "Build Objects Script"
        '
        'tabpageTableInsertStatements
        '
        Me.tabpageTableInsertStatements.Controls.Add(Me.txtTableInsertStatements)
        Me.tabpageTableInsertStatements.DockPadding.All = 5
        Me.tabpageTableInsertStatements.Location = New System.Drawing.Point(4, 22)
        Me.tabpageTableInsertStatements.Name = "tabpageTableInsertStatements"
        Me.tabpageTableInsertStatements.Size = New System.Drawing.Size(576, 366)
        Me.tabpageTableInsertStatements.TabIndex = 2
        Me.tabpageTableInsertStatements.Text = "Table Insert Statements"
        '
        'tabpageImportBlobValues
        '
        Me.tabpageImportBlobValues.Controls.Add(Me.txtImportBlobValues)
        Me.tabpageImportBlobValues.DockPadding.All = 5
        Me.tabpageImportBlobValues.Location = New System.Drawing.Point(4, 22)
        Me.tabpageImportBlobValues.Name = "tabpageImportBlobValues"
        Me.tabpageImportBlobValues.Size = New System.Drawing.Size(576, 366)
        Me.tabpageImportBlobValues.TabIndex = 3
        Me.tabpageImportBlobValues.Text = "Import Blob Values"
        '
        'cmdClose
        '
        Me.cmdClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdClose.Location = New System.Drawing.Point(477, 408)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.Size = New System.Drawing.Size(112, 24)
        Me.cmdClose.TabIndex = 5
        Me.cmdClose.Text = "Close"
        '
        'frmMain
        '
        Me.AcceptButton = Me.cmdGenerate
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(600, 445)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.tabMain)
        Me.Controls.Add(Me.cmdGenerate)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.Text = "Generate Database Scripts"
        Me.tabMain.ResumeLayout(False)
        Me.tabpageConnectionInfo.ResumeLayout(False)
        Me.groupConnectionMethod.ResumeLayout(False)
        Me.groupDatabaseObjects.ResumeLayout(False)
        Me.tabpageCreateDatabaseScript.ResumeLayout(False)
        Me.tabpageBuildObjects.ResumeLayout(False)
        Me.tabpageTableInsertStatements.ResumeLayout(False)
        Me.tabpageImportBlobValues.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private mcolCompletedItems As New System.Collections.Specialized.StringCollection    
    Private mConnectionString As String
    Private mOutputDirectoryPath As String

    Private WithEvents mfrmProgress As frmProgress

    Private mCancelOperation As Boolean

    Private Sub SetVariables()
        If Me.radioSQLServer.Checked Then
            SetSQLServerConnectionString()
        Else
            SetWindowsConnectionString()
        End If
    End Sub

    Private Sub SetWindowsConnectionString()
        Dim Temp As String = "Integrated Security=SSPI;data source=<SERVER>;persist security info=FALSE;initial catalog=<DATABASE>"

        Temp = Temp.Replace("<SERVER>", Me.txtServerName.Text)
        Temp = Temp.Replace("<DATABASE>", Me.txtDatabase.Text)

        mConnectionString = Temp

    End Sub

    Private Sub SetSQLServerConnectionString()
        Dim Temp As String = "User ID=<USERNAME>;pwd=<PASSWORD>;data source=<SERVER>;persist security info=False;initial catalog=<DATABASE>"

        Temp = Temp.Replace("<USERNAME>", Me.txtUsername.Text)
        Temp = Temp.Replace("<PASSWORD>", Me.txtPassword.Text)
        Temp = Temp.Replace("<SERVER>", Me.txtServerName.Text)
        Temp = Temp.Replace("<DATABASE>", Me.txtDatabase.Text)

        mConnectionString = Temp

    End Sub

    Private Sub Generate()
        Dim objServer As SQLDMO.SQLServer2
        Dim objDatabase As SQLDMO.Database2
        Dim ServerName As String = Me.txtServerName.Text
        Dim DatabaseName As String = Me.txtDatabase.Text

        ' Connect to the specified sql server
        objServer = New SQLDMO.SQLServer2

        If Me.radioSQLServer.Checked Then
            objServer.Connect(ServerName, Me.txtUsername.Text, Me.txtPassword.Text)
        Else
            objServer.LoginSecure = True
            objServer.Connect(ServerName)
        End If

        ' Init the output
        Me.txtCreateDatabaseScript.Text = ""
        Me.txtTableInsertStatements.Text = ""
        Me.txtBuildObjects.Text = ""
        Me.txtImportBlobValues.Text = ""
        mCancelOperation = False

        ' Create and show the progress screen
        mfrmProgress = New frmProgress
        mfrmProgress.Show()

        For Each objDatabase In objServer.Databases
            If objDatabase.Name = DatabaseName Then

                ' Create the output path for the database
                mOutputDirectoryPath = Me.txtOutputFolderPath.Text & objDatabase.Name & "\"
                Me.CreateDirectory(mOutputDirectoryPath)
                Me.CreateDirectory(mOutputDirectoryPath & "files\") ' directory to store blob values as files

                ' Initialize the Progress Screen
                mfrmProgress.pbTotal.Maximum = GetDatabaseObjectCount()
                mfrmProgress.pbTotal.Step = 1
                mfrmProgress.pbTotal.Value = 0

                ' Script out the database objects
                ScriptDatabaseRoles(objDatabase)
                ScriptUsers(objDatabase)
                ScriptUserDefinedDataTypes(objDatabase)
                ScriptDefaults(objDatabase)
                ScriptRules(objDatabase)
                ScriptUserDefinedFunctions(objDatabase)
                ScriptTables(objDatabase)
                ScriptViews(objDatabase)
                ScriptStoredProcedures(objDatabase)

                ' Cleanup output
                Me.txtBuildObjects.Text = GetNoCountHeader() & Me.txtBuildObjects.Text
                Me.txtTableInsertStatements.Text = GetNoCountHeader() & Me.txtTableInsertStatements.Text
                Me.txtCreateDatabaseScript.Text = Me.GetCreateDatabaseScript(Me.txtDatabase.Text)
                Me.txtImportBlobValues.Text = GetBatchFileHeader() & Me.txtImportBlobValues.Text & GetBatchFileFooter()

                ' Save Output to disk
                Me.WriteToTextFile(mOutputDirectoryPath & "createdatabase.sql", Me.txtCreateDatabaseScript.Text)
                Me.WriteToTextFile(mOutputDirectoryPath & "buildobjects.sql", Me.txtBuildObjects.Text)
                Me.WriteToTextFile(mOutputDirectoryPath & "populatedata.sql", Me.txtTableInsertStatements.Text)
                Me.WriteToTextFile(mOutputDirectoryPath & "importblobvalues.bat", Me.txtImportBlobValues.Text)
                Me.WriteToTextFile(mOutputDirectoryPath & "install.bat", GetInstallBatchFile())

                ' Copy the setup.bat, osql.exe, and textcopy.exe files to the script folder (existing files to be overwritten)
                System.IO.File.Copy(Application.StartupPath & "\template\setup.bat", mOutputDirectoryPath & "setup.bat", True)
                System.IO.File.Copy(Application.StartupPath & "\template\osql.exe", mOutputDirectoryPath & "osql.exe", True)
                System.IO.File.Copy(Application.StartupPath & "\template\textcopy.exe", mOutputDirectoryPath & "textcopy.exe", True)

                mfrmProgress.cmdCancel.Text = "Finished"

                Exit For

            End If
        Next

        objServer.DisConnect()
        objServer = Nothing

    End Sub

    Private Sub ScriptDatabaseRoles(ByVal objDatabase As SQLDMO.Database2)
        Dim objDatabaseRole As SQLDMO.DatabaseRole
        Dim TempOutput As String

        If Me.chkDatabaseRoles.Checked = False Then Return

        For Each objDatabaseRole In objDatabase.DatabaseRoles()

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            TempOutput = ""

            If objDatabaseRole.IsFixedRole Then

                Try
                    ' Generate CREATE script for the Database Role
                    TempOutput = TempOutput & "PRINT 'CREATING Database Role " & objDatabaseRole.Name & "'" & vbCrLf
                    TempOutput = TempOutput & objDatabaseRole.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

                    ' Add [Database Role] to completed items list
                    mcolCompletedItems.Add(objDatabaseRole.Name)

                    Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & TempOutput

                Catch ex As Exception
                    ' Script Method should only work on Fixed Roles, however I found
                    ' it still generated an error for the Fixed 'Public' role in the 'pubs' database
                    ' so I'm just ignoring any error generated here
                End Try

            End If

        Next

    End Sub

    Private Sub ScriptUsers(ByVal objDatabase As SQLDMO.Database2)
        Dim objUser As SQLDMO.User

        If Me.chkUsers.Checked = False Then Return

        For Each objUser In objDatabase.Users

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            ' Generate CREATE script for the User
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING User " & objUser.Name & "'" & vbCrLf
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objUser.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

            ' Add [User] to completed items list
            mcolCompletedItems.Add(objUser.Name)

        Next

    End Sub

    Private Sub ScriptDefaults(ByVal objDatabase As SQLDMO.Database2)
        Dim objDefault As SQLDMO.Default

        If Me.chkDefaults.Checked = False Then Return

        For Each objDefault In objDatabase.Defaults()

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form

            ' Generate CREATE script for the Default
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING Default " & objDefault.Name & "'" & vbCrLf
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objDefault.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

            ' Add [Default] to completed items list
            mcolCompletedItems.Add(objDefault.Name)

        Next

    End Sub

    Private Sub ScriptRules(ByVal objDatabase As SQLDMO.Database2)
        Dim objRule As SQLDMO.Rule

        If Me.chkRules.Checked = False Then Return

        For Each objRule In objDatabase.Rules()

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            ' Generate CREATE script for the Rule
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING Rule " & objRule.Name & "'" & vbCrLf
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objRule.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

            ' Add [Rule] to completed items list
            mcolCompletedItems.Add(objRule.Name)

        Next

    End Sub

    Private Sub ScriptUserDefinedDataTypes(ByVal objDatabase As SQLDMO.Database2)
        Dim objUserDefinedDataType As SQLDMO.UserDefinedDatatype

        If Me.chkUserDefinedDataTypes.Checked = False Then Return

        For Each objUserDefinedDataType In objDatabase.UserDefinedDatatypes()

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            ' Update Progress Bar
            mfrmProgress.txtCurrentDatabaseObject.Text = objUserDefinedDataType.Name
            mfrmProgress.Refresh()

            ' Generate CREATE script for the User Defined Data Type                        
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING User Defined Data Type " & objUserDefinedDataType.Name & "'" & vbCrLf
            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objUserDefinedDataType.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

            ' Add [UserDefinedDataType] to completed items list
            mcolCompletedItems.Add(objUserDefinedDataType.Name)

            ' Update Progress Bar
            mfrmProgress.pbTotal.PerformStep()
            mfrmProgress.Refresh()

        Next

    End Sub

    Private Sub ScriptUserDefinedFunctions(ByVal objDatabase As SQLDMO.Database2, Optional ByVal Name As String = "")
        Dim objUserDefinedFunction As SQLDMO.UserDefinedFunction
        Dim objDependents As SQLDMO.QueryResults

        If Me.chkUserDefinedFunctions.Checked = False Then Return

        For Each objUserDefinedFunction In objDatabase.UserDefinedFunctions()

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            If Name = "" Or Name = objUserDefinedFunction.Name Then

                ' Script out any Dependent objects first
                objDependents = objUserDefinedFunction.EnumDependencies(SQLDMO.SQLDMO_DEPENDENCY_TYPE.SQLDMODep_Parents)
                ScriptDependencies(objDatabase, objDependents)

                If mcolCompletedItems.Contains(objUserDefinedFunction.Name) = False Then

                    ' Update Progress Bar
                    mfrmProgress.txtCurrentDatabaseObject.Text = objUserDefinedFunction.Name
                    mfrmProgress.Refresh()

                    ' Generate CREATE script for the User Defined Function
                    Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING User Defined Function " & objUserDefinedFunction.Name & "'" & vbCrLf
                    Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objUserDefinedFunction.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

                    ' Add [UserDefinedFunction] to completed items list
                    mcolCompletedItems.Add(objUserDefinedFunction.Name)

                    ' Update Progress Bar
                    mfrmProgress.pbTotal.PerformStep()
                    mfrmProgress.Refresh()

                End If

                ' Exit method if only a single object needed to be scripted (used when dependencies are scripted individually)
                If Name = objUserDefinedFunction.Name Then Return

            End If

        Next

    End Sub

    Private Sub ScriptTables(ByVal objDatabase As SQLDMO.Database2, Optional ByVal Name As String = "")
        Dim objTable As SQLDMO.Table2
        Dim objDependents As SQLDMO.QueryResults

        For Each objTable In objDatabase.Tables

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            If objTable.SystemObject = False Then

                If Name = "" Or Name = objTable.Name Then

                    ' Script out any Dependent objects first
                    objDependents = objTable.EnumDependencies(SQLDMO.SQLDMO_DEPENDENCY_TYPE.SQLDMODep_Parents)
                    ScriptDependencies(objDatabase, objDependents)

                    If mcolCompletedItems.Contains(objTable.Name) = False Then

                        ' Update Progress Bar
                        mfrmProgress.txtCurrentDatabaseObject.Text = objTable.Name
                        mfrmProgress.Refresh()

                        If Me.chkTables.Checked = True Then
                            ' Generate CREATE script for the TABLE                        
                            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING TABLE " & objTable.Name & "'" & vbCrLf
                            Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objTable.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default, , , SQLDMO.SQLDMO_SCRIPT2_TYPE.SQLDMOScript2_FullTextCat Or SQLDMO.SQLDMO_SCRIPT2_TYPE.SQLDMOScript2_FullTextIndex) & vbCrLf & vbCrLf
                        End If

                        ' Add [Table] to completed items list
                        mcolCompletedItems.Add(objTable.Name)

                        ' Generate INSERT Statements for the TABLE if required
                        If Me.chkTableInsertStatements.Checked Then
                            txtTableInsertStatements.Text = txtTableInsertStatements.Text & GenerateTableInserts(objTable, HasIdentityColumn(objTable))
                        End If

                        ' Update Progress Bar
                        mfrmProgress.pbTotal.PerformStep()
                        mfrmProgress.Refresh()

                    End If

                    ' Exit method if only a single object needed to be scripted (used when dependencies are scripted individually)
                    If Name = objTable.Name Then Return

                End If

            End If ' Is System object

        Next

    End Sub

    Private Sub ScriptViews(ByVal objDatabase As SQLDMO.Database2, Optional ByVal Name As String = "")
        Dim objView As SQLDMO.View2
        Dim objDependents As SQLDMO.QueryResults

        If Me.chkViews.Checked = False Then Return

        For Each objView In objDatabase.Views

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            If objView.SystemObject = False Then

                If Name = "" Or Name = objView.Name Then

                    ' Script out any Dependent objects first
                    objDependents = objView.EnumDependencies(SQLDMO.SQLDMO_DEPENDENCY_TYPE.SQLDMODep_Parents)
                    ScriptDependencies(objDatabase, objDependents)

                    If mcolCompletedItems.Contains(objView.Name) = False Then

                        ' Update Progress Bar
                        mfrmProgress.txtCurrentDatabaseObject.Text = objView.Name
                        mfrmProgress.Refresh()

                        ' Generate CREATE script for the VIEW
                        Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING VIEW " & objView.Name & "'" & vbCrLf
                        Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objView.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

                        ' Add [View] to completed items list
                        mcolCompletedItems.Add(objView.Name)

                        ' Update Progress Bar
                        mfrmProgress.pbTotal.PerformStep()
                        mfrmProgress.Refresh()

                    End If

                    ' Exit method if only a single object needed to be scripted (used when dependencies are scripted individually)
                    If Name = objView.Name Then Return

                End If

            End If

        Next

    End Sub

    Private Sub ScriptStoredProcedures(ByVal objDatabase As SQLDMO.Database2, Optional ByVal Name As String = "")
        Dim objStoredProcedure As SQLDMO.StoredProcedure2
        Dim objDependents As SQLDMO.QueryResults

        If Me.chkStoredProcedures.Checked = False Then Return

        For Each objStoredProcedure In objDatabase.StoredProcedures

            Application.DoEvents() ' allow user a chance to press the cancel button on the progress form
            If mCancelOperation Then Return

            If objStoredProcedure.SystemObject = False Then

                If Name = "" Or Name = objStoredProcedure.Name Then

                    ' Script out any Dependent objects first
                    objDependents = objStoredProcedure.EnumDependencies(SQLDMO.SQLDMO_DEPENDENCY_TYPE.SQLDMODep_Parents)
                    ScriptDependencies(objDatabase, objDependents)

                    If mcolCompletedItems.Contains(objStoredProcedure.Name) = False Then

                        'Update Progress Bar
                        mfrmProgress.txtCurrentDatabaseObject.Text = objStoredProcedure.Name
                        mfrmProgress.Refresh()

                        ' Generate CREATE script for the Stored Procedure
                        Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & "PRINT 'CREATING STORED PROCEDURE " & objStoredProcedure.Name & "'" & vbCrLf
                        Me.txtBuildObjects.Text = Me.txtBuildObjects.Text & objStoredProcedure.Script(SQLDMO.SQLDMO_SCRIPT_TYPE.SQLDMOScript_Default) & vbCrLf & vbCrLf

                        ' Add [Stored Procedure] to completed items list
                        mcolCompletedItems.Add(objStoredProcedure.Name)

                        ' Update Progress Bar
                        mfrmProgress.pbTotal.PerformStep()
                        mfrmProgress.Refresh()

                    End If

                    ' Exit method if only a single object needed to be scripted (used when dependencies are scripted individually)
                    If Name = objStoredProcedure.Name Then Return

                End If

            End If

        Next

    End Sub

    Private Sub ScriptDependencies(ByVal objDatabase As SQLDMO.Database2, _
                                   ByVal objDependents As SQLDMO.QueryResults)
        Dim RowIndex As Integer
        Dim ColumnIndex As Integer
        Dim ResultsetIndex As Integer
        Dim DependentColumnIndex As Integer
        Dim DependentTypeColumnIndex As Integer
        Dim DependentName As String
        Dim DependentType As String

        For ResultsetIndex = 1 To objDependents.ResultSets

            objDependents.CurrentResultSet = ResultsetIndex

            DependentColumnIndex = -1
            DependentTypeColumnIndex = -1
            For ColumnIndex = 1 To objDependents.Columns
                If objDependents.ColumnName(ColumnIndex) = "oObjName" Then DependentColumnIndex = ColumnIndex
                If objDependents.ColumnName(ColumnIndex) = "oType" Then DependentTypeColumnIndex = ColumnIndex
            Next

            ' Only loop through the Dependent resultset that contains other objects
            ' Not interested in dependancies for user-defined data types, rules and constraints
            If DependentColumnIndex <> -1 Then
                For RowIndex = 1 To objDependents.Rows

                    DependentName = objDependents.GetColumnString(RowIndex, DependentColumnIndex)
                    DependentType = objDependents.GetColumnString(RowIndex, DependentTypeColumnIndex)

                    If mcolCompletedItems.Contains(DependentName) = False Then
                        ' Add the Dependent item to the script file                                
                        ScriptDependentItem(objDatabase, DependentType, DependentName)
                    End If

                Next
            End If

        Next

    End Sub

    Private Function GetInstallBatchFile() As String
        Dim strOutput As String

        strOutput = ""
        strOutput = strOutput & "@echo off" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "REM Create and populate the database" & vbCrLf
        strOutput = strOutput & "@call setup.bat SQLServer (local) sa BLANK " & Me.txtDatabase.Text & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "ECHO About to Import Large Text and Binary Data..." & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "REM Insert BLOB values (large text and binary data) into the database" & vbCrLf
        strOutput = strOutput & "@call importblobvalues.bat SQLServer (local) sa BLANK " & Me.txtDatabase.Text & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "ECHO Finished" & vbCrLf
        strOutput = strOutput & "PAUSE" & vbCrLf

        Return strOutput

    End Function

    Private Function GetNoCountHeader() As String
        Dim strOutput As String

        strOutput = ""
        strOutput = strOutput & "SET NOCOUNT ON" & vbCrLf
        strOutput = strOutput & "-- Restricts volume of output to errors and" & vbCrLf
        strOutput = strOutput & "-- messages that use the PRINT function" & vbCrLf & vbCrLf

        Return strOutput

    End Function

    Private Function GetBatchFileHeader() As String
        Dim strOutput As String

        strOutput = ""
        strOutput = strOutput & "@Echo Off" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "CLS" & vbCrLf
        strOutput = strOutput & "ECHO MYCOMPANYNAME MYPRODUCTNAME Database Setup " & vbCrLf
        strOutput = strOutput & "ECHO for MYCOMPANYNAME MYPRODUCTNAME v4.0.1.0" & vbCrLf
        strOutput = strOutput & "ECHO Copyright (C) MYCOMPANYNAME 2004. All rights reserved." & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "IF ""%1""=="""" GOTO usage" & vbCrLf
        strOutput = strOutput & "IF ""%2""=="""" GOTO usage" & vbCrLf
        strOutput = strOutput & "IF ""%3""=="""" GOTO usage" & vbCrLf
        strOutput = strOutput & "IF ""%4""=="""" GOTO usage" & vbCrLf
        strOutput = strOutput & "IF ""%5""=="""" GOTO usage" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "IF ""%4""==""BLANK"" goto blankpassword" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "SET PARAM_PASSWORD=%4" & vbCrLf
        strOutput = strOutput & "GOTO setparams" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & ":blankpassword" & vbCrLf
        strOutput = strOutput & "SET PARAM_PASSWORD=""""" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & ":setparams" & vbCrLf
        strOutput = strOutput & "SET PARAM_CONNECTIONMETHOD=%1" & vbCrLf
        strOutput = strOutput & "SET PARAM_SERVER=%2" & vbCrLf
        strOutput = strOutput & "SET PARAM_USERNAME=%3" & vbCrLf
        strOutput = strOutput & "SET PARAM_DATABASE=%5" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "REM Echo %PARAM_CONNECTIONMETHOD%" & vbCrLf
        strOutput = strOutput & "REM Echo %PARAM_SERVER%" & vbCrLf
        strOutput = strOutput & "REM Echo %PARAM_USERNAME%" & vbCrLf
        strOutput = strOutput & "REM Echo %PARAM_PASSWORD%" & vbCrLf
        strOutput = strOutput & "REM Echo %PARAM_DATABASE%" & vbCrLf

        Return strOutput

    End Function

    Private Function GetBatchFileFooter() As String
        Dim strOutput As String

        strOutput = ""

        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "goto done" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & ":usage" & vbCrLf
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & "ECHO Usage: setup.bat AuthenticationMethod Server Username Password" & vbCrLf
        strOutput = strOutput & "ECHO     eg: setup.bat SQLServer (local) sa BLANK northwind" & vbCrLf
        strOutput = strOutput & "ECHO     eg: setup.bat Windows (local) sa BLANK northwind" & vbCrLf        
        strOutput = strOutput & "" & vbCrLf
        strOutput = strOutput & ":done" & vbCrLf

        Return strOutput

    End Function

#Region "File I/O Methods"

    Private Function CreateDirectory(ByVal FolderPath As String) As Boolean
        System.IO.Directory.CreateDirectory(FolderPath)
        Return True
    End Function

    Private Function WriteToTextFile(ByVal FileName As String, ByVal FileContents As String) As Boolean
        Dim fs As FileStream                 ' Writes the FileContents to a file 
        Dim sw As IO.StreamWriter            ' Streams the text data to the FileStream object.

        ' Create a file to hold the output. (existing files will be overwritten)
        fs = New FileStream(FileName, FileMode.Create, FileAccess.Write)
        sw = New StreamWriter(fs)

        sw.Write(FileContents)

        sw.Flush()

        ' Close the output file.            
        sw.Close()
        fs.Close()

        Return True

    End Function

#End Region

    Private Function GetCreateDatabaseScript(ByVal DatabaseName As String) As String
        Dim Temp As String

        Temp = ""
        Temp = Temp & "USE [master]" & vbCrLf
        Temp = Temp & "" & vbCrLf
        Temp = Temp & "IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'<DATABASE>')" & vbCrLf
        Temp = Temp & "	DROP DATABASE [<DATABASE>]" & vbCrLf
        Temp = Temp & "GO" & vbCrLf
        Temp = Temp & "" & vbCrLf
        Temp = Temp & "CREATE DATABASE [<DATABASE>]" & vbCrLf
        Temp = Temp & "GO" & vbCrLf

        Temp = Temp.Replace("<DATABASE>", DatabaseName)

        Return Temp

    End Function

    Private Function GetDatabaseObjectCount() As Integer
        Dim strSQL As String
        Dim oData As New SQLHelper
        Dim oReader As System.Data.IDataReader
        Dim DatabaseObjectCount As Integer

        strSQL = ""
        strSQL = strSQL & "SELECT COUNT(*) As DatabaseObjectCount" & vbCrLf
        strSQL = strSQL & "FROM sysobjects" & vbCrLf
        strSQL = strSQL & "where " & vbCrLf
        strSQL = strSQL & "	(type='U' or type='P' or type='V' or type='FN')" & vbCrLf
        strSQL = strSQL & "	AND SUBSTRING(name, 1, 3) <> 'dt_' -- REMOVES Source Control Procedures" & vbCrLf
        strSQL = strSQL & "	AND SUBSTRING(name, 1, 3) <> 'sys' -- REMOVES System Views" & vbCrLf

        oReader = oData.ExecuteSQLReturnResultset(mConnectionString, strSQL)

        DatabaseObjectCount = 0
        If oReader.Read Then
            DatabaseObjectCount = CInt(oReader.Item("DatabaseObjectCount"))
        End If

        Return DatabaseObjectCount

    End Function

    Private Function HasIdentityColumn(ByVal objTable As SQLDMO.Table2) As Boolean
        Dim objColumn As SQLDMO.Column

        For Each objColumn In objTable.Columns
            If objColumn.Identity = True Then
                Return True
            End If
        Next

        Return False

    End Function

#Region "AddItemScripts"

    Private Sub ScriptDependentItem(ByVal objDatabase As SQLDMO.Database2, _
                                    ByVal ItemType As String, _
                                    ByVal ItemName As String)

        Select Case ItemType

            Case "8" ' User defined Table
                ScriptTables(objDatabase, ItemName)

            Case "4" ' View
                ScriptViews(objDatabase, ItemName)

            Case "1" ' User Defined Function
                ScriptUserDefinedFunctions(objDatabase, ItemName)

            Case "16" ' Stored Procedure
                ScriptStoredProcedures(objDatabase, ItemName)

        End Select


    End Sub

#End Region

    Private Function GenerateTableInserts(ByVal objTable As SQLDMO.Table2, _
                                          ByVal HasIdentityColumn As Boolean) As String
        Dim oReader As System.Data.IDataReader
        Dim oData As New SQLHelper
        Dim ColumnIndex As Integer

        Dim strColumnOutput As String
        Dim strValueOutput As String
        Dim strOutput As String
        Dim strTableOutput As String
        Dim RowCount As Integer = 0
        Dim TableName As String
        Dim strTemp As String
        Dim FileName As String
        Dim bRetValue As Boolean

        TableName = objTable.Name

        ' Get all rows of data for the table from the database (BLOB columns are last in the select list)
        oReader = Me.GetReaderForTable(objTable)

        strColumnOutput = ""
        strOutput = ""

        Do While oReader.Read

            If mCancelOperation Then Exit Do

            RowCount = RowCount + 1
            strValueOutput = ""

            ' Update Progress Screen
            mfrmProgress.txtRowCount.Text = RowCount.ToString
            mfrmProgress.Refresh()

            If strColumnOutput = "" Then
                ' Build the column headings part of the INSERT statement (this is done once only for the first row in a table as it will be the same for all rows)
                strColumnOutput = "INSERT INTO [" & TableName & "] ("
                For ColumnIndex = 0 To oReader.FieldCount - 1
                    strColumnOutput = strColumnOutput & "[" & oReader.GetName(ColumnIndex) & "]"
                    If ColumnIndex <> oReader.FieldCount - 1 Then
                        strColumnOutput = strColumnOutput & ","
                    End If
                Next
                strColumnOutput = strColumnOutput & ")" ' End of "INSERT INTO TABLE (Column1, Column2)"
            End If

            ' Build INSERT statement for the row values
            strValueOutput = " VALUES ("
            For ColumnIndex = 0 To oReader.FieldCount - 1

                If IsSupportedBlobColumn(oReader.GetDataTypeName(ColumnIndex)) Then

                    ' BLOB values are replaced with initializers in the table insert statements
                    ' and are later added via a separate batch file

                    ' ========================================================
                    ' NOTE: ntext columns are currently not supported.
                    '       All ntext data will be replaced with NULL values
                    ' ========================================================

                    ' Get BLOB value                    
                    Select Case oReader.GetDataTypeName(ColumnIndex)

                        Case "image"

                            ' Inititalize Image Column for the Table Insert Statement (otherwise Textcopy.exe won't work)
                            strValueOutput = strValueOutput & "0xFFFFFFFF"
                            FileName = Me.mOutputDirectoryPath & "files\" & Guid.NewGuid.ToString & ".dat"
                            ' bRetValue = Me.WriteImageColumnToTextFile(FileName, oReader, ColumnIndex)
                            bRetValue = Me.WriteImageColumnToBinaryFile(FileName, oReader, ColumnIndex)

                        Case "text" ' ,"ntext" currently not supported

                            ' Inititalize Text Column for the Table Insert Statement (otherwise Textcopy.exe won't work)
                            strValueOutput = strValueOutput & "''"
                            FileName = Me.mOutputDirectoryPath & "files\" & Guid.NewGuid.ToString & ".txt"
                            bRetValue = Me.WriteTextColumnToTextFile(FileName, oReader, ColumnIndex)

                        Case Else
                            bRetValue = False

                    End Select

                    ' Check to see if a BLOB value was actually written to a file and was not just a NULL value
                    If bRetValue Then

                        ' Build batch file line to import file into BLOB column in current table
                        strTemp = "textcopy -I -U%PARAM_USERNAME% -P%PARAM_PASSWORD% -S%PARAM_SERVER% -D%PARAM_DATABASE% -T<TABLENAME> -C<COLUMNNAME> -W""<WHERECLAUSE>"" -F<FILENAME>"
                        strTemp = strTemp.Replace("<TABLENAME>", "[" & objTable.Name & "]")
                        strTemp = strTemp.Replace("<COLUMNNAME>", "[" & oReader.GetName(ColumnIndex) & "]")
                        strTemp = strTemp.Replace("<WHERECLAUSE>", Me.GenerateWhereClause(objTable, oReader))
                        strTemp = strTemp.Replace("<FILENAME>", FileName) & vbCrLf

                        ' Generate batch file text for importing the BLOB value
                        Me.txtImportBlobValues.Text = txtImportBlobValues.Text & strTemp

                    End If

                Else
                    ' Get non BLOB column value for Table Insert Statement
                    strValueOutput = strValueOutput & GetValueForTableInsertStatement(oReader.GetDataTypeName(ColumnIndex), oReader.Item(ColumnIndex))
                End If

                If ColumnIndex <> oReader.FieldCount - 1 Then
                    strValueOutput = strValueOutput & ","
                End If

            Next
            strValueOutput = strValueOutput & ")"

            ' Combine the ColumnNames and Values section of the INSERT statement
            strOutput = strOutput & strColumnOutput & strValueOutput & vbCrLf

        Loop
        If oReader.IsClosed = False Then oReader.Close()

        If RowCount > 0 Then

            strTableOutput = strTableOutput & vbCrLf & "PRINT 'INSERTING DATA INTO TABLE " & TableName & "'" & vbCrLf

            ' Disable Constraint Checking so that foreign key constraints do not hinder bulk insert operations
            strTableOutput = strTableOutput & "ALTER TABLE [" & TableName & "] NOCHECK CONSTRAINT ALL" & vbCrLf ' Disable all constraints

            ' Disable identity columns insertion
            If HasIdentityColumn Then strTableOutput = strTableOutput & "SET IDENTITY_INSERT [" & TableName & "] ON" & vbCrLf

            ' Add the "INSERT INTO tblMyTable (..) VALUES (...)" statements
            strTableOutput = strTableOutput & strOutput

            ' Disable identity columns insertion
            If HasIdentityColumn Then strTableOutput = strTableOutput & "SET IDENTITY_INSERT [" & TableName & "] OFF" & vbCrLf

            ' Turn back on Constraint Checking
            strTableOutput = strTableOutput & "ALTER TABLE [" & TableName & "] CHECK CONSTRAINT ALL" & vbCrLf ' Re-enable all constraints            

            Return strTableOutput

        Else
            Return ""
        End If

    End Function

    ' This method generates the where clause for a specific row in a table
    ' SQLDMO is used to identify which columns are part of the Primary Key
    ' and the datareader is used to pull in the values for the columns in the Primary Key
    Private Function GenerateWhereClause(ByVal objTable As SQLDMO.Table2, _
                                         ByVal oReader As System.Data.IDataReader) As String

        Dim strWhereClause As String
        Dim objColumn As SQLDMO.Column

        strWhereClause = ""

        For Each objColumn In objTable.Columns
            If objColumn.InPrimaryKey Then
                If strWhereClause <> "" Then
                    strWhereClause = strWhereClause & " AND "
                End If
                strWhereClause = strWhereClause & "[" & objColumn.Name & "]=" & Me.GetValueForTableInsertStatement(objColumn.Datatype, oReader.Item(objColumn.Name))
            End If
        Next

        strWhereClause = "WHERE " & strWhereClause

        Return strWhereClause

    End Function

    ' This method is used to return a reseultset (reader) for a table
    ' where the BLOB columns are the last in the SELECT list
    Private Function GetReaderForTable(ByVal objTable As SQLDMO.Table2) As System.Data.IDataReader
        Dim strSQL As String
        Dim strColumns As String
        Dim strBlobColumns As String

        Dim objColumn As SQLDMO.Column

        strColumns = ""
        strBlobColumns = ""

        For Each objColumn In objTable.Columns

            If Me.IsBlobColumn(objColumn.Datatype) Then
                If strBlobColumns <> "" Then strBlobColumns = strBlobColumns & ", "
                strBlobColumns = strBlobColumns & "[" & objColumn.Name & "]"
            Else
                If strColumns <> "" Then strColumns = strColumns & ", "
                strColumns = strColumns & "[" & objColumn.Name & "]"
            End If

        Next

        strSQL = "SELECT " & strColumns
        If strBlobColumns <> "" Then
            ' Append the BLOB columns after all of the other columns in the table
            strSQL = strSQL & ", " & strBlobColumns
        End If

        strSQL = strSQL & " FROM [" & objTable.Name & "]"

        Dim objData As New SQLHelper
        Dim oReader As System.Data.IDataReader

        oReader = objData.ExecuteSQLReturnResultset(mConnectionString, strSQL)

        Return oReader

    End Function

    Private Function GetValueForTableInsertStatement(ByVal DataTypeName As String, ByVal Value As Object) As String
        Dim Temp As String
        Dim dtValue As Date

        If Value Is System.DBNull.Value Then Return "NULL"

        Select Case DataTypeName.ToLower

            Case "int", "decimal", "real", "bigint", "smallint", "tinyint", "float", "money", "numeric", "real", "smallmoney", "varbinary", "binary"
                Return Value.ToString()

            Case "nvarchar", "varchar", "char", "nchar", "uniqueidentifier"
                Return "'" & Value.ToString.Replace("'", "''") & "'"

            Case "ntext"
                Return "NULL" ' Unfortunately not supported as TextCopy does not work on ntext columns

            Case "datetime", "smalldatetime", "timestamp"
                dtValue = CType(Value, Date)
                ' Convert to universal datetime format (will work on all databases in all countries)
                Return "'" & dtValue.ToString("yyyy/MM/dd hh:mm:ss tt") & "'"

            Case "bit"
                Temp = Value.ToString()
                Temp = Temp.Replace("True", "1")
                Temp = Temp.Replace("False", "0")
                Return Temp

            Case Else ' "sql_variant" columns should be catered for as the underlying physical datatype should be passed to this method
                Return "NOTSUPPORTED"

        End Select

    End Function


#Region "Unused Blob functions"

    'Private Function GetBlobValue(ByVal oReader As System.Data.IDataReader, ByVal ColIndex As Integer) As String

    '    Dim bufferSize As Integer = 5000      ' The size of the BLOB buffer.
    '    Dim outbyte(bufferSize - 1) As Byte  ' The BLOB byte() buffer to be filled by GetBytes.
    '    Dim retval As Long                   ' The bytes returned from GetBytes.
    '    Dim startIndex As Long = 0           ' The starting position in the BLOB output.        

    '    Dim arTemp As Array
    '    Dim Output As New System.Text.StringBuilder(10000)

    '    Dim oTemp As Object

    '    oTemp = oReader.Item(ColIndex)

    '    If oTemp Is System.DBNull.Value Then Return "NULL"

    '    ' TODO: Error check value is a byte array before casting
    '    If IsNullByteArray(CType(oTemp, Byte())) Then Return "NULL"

    '    ' Reset the starting byte for a new BLOB.
    '    startIndex = 0

    '    ' Read bytes into outbyte() and retain the number of bytes returned.
    '    retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

    '    ' Continue reading and writing while there are bytes beyond the size of the buffer.
    '    Do While retval = bufferSize

    '        ' Append chunk of chars to the output
    '        Output.Append(System.Text.Encoding.Unicode.GetString(outbyte))

    '        ' Reposition the start index to the end of the last buffer and fill the buffer.
    '        startIndex += bufferSize
    '        retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

    '    Loop

    '    ' Write the remaining buffer if necessary
    '    If (retval - 1) >= 0 Then

    '        ' copy remaining bytes into a smaller byte array
    '        arTemp = Array.CreateInstance(GetType(Byte), retval - 1)
    '        Array.Copy(outbyte, 0, arTemp, 0, retval - 1)

    '        ' Append remaining chunk of chars to the output
    '        Output.Append(System.Text.Encoding.Unicode.GetString(CType(arTemp, Byte())))

    '    End If

    '    ' Enclose Blob value within single quotes and double up the single quotes within the BLOB data
    '    Return "'" & Output.ToString.Replace("'", "''") & "'"

    'End Function

#End Region

#Region "Blob Functions"

    Private Function IsBlobColumn(ByVal DataTypeName As String) As Boolean
        Select Case DataTypeName
            Case "image", "text"
                Return True
            Case "ntext"
                Return True
            Case Else
                Return False
        End Select
    End Function

    Private Function IsSupportedBlobColumn(ByVal DataTypeName As String) As Boolean
        Select Case DataTypeName
            Case "image", "text"
                Return True
            Case "ntext"
                Return False ' ntext is not currently supported because TEXTCOPY only works for text and image columns
            Case Else
                Return False
        End Select
    End Function

    Private Function IsNullByteArray(ByVal arByte() As Byte) As Boolean
        If arByte.Length = 4 Then
            If arByte(0) = 255 And arByte(1) = 255 And arByte(2) = 255 And arByte(3) = 255 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Private Function IsNullCharArray(ByVal arChar() As Char) As Boolean
        If arChar.Length = 1 Then
            If arChar(0) = "" Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Private Function WriteImageColumnToTextFile(ByVal FileName As String, _
                                                ByVal oReader As System.Data.IDataReader, _
                                                ByVal ColIndex As Integer) As Boolean

        Dim bufferSize As Integer = 512000      ' The size of the BLOB buffer.
        Dim outbyte(bufferSize - 1) As Byte  ' The BLOB byte() buffer to be filled by GetBytes.
        Dim retval As Long                   ' The bytes returned from GetBytes.
        Dim startIndex As Long = 0           ' The starting position in the BLOB output.        

        Dim arTemp As Array

        Dim fs As FileStream                 ' Writes the BLOB to a file 
        Dim sw As IO.StreamWriter            ' Streams the text data to the FileStream object.

        Dim TotalBytes As Long

        Dim oTemp As Object

        oTemp = oReader.Item(ColIndex)

        If oTemp Is System.DBNull.Value Then Return False

        ' TODO: Error check value is a byte array before casting
        If IsNullByteArray(CType(oTemp, Byte())) Then Return False

        ' Create a file to hold the output.
        fs = New FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write)
        sw = New StreamWriter(fs)

        ' Reset the starting byte for a new BLOB.
        startIndex = 0
        TotalBytes = 0

        ' Read bytes into outbyte() and retain the number of bytes returned.
        retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

        ' Continue reading and writing while there are bytes beyond the size of the buffer.
        Do While retval = bufferSize

            ' Update Progress Screen
            TotalBytes = TotalBytes + bufferSize
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

            sw.Write(System.Text.Encoding.Unicode.GetString(outbyte))
            sw.Flush()

            ' Reposition the start index to the end of the last buffer and fill the buffer.
            startIndex += bufferSize
            retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

        Loop

        ' Write the remaining buffer if necessary
        If (retval) > 0 Then

            ' copy remaining bytes into a smaller byte array
            arTemp = Array.CreateInstance(GetType(Byte), retval)
            Array.Copy(outbyte, 0, arTemp, 0, retval)

            ' Append remaining chunk of chars to the output
            sw.Write(System.Text.Encoding.Unicode.GetString(CType(arTemp, Byte())))

            ' Update Progress Screen
            TotalBytes = TotalBytes + (retval)
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

        End If

        sw.Flush()

        ' Close the output file.            
        sw.Close()
        fs.Close()

        Return True

    End Function

    Private Function WriteTextColumnToTextFile(ByVal FileName As String, _
                                               ByVal oReader As System.Data.IDataReader, _
                                               ByVal ColIndex As Integer) As Boolean

        Dim bufferSize As Integer = 4096     ' The size of the BLOB buffer.
        Dim outchar(bufferSize - 1) As Char  ' The BLOB char() buffer to be filled by GetChars.
        Dim retval As Long                   ' The bytes returned from GetChars.
        Dim startIndex As Long = 0           ' The starting position in the BLOB output.        

        Dim arTemp As Array

        Dim fs As FileStream                 ' Writes the BLOB to a file 
        Dim sw As IO.StreamWriter            ' Streams the text data to the FileStream object.
        Dim TotalBytes As Long

        Dim oTemp As Object

        oTemp = oReader.Item(ColIndex)

        If oTemp Is System.DBNull.Value Then Return False

        '' TODO: Error check value is a char array before casting
        'If IsNullCharArray(CType(oTemp, Char())) Then Return False

        ' Create a file to hold the output.
        fs = New FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write)
        sw = New StreamWriter(fs)

        ' Reset the starting byte for a new BLOB.
        startIndex = 0

        ' Read bytes into outchar() and retain the number of chars returned.
        retval = oReader.GetChars(ColIndex, startIndex, outchar, CInt(0), CInt(bufferSize))

        ' Continue reading and writing while there are bytes beyond the size of the buffer.
        Do While retval = bufferSize

            ' Update Progress Screen
            TotalBytes = TotalBytes + bufferSize
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

            sw.Write(outchar)
            sw.Flush()

            ' Reposition the start index to the end of the last buffer and fill the buffer.
            startIndex += bufferSize
            retval = oReader.GetChars(ColIndex, startIndex, outchar, CInt(0), CInt(bufferSize))

        Loop

        ' Write the remaining buffer if necessary
        If (retval) > 0 Then

            ' copy remaining chars into a smaller char array
            arTemp = Array.CreateInstance(GetType(Char), retval)
            Array.Copy(outchar, 0, arTemp, 0, retval)

            ' Append remaining chunk of chars to the output
            sw.Write(CType(arTemp, Char()))

            ' Update Progress Screen
            TotalBytes = TotalBytes + (retval)
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

        End If

        sw.Flush()

        ' Close the output file.            
        sw.Close()
        fs.Close()

        Return True

    End Function

    Private Function WriteImageColumnToBinaryFile(ByVal FileName As String, _
                                                  ByVal oReader As System.Data.IDataReader, _
                                                  ByVal ColIndex As Integer) As Boolean

        Dim bufferSize As Integer = 4096    ' The size of the BLOB buffer.
        Dim outbyte(bufferSize - 1) As Byte  ' The BLOB byte() buffer to be filled by GetBytes.
        Dim retval As Long                   ' The bytes returned from GetBytes.
        Dim startIndex As Long = 0           ' The starting position in the BLOB output.        

        Dim arTemp As Array

        Dim fs As FileStream                 ' Writes the BLOB to a file 
        Dim bw As IO.BinaryWriter             ' Streams the text data to the FileStream object.
        Dim TotalBytes As Long

        Dim oTemp As Object

        oTemp = oReader.Item(ColIndex)

        If oTemp Is System.DBNull.Value Then Return False

        ' TODO: Error check value is a byte array before casting
        If IsNullByteArray(CType(oTemp, Byte())) Then Return False

        ' Create a file to hold the output.
        fs = New FileStream(FileName, FileMode.OpenOrCreate, FileAccess.Write)
        bw = New BinaryWriter(fs)

        ' Reset the starting byte for a new BLOB.
        startIndex = 0

        ' Read bytes into outbyte() and retain the number of bytes returned.
        retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

        ' Continue reading and writing while there are bytes beyond the size of the buffer.
        Do While retval = bufferSize

            ' Update Progress Screen
            TotalBytes = TotalBytes + bufferSize
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

            bw.Write(outbyte)
            bw.Flush()

            ' Reposition the start index to the end of the last buffer and fill the buffer.
            startIndex += bufferSize
            retval = oReader.GetBytes(ColIndex, startIndex, outbyte, CInt(0), CInt(bufferSize))

        Loop

        ' Write the remaining buffer if necessary
        If (retval) > 0 Then

            ' copy remaining bytes into a smaller byte array
            arTemp = Array.CreateInstance(GetType(Byte), retval)
            Array.Copy(outbyte, 0, arTemp, 0, retval)

            ' Append remaining chunk of chars to the output
            bw.Write(CType(arTemp, Byte()))

            ' Update Progress Screen
            TotalBytes = TotalBytes + (retval)
            mfrmProgress.txtByteCount.Text = TotalBytes.ToString
            mfrmProgress.Refresh()

        End If

        bw.Flush()

        ' Close the output file.            
        bw.Close()
        fs.Close()

        Return True

    End Function

#End Region

    Private Sub cmdGenerate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdGenerate.Click
        Try
            Cursor.Current = Cursors.WaitCursor

            SetVariables()
            Generate()

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, Application.ProductName)
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Try
            Cursor.Current = Cursors.WaitCursor
            Application.Exit()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Exclamation, Application.ProductName)
        Finally
            Cursor.Current = Cursors.Default
        End Try
    End Sub

    Private Sub mfrmProgress_OnCancelOperation() Handles mfrmProgress.OnCancelOperation
        mCancelOperation = True
    End Sub

    Private Sub cmdSelectAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSelectAll.Click
        Me.chkDatabaseRoles.Checked = True
        Me.chkUsers.Checked = True
        Me.chkUserDefinedDataTypes.Checked = True
        Me.chkUserDefinedFunctions.Checked = True
        Me.chkDefaults.Checked = True
        Me.chkRules.Checked = True
        Me.chkTables.Checked = True
        Me.chkViews.Checked = True
        Me.chkStoredProcedures.Checked = True
    End Sub

    Private Sub cmdSelectNone_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSelectNone.Click
        Me.chkDatabaseRoles.Checked = False
        Me.chkUsers.Checked = False
        Me.chkUserDefinedDataTypes.Checked = False
        Me.chkUserDefinedFunctions.Checked = False
        Me.chkDefaults.Checked = False
        Me.chkRules.Checked = False
        Me.chkTables.Checked = False
        Me.chkViews.Checked = False
        Me.chkStoredProcedures.Checked = False
    End Sub

End Class
