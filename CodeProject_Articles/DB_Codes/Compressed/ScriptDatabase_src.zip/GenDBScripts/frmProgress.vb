Public Class frmProgress
    Inherits System.Windows.Forms.Form

    Public Event OnCancelOperation()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pbTotal As System.Windows.Forms.ProgressBar
    Friend WithEvents lblTotalProgress As System.Windows.Forms.Label
    Friend WithEvents lblProgressTableInsertStatement As System.Windows.Forms.Label
    Friend WithEvents txtRowCount As System.Windows.Forms.TextBox
    Friend WithEvents txtByteCount As System.Windows.Forms.TextBox
    Friend WithEvents lblByteCount As System.Windows.Forms.Label
    Friend WithEvents txtCurrentDatabaseObject As System.Windows.Forms.TextBox
    Friend WithEvents lblCurrentObject As System.Windows.Forms.Label
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.pbTotal = New System.Windows.Forms.ProgressBar
        Me.lblTotalProgress = New System.Windows.Forms.Label
        Me.lblProgressTableInsertStatement = New System.Windows.Forms.Label
        Me.txtRowCount = New System.Windows.Forms.TextBox
        Me.txtByteCount = New System.Windows.Forms.TextBox
        Me.lblByteCount = New System.Windows.Forms.Label
        Me.txtCurrentDatabaseObject = New System.Windows.Forms.TextBox
        Me.lblCurrentObject = New System.Windows.Forms.Label
        Me.cmdCancel = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'pbTotal
        '
        Me.pbTotal.Location = New System.Drawing.Point(16, 32)
        Me.pbTotal.Name = "pbTotal"
        Me.pbTotal.Size = New System.Drawing.Size(416, 24)
        Me.pbTotal.TabIndex = 0
        '
        'lblTotalProgress
        '
        Me.lblTotalProgress.AutoSize = True
        Me.lblTotalProgress.Location = New System.Drawing.Point(16, 8)
        Me.lblTotalProgress.Name = "lblTotalProgress"
        Me.lblTotalProgress.Size = New System.Drawing.Size(81, 16)
        Me.lblTotalProgress.TabIndex = 1
        Me.lblTotalProgress.Text = "Total Progress:"
        '
        'lblProgressTableInsertStatement
        '
        Me.lblProgressTableInsertStatement.AutoSize = True
        Me.lblProgressTableInsertStatement.Location = New System.Drawing.Point(16, 121)
        Me.lblProgressTableInsertStatement.Name = "lblProgressTableInsertStatement"
        Me.lblProgressTableInsertStatement.Size = New System.Drawing.Size(204, 16)
        Me.lblProgressTableInsertStatement.TabIndex = 2
        Me.lblProgressTableInsertStatement.Text = "Current Row for Table Insert Statement:"
        '
        'txtRowCount
        '
        Me.txtRowCount.Location = New System.Drawing.Point(16, 145)
        Me.txtRowCount.Name = "txtRowCount"
        Me.txtRowCount.Size = New System.Drawing.Size(80, 20)
        Me.txtRowCount.TabIndex = 3
        Me.txtRowCount.Text = ""
        '
        'txtByteCount
        '
        Me.txtByteCount.Location = New System.Drawing.Point(16, 201)
        Me.txtByteCount.Name = "txtByteCount"
        Me.txtByteCount.Size = New System.Drawing.Size(80, 20)
        Me.txtByteCount.TabIndex = 5
        Me.txtByteCount.Text = ""
        '
        'lblByteCount
        '
        Me.lblByteCount.AutoSize = True
        Me.lblByteCount.Location = New System.Drawing.Point(16, 177)
        Me.lblByteCount.Name = "lblByteCount"
        Me.lblByteCount.Size = New System.Drawing.Size(258, 16)
        Me.lblByteCount.TabIndex = 4
        Me.lblByteCount.Text = "Bytes(chars) written to disk for current BLOB value"
        '
        'txtCurrentDatabaseObject
        '
        Me.txtCurrentDatabaseObject.Location = New System.Drawing.Point(16, 88)
        Me.txtCurrentDatabaseObject.Name = "txtCurrentDatabaseObject"
        Me.txtCurrentDatabaseObject.Size = New System.Drawing.Size(416, 20)
        Me.txtCurrentDatabaseObject.TabIndex = 7
        Me.txtCurrentDatabaseObject.Text = ""
        '
        'lblCurrentObject
        '
        Me.lblCurrentObject.AutoSize = True
        Me.lblCurrentObject.Location = New System.Drawing.Point(16, 64)
        Me.lblCurrentObject.Name = "lblCurrentObject"
        Me.lblCurrentObject.Size = New System.Drawing.Size(129, 16)
        Me.lblCurrentObject.TabIndex = 6
        Me.lblCurrentObject.Text = "Current Database Object"
        '
        'cmdCancel
        '
        Me.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.cmdCancel.Location = New System.Drawing.Point(352, 240)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(88, 24)
        Me.cmdCancel.TabIndex = 8
        Me.cmdCancel.Text = "Cancel"
        '
        'frmProgress
        '
        Me.AcceptButton = Me.cmdCancel
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.cmdCancel
        Me.ClientSize = New System.Drawing.Size(448, 271)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.txtCurrentDatabaseObject)
        Me.Controls.Add(Me.lblCurrentObject)
        Me.Controls.Add(Me.txtByteCount)
        Me.Controls.Add(Me.lblByteCount)
        Me.Controls.Add(Me.txtRowCount)
        Me.Controls.Add(Me.lblProgressTableInsertStatement)
        Me.Controls.Add(Me.lblTotalProgress)
        Me.Controls.Add(Me.pbTotal)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmProgress"
        Me.Text = "Progress"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        RaiseEvent OnCancelOperation()
        Me.Close()
    End Sub
End Class
