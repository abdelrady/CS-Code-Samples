Option Strict Off

Public Class SQLHelper

    Private Const mDebug As Boolean = False

    Public Function ExecuteSQLReturnDataSet(ByVal ConnectionString As String, ByVal strSQL As String) As System.Data.DataSet
        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oDataSet As System.Data.DataSet
        Dim oAdapter As System.Data.SqlClient.SqlDataAdapter

        If mDebug Then Console.WriteLine(strSQL)

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oAdapter = New System.Data.SqlClient.SqlDataAdapter(strSQL, oConn)

        oDataSet = New DataSet

        oAdapter.Fill(oDataSet)

        Return oDataSet

    End Function

    Public Function ExecuteSPReturnDataSet(ByVal ConnectionString As String, ByVal strSP As String, ByVal params As Object) As System.Data.DataSet

        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oCommand As System.Data.SqlClient.SqlCommand
        Dim oAdapter As System.Data.SqlClient.SqlDataAdapter
        Dim oDataset As System.Data.DataSet

        If mDebug Then
            'Console.WriteLine("ExecuteSPReturnResultset3 called")
            Console.WriteLine(strSP)
        End If

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oConn
        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        oAdapter = New System.Data.SqlClient.SqlDataAdapter(oCommand)

        oDataset = New DataSet
        oAdapter.Fill(oDataset)

        Return oDataset

    End Function

    Public Function ExecuteSQL(ByVal ConnectionString As String, ByVal strSQL As String)

        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oCommand As System.Data.SqlClient.SqlCommand

        If mDebug Then
            'Console.WriteLine("ExecuteSQL called")
            Console.WriteLine(strSQL)
        End If

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oConn
        oCommand.CommandText = strSQL
        oCommand.CommandType = CommandType.Text

        oCommand.ExecuteNonQuery()

        oConn.Close()

    End Function

    Public Sub ExecuteSQL(ByVal oTrans As System.Data.SqlClient.SqlTransaction, ByVal strSQL As String)
        Dim oCommand As System.Data.SqlClient.SqlCommand

        If mDebug Then
            'Console.WriteLine("ExecuteSP (Trans) called")
            Console.WriteLine(strSQL)
        End If

        oCommand = New System.Data.SqlClient.SqlCommand
        oCommand.Connection = oTrans.Connection

        ' =======================
        ' Set the Transaction !!!
        ' =======================
        oCommand.Transaction = oTrans

        oCommand.CommandText = strSQL
        oCommand.CommandType = CommandType.Text

        oCommand.ExecuteNonQuery()

    End Sub

    Public Function ExecuteSQLReturnResultset(ByVal ConnectionString As String, ByVal strSQL As String) As System.Data.SqlClient.SqlDataReader

        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oCommand As System.Data.SqlClient.SqlCommand
        Dim oReader As System.Data.SqlClient.SqlDataReader

        If mDebug Then
            'Console.WriteLine("ExecuteSQLReturnResultset called")
            Console.WriteLine(strSQL)
        End If

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oConn
        oCommand.CommandText = strSQL
        oCommand.CommandType = CommandType.Text

        ' Use Sequential Access to be able to read BLOB values properly
        oReader = oCommand.ExecuteReader(CommandBehavior.CloseConnection)

        Return oReader

    End Function

    Public Sub ExecuteSP(ByVal ConnectionString As String, ByVal strSP As String, ByVal params As Object)

        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oCommand As System.Data.SqlClient.SqlCommand

        If mDebug Then
            Console.WriteLine("ExecuteSP called")
            Console.WriteLine(strSP)
        End If

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oConn
        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        oCommand.ExecuteNonQuery()

        oConn.Close()

    End Sub

    Public Sub ExecuteSP(ByVal oTrans As System.Data.SqlClient.SqlTransaction, ByVal strSP As String, ByVal params As Object)
        Dim oCommand As System.Data.SqlClient.SqlCommand

        If mDebug Then
            'Console.WriteLine("ExecuteSP (Trans) called")
            Console.WriteLine(strSP)
        End If

        oCommand = New System.Data.SqlClient.SqlCommand
        oCommand.Connection = oTrans.Connection

        ' =======================
        ' Set the Transaction !!!
        ' =======================
        oCommand.Transaction = oTrans

        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        oCommand.ExecuteNonQuery()

    End Sub

    Public Function ExecuteSPReturnResultset(ByVal oTrans As System.Data.SqlClient.SqlTransaction, _
                                             ByVal strSP As String, _
                                             ByVal params As Object) As System.Data.SqlClient.SqlDataReader

        Dim oCommand As System.Data.SqlClient.SqlCommand
        Dim oReader As System.Data.SqlClient.SqlDataReader

        If mDebug Then
            'Console.WriteLine("ExecuteSPReturnResultset1 called")
            Console.WriteLine(strSP)
        End If

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oTrans.Connection

        ' =======================
        ' Set the Transaction !!!
        ' =======================
        oCommand.Transaction = oTrans

        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        ' Do not close the connection during this transaction
        oReader = oCommand.ExecuteReader()

        Return oReader

    End Function

    Public Function ExecuteSPReturnResultset(ByVal Conn As System.Data.SqlClient.SqlConnection, _
                                             ByVal strSP As String, _
                                             ByVal params As Object, _
                                             ByVal bCloseConnection As Boolean) As System.Data.SqlClient.SqlDataReader

        Dim oCommand As System.Data.SqlClient.SqlCommand
        Dim oReader As System.Data.SqlClient.SqlDataReader

        If mDebug Then
            'Console.WriteLine("ExecuteSPReturnResultset2 called")
            Console.WriteLine(strSP)
        End If

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = Conn
        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        If bCloseConnection Then
            oReader = oCommand.ExecuteReader(CommandBehavior.CloseConnection)
        Else
            oReader = oCommand.ExecuteReader()
        End If

        Return oReader

    End Function

    Public Function ExecuteSPReturnResultset(ByVal ConnectionString As String, ByVal strSP As String, ByVal params As Object) As System.Data.SqlClient.SqlDataReader

        Dim oConn As System.Data.SqlClient.SqlConnection
        Dim oCommand As System.Data.SqlClient.SqlCommand
        Dim oReader As System.Data.SqlClient.SqlDataReader

        If mDebug Then
            'Console.WriteLine("ExecuteSPReturnResultset3 called")
            Console.WriteLine(strSP)
        End If

        oConn = New System.Data.SqlClient.SqlConnection
        oConn.ConnectionString = ConnectionString
        oConn.Open()

        oCommand = New System.Data.SqlClient.SqlCommand

        oCommand.Connection = oConn
        oCommand.CommandText = strSP
        oCommand.CommandType = CommandType.StoredProcedure

        mscollectParams(oCommand, params)

        oReader = oCommand.ExecuteReader(CommandBehavior.CloseConnection)

        Return oReader

    End Function

    ' mp is short for MakeParameter - does typesafe array creation for use with Run* functions
    Public Function mp(ByVal PName As String, ByVal PType As System.Data.SqlDbType, ByVal PSize As Long, ByVal PValue As Object)
        Dim myarray As Object() = {PName, PType, PSize, PValue}
        Return myarray
    End Function

    ' =======================================================================================
    ' Name: ParamsToString
    ' Purpose: This Function is used by the ErrorHandling code to build a user-friendly list
    '          of the parameters passed to a method
    ' =======================================================================================
    Private Function ParamsToString(ByVal argparams As Object) As String
        Dim params As Object
        Dim v As Object
        Dim i As Integer
        Dim l As Integer
        Dim u As Integer
        Dim intUParam As Integer
        Dim intLParam As Integer

        Dim strParams As String
        Dim strParam As String

        Dim oParam As System.Data.SqlClient.SqlParameter

        strParams = ""
        If Not IsArray(argparams) Then Return strParams

        Try
            params = argparams

            If UBound(argparams) = -1 Then
                ParamsToString = "No Parameters passed" & vbCrLf
                Return strParams
            End If

            intLParam = LBound(params)
            intUParam = UBound(params)

            strParams = "Parameters: " & vbCrLf
            For i = intLParam To intUParam
                l = LBound(params(i))
                u = UBound(params(i))
                ' Check that the bounds of the array are correct for a parameter
                If u - l = 3 Then
                    strParam = ""
                    strParam = strParam & "Name : " & params(i)(0) & vbCrLf
                    strParam = strParam & "Type : " & params(i)(1) & vbCrLf
                    strParam = strParam & "Size : " & params(i)(2) & vbCrLf
                    strParam = strParam & "Value: " & params(i)(3) & vbCrLf
                    strParam = strParam & "====================" & vbCrLf
                Else
                    strParam = "Invalid Parameter passed" & vbCrLf
                End If
                strParams = strParams & strParam
            Next i

            Return strParams
        Catch ex As Exception
            Return "Unable to describe the parameters" & vbCrLf
        End Try

    End Function

    Private Sub mscollectParams(ByRef cmd As System.Data.SqlClient.SqlCommand, ByVal argparams As Object)
        Dim params As Object
        Dim v As Object
        Dim i As Integer
        Dim l As Integer
        Dim u As Integer
        Dim intUParam As Integer
        Dim intLParam As Integer

        Dim oParam As System.Data.SqlClient.SqlParameter

        If Not IsArray(argparams) Then Return

        params = argparams
        intLParam = LBound(params)
        intUParam = UBound(params)

        For i = intLParam To intUParam
            l = LBound(params(i))
            u = UBound(params(i))
            ' Check for nulls.
            If u - l = 3 Then
                If VarType(params(i)(3)) = vbString Then
                    v = IIf(params(i)(3) = "", Nothing, params(i)(3))
                Else
                    v = params(i)(3)
                End If

                oParam = New System.Data.SqlClient.SqlParameter
                oParam.ParameterName = params(i)(0)
                oParam.SqlDbType = params(i)(1)
                oParam.Size = params(i)(2)
                oParam.Value = params(i)(3)

                cmd.Parameters.Add(oParam)
            Else
                Throw New ApplicationException("Parameter Error")
            End If
        Next i
    End Sub

End Class