Imports System.Text

''' <summary>
''' Manages an array of integer values, which can be extracted in binary form.
''' </summary>
Public Class BinaryIntegerArray(Of T As Structure) : Inherits List(Of T)

#Region "Methods"

    Private Function GetBytes(ByVal typeCode As TypeCode, ByVal value As T) As Byte()

        Dim bytes As Byte() = Nothing

        Select Case (typeCode)

            Case System.TypeCode.Int16

                bytes = BitConverter.GetBytes(Convert.ToInt16(value))

            Case System.TypeCode.Int32

                bytes = BitConverter.GetBytes(Convert.ToInt32(value))

            Case System.TypeCode.Int64

                bytes = BitConverter.GetBytes(Convert.ToInt64(value))

            Case System.TypeCode.UInt16

                bytes = BitConverter.GetBytes(Convert.ToUInt16(value))

            Case System.TypeCode.UInt32

                bytes = BitConverter.GetBytes(Convert.ToUInt32(value))

            Case System.TypeCode.UInt64

                bytes = BitConverter.GetBytes(Convert.ToUInt64(value))

        End Select

        ' NOTE: oddly BitConverter.IsLittleEndian is true even though Windows is big endian

        ' reverse byte order
        Array.Reverse(bytes)

        Return bytes

    End Function

    ''' <summary>
    ''' Returns the contents of the collection in binary form.
    ''' </summary>
    ''' <returns>An array of type <see cref="Byte"/>.</returns>`
    Public Function ToBinary() As Byte()

        ' exit if there is nothing to do
        If Count = 0 Then Return New Byte() {}

        Dim binary As List(Of Byte) = New List(Of Byte)()
        Dim typeCode As TypeCode = Type.GetTypeCode(GetType(T))

        ' append values to the binary array
        For Each value As T In Me

            binary.AddRange(GetBytes(typeCode, value))

        Next

        Return binary.ToArray()

    End Function

    ''' <summary>
    ''' Returns the contexts of the collection in hexadecimal form.
    ''' </summary>
    ''' <returns>A hexadecimal <see cref="String"/>.</returns>
    Public Function ToHexadecimal() As String

        ' exit if there is nothing to do
        If Count = 0 Then Return String.Empty

        Dim typeCode As TypeCode = Type.GetTypeCode(GetType(T))
        Dim size As Integer = 0

        ' determine size
        Select Case (typeCode)

            Case System.TypeCode.Int16, System.TypeCode.UInt16

                size = 2

            Case System.TypeCode.Int32, System.TypeCode.UInt32

                size = 4

            Case System.TypeCode.Int64, System.TypeCode.UInt64

                size = 8

        End Select

        ' size string builder accordingly
        Dim capacity As Integer = ((size * Count) + 2)
        Dim hex As StringBuilder = New StringBuilder("0x", capacity)

        ' append each value as hex
        For Each value As T In Me
            For Each b As Byte In GetBytes(typeCode, value)
                hex.Append(b.ToString("X2"))
            Next
        Next

        Return hex.ToString()

    End Function

#End Region

#Region "Constructors"

    ''' <summary>
    ''' Instantiates a new instance of the <see cref="BinaryIntegerArray(Of T)"/> class.
    ''' </summary>
    Friend Sub New()

    End Sub

    ''' <summary>
    ''' Instantiates a new instance of the <see cref="BinaryIntegerArray(Of T)"/> class.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    Friend Sub New(ByVal values As T())

        If Not values Is Nothing AndAlso values.Length > 0 Then

            AddRange(values)

        End If

    End Sub

#End Region

End Class
