-- ==================================================
-- SQL SCRIPT
-- ==================================================
-- Purpose:
--	Creates the integer array user-defined function.
--
-- Author:
--	Chris Martinez
--
-- Last Modified:
--	05/08/2006 - Created.

USE Northwind;
GO

SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE FUNCTION dbo.udfIntegerArray
(
 @Binary	IMAGE
,@ElementSize	TINYINT
)
RETURNS @Array TABLE
(
	 "Index" SMALLINT IDENTITY(0,1)
	,"Value" VARBINARY(8) NOT NULL
)
AS
BEGIN

	/* ===============================================
	 * THE INTEGER ARRAY USER-DEFINED FUNCTION
	 * ===============================================
	 * Purpose:
	 *	Creates a table of integer values from
	 *	the specified binary input.
	 *
	 * Author:
	 *	Chris Martinez
	 *
	 * Last Modified:
	 *	04/25/2006 - Created.
	*/

	-- the RAISERROR is a non-deterministic function and cannot be
	-- used in a user-defined function.  do nothing if the parameters
	-- are incorrect.
	IF ( @ElementSize IS NOT NULL AND @ElementSize IN ( 1, 2, 4, 8 ) )
	BEGIN
		DECLARE	 @Value VARBINARY(8)
				,@Length SMALLINT
				,@Index SMALLINT;

		-- initialize variables
		SET @Index = 1;
		SET @Length = DATALENGTH( @Binary );

		-- extract values
		WHILE ( @Index <= @Length )
		BEGIN
			-- get value
			SET @Value = SUBSTRING( @Binary, @Index, @ElementSize );

			-- insert into table
			INSERT INTO @Array VALUES( @Value );

			-- increment index
			SET @Index = @Index + @ElementSize;
		END;
	END;

	RETURN;
END
GO

IF ( @@ERROR = 0 )
	PRINT 'Successfully created user-defined function dbo."udfIntegerArray".';
GO

SET QUOTED_IDENTIFIER OFF;
GO