-- ==================================================
-- SQL SCRIPT
-- ==================================================
-- Purpose:
--	Creates the product search stored procedure.
--
-- Author:
--	Chris Martinez
--
-- Last Modified:
--	05/08/2006 - Created.

USE Northwind;
GO

SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

CREATE PROCEDURE dbo.uspProductsSearch
(
 @ProductIDs IMAGE
)
AS

-- find all products in Northwind that match the specified list of identifiers
SELECT
  *
FROM
  Products
WHERE
  ProductID IN ( SELECT Value FROM dbo.udfIntegerArray( @ProductIDs, 4 ) );
GO

IF ( @@ERROR = 0 )
	PRINT 'Successfully created stored procedure dbo."uspProductsSearch".';
GO

SET QUOTED_IDENTIFIER OFF;
GO