using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Tree
{
    public partial class TreeForm : Form
    {
        // Declare Connection Strings
        private static string cs1 = "Data Source=(local)\\cm_express;Integrated Security = True";
        private static string cs2 = "Data Source=(local)\\cm_express;Initial Catalog=tree;Integrated Security = True";

        public TreeForm()
        {
            InitializeComponent();
        }

        private void TreeForm_Load(object sender, EventArgs e)
        {
            // Ckeck SQL Connection
            SqlConnection Sqlcon = new SqlConnection(cs1);
            try
            {
                Sqlcon.Open();
                Sqlcon.Close();
            }
            catch
            {
                MessageBox.Show("Please First Install Microsoft SQL Server 2005 Express Edition with 'cm_express' instance name. ");
                this.Close();
            }

            // Attach tree database
            SqlCommand sqlcm = new SqlCommand();
            Sqlcon.Open();
            sqlcm.Connection = Sqlcon;
            try
            {
                sqlcm.CommandText = "EXEC sp_attach_db @dbname = N'tree', @filename1 = N'" + Application.StartupPath + "\\tree.mdf" + " ', @filename2 = N'" + Application.StartupPath + "\\tree_log.ldf" + " ' ";
                sqlcm.ExecuteNonQuery();
                Sqlcon.Close();
            }
            catch { }

            // Load tree from database
            SqlConnection sqlconn = new SqlConnection(cs2);
            SqlConnection sqlconn2 = new SqlConnection(cs2);
            sqlconn.Open();
            sqlconn2.Open();
            SqlCommand sqlcmd = new SqlCommand("select * from t1", sqlconn);
            SqlDataReader data = sqlcmd.ExecuteReader();

            SqlCommand sqlcmd2 = new SqlCommand();
            sqlcmd2.Connection = sqlconn2;
            SqlDataReader data2;

            string lvl1, lvl2, lvl3, lv2, lv3;
            int myindex, myindex1, i, j, k;
            myindex1 = myindex = i = j = k = 0;
            while (data.Read())
            {
                lvl1 = data["lvl1"].ToString();
                treeView1.Nodes.Insert(i, lvl1);
                lvl2 = data["lvl2"].ToString();
                j = 0;
                while (lvl2 != "")
                {
                    myindex = lvl2.IndexOf('|');
                    lv2 = lvl2.Substring(0, myindex);

                    treeView1.Nodes[i].Nodes.Insert(j, lv2);

                    sqlcmd2.CommandText = "select * from t2 where lvl2='" + lvl1 + '|' + lv2 + "' ";
                    data2 = sqlcmd2.ExecuteReader();
                    while (data2.Read())
                    {
                        lvl3 = data2["lvl3"].ToString();
                        k = 0;
                        while (lvl3 != "")
                        {
                            myindex1 = lvl3.IndexOf('|');
                            lv3 = lvl3.Substring(0, myindex1);

                            treeView1.Nodes[i].Nodes[j].Nodes.Insert(k, lv3);

                            if (lvl3.Length <= (myindex1 + 1))
                                lvl3 = "";
                            else
                                lvl3 = lvl3.Substring(myindex1 + 1, lvl3.Length - (myindex1 + 1));

                            k++;
                        }
                    }
                    data2.Close();

                    if (lvl2.Length <= (myindex + 1))
                        lvl2 = "";
                    else
                        lvl2 = lvl2.Substring(myindex + 1, lvl2.Length - (myindex + 1));

                    j++;
                }
                i++;
            }
            data.Close();
            sqlconn.Close();
            sqlconn2.Close();
        }

        private void Apply_Click(object sender, EventArgs e)
        {
            SqlConnection sqlconn = new SqlConnection(cs2);
            sqlconn.Open();
            SqlCommand sqlcmd = new SqlCommand("Delete from t1", sqlconn);
            sqlcmd.ExecuteNonQuery();
            sqlcmd.CommandText = "Delete from t2";
            sqlcmd.ExecuteNonQuery();

            int i1, i2, i3;
            i1 = 0;
            while (i1 < treeView1.Nodes.Count)
            {
                sqlcmd.CommandText = "insert into t1(lvl1) values('" + treeView1.Nodes[i1].Text + "')";
                sqlcmd.ExecuteNonQuery();

                i2 = 0;
                while (i2 < treeView1.Nodes[i1].Nodes.Count)
                {
                    sqlcmd.CommandText = "insert into t2(lvl2) values('" + treeView1.Nodes[i1].Text + '|' + treeView1.Nodes[i1].Nodes[i2].Text + "')";
                    sqlcmd.ExecuteNonQuery();
                    sqlcmd.CommandText = "update t1 set lvl2 = IsNull(lvl2,'') + '" + treeView1.Nodes[i1].Nodes[i2].Text + "'+'|' where lvl1 ='" + treeView1.Nodes[i1].Text + "' ";
                    sqlcmd.ExecuteNonQuery();

                    i3 = 0;
                    while (i3 < treeView1.Nodes[i1].Nodes[i2].Nodes.Count)
                    {
                        sqlcmd.CommandText = "update t2 set lvl3 = IsNull(lvl3,'') + '" + treeView1.Nodes[i1].Nodes[i2].Nodes[i3].Text + "'+'|' where lvl2 ='" + treeView1.Nodes[i1].Text + '|' + treeView1.Nodes[i1].Nodes[i2].Text + "' ";
                        sqlcmd.ExecuteNonQuery();
                        i3++;
                    }
                    i2++;
                }
                i1++;
            }

            sqlconn.Close();
        }
    }
}