/*
 *	Copyright by Dejan Grujic 2004. http://www.cogin.com
 *  This code is provided as-is without waranties of any kind.
 *  You can copy, use and modify this code freely as long as you keep this copyright info.
 */
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Cogin.Data;

namespace Cogin
{
	/// <summary>
	/// Windows Form for playing with data access classes
	/// </summary>
	public class TestForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.DataGrid customersDataGrid;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle1;
		private System.Windows.Forms.ContextMenu gridContextMenu;
		private System.Windows.Forms.MenuItem deleteMenuItem;
		private System.Windows.Forms.Button newOrderButton;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox shipToTextBox;
		private System.Windows.Forms.Button saveButton;
		private System.Windows.Forms.Panel orderPanel;

		bool displayingOrder = false;
		private Cogin.Data.CustomersDS customersDS;
		CustomersDataAccess customersDataAccess;
		
		[STAThread]
		public static void Main()
		{
			TestForm form = new TestForm();
			Application.Run( form );
		}

		public TestForm()
		{
			InitializeComponent();

			customersDataAccess = new CustomersDataAccess( customersDS );
			customersDataAccess.FillAllCustomers();
		}

		private void customersDataGrid_Navigate(object sender, System.Windows.Forms.NavigateEventArgs ne)
		{
			displayingOrder = ne.Forward;
			customersDataGrid.ReadOnly = displayingOrder;
			orderPanel.Visible = displayingOrder;
			if ( displayingOrder )
			{
				customersDataAccess.FillOrdersForCustomer( CurrentCustomer.CustomerID );
			}
		}

		private void deleteMenuItem_Click(object sender, System.EventArgs e)
		{
			if ( displayingOrder )
			{
				CurrentOrder.Delete();
				customersDataAccess.updateOrders();
			} 
			else 
			{
				// Northwind doesn't have cascade update turned on,
				// so we have to delete child orders manually.
				// Orders that have items will not be deleted
				CustomersDS.CustomersRow customerRow = CurrentCustomer;
				customersDataAccess.FillOrdersForCustomer( customerRow.CustomerID );
				foreach( CustomersDS.OrdersRow orderRow in customerRow.GetOrdersRows() )
				{
					orderRow.Delete();
				}
				customerRow.Delete();
				customersDataAccess.updateOrders();
				customersDataAccess.updateCustomers();
			}
		}

		private void newOrderButton_Click(object sender, System.EventArgs e)
		{
			customersDS.Orders.AddOrdersRow( 
				CurrentCustomer, 1, DateTime.Today, 
				DateTime.Today.AddDays( 5 ), DateTime.Today, 1, 1, 
				shipToTextBox.Text, "address", "city", "region", 
				"post code", "country" );
			customersDataAccess.updateOrders();
		}

		private void saveButton_Click(object sender, System.EventArgs e)
		{
			try 
			{
				customersDataAccess.updateCustomers();
				customersDataAccess.updateOrders();
			} 
			catch ( Exception exception )
			{
				MessageBox.Show( exception.Message, "Error saving changes" );
			}
		}

		private CustomersDS.CustomersRow CurrentCustomer
		{
			get
			{
				return (CustomersDS.CustomersRow) 
					( ( DataRowView ) BindingContext[ customersDS, "Customers" ].Current ).Row;
			}
		}

		private CustomersDS.OrdersRow CurrentOrder
		{
			get
			{
				object currentRowView = BindingContext[ customersDS, "customers.customersorders" ].Current;
				return (CustomersDS.OrdersRow) 
					( ( DataRowView ) currentRowView ).Row;
			}
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.customersDataGrid = new System.Windows.Forms.DataGrid();
			this.gridContextMenu = new System.Windows.Forms.ContextMenu();
			this.deleteMenuItem = new System.Windows.Forms.MenuItem();
			this.customersDS = new Cogin.Data.CustomersDS();
			this.dataGridTableStyle1 = new System.Windows.Forms.DataGridTableStyle();
			this.newOrderButton = new System.Windows.Forms.Button();
			this.shipToTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.saveButton = new System.Windows.Forms.Button();
			this.orderPanel = new System.Windows.Forms.Panel();
			((System.ComponentModel.ISupportInitialize)(this.customersDataGrid)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.customersDS)).BeginInit();
			this.orderPanel.SuspendLayout();
			this.SuspendLayout();
			// 
			// customersDataGrid
			// 
			this.customersDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.customersDataGrid.BackgroundColor = System.Drawing.Color.Silver;
			this.customersDataGrid.CaptionText = "Customers";
			this.customersDataGrid.ContextMenu = this.gridContextMenu;
			this.customersDataGrid.DataMember = "Customers";
			this.customersDataGrid.DataSource = this.customersDS;
			this.customersDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.customersDataGrid.Location = new System.Drawing.Point(8, 8);
			this.customersDataGrid.Name = "customersDataGrid";
			this.customersDataGrid.Size = new System.Drawing.Size(648, 336);
			this.customersDataGrid.TabIndex = 1;
			this.customersDataGrid.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
																										  this.dataGridTableStyle1});
			this.customersDataGrid.Navigate += new System.Windows.Forms.NavigateEventHandler(this.customersDataGrid_Navigate);
			// 
			// gridContextMenu
			// 
			this.gridContextMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							this.deleteMenuItem});
			// 
			// deleteMenuItem
			// 
			this.deleteMenuItem.Index = 0;
			this.deleteMenuItem.Text = "Delete";
			this.deleteMenuItem.Click += new System.EventHandler(this.deleteMenuItem_Click);
			// 
			// customersDS
			// 
			this.customersDS.DataSetName = "CustomersDS";
			this.customersDS.Locale = new System.Globalization.CultureInfo("en-US");
			// 
			// dataGridTableStyle1
			// 
			this.dataGridTableStyle1.DataGrid = this.customersDataGrid;
			this.dataGridTableStyle1.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridTableStyle1.MappingName = "";
			this.dataGridTableStyle1.PreferredColumnWidth = 100;
			// 
			// newOrderButton
			// 
			this.newOrderButton.Location = new System.Drawing.Point(8, 8);
			this.newOrderButton.Name = "newOrderButton";
			this.newOrderButton.TabIndex = 2;
			this.newOrderButton.Text = "Insert Order";
			this.newOrderButton.Click += new System.EventHandler(this.newOrderButton_Click);
			// 
			// shipToTextBox
			// 
			this.shipToTextBox.Location = new System.Drawing.Point(160, 8);
			this.shipToTextBox.Name = "shipToTextBox";
			this.shipToTextBox.TabIndex = 3;
			this.shipToTextBox.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(96, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(48, 23);
			this.label1.TabIndex = 4;
			this.label1.Text = "Ship to:";
			// 
			// saveButton
			// 
			this.saveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.saveButton.Location = new System.Drawing.Point(8, 360);
			this.saveButton.Name = "saveButton";
			this.saveButton.Size = new System.Drawing.Size(88, 23);
			this.saveButton.TabIndex = 5;
			this.saveButton.Text = "Save changes";
			this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
			// 
			// orderPanel
			// 
			this.orderPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.orderPanel.Controls.Add(this.newOrderButton);
			this.orderPanel.Controls.Add(this.shipToTextBox);
			this.orderPanel.Controls.Add(this.label1);
			this.orderPanel.Location = new System.Drawing.Point(112, 352);
			this.orderPanel.Name = "orderPanel";
			this.orderPanel.Size = new System.Drawing.Size(272, 40);
			this.orderPanel.TabIndex = 6;
			this.orderPanel.Visible = false;
			// 
			// TestForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(664, 390);
			this.Controls.Add(this.orderPanel);
			this.Controls.Add(this.saveButton);
			this.Controls.Add(this.customersDataGrid);
			this.DockPadding.Bottom = 5;
			this.DockPadding.Left = 5;
			this.DockPadding.Right = 5;
			this.DockPadding.Top = 5;
			this.Name = "TestForm";
			this.Text = "TestForm";
			((System.ComponentModel.ISupportInitialize)(this.customersDataGrid)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.customersDS)).EndInit();
			this.orderPanel.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

	}
}
