/*
 *	Copyright by Dejan Grujic 2004. http://www.cogin.com
 *  This code is provided as-is without waranties of any kind.
 *  You can copy, use and modify this code freely as long as you keep this copyright info.
 */
using System;
using Cogin.Data;

namespace Cogin
{
	public class Benchmark
	{
		CustomersDS customersDS = new CustomersDS();
		OrdersViewDS ordersDS = new OrdersViewDS();
		OrdersViewDataAccess ordersDataAccess;
		Random random = new Random();
		enum InvoicationMethod { STORED_PROCEDURE, GENERATED_SQL_WITH_PARAM, GENERATED_SQL_WITHOUT_PARAM };
		const int ITERATIONS = 1000;

		public static void Main( string[] args )
		{
			new Benchmark();
		}

		public Benchmark()
		{
			new CustomersDataAccess( customersDS ).FillAllCustomers();
			ordersDataAccess = new OrdersViewDataAccess( ordersDS );

			// Warm up
			performQueries( 10, InvoicationMethod.STORED_PROCEDURE, true );
			performQueries( 10, InvoicationMethod.GENERATED_SQL_WITH_PARAM, true );
			performQueries( 10, InvoicationMethod.GENERATED_SQL_WITHOUT_PARAM, true );

			Console.WriteLine( "With reusing data access and typed DS classes" );
			performBenchmark( true );

			Console.WriteLine( "\nWithout reusing data access and typed DS classes" );
			performBenchmark( false );
		}

		private void performBenchmark( bool reuseClasses )
		{
			Console.WriteLine( "------------------------------------------------" );
			double elapsedMs;
			elapsedMs = performQueries( ITERATIONS, InvoicationMethod.STORED_PROCEDURE, reuseClasses );
			Console.WriteLine( "Time for stored proc: " + elapsedMs + "ms" );

			elapsedMs = performQueries( ITERATIONS, InvoicationMethod.GENERATED_SQL_WITH_PARAM, reuseClasses );
			Console.WriteLine( "Time for generated sql: " + elapsedMs + "ms" );

			elapsedMs = performQueries( ITERATIONS, InvoicationMethod.GENERATED_SQL_WITHOUT_PARAM, reuseClasses );
			Console.WriteLine( "Time for generated sql without using SqlParameter: "
					+ elapsedMs + "ms" );

		}

		private double performQueries( int numberOfIterations, 
				InvoicationMethod invocationMethod, bool reuseClasses )
		{
			DateTime startTime = DateTime.Now;
			for( int i = 0; i < numberOfIterations; i++ )
			{
				string customerId = customersDS.Customers[ 
						random.Next( customersDS.Customers.Rows.Count ) ].CustomerID;
				switch ( invocationMethod )
				{
					case InvoicationMethod.STORED_PROCEDURE:
						ordersDataAccess.fillOrderByStoredProc( customerId );
						break;
					case InvoicationMethod.GENERATED_SQL_WITH_PARAM:
						ordersDataAccess.fillOrderByGeneratedSql( customerId );
						break;
					case InvoicationMethod.GENERATED_SQL_WITHOUT_PARAM:
						ordersDataAccess.fillOrderByGeneratedSqlWithoutParam( customerId );
						break;
				}
			}
			TimeSpan elapsedTime = DateTime.Now.Subtract( startTime ) ;
			return elapsedTime.TotalMilliseconds;
		}
	}
}
