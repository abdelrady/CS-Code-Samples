/*
 *	Copyright by Dejan Grujic 2004. http://www.cogin.com
 *  This code is provided as-is without waranties of any kind.
 *  You can copy, use and modify this code freely as long as you keep this copyright info.
 */
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Text;

namespace Cogin.Data.DataAccess
{
	public class CustomCommandBuilder
	{
		DataTable dataTable;
		SqlConnection connection;
 
		public CustomCommandBuilder( DataTable dataTable, SqlConnection connection )
		{
			this.dataTable = dataTable;
			this.connection = connection;
		}

		public SqlCommand SelectAllCommand
		{
			get 
			{
				string commandText = "SELECT " + ColumnsString + " FROM " + TableName;
				return GetTextCommand( commandText );
			}
		}

		public SqlCommand GetSelectWithFilterCommand( string filter )
		{
			string commandText = "SELECT " + ColumnsString + 
							 " FROM " + TableName +
							 " WHERE " + filter;
			return GetTextCommand( commandText );
		}

		public SqlCommand GetSelectWithOrderCommand( string order )
		{
			string commandText = "SELECT " + ColumnsString + 
				" FROM " + TableName +
				" ORDER BY " + order;
			return GetTextCommand( commandText );
		}

		public SqlCommand DeleteCommand
		{
			get
			{
				SqlCommand command = GetTextCommand( "" );
				StringBuilder whereString = new StringBuilder();
				foreach( DataColumn column in dataTable.PrimaryKey )
				{
					if( whereString.Length > 0 )
					{
						whereString.Append( " AND " );
					}
					whereString.Append( column.ColumnName )
							.Append( " = @" ).Append( column.ColumnName );
					command.Parameters.Add( CreateParam( column ) );
				}
				string commandText = "DELETE FROM " + TableName
					+ " WHERE " + whereString.ToString();
				command.CommandText = commandText;
				return command;
			}
		}

		/// <summary>
		/// Creates Insert command with support for Autoincrement (Identity) tables
		/// </summary>
		public SqlCommand InsertCommand
		{
			get
			{
				SqlCommand command = GetTextCommand( "" );
				StringBuilder intoString = new StringBuilder();
				StringBuilder valuesString = new StringBuilder();
				ArrayList autoincrementColumns = AutoincrementKeyColumns;
				foreach( DataColumn column in dataTable.Columns )
				{
					if( ! autoincrementColumns.Contains( column ) )
					{
						// Not a primary key
						if( intoString.Length > 0 )
						{
							intoString.Append( ", " );
							valuesString.Append( ", " );
						}
						intoString.Append( column.ColumnName );
						valuesString.Append( "@" ).Append( column.ColumnName );
						command.Parameters.Add( CreateParam(column) );
					}
				}
				string commandText = "INSERT INTO " + TableName + "("
					+ intoString.ToString() + ") VALUES (" + valuesString.ToString() + "); ";
				if( autoincrementColumns.Count > 0 ) 
				{
					commandText += "SELECT SCOPE_IDENTITY() AS "
						+ ( (DataColumn) autoincrementColumns[0]) .ColumnName;
				}
				command.CommandText = commandText;
				return command;
			}
		}

		/// <summary>
		/// Creates Update command with optimistic concurency support
		/// </summary>
		public SqlCommand UpdateCommand
		{
			get
			{
				SqlCommand command = GetTextCommand( "" );
				StringBuilder setString = new StringBuilder();
				StringBuilder whereString = new StringBuilder();
				DataColumn[] primaryKeyColumns = dataTable.PrimaryKey;
				foreach( DataColumn column in dataTable.Columns )
				{
//					if( System.Array.IndexOf( primaryKeyColumns, column) != -1 )
//					{
						// A primary key
						if( whereString.Length > 0 )
						{
							whereString.Append( " AND " );
						}
						whereString.Append( column.ColumnName )
								.Append( "= @old" ).Append( column.ColumnName );
//					} 
//					else 
//					{
						if( setString.Length > 0 )
						{
							setString.Append( ", " );
						}
						setString.Append( column.ColumnName )
								.Append( " = @" ).Append( column.ColumnName );
//					}
					command.Parameters.Add( CreateParam( column ) );
					command.Parameters.Add( CreateOldParam( column ) );

				}
				string commandText = "UPDATE " + TableName + " SET "
					+ setString.ToString() + " WHERE " + whereString.ToString();
				command.CommandText = commandText;
				return command;
			}
		}

		private SqlParameter CreateOldParam( DataColumn column )
		{
			SqlParameter sqlParam = new SqlParameter();
			string columnName = column.ColumnName;
			sqlParam.ParameterName = "@old" + columnName;
			sqlParam.SourceColumn = columnName;
			sqlParam.SourceVersion = DataRowVersion.Original;
			return sqlParam;
		}

		private ArrayList AutoincrementKeyColumns
		{
			get
			{
				ArrayList autoincrementKeys = new ArrayList();
				foreach( DataColumn primaryKeyColumn in dataTable.PrimaryKey )
				{
					if( primaryKeyColumn.AutoIncrement ) 
					{
						autoincrementKeys.Add( primaryKeyColumn );
					}
				}
				return autoincrementKeys;
			}
		}

		private SqlParameter CreateParam( DataColumn column )
		{
			SqlParameter sqlParam = new SqlParameter();
			string columnName = column.ColumnName;
			sqlParam.ParameterName = "@" + columnName;
			sqlParam.SourceColumn = columnName;
			return sqlParam;
		}

		private SqlCommand GetTextCommand( string text )
		{
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.Text;
			command.CommandText = text;
			command.Connection = connection;
			return command;
		}

		private string TableName 
		{
			get { return "[" + dataTable.TableName + "]"; }
		}

		private string ColumnsString
		{
			get 
			{
				StringBuilder columnsString = new StringBuilder();
				foreach( DataColumn column in dataTable.Columns )
				{
					if( columnsString.Length > 0 ) 
					{
						columnsString.Append( ", " );
					}
					columnsString.Append( column.ColumnName );
				}
				return columnsString.ToString();
			}
		}

	}
}
