using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Data.OleDb;

namespace Cogin.Data.DataAccess
{
	public class OleDbCustomCommandBuilder
	{
		DataTable dataTable;
		OleDbConnection connection;
 
		public OleDbCustomCommandBuilder( DataTable dataTable, OleDbConnection connection )
		{
			this.dataTable = dataTable;
			this.connection = connection;
		}

		public OleDbCommand SelectAllCommand
		{
			get 
			{
				string commandText = "SELECT " + ColumnsString + " FROM " + TableName;
				return GetTextCommand( commandText );
			}
		}

		public OleDbCommand GetSelectWithFilterCommand( string filter )
		{
			string commandText = "SELECT " + ColumnsString + 
				" FROM " + TableName +
				" WHERE " + filter;
			return GetTextCommand( commandText );
		}

		public OleDbCommand GetSelectWithOrderCommand( string order )
		{
			string commandText = "SELECT " + ColumnsString + 
				" FROM " + TableName +
				" ORDER BY " + order;
			return GetTextCommand( commandText );
		}

		public OleDbCommand DeleteCommand
		{
			get
			{
				OleDbCommand command = GetTextCommand( "" );
				StringBuilder whereString = new StringBuilder();
				foreach( DataColumn column in dataTable.PrimaryKey )
				{
					if( whereString.Length > 0 )
					{
						whereString.Append( " AND " );
					}
					whereString.Append( column.ColumnName )
						.Append( " = @" ).Append( column.ColumnName );
					command.Parameters.Add( CreateParam( column ) );
				}
				string commandText = "DELETE FROM " + TableName
					+ " WHERE " + whereString.ToString();
				command.CommandText = commandText;
				return command;
			}
		}

		/// <summary>
		/// Creates Insert command with support for Autoincrement (Identity) tables
		/// </summary>
		public OleDbCommand InsertCommand
		{
			get
			{
				OleDbCommand command = GetTextCommand( "" );
				StringBuilder intoString = new StringBuilder();
				StringBuilder valuesString = new StringBuilder();
				ArrayList autoincrementColumns = AutoincrementKeyColumns;
				foreach( DataColumn column in dataTable.Columns )
				{
					if( ! autoincrementColumns.Contains( column ) )
					{
						// Not a primary key
						if( intoString.Length > 0 )
						{
							intoString.Append( ", " );
							valuesString.Append( ", " );
						}
						intoString.Append( column.ColumnName );
						valuesString.Append( "@" ).Append( column.ColumnName );
						command.Parameters.Add( CreateParam(column) );
					}
				}
				string commandText = "INSERT INTO " + TableName + "("
					+ intoString.ToString() + ") VALUES (" + valuesString.ToString() + "); ";
				if( autoincrementColumns.Count > 0 ) 
				{
					commandText += "SELECT SCOPE_IDENTITY() AS "
						+ ( (DataColumn) autoincrementColumns[0]) .ColumnName;
				}
				command.CommandText = commandText;
				return command;
			}
		}

		/// <summary>
		/// Creates Update command with optimistic concurency support
		/// </summary>
		public OleDbCommand UpdateCommand
		{
			get
			{
				OleDbCommand command = GetTextCommand( "" );
				StringBuilder setString = new StringBuilder();
				StringBuilder whereString = new StringBuilder();
				DataColumn[] primaryKeyColumns = dataTable.PrimaryKey;

				foreach( DataColumn column in dataTable.Columns )
				{
					if( System.Array.IndexOf( primaryKeyColumns, column) != -1 )
					{
						// A primary key
						if( whereString.Length > 0 )
						{
							whereString.Append( " AND " );
						}
						whereString.Append( column.ColumnName )
							.Append( "= ?" );
					} 
					else 
					{
						if( setString.Length > 0 )
						{
							setString.Append( ", " );
						}
						setString.Append( column.ColumnName )
							.Append( " = ?" );
						command.Parameters.Add( CreateParam( column ) );
					}
				}

				foreach( DataColumn column in dataTable.Columns )
				{
					if( System.Array.IndexOf( primaryKeyColumns, column) != -1 )
					{
						command.Parameters.Add( CreateParam( column ) );
					} 
				}

				string commandText = "UPDATE " + TableName + " SET "
					+ setString.ToString() + " WHERE " + whereString.ToString();
				command.CommandText = commandText;
				return command;
			}
		}

		private ArrayList AutoincrementKeyColumns
		{
			get
			{
				ArrayList autoincrementKeys = new ArrayList();
				foreach( DataColumn primaryKeyColumn in dataTable.PrimaryKey )
				{
					if( primaryKeyColumn.AutoIncrement ) 
					{
						autoincrementKeys.Add( primaryKeyColumn );
					}
				}
				return autoincrementKeys;
			}
		}

		private OleDbParameter CreateParam( DataColumn column )
		{
			OleDbParameter sqlParam = new OleDbParameter();
			string columnName = column.ColumnName;
			sqlParam.ParameterName = "@" + columnName;
			sqlParam.SourceColumn = columnName;
			return sqlParam;
		}

		private OleDbCommand GetTextCommand( string text )
		{
			OleDbCommand command = new OleDbCommand();
			command.CommandType = CommandType.Text;
			command.CommandText = text;
			command.Connection = connection;
			return command;
		}

		private string TableName 
		{
			get { return "[" + dataTable.TableName + "]"; }
		}

		private string ColumnsString
		{
			get 
			{
				StringBuilder columnsString = new StringBuilder();
				foreach( DataColumn column in dataTable.Columns )
				{
					if( columnsString.Length > 0 ) 
					{
						columnsString.Append( ", " );
					}
					columnsString.Append( column.ColumnName );
				}
				return columnsString.ToString();
			}
		}

	}
}
