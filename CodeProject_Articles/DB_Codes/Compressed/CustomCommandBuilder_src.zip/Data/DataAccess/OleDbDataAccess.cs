using System;
using System.Data;
using System.Data.OleDb;

namespace Cogin.Data.DataAccess
{
	public class OleDbDataAccess : IDataAccess
	{
		public OleDbConnection sqlConnection;

		public OleDbDataAccess()
		{
			string connString = System.Configuration.ConfigurationSettings
				.AppSettings[ "OleDbConnection" ];
			sqlConnection = new OleDbConnection( connString );
		}

		/// <summary>
		/// Selects all rows from a table, without filtering
		/// </summary>
		public void SelectAll( DataTable dataTable )
		{
			try
			{
				OleDbDataAdapter dataAdapter = new OleDbDataAdapter(
					new OleDbCustomCommandBuilder( dataTable, sqlConnection ).SelectAllCommand );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill( dataTable );
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills DataTable with simple text filter
		/// </summary>
		public void SelectWithFilter( DataTable dataTable, string filter )
		{
			try
			{
				OleDbDataAdapter dataAdapter = new OleDbDataAdapter(
					new OleDbCustomCommandBuilder( dataTable, sqlConnection )
					.GetSelectWithFilterCommand( filter ) );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill(dataTable);
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills DataTable with filtered data. Parameters are passed
		/// using SqlParamater objects.
		/// </summary>
		public void SelectWithFilter( DataTable dataTable, string filter, params GenericSqlParameter[] parameters )
		{
			try
			{
				OleDbCommand command = new OleDbCustomCommandBuilder( dataTable, sqlConnection )
					.GetSelectWithFilterCommand( filter );
				foreach( GenericSqlParameter parameter in parameters )
				{
					command.Parameters.Add( parameter.OleDbParameter );
				}
				OleDbDataAdapter dataAdapter = new OleDbDataAdapter( command );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill(dataTable);
			}
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills data table using stored procedure
		/// </summary>
		public void SelectFromSP( DataTable dataTable, string storedProcName,
			params GenericSqlParameter[] parameters )
		{
			try
			{
				OleDbCommand cmd = GetCommandForSelect( storedProcName, parameters );
				OleDbDataAdapter dataAdapter = new OleDbDataAdapter( cmd );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill( dataTable );
			}
			finally
			{
				sqlConnection.Close();
			}
		} 

		/// <summary>
		/// Creates select command for stored procedure
		/// </summary>
		public OleDbCommand GetCommandForSelect( string storedProcName, params GenericSqlParameter[] parameters )
		{
			OleDbCommand cmd = new OleDbCommand( storedProcName );
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Connection = sqlConnection;
			foreach( GenericSqlParameter parameter in parameters )
			{
				cmd.Parameters.Add( parameter.OleDbParameter );
			}
			return cmd;
		}

		/// <summary>
		/// Performs all update operations for changed rows in a table
		/// </summary>
		public void FullUpdate( DataTable dataTable )
		{
			try
			{
				OleDbCustomCommandBuilder commandBuilder = new OleDbCustomCommandBuilder( dataTable, sqlConnection );
				OleDbDataAdapter adapter = new OleDbDataAdapter();
				adapter.UpdateCommand = commandBuilder.UpdateCommand;
				adapter.DeleteCommand = commandBuilder.DeleteCommand;
				adapter.InsertCommand = commandBuilder.InsertCommand;

				sqlConnection.Open();
				adapter.Update(dataTable);
			}			
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Calls sql command that doesn't return params
		/// </summary>
		public void ExecuteNonQueryCmd( OleDbCommand command ) 
		{
			try
			{
				sqlConnection.Open();
				command.ExecuteNonQuery();
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Calls sql command that returns single scalar value
		/// </summary>
		public object ExecuteScalar( OleDbCommand command ) 
		{
			try
			{
				sqlConnection.Open();
				object result = command.ExecuteScalar();
				return result;
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}
	}
}
