using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Cogin.Data.DataAccess
{
	public interface IDataAccess
	{
		void SelectAll( DataTable table );
		void SelectWithFilter( DataTable table, string filter,
				params GenericSqlParameter[] parameters );
		void SelectFromSP( DataTable dataTable, string storedProcName,
				params GenericSqlParameter[] parameters );
		void FullUpdate( DataTable table );
	}

	public class GenericSqlParameter
	{
		string paramName;
		object paramValue;

		public GenericSqlParameter( string paramName, object paramValue )
		{
			this.paramName = paramName;
			this.paramValue = paramValue;
		}

		public SqlParameter SqlParameter
		{
			get { return new SqlParameter( paramName, paramValue ); }
		}

		public OleDbParameter OleDbParameter
		{
			get { return new OleDbParameter( paramName, paramValue ); }
		}
	}

	public class DataAccessFactory
	{
		public static IDataAccess DataAccess
		{
			get
			{
				string dataAccess = System.Configuration.ConfigurationSettings
						.AppSettings[ "DataAccess" ];		
				if ( dataAccess == "SqlClient" )
				{
					return new SqlDataAccess();
				}
				else 
				{
					return new OleDbDataAccess();
				}
			}
		}

	}
}
