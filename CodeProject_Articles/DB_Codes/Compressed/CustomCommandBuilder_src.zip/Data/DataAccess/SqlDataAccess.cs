/*
 *	Copyright by Dejan Grujic 2004. http://www.cogin.com
 *  This code is provided as-is without waranties of any kind.
 *  You can copy, use and modify this code freely as long as you keep this copyright info.
 */
using System;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

namespace Cogin.Data.DataAccess
{
	/// <summary>
	/// Base DataAccess class
	/// main responsibilities of this class:
	/// - centralized fetching of connection string from configuration
	/// - opening/closing connections
	/// - DataAdapter handling
	/// Subclasses don't have to do any of these things
	/// </summary>

	public class SqlDataAccess : IDataAccess
	{
		public SqlConnection sqlConnection;

		public SqlDataAccess()
		{
			string connString = System.Configuration.ConfigurationSettings
					.AppSettings[ "DbConnection" ];
			sqlConnection = new SqlConnection( connString );
		}

		/// <summary>
		/// Selects all rows from a table, without filtering
		/// </summary>
		public void SelectAll( DataTable dataTable )
		{
			try
			{
				SqlDataAdapter dataAdapter = new SqlDataAdapter(
					new CustomCommandBuilder( dataTable, sqlConnection ).SelectAllCommand );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill( dataTable );
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills DataTable with simple text filter
		/// </summary>
		public void SelectWithFilter( DataTable dataTable, string filter )
		{
			try
			{
				SqlDataAdapter dataAdapter = new SqlDataAdapter(
					new CustomCommandBuilder( dataTable, sqlConnection )
					.GetSelectWithFilterCommand( filter ) );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill(dataTable);
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills DataTable with filtered data. Parameters are passed
		/// using SqlParamater objects.
		/// </summary>
		public void SelectWithFilter( DataTable dataTable, string filter, 
				params GenericSqlParameter[] parameters )
		{
			try
			{
				SqlCommand command = new CustomCommandBuilder( dataTable, sqlConnection )
					.GetSelectWithFilterCommand( filter );
				foreach( GenericSqlParameter parameter in parameters )
				{
					command.Parameters.Add( parameter.SqlParameter );
				}
				SqlDataAdapter dataAdapter = new SqlDataAdapter( command );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill(dataTable);
			}
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Fills data table using stored procedure
		/// </summary>
		public void SelectFromSP( DataTable dataTable, string storedProcName,
			params GenericSqlParameter[] parameters )
		{
			try
			{
				SqlCommand cmd = GetCommandForSelect( storedProcName, parameters );
				SqlDataAdapter dataAdapter = new SqlDataAdapter( cmd );
				dataAdapter.TableMappings.Add( "Table", dataTable.TableName );
				sqlConnection.Open();
				dataAdapter.Fill( dataTable );
			}
			finally
			{
				sqlConnection.Close();
			}
		} 

		/// <summary>
		/// Creates select command for stored procedure
		/// </summary>
		public SqlCommand GetCommandForSelect( string storedProcName, params GenericSqlParameter[] parameters )
		{
			SqlCommand cmd = new SqlCommand( storedProcName );
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Connection = sqlConnection;
			foreach( GenericSqlParameter parameter in parameters )
			{
				cmd.Parameters.Add( parameter.SqlParameter );
			}
			return cmd;
		}

		/// <summary>
		/// Performs all update operations for changed rows in a table
		/// </summary>
		public void FullUpdate( DataTable dataTable )
		{
			try
			{
				CustomCommandBuilder commandBuilder = new CustomCommandBuilder( dataTable, sqlConnection );
				SqlDataAdapter adapter = new SqlDataAdapter();
				adapter.UpdateCommand = commandBuilder.UpdateCommand;
				adapter.DeleteCommand = commandBuilder.DeleteCommand;
				adapter.InsertCommand = commandBuilder.InsertCommand;

				sqlConnection.Open();
				adapter.Update(dataTable);
			}			
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Calls sql command that doesn't return params
		/// </summary>
		public void ExecuteNonQueryCmd( SqlCommand command ) 
		{
			try
			{
				sqlConnection.Open();
				command.ExecuteNonQuery();
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}

		/// <summary>
		/// Calls sql command that returns single scalar value
		/// </summary>
		public object ExecuteScalar( SqlCommand command ) 
		{
			try
			{
				sqlConnection.Open();
				object result = command.ExecuteScalar();
				return result;
			} 
			finally 
			{
				sqlConnection.Close();
			}
		}
	}
}
