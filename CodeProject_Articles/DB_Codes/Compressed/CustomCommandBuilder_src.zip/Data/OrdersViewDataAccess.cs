/*
 *	Copyright by Dejan Grujic 2004. http://www.cogin.com
 *  This code is provided as-is without waranties of any kind.
 *  You can copy, use and modify this code freely as long as you keep this copyright info.
 */
using System;
using System.Data.OleDb;
using Cogin.Data.DataAccess;

namespace Cogin.Data
{
	public class OrdersViewDataAccess
	{
		IDataAccess dataAccess = DataAccessFactory.DataAccess;
		OrdersViewDS dataSet;

		public OrdersViewDataAccess( OrdersViewDS dataSet )
		{
			this.dataSet = dataSet;
		}

		public void fillOrderByGeneratedSql( string customerId )
		{
			dataAccess.SelectWithFilter( dataSet.Orders, "CustomerId=@customerId",
					new GenericSqlParameter( "@customerId", customerId ) );
		}

		public void fillOrderByGeneratedSqlWithoutParam( string customerId )
		{
			dataAccess.SelectWithFilter( dataSet.Orders, "CustomerId='" + customerId + "'" );
		}

		public void fillOrderByStoredProc( string customerId )
		{
			dataAccess.SelectFromSP( dataSet.Orders, "CustOrdersOrders",
					new GenericSqlParameter( "@customerId", customerId ) );
		}
	}
}
