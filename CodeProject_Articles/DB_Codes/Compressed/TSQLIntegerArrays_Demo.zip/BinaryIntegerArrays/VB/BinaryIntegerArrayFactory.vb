
''' <summary>
''' Represents a factory for binary integer array objects.
''' </summary>
Public Class BinaryIntegerArrayFactory

#Region "Methods"

    ''' <summary>
    ''' Returns an array for signed 16-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Short)" /> object.</returns>
    Public Shared Function CreateInt16() As BinaryIntegerArray(Of Short)
        Return New BinaryIntegerArray(Of Short)()
    End Function

    ''' <summary>
    ''' Returns an array for signed 16-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Short)" /> object.</returns>
    Public Shared Function CreateInt16(ByVal ParamArray values As Short()) As BinaryIntegerArray(Of Short)
        Return New BinaryIntegerArray(Of Short)(values)
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 16-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of UShort)" /> object.</returns>
    Public Shared Function CreateUInt16() As BinaryIntegerArray(Of UShort)
        Return New BinaryIntegerArray(Of UShort)()
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 16-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of UShort)" /> object.</returns>
    Public Shared Function CreateUInt16(ByVal ParamArray values As UShort()) As BinaryIntegerArray(Of UShort)
        Return New BinaryIntegerArray(Of UShort)(values)
    End Function

    ''' <summary>
    ''' Returns an array for signed 32-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Integer)" /> object.</returns>
    Public Shared Function CreateInt32() As BinaryIntegerArray(Of Integer)
        Return New BinaryIntegerArray(Of Integer)()
    End Function

    ''' <summary>
    ''' Returns an array for signed 32-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Integer)" /> object.</returns>
    Public Shared Function CreateInt32(ByVal ParamArray values As Integer()) As BinaryIntegerArray(Of Integer)
        Return New BinaryIntegerArray(Of Integer)(values)
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 32-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of UInteger)" /> object.</returns>
    Public Shared Function CreateUInt32() As BinaryIntegerArray(Of UInteger)
        Return New BinaryIntegerArray(Of UInteger)()
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 32-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of UInteger)" /> object.</returns>
    Public Shared Function CreateUInt32(ByVal ParamArray values As UInteger()) As BinaryIntegerArray(Of UInteger)
        Return New BinaryIntegerArray(Of UInteger)(values)
    End Function

    ''' <summary>
    ''' Returns an array for signed 64-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Long)" /> object.</returns>
    Public Shared Function CreateInt64() As BinaryIntegerArray(Of Long)
        Return New BinaryIntegerArray(Of Long)()
    End Function

    ''' <summary>
    ''' Returns an array for signed 64-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of Long)" /> object.</returns>
    Public Shared Function CreateInt64(ByVal ParamArray values As Long()) As BinaryIntegerArray(Of Long)
        Return New BinaryIntegerArray(Of Long)(values)
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 64-bit integers.
    ''' </summary>
    ''' <returns>A <see cref="BinaryIntegerArray(Of ULong)" /> object.</returns>
    Public Shared Function CreateuInt64() As BinaryIntegerArray(Of ULong)
        Return New BinaryIntegerArray(Of ULong)()
    End Function

    ''' <summary>
    ''' Returns an array for unsigned 64-bit integers.
    ''' </summary>
    ''' <param name="values">An array of initial values to add.</param>
    ''' <returns>A <see cref="BinaryIntegerArray(Of ULong)" /> object.</returns>
    Public Shared Function CreateuInt64(ByVal ParamArray values As ULong()) As BinaryIntegerArray(Of ULong)
        Return New BinaryIntegerArray(Of ULong)(values)
    End Function

#End Region

#Region "Constructors"

    ''' <summary>
    ''' The type initializer for the <see cref="BinaryIntegerArrayFactory" /> class.
    ''' </summary>
    Shared Sub New()

    End Sub

#End Region

End Class
