Imports System.Data.SqlClient

Module Program

    Sub Main()

        Try

            ExecuteExample()

        Catch ex As Exception

            Console.WriteLine(ex.Message)

        End Try

        Console.WriteLine()
        Console.WriteLine("Press ENTER to continue...")
        Console.ReadLine()

    End Sub

    Private Sub ExecuteExample()

        ' create a binary array of 32-bit integers
        Dim cs As String = "Server=localhost;Database=Northwind;Integrated Security=SSPI"
        Dim ids As BinaryIntegerArray(Of Integer) = BinaryIntegerArrayFactory.CreateInt32()

        ' add integers (this can easily be passed a parameter or derived in some other way)
        ids.Add(1)
        ids.Add(3)
        ids.Add(15)

        ' create a connection
        Using connection As SqlConnection = New SqlConnection(cs)

            ' create a command
            Using command As SqlCommand = New SqlCommand("dbo.uspProductsSearch", connection)

                ' set command type
                command.CommandType = CommandType.StoredProcedure

                ' add parameters
                Dim param As SqlParameter = command.Parameters.Add("@ProductIDs", SqlDbType.Binary)
                param.Size = 8000
                param.Value = ids.ToBinary()

                ' open connection and execute command
                connection.Open()
                Dim reader As SqlDataReader = command.ExecuteReader(CommandBehavior.CloseConnection)

                While reader.Read()

                    ' TODO: do something with the results

                End While

                ' close the reader
                reader.Close()

            End Using

        End Using

    End Sub

End Module
