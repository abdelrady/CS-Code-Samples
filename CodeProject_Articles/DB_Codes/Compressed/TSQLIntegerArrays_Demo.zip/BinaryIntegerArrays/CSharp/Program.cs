using System;
using System.Data;
using System.Data.SqlClient;

namespace TestConsole
{
    /// <summary>
    /// Summary description for Class1.
    /// </summary>
    class Class1
    {
        #region Methods

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main( string[] args )
        {
            try
            {
                ExecuteExample();
            }
            catch ( Exception ex )
            {
                Console.WriteLine( ex.Message );
            }

            Console.WriteLine( "\nPress ENTER to continue..." );
            Console.ReadLine();
        }

        private static void ExecuteExample()
        {
            // create a binary array of 32-bit integers
            string cs = "Server=localhost;Database=Northwind;Integrated Security=SSPI";
            BinaryIntegerArray<int> ids = BinaryIntegerArrayFactory.CreateInt32();

            // add integers (this can easily be passed a parameter or derived in some other way)
            ids.Add( 1 );
            ids.Add( 3 );
            ids.Add( 15 );

            // create a connection
            using ( SqlConnection connection = new SqlConnection( cs ) )
            {
                // create a command
                using ( SqlCommand command = new SqlCommand( "dbo.uspProductsSearch", connection ) )
                {
                    // set command type
                    command.CommandType = CommandType.StoredProcedure;

                    // add parameters
                    SqlParameter param = command.Parameters.Add( "@ProductIDs", SqlDbType.Binary );
                    param.Size = 8000;
                    param.Value = ids.ToBinary();

                    // open connection and execute command
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader( CommandBehavior.CloseConnection );

                    while ( reader.Read() )
                    {
                        // TODO: do something with the results
                    }

                    // close the reader
                    reader.Close();
                }
            }
        }

        #endregion
    }
}
