using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.Data;
using System.Data.Odbc;

/// <summary>
/// Summary description for frmSincronizar.
/// </summary>
public class OdbcExecuter : System.Windows.Forms.Form
{
	private System.Windows.Forms.GroupBox groupBox1;
	private System.Windows.Forms.Label ldots;
	private System.Windows.Forms.Label cWaitMessage;

	/// <summary>
	/// Private vars
	/// </summary>
	private string[] QueryCollection = new string[1];		// the string array with queries
	private string connstring;								// the connection string
	private string waitmessage = "EXECUTING THE queries";	// the message to show to the user when executing
	private int nCommands = 0;								// total commands to execute
								
			

	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public OdbcExecuter()
	{
		InitializeComponent();
	}


	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
		if( disposing )
		{
			if(components != null)
			{
				components.Dispose();
			}
		}
		base.Dispose( disposing );
	}


	/// <summary>
	/// The connection string to use
	/// </summary>
	public string ConnectionString
	{
		get
		{
			return(connstring);
		}
		set 
		{			
			this.connstring = value;
		}
	}


	/// <summary>
	/// Message show to user in form
	/// </summary>
	public string WaitMessage
	{
		get
		{
			return(waitmessage);
		}
		set
		{
			cWaitMessage.Text = value;
		}
	}
	

	#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
		this.groupBox1 = new System.Windows.Forms.GroupBox();
		this.ldots = new System.Windows.Forms.Label();
		this.cWaitMessage = new System.Windows.Forms.Label();
		this.groupBox1.SuspendLayout();
		this.SuspendLayout();
		// 
		// groupBox1
		// 
		this.groupBox1.Controls.Add(this.ldots);
		this.groupBox1.Controls.Add(this.cWaitMessage);
		this.groupBox1.Location = new System.Drawing.Point(0, 0);
		this.groupBox1.Name = "groupBox1";
		this.groupBox1.Size = new System.Drawing.Size(368, 96);
		this.groupBox1.TabIndex = 1;
		this.groupBox1.TabStop = false;
		// 
		// ldots
		// 
		this.ldots.Location = new System.Drawing.Point(72, 64);
		this.ldots.Name = "ldots";
		this.ldots.Size = new System.Drawing.Size(216, 16);
		this.ldots.TabIndex = 2;
		// 
		// cWaitMessage
		// 
		this.cWaitMessage.ForeColor = System.Drawing.Color.LightCoral;
		this.cWaitMessage.Location = new System.Drawing.Point(8, 40);
		this.cWaitMessage.Name = "cWaitMessage";
		this.cWaitMessage.Size = new System.Drawing.Size(352, 23);
		this.cWaitMessage.TabIndex = 1;
		this.cWaitMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
		// 
		// OdbcExecuter
		// 
		this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
		this.BackColor = System.Drawing.SystemColors.Control;
		this.ClientSize = new System.Drawing.Size(368, 96);
		this.Controls.Add(this.groupBox1);
		this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
		this.Name = "OdbcExecuter";
		this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
		this.Text = "frmSincronizar";
		this.groupBox1.ResumeLayout(false);
		this.ResumeLayout(false);

	}
	#endregion


	#region Private Core Functions

	/// <summary>
	/// Resize the original array
	/// </summary>
	/// <param name="origArray"></param>
	/// <param name="desiredSize"></param>
	/// <returns></returns>
	private Array ResizeArray(Array QueryArray, int NewSize) 
	{
		// Check to see the type of the elements
		Type QueryArrayType = QueryArray.GetType().GetElementType();
		// Build our new array maintaining the original type
		Array NewQueryArray = Array.CreateInstance(QueryArrayType, NewSize);
		// Copy the values set to the new array
		Array.Copy(QueryArray, 0, NewQueryArray, 0, Math.Min(QueryArray.Length, NewSize));
				
		return NewQueryArray;
	}

	private bool LockTables()
	{
		// Build the connection object
		OdbcConnection OdbcMyConnection = new OdbcConnection(connstring);
		OdbcMyConnection.Open();
		// Our var to see how things end up
		bool bStatus = false;

		// Build the command object
		OdbcCommand OdbcMyCommand = OdbcMyConnection.CreateCommand();
		
		// In MySQL the function IS_FREE_LOCK is called by: IS_FREE_LOCK(name_of_lock)
		OdbcMyCommand.CommandText = "SELECT IS_FREE_LOCK('OdbcExecuter')";
		int nStatus = 0;
		while (!bStatus)
		{
			// Execute function IS_FREE_LOCK and see what returns
			bStatus = Convert.ToBoolean(OdbcMyCommand.ExecuteScalar());
			if (bStatus) break;  // Could lock the table, let's exit the cycle

			// Still trying to lock, let's give feedback to user
			ldots.Text += ".";				
			Thread.Sleep(400);
			Application.DoEvents();				
		}

		// The lock is free for us, let's lock
		try
		{
			// Execute lock query
			// In MySQL the function GET_LOCK is called by: GET_LOCK(name_of_lock, timeout seconds)
			OdbcMyCommand.CommandText = "SELECT GET_LOCK('OdbcExecuter',60)";
			nStatus = Convert.ToInt32(OdbcMyCommand.ExecuteScalar());
			if (nStatus == 1) bStatus = true;
			else bStatus = false;
		}
		catch (OdbcException e)
		{
			// Something bad happened, let the user know
			MessageBox.Show(this, e.ToString());
			bStatus = false;
		}

		// Close the connection object and return the result
		OdbcMyCommand.Dispose();
		OdbcMyConnection.Close();
		return bStatus;
	}

	private bool ReleaseTables()
	{
		// Build the connection object
		OdbcConnection OdbcMyConnection = new OdbcConnection(connstring);
		OdbcMyConnection.Open();
		// Our var to see how things end up
		bool bStatus = false;

		// Build our command object
		OdbcCommand OdbcMyCommand = OdbcMyConnection.CreateCommand();
		
		// See if our tables are already loocked
		try
		{
			// Execute the release lock query
			int nStatus = 0;
			// In MySQL the function RELEASE_LOCK is called by: RELEASE_LOCK(name_of_lock)
			OdbcMyCommand.CommandText = "SELECT RELEASE_LOCK('OdbcExecuter')";
			nStatus = Convert.ToInt32(OdbcMyCommand.ExecuteScalar());
			if (nStatus == 1) bStatus = true;
			else bStatus = false;
		}
		catch (OdbcException e)
		{
			// Something bad happened, let the user know
			MessageBox.Show(this, e.ToString());
			bStatus = false;
		}

		// Close the connection object and return the result
		OdbcMyCommand.Dispose();
		OdbcMyConnection.Close();			
		return bStatus;
	}

	#endregion


	#region Public Functions

	/// <summary>
	/// Add an query to queries collection
	/// </summary>
	/// <param name="sQuery">query to add</param>
	public void AddQuery(string sQuery)
	{			
		// Check to see if our string array as elements
		if (nCommands > 0)
			// Resize the array and cast to prevent an exception throw
			QueryCollection = (string[])ResizeArray(QueryCollection, QueryCollection.Length + 1);

		// Store the new query passed
		QueryCollection[nCommands] = sQuery;
		nCommands++;
	}

	/// <summary>
	/// Executes stored queries on query collection
	/// </summary>
	/// <returns>operation result</returns>
	public bool ExecuteQueries()
	{
		// Our var to see how things end up
		bool bStatus = false;

		// Force the form to show
		if (!this.Focus())
		{
			this.TopMost = true;			// force window to show on top
			this.ShowInTaskbar = false;		// hide window from taskbar
			this.Show();					// show window
		}

		// Build the connection object
		OdbcConnection OdbcMyConnection = new OdbcConnection(connstring);
		OdbcMyConnection.Open();

		// Start our transaction
		OdbcCommand OdbcMyCommand = OdbcMyConnection.CreateCommand();
		OdbcTransaction transact = OdbcMyConnection.BeginTransaction(IsolationLevel.ReadCommitted);
		OdbcMyCommand.Transaction = transact;

		if (LockTables())
		{
			try
			{
				// Execute the queries in our QueryCollection array
				for (int nQuerys = 0; nQuerys < nCommands; nQuerys++)
				{
					OdbcMyCommand.CommandText = QueryCollection[nQuerys];
					OdbcMyCommand.ExecuteNonQuery();
				}

				// Commit our queries to the database							
				transact.Commit();
				bStatus = true;
			}
			catch (Exception cmex)
			{
				try
				{
					// Something bad happened, let's roll back our transaction
					transact.Rollback();
				}
				catch (OdbcException ex)
				{
					// Something bad happened, let user know
					MessageBox.Show(this, ex.ToString());
				}
				// Let user know what happened with the transaction
				MessageBox.Show(this, cmex.ToString());
				bStatus = false;
			}
			finally
			{
				// Finally, the clean up
				OdbcMyCommand.Dispose();
				OdbcMyConnection.Close();
			}
		}
		// We finish executing the queries, release tables
		ReleaseTables();
		this.Hide();
		return bStatus;
	}

	public void CleanQueries()
	{
		QueryCollection.Initialize();
		QueryCollection = new string[1];
		nCommands = 0;
	}

	#endregion

	
}
