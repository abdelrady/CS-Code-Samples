using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace OdbcExecuterDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbConn;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbQuery;
		private System.Windows.Forms.Button btRun;
		private System.Windows.Forms.Button btClose;
		private System.Windows.Forms.Button btAdd;

		// #################################################
		// declaration
		private OdbcExecuter OdbcExecuter;


		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			// #################################################
			// inicialization
			OdbcExecuter = new OdbcExecuter();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.tbConn = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.tbQuery = new System.Windows.Forms.TextBox();
			this.btRun = new System.Windows.Forms.Button();
			this.btClose = new System.Windows.Forms.Button();
			this.btAdd = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.TabIndex = 0;
			this.label1.Text = "Connection String:";
			// 
			// tbConn
			// 
			this.tbConn.Location = new System.Drawing.Point(112, 16);
			this.tbConn.Name = "tbConn";
			this.tbConn.Size = new System.Drawing.Size(288, 20);
			this.tbConn.TabIndex = 1;
			this.tbConn.Text = "DSN=MySQL";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 40);
			this.label2.Name = "label2";
			this.label2.TabIndex = 2;
			this.label2.Text = "Query:";
			// 
			// tbQuery
			// 
			this.tbQuery.Location = new System.Drawing.Point(112, 40);
			this.tbQuery.Name = "tbQuery";
			this.tbQuery.Size = new System.Drawing.Size(288, 20);
			this.tbQuery.TabIndex = 3;
			this.tbQuery.Text = "";
			// 
			// btRun
			// 
			this.btRun.Location = new System.Drawing.Point(224, 120);
			this.btRun.Name = "btRun";
			this.btRun.Size = new System.Drawing.Size(80, 23);
			this.btRun.TabIndex = 4;
			this.btRun.Text = "Run Queries";
			this.btRun.Click += new System.EventHandler(this.btRun_Click);
			// 
			// btClose
			// 
			this.btClose.Location = new System.Drawing.Point(320, 120);
			this.btClose.Name = "btClose";
			this.btClose.Size = new System.Drawing.Size(80, 23);
			this.btClose.TabIndex = 5;
			this.btClose.Text = "Close";
			this.btClose.Click += new System.EventHandler(this.btClose_Click);
			// 
			// btAdd
			// 
			this.btAdd.Location = new System.Drawing.Point(320, 64);
			this.btAdd.Name = "btAdd";
			this.btAdd.Size = new System.Drawing.Size(80, 23);
			this.btAdd.TabIndex = 6;
			this.btAdd.Text = "Add Query";
			this.btAdd.Click += new System.EventHandler(this.btAdd_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(408, 147);
			this.Controls.Add(this.btAdd);
			this.Controls.Add(this.btClose);
			this.Controls.Add(this.btRun);
			this.Controls.Add(this.tbQuery);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.tbConn);
			this.Controls.Add(this.label1);
			this.Name = "Form1";
			this.Text = "OdbcExecuterDemo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			OdbcExecuter.WaitMessage = "EXECUTING QUERIES...";
		}

		private void btAdd_Click(object sender, System.EventArgs e)
		{
			OdbcExecuter.AddQuery(tbQuery.Text);
			tbQuery.Text = "";
		}

		private void btRun_Click(object sender, System.EventArgs e)
		{
			OdbcExecuter.ConnectionString = tbConn.Text;
			if (!OdbcExecuter.ExecuteQueries()) MessageBox.Show("Could not execute all queries or database error!");
			OdbcExecuter.CleanQueries();
		}

		private void btClose_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
