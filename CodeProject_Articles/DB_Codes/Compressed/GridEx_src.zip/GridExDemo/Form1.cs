using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace GridExDemo
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private RtF.WinUtils.Grids.GridEx gridEx1;
		private System.Windows.Forms.Panel panel1;
		private GridExDemo.dsOrder dsOrder1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox cbAutoSearch;
		private System.Windows.Forms.CheckBox cbRowSelect;
		private System.Windows.Forms.CheckBox cbUserGridParentStyle;
		private System.Windows.Forms.CheckBox cbAutoSize;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn2;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn3;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn4;
		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle1;
		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle2;
		private System.Windows.Forms.DataGridTableStyle dataGridTableStyle3;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn5;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn6;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn7;
		private System.Windows.Forms.NumericUpDown numericUpDown1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn8;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn9;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn10;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn11;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn12;
		private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn13;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			//this.sqlDataAdapter1.Fill(this.dsOrder1);

			this.dsOrder1.ReadXml("Orders.xml");
			this.gridEx1.DataSource = this.dsOrder1.Orders;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.dataGridTableStyle2 = new System.Windows.Forms.DataGridTableStyle();
			this.gridEx1 = new RtF.WinUtils.Grids.GridEx();
			this.dataGridTableStyle1 = new System.Windows.Forms.DataGridTableStyle();
			this.dataGridTableStyle3 = new System.Windows.Forms.DataGridTableStyle();
			this.dataGridTextBoxColumn8 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn9 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn10 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn11 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn12 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn13 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn5 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn6 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn7 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dsOrder1 = new GridExDemo.dsOrder();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.cbAutoSearch = new System.Windows.Forms.CheckBox();
			this.cbAutoSize = new System.Windows.Forms.CheckBox();
			this.cbRowSelect = new System.Windows.Forms.CheckBox();
			this.cbUserGridParentStyle = new System.Windows.Forms.CheckBox();
			this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn2 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn3 = new System.Windows.Forms.DataGridTextBoxColumn();
			this.dataGridTextBoxColumn4 = new System.Windows.Forms.DataGridTextBoxColumn();
			((System.ComponentModel.ISupportInitialize)(this.gridEx1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsOrder1)).BeginInit();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// dataGridTableStyle2
			// 
			this.dataGridTableStyle2.AlternatingBackColor = System.Drawing.Color.PaleTurquoise;
			this.dataGridTableStyle2.BackColor = System.Drawing.Color.LightCyan;
			this.dataGridTableStyle2.DataGrid = this.gridEx1;
			this.dataGridTableStyle2.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
																												  this.dataGridTextBoxColumn5,
																												  this.dataGridTextBoxColumn6,
																												  this.dataGridTextBoxColumn7});
			this.dataGridTableStyle2.HeaderBackColor = System.Drawing.Color.DarkTurquoise;
			this.dataGridTableStyle2.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridTableStyle2.MappingName = "";
			// 
			// gridEx1
			// 
			this.gridEx1.AlternatingBackColor = System.Drawing.Color.Gainsboro;
			this.gridEx1.AutoSearch = true;
			this.gridEx1.AutoSize = false;
			this.gridEx1.BackColor = System.Drawing.Color.Silver;
			this.gridEx1.BackgroundColor = System.Drawing.Color.Gray;
			this.gridEx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.gridEx1.CaptionBackColor = System.Drawing.Color.DarkSlateBlue;
			this.gridEx1.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
			this.gridEx1.CaptionForeColor = System.Drawing.Color.White;
			this.gridEx1.CurrentStyleIndex = -1;
			this.gridEx1.DataMember = "";
			this.gridEx1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gridEx1.FlatMode = true;
			this.gridEx1.ForeColor = System.Drawing.Color.Black;
			this.gridEx1.GridLineColor = System.Drawing.Color.White;
			this.gridEx1.HeaderBackColor = System.Drawing.Color.DarkGray;
			this.gridEx1.HeaderForeColor = System.Drawing.Color.Black;
			this.gridEx1.LinkColor = System.Drawing.Color.DarkSlateBlue;
			this.gridEx1.Location = new System.Drawing.Point(0, 80);
			this.gridEx1.Name = "gridEx1";
			this.gridEx1.ParentRowsBackColor = System.Drawing.Color.Black;
			this.gridEx1.ParentRowsForeColor = System.Drawing.Color.White;
			this.gridEx1.ReadOnly = true;
			this.gridEx1.RowSelect = true;
			this.gridEx1.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
			this.gridEx1.SelectionForeColor = System.Drawing.Color.White;
			this.gridEx1.Size = new System.Drawing.Size(552, 237);
			this.gridEx1.TabIndex = 0;
			this.gridEx1.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
																								this.dataGridTableStyle2,
																								this.dataGridTableStyle1,
																								this.dataGridTableStyle3});
			this.gridEx1.UseGridParentStyle = false;
			// 
			// dataGridTableStyle1
			// 
			this.dataGridTableStyle1.AlternatingBackColor = System.Drawing.Color.Wheat;
			this.dataGridTableStyle1.BackColor = System.Drawing.Color.PapayaWhip;
			this.dataGridTableStyle1.DataGrid = this.gridEx1;
			this.dataGridTableStyle1.GridLineColor = System.Drawing.Color.Tan;
			this.dataGridTableStyle1.HeaderBackColor = System.Drawing.Color.Peru;
			this.dataGridTableStyle1.HeaderForeColor = System.Drawing.Color.White;
			this.dataGridTableStyle1.MappingName = "";
			this.dataGridTableStyle1.SelectionBackColor = System.Drawing.Color.Gold;
			this.dataGridTableStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(192)));
			// 
			// dataGridTableStyle3
			// 
			this.dataGridTableStyle3.AlternatingBackColor = System.Drawing.Color.PaleGreen;
			this.dataGridTableStyle3.BackColor = System.Drawing.Color.MediumAquamarine;
			this.dataGridTableStyle3.DataGrid = this.gridEx1;
			this.dataGridTableStyle3.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
																												  this.dataGridTextBoxColumn8,
																												  this.dataGridTextBoxColumn9,
																												  this.dataGridTextBoxColumn10,
																												  this.dataGridTextBoxColumn11,
																												  this.dataGridTextBoxColumn12,
																												  this.dataGridTextBoxColumn13});
			this.dataGridTableStyle3.HeaderBackColor = System.Drawing.Color.SeaGreen;
			this.dataGridTableStyle3.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dataGridTableStyle3.MappingName = "";
			// 
			// dataGridTextBoxColumn8
			// 
			this.dataGridTextBoxColumn8.Format = "";
			this.dataGridTextBoxColumn8.FormatInfo = null;
			this.dataGridTextBoxColumn8.HeaderText = "OrderID";
			this.dataGridTextBoxColumn8.MappingName = "OrderID";
			this.dataGridTextBoxColumn8.Width = 75;
			// 
			// dataGridTextBoxColumn9
			// 
			this.dataGridTextBoxColumn9.Format = "";
			this.dataGridTextBoxColumn9.FormatInfo = null;
			this.dataGridTextBoxColumn9.HeaderText = "CustomerID";
			this.dataGridTextBoxColumn9.MappingName = "CustomerID";
			this.dataGridTextBoxColumn9.Width = 75;
			// 
			// dataGridTextBoxColumn10
			// 
			this.dataGridTextBoxColumn10.Format = "";
			this.dataGridTextBoxColumn10.FormatInfo = null;
			this.dataGridTextBoxColumn10.HeaderText = "OrderDate";
			this.dataGridTextBoxColumn10.MappingName = "OrderDate";
			this.dataGridTextBoxColumn10.Width = 75;
			// 
			// dataGridTextBoxColumn11
			// 
			this.dataGridTextBoxColumn11.Format = "";
			this.dataGridTextBoxColumn11.FormatInfo = null;
			this.dataGridTextBoxColumn11.HeaderText = "ShippedDate";
			this.dataGridTextBoxColumn11.MappingName = "ShippedDate";
			this.dataGridTextBoxColumn11.Width = 75;
			// 
			// dataGridTextBoxColumn12
			// 
			this.dataGridTextBoxColumn12.Format = "";
			this.dataGridTextBoxColumn12.FormatInfo = null;
			this.dataGridTextBoxColumn12.HeaderText = "Freight";
			this.dataGridTextBoxColumn12.MappingName = "Freight";
			this.dataGridTextBoxColumn12.Width = 75;
			// 
			// dataGridTextBoxColumn13
			// 
			this.dataGridTextBoxColumn13.Format = "";
			this.dataGridTextBoxColumn13.FormatInfo = null;
			this.dataGridTextBoxColumn13.HeaderText = "ShipName";
			this.dataGridTextBoxColumn13.MappingName = "ShipName";
			this.dataGridTextBoxColumn13.Width = 75;
			// 
			// dataGridTextBoxColumn5
			// 
			this.dataGridTextBoxColumn5.Format = "";
			this.dataGridTextBoxColumn5.FormatInfo = null;
			this.dataGridTextBoxColumn5.HeaderText = "OrderID";
			this.dataGridTextBoxColumn5.MappingName = "OrderID";
			this.dataGridTextBoxColumn5.Width = 75;
			// 
			// dataGridTextBoxColumn6
			// 
			this.dataGridTextBoxColumn6.Format = "";
			this.dataGridTextBoxColumn6.FormatInfo = null;
			this.dataGridTextBoxColumn6.HeaderText = "CustomerID";
			this.dataGridTextBoxColumn6.MappingName = "CustomerID";
			this.dataGridTextBoxColumn6.Width = 75;
			// 
			// dataGridTextBoxColumn7
			// 
			this.dataGridTextBoxColumn7.Format = "";
			this.dataGridTextBoxColumn7.FormatInfo = null;
			this.dataGridTextBoxColumn7.HeaderText = "EmployeeID";
			this.dataGridTextBoxColumn7.MappingName = "EmployeeID";
			this.dataGridTextBoxColumn7.Width = 75;
			// 
			// dsOrder1
			// 
			this.dsOrder1.DataSetName = "dsOrder";
			this.dsOrder1.Locale = new System.Globalization.CultureInfo("en-US");
			this.dsOrder1.Namespace = "http://www.tempuri.org/dsOrder.xsd";
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.label1,
																				 this.numericUpDown1,
																				 this.groupBox1});
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(552, 80);
			this.panel1.TabIndex = 1;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(272, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(97, 13);
			this.label1.TabIndex = 5;
			this.label1.Text = "Change Grid Style";
			// 
			// numericUpDown1
			// 
			this.numericUpDown1.Location = new System.Drawing.Point(376, 11);
			this.numericUpDown1.Maximum = new System.Decimal(new int[] {
																		   2,
																		   0,
																		   0,
																		   0});
			this.numericUpDown1.Minimum = new System.Decimal(new int[] {
																		   1,
																		   0,
																		   0,
																		   -2147483648});
			this.numericUpDown1.Name = "numericUpDown1";
			this.numericUpDown1.Size = new System.Drawing.Size(56, 20);
			this.numericUpDown1.TabIndex = 4;
			this.numericUpDown1.Value = new System.Decimal(new int[] {
																		 1,
																		 0,
																		 0,
																		 -2147483648});
			this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.cbAutoSearch,
																					this.cbAutoSize,
																					this.cbRowSelect,
																					this.cbUserGridParentStyle});
			this.groupBox1.Location = new System.Drawing.Point(13, 7);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(241, 63);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Settings";
			// 
			// cbAutoSearch
			// 
			this.cbAutoSearch.Checked = true;
			this.cbAutoSearch.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbAutoSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cbAutoSearch.Location = new System.Drawing.Point(14, 19);
			this.cbAutoSearch.Name = "cbAutoSearch";
			this.cbAutoSearch.Size = new System.Drawing.Size(79, 16);
			this.cbAutoSearch.TabIndex = 0;
			this.cbAutoSearch.Text = "AutoSearch";
			this.cbAutoSearch.CheckedChanged += new System.EventHandler(this.cbAutoSearch_CheckedChanged);
			// 
			// cbAutoSize
			// 
			this.cbAutoSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cbAutoSize.Location = new System.Drawing.Point(104, 19);
			this.cbAutoSize.Name = "cbAutoSize";
			this.cbAutoSize.Size = new System.Drawing.Size(66, 16);
			this.cbAutoSize.TabIndex = 0;
			this.cbAutoSize.Text = "AutoSize";
			this.cbAutoSize.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// cbRowSelect
			// 
			this.cbRowSelect.Checked = true;
			this.cbRowSelect.CheckState = System.Windows.Forms.CheckState.Checked;
			this.cbRowSelect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cbRowSelect.Location = new System.Drawing.Point(14, 40);
			this.cbRowSelect.Name = "cbRowSelect";
			this.cbRowSelect.Size = new System.Drawing.Size(75, 16);
			this.cbRowSelect.TabIndex = 0;
			this.cbRowSelect.Text = "RowSelect";
			this.cbRowSelect.CheckedChanged += new System.EventHandler(this.cbRowSelect_CheckedChanged);
			// 
			// cbUserGridParentStyle
			// 
			this.cbUserGridParentStyle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.cbUserGridParentStyle.Location = new System.Drawing.Point(104, 40);
			this.cbUserGridParentStyle.Name = "cbUserGridParentStyle";
			this.cbUserGridParentStyle.Size = new System.Drawing.Size(124, 16);
			this.cbUserGridParentStyle.TabIndex = 0;
			this.cbUserGridParentStyle.Text = "UserGridParentStyle";
			this.cbUserGridParentStyle.CheckedChanged += new System.EventHandler(this.cbUserGridParentStyle_CheckedChanged);
			// 
			// dataGridTextBoxColumn1
			// 
			this.dataGridTextBoxColumn1.Format = "";
			this.dataGridTextBoxColumn1.FormatInfo = null;
			this.dataGridTextBoxColumn1.HeaderText = "OrderID";
			this.dataGridTextBoxColumn1.MappingName = "OrderID";
			this.dataGridTextBoxColumn1.Width = 75;
			// 
			// dataGridTextBoxColumn2
			// 
			this.dataGridTextBoxColumn2.Format = "";
			this.dataGridTextBoxColumn2.FormatInfo = null;
			this.dataGridTextBoxColumn2.HeaderText = "CustomerID";
			this.dataGridTextBoxColumn2.MappingName = "CustomerID";
			this.dataGridTextBoxColumn2.Width = 75;
			// 
			// dataGridTextBoxColumn3
			// 
			this.dataGridTextBoxColumn3.Format = "";
			this.dataGridTextBoxColumn3.FormatInfo = null;
			this.dataGridTextBoxColumn3.HeaderText = "OrderDate";
			this.dataGridTextBoxColumn3.MappingName = "OrderDate";
			this.dataGridTextBoxColumn3.Width = 75;
			// 
			// dataGridTextBoxColumn4
			// 
			this.dataGridTextBoxColumn4.Format = "";
			this.dataGridTextBoxColumn4.FormatInfo = null;
			this.dataGridTextBoxColumn4.HeaderText = "ShipVia";
			this.dataGridTextBoxColumn4.MappingName = "ShipVia";
			this.dataGridTextBoxColumn4.Width = 75;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(552, 317);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.gridEx1,
																		  this.panel1});
			this.Name = "Form1";
			this.Text = "GridEx Demo";
			((System.ComponentModel.ISupportInitialize)(this.gridEx1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsOrder1)).EndInit();
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cbAutoSearch_CheckedChanged(object sender, System.EventArgs e)
		{
			this.gridEx1.AutoSearch = this.cbAutoSearch.Checked;
		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			this.gridEx1.AutoSize = this.cbAutoSize.Checked;
		}

		private void cbRowSelect_CheckedChanged(object sender, System.EventArgs e)
		{
			this.gridEx1.RowSelect = this.cbRowSelect.Checked;
		}

		private void cbUserGridParentStyle_CheckedChanged(object sender, System.EventArgs e)
		{
			this.gridEx1.UseGridParentStyle = this.cbUserGridParentStyle.Checked;
		}

		private void numericUpDown1_ValueChanged(object sender, System.EventArgs e)
		{
			this.gridEx1.CurrentStyleIndex = (int)this.numericUpDown1.Value;
		}
	}
}
