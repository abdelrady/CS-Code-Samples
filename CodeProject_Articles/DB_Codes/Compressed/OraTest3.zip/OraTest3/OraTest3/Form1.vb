Imports System.Data
Imports System.Data.OracleClient
Imports System.Data.SqlClient


Public Class s
    Private Function GetConnectionString() As String
        Return txtOracleConnString.Text
    End Function
    Private Sub msgOut(ByVal message As String)
        rTextOut.Text += message & vbCrLf
        Application.DoEvents()
    End Sub
    Private Sub ConnectAndQuery()
        Dim connectionString As String = GetConnectionString()
        ' Using 
        Dim connection As OracleConnection = New OracleConnection
        Dim oConn As SqlConnection
        Try

            connection.ConnectionString = connectionString
            connection.Open()
            msgOut("Oracle Connection Opened, OK")
            Dim command As OracleCommand = connection.CreateCommand
            Dim sql As String = TextBox2.Text
            command.CommandText = sql

            Dim reader As OracleDataReader = command.ExecuteReader
            msgOut("Data retrieved to reader from Oracle, OK " & reader.HasRows)
            'Dim dt As DataTable = reader.GetSchemaTable


            'CONVERT DATAREADER TO DATATABLE
            Dim dra As DataUtils.DataReaderAdapter = New DataUtils.DataReaderAdapter
            Dim dt As DataTable = New DataTable
            dra.FillFromReader(dt, reader)
            msgOut("Datatable created, OK")
            reader.Close()

            'BIND THE DATATABLE TO THE DATAGRIDVIEW
            DataGridView1.DataSource = dt
            msgOut("Datagrid Bound to Datatable, OK")

            'Create the SQL Server Table
            'oConn = New SqlConnection("Data Source=MSPM1BDB19;Initial Catalog=Ascendant;User ID=ricef;Password=cards4me;Connect Timeout=30")
            oConn = New SqlConnection(txtDestinationConnString.Text)

            oConn.Open()
            msgOut("SQL Connection Opened, OK")
            Dim sqlTableCreator As SQLCreateTable = New SQLCreateTable
            sqlTableCreator.Connection = oConn
            sqlTableCreator.DestinationTableName = txtDestTableName.Text
            sqlTableCreator.DropTableIfExists = CheckBox1.Checked
            sqlTableCreator.CreateFromDataTable(dt)
            msgOut("SQL table created from Datatable, OK")

            'INSERT INTO SQL SERVER DATABASE


            CopyData(dt, oConn)
            msgOut("Data copied to SQL Server using SQLBulkCopy, -- FINISHED --")

        Catch ex As Exception
            msgOut(ex.ToString)
        Finally
            CType(connection, IDisposable).Dispose()
            oConn.Close()
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        rTextOut.Text = ""
        ConnectAndQuery()
    End Sub
    Private Sub CopyData(ByVal sourceTable As DataTable, ByVal destConnection As SqlConnection)
        ' Using 
        Dim s As SqlBulkCopy = New SqlBulkCopy(destConnection)
        Try
            s.DestinationTableName = "OraTest3"
            s.NotifyAfter = 10000

            's.SqlRowsCopied += New SqlRowsCopiedEventHandler(s_SqlRowsCopied)
            AddHandler s.SqlRowsCopied, AddressOf s_SqlRowsCopied

            s.WriteToServer(sourceTable)
            s.Close()
        Finally
            CType(s, IDisposable).Dispose()
        End Try
    End Sub
    Private Sub s_SqlRowsCopied(ByVal sender As Object, ByVal e As SqlRowsCopiedEventArgs)
        msgOut("Copied " & e.RowsCopied & " rows, OK")
    End Sub
    Public Function GetTable(ByVal _reader As System.Data.OracleClient.OracleDataReader) As System.Data.DataTable
        Dim _table As System.Data.DataTable = _reader.GetSchemaTable
        Dim _dt As System.Data.DataTable = New System.Data.DataTable
        Dim _dc As System.Data.DataColumn
        Dim _row As System.Data.DataRow
        Dim _al As System.Collections.ArrayList = New System.Collections.ArrayList
        Dim i As Integer = 0
        While i < _table.Rows.Count
            _dc = New System.Data.DataColumn
            If Not _dt.Columns.Contains(_table.Rows(i)("ColumnName").ToString) Then
                _dc.ColumnName = _table.Rows(i)("ColumnName").ToString
                _dc.Unique = Convert.ToBoolean(_table.Rows(i)("IsUnique"))
                _dc.AllowDBNull = Convert.ToBoolean(_table.Rows(i)("AllowDBNull"))
                _dc.ReadOnly = Convert.ToBoolean(_table.Rows(i)("IsReadOnly"))
                _al.Add(_dc.ColumnName)
                _dt.Columns.Add(_dc)
            End If
            System.Math.Min(System.Threading.Interlocked.Increment(i), i - 1)
        End While
        While _reader.Read
            _row = _dt.NewRow
            i = 0
            While i < _al.Count
                _row(CType(_al(i), System.String)) = _reader(CType(_al(i), System.String))
                System.Math.Min(System.Threading.Interlocked.Increment(i), i - 1)
            End While
            _dt.Rows.Add(_row)
        End While
        Return _dt
    End Function

End Class
