Public Class SqlConnectVB
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'Dim conStr As New SqlClient.SqlConnection
        'conStr.ConnectionString = "workstation id=XPHTEK;packet size=4096;integrated security=SSPI;data source=XPHTEK; initial catalog=pubs;persist security info=false"
        ' conStr.Open()
        'If conStr.State = ConnectionState.Open Then
        '  Label1.Text = "SQLConnection conStr is Open"
        ' ElseIf conStr.State = ConnectionState.Closed Then
        '    Label1.Text = "SQLConnection conStris closed"
        ' End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.Text = ""
        Label2.Text = ""
        Try
            Dim conStr As New SqlClient.SqlConnection
            conStr.ConnectionString = "workstation id=XPHTEK;" & _
            "packet size=4096;integrated security=SSPI;data source=XPHTEK;" & _
            "persist security info=false;" & "initial catalog= " & TextBox1.Text & ";"
            Response.Write("Connection string:  " & vbCrLf & conStr.ConnectionString)
            conStr.Open()
            If conStr.State = ConnectionState.Open Then
                Label1.Text = "SQLConnection conStr is Open"
                conStr.Close()
            ElseIf conStr.State = ConnectionState.Closed Then
                Label1.Text = "SQLConnection conStr is closed"
            End If
        Catch sqlxcp As SqlClient.SqlException
            Label2.Text = sqlxcp.ToString
            Label3.Text = sqlxcp.Message
            Label4.Text = sqlxcp.Source
            Label5.Text = sqlxcp.Number
        Finally
            

        End Try

    End Sub
    
End Class
