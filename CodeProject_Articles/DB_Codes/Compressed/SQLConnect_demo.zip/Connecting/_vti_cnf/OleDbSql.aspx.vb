vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|30 Aug 2004 04:02:02 -0000
vti_timelastmodified:TR|30 Aug 2004 04:10:09 -0000
vti_filesize:IR|1806
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|30 Aug 2004 04:09:06 -0000
vti_cacheddtm:TX|30 Aug 2004 04:10:09 -0000
