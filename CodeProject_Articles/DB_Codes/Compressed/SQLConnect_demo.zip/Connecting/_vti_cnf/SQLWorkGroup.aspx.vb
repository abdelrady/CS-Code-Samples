vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|30 Aug 2004 03:19:17 -0000
vti_timelastmodified:TR|01 Sep 2004 16:23:46 -0000
vti_filesize:IR|1947
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|31 Aug 2004 18:21:14 -0000
vti_cacheddtm:TX|01 Sep 2004 16:23:46 -0000
