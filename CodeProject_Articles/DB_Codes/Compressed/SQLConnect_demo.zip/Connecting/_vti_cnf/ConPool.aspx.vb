vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|01 Sep 2004 03:04:56 -0000
vti_timelastmodified:TR|01 Sep 2004 03:29:51 -0000
vti_filesize:IR|2596
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|01 Sep 2004 03:18:39 -0000
vti_cacheddtm:TX|01 Sep 2004 03:29:51 -0000
