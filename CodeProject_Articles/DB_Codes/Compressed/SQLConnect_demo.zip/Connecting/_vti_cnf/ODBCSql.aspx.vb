vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|30 Aug 2004 03:51:42 -0000
vti_timelastmodified:TR|30 Aug 2004 04:12:28 -0000
vti_filesize:IR|1688
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|30 Aug 2004 04:00:26 -0000
vti_cacheddtm:TX|30 Aug 2004 04:12:28 -0000
