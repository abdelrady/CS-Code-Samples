vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|29 Aug 2004 15:36:07 -0000
vti_timelastmodified:TR|29 Aug 2004 15:36:07 -0000
vti_cacheddtm:TX|29 Aug 2004 15:36:07 -0000
vti_filesize:IR|1800
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
