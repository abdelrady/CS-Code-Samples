vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|29 Aug 2004 19:49:37 -0000
vti_timelastmodified:TR|31 Aug 2004 19:25:58 -0000
vti_filesize:IR|3138
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|31 Aug 2004 18:48:55 -0000
vti_cacheddtm:TX|31 Aug 2004 19:25:58 -0000
