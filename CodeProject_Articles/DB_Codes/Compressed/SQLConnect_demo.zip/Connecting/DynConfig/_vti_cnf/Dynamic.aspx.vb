vti_encoding:SR|utf8-nl
vti_author:SR|XPHTEK\\computer user
vti_modifiedby:SR|XPHTEK\\computer user
vti_timecreated:TR|31 Aug 2004 20:09:11 -0000
vti_timelastmodified:TR|31 Aug 2004 20:43:02 -0000
vti_filesize:IR|1822
vti_extenderversion:SR|4.0.2.5322
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TR|31 Aug 2004 20:39:24 -0000
vti_cacheddtm:TX|31 Aug 2004 20:43:02 -0000
