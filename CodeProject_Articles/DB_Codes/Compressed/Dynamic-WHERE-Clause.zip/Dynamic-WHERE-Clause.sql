
CREATE TABLE tblEmployee
(
	EmployeeID      SMALLINT IDENTITY(1001,1) NOT NULL,
	First_Name       NVARCHAR(100) NOT NULL,
	Middle_Name    NVARCHAR(100) NULL,
	Last_Name       NVARCHAR(100) NULL
)

/*The following Insert statements inserts sample records into tblEmployee table.*/

INSERT INTO tblEmployee(First_Name, Middle_Name, Last_Name) 
Values('John', 'Wessley', 'Harris')
INSERT INTO tblEmployee(First_Name, Middle_Name, Last_Name) 
Values('Christo', NULL, 'Solomon')
INSERT INTO tblEmployee(First_Name, Middle_Name, Last_Name) 
Values('Micheal', 'Potter', NULL)
INSERT INTO tblEmployee(First_Name, Middle_Name, Last_Name) 
Values('Peter', NULL, NULL)

Select EmployeeID, (First_Name + ' ' + Middle_Name + ' ' + Last_Name) AS 'Employee Name' From  tblEmployee where EmployeeID = 1002


/* Variable Declaration */
DECLARE @EmpID AS SMALLINT
/* set the parameter value */
SET @EmpID = NULL
/* Transact-SQL with dynamic WHERE-Clause Using COALESCE function  */
Select EmployeeID,
       First_Name + ' ' + 
       Coalesce(Middle_Name,'') + 
       CASE WHEN Coalesce(Middle_Name,NULL) IS NOT NULL THEN ' ' ELSE '' END +  
       Coalesce(Last_Name, '') AS 'Employee Name' 
From tblEmployee where EmployeeID = COALESCE(@EmpID, EmployeeID)


/* Transact-Sql to create the table tblEmployees */
CREATE TABLE tblEmployees
(
    EmployeeID       SMALLINT IDENTITY(1001,1) NOT NULL,
    EmployeeName     NVARCHAR(100) NOT NULL,
    Department       NVARCHAR(50) NOT NULL,
    Designation      NVARCHAR(50) NOT NULL,
    JoiningDate      DATETIME NOT NULL,
    Salary           DECIMAL(10,2) NOT NULL
)



/* Transact SQL to insert some sample records into tblEmployees table */
INSERT INTO 
tblEmployees(EmployeeName, Department, Designation,  JoiningDate, Salary) 
VALUES('John Smith', 'IT Research', 'Research Analyst', '02/08/2005', 23000.00)

INSERT INTO 
tblEmployees(EmployeeName, Department, Designation, JoiningDate, Salary) 
VALUES('John Micheal', 'IT Operations', 'Manager', '07/15/2007', 15000.00)

INSERT INTO 
tblEmployees(EmployeeName, Department, Designation, JoiningDate, Salary) 
VALUES('Will Smith', 'IT Support', 'Manager', '05/20/2006', 13000.00)


/* Using Coalesce */
/* Create Stored Procedure 'sp_EmployeeSelect_Coalesce'. Example 2.1  */ 
Create Procedure sp_EmployeeSelect_Coalesce
	@EmployeeName NVarchar(100),
	@Department NVarchar(50),
	@Designation NVarchar(50),
	@StartDate DateTime,
	@EndDate DateTime,
	@Salary Decimal(10,2)
	    
AS
  	Set NoCount ON
  
	Select * From tblEmployees 
	where   EmployeeName = Coalesce(@EmployeeName, EmployeeName) AND
		Department = Coalesce(@Department, Department ) AND
		Designation = Coalesce(@Designation, Designation) AND
		JoiningDate >= Coalesce(@StartDate, JoiningDate) AND 
		JoiningDate <= Coalesce(@EndDate, JoiningDate) AND
		Salary >= Coalesce(@Salary, Salary)

	If @@ERROR <> 0 GoTo ErrorHandler
	Set NoCount OFF
	Return(0)
  
ErrorHandler:
	Return(@@ERROR)
GO

/* Using IsNull */
/* Create Stored Procedure 'sp_EmployeeSelect_ISNULL'. Example 2.1  */ 
Create Procedure sp_EmployeeSelect_ISNULL
	@EmployeeName NVarchar(100),
	@Department NVarchar(50),
	@Designation NVarchar(50),
	@StartDate DateTime,
	@EndDate DateTime,
	@Salary Decimal(10,2)
AS
  	Set NoCount ON
  
	Select * From tblEmployees 
	where     EmployeeName = IsNull(@EmployeeName, EmployeeName) AND
		Department = IsNull(@Department, Department ) AND
		Designation = IsNull(@Designation, Designation) AND
		JoiningDate >= IsNull(@StartDate, JoiningDate) AND 
		JoiningDate <= IsNull(@EndDate, JoiningDate) AND
		Salary >= IsNull(@Salary, Salary)

	If @@ERROR <> 0 GoTo ErrorHandler
	Set NoCount OFF
	Return(0)
  
ErrorHandler:
	Return(@@ERROR)
GO

/* Using Case */
/* Create Stored Procedure 'sp_EmployeeSelect_Case'. Example 1.2  */ 
Create Procedure sp_EmployeeSelect_Case
	@EmployeeName NVarchar(100),
	@Department NVarchar(50),
	@Designation NVarchar(50),
	@StartDate DateTime,
	@EndDate DateTime,
	@Salary Decimal(10,2)
AS
  	Set NoCount ON
  
	Select * From tblEmployees 
	where   EmployeeName = Case When @EmployeeName Is Not Null Then @EmployeeName ELSE EmployeeName End AND
		Department = Case When @Department Is Not Null Then @Department Else Department End AND
		Designation = Case When @Designation Is Not Null Then @Designation Else Designation End AND
		JoiningDate >= Case When @StartDate Is Not Null Then @StartDate Else JoiningDate End AND
		JoiningDate <= Case When @EndDate Is Not Null Then @EndDate Else JoiningDate End AND
		Salary >= Case When @Salary Is Not Null Then @Salary else Salary End 

	If @@ERROR <> 0 GoTo ErrorHandler
	Set NoCount OFF
	Return(0)
  
ErrorHandler:
	Return(@@ERROR)
GO

/* A simple Logic to implement the same */
/* Create Stored Procedure 'sp_EmployeeSelect_Alternate'. Example 1.4  */ 
Create Procedure sp_EmployeeSelect_Alternate
	@EmployeeName NVarchar(100),
	@Department NVarchar(50),
	@Designation NVarchar(50),
	@StartDate DateTime,
	@EndDate DateTime,
	@Salary Decimal(10,2)
AS 
	Set NoCount ON
  
	SELECT * FROM tblEmployees
	WHERE   (@EmployeeName Is Null OR @EmployeeName = EmployeeName) AND
		(@Department Is Null OR @Department = Department) AND
		(@Designation Is Null OR @Designation = Designation) AND
		(@Salary Is Null OR @Salary = Salary) AND
		(@StartDate Is Null OR @EndDate Is Null OR 
		(@StartDate Is Not Null AND @EndDate Is Not Null AND 
		JoiningDate BETWEEN @StartDate AND @EndDate))

	If @@ERROR <> 0 GoTo ErrorHandler
	Set NoCount OFF
	Return(0)
  
ErrorHandler:
	Return(@@ERROR)
GO


EXEC sp_EmployeeSelect_Coalesce NULL, NULL, 'Manager', NULL, NULL, NULL
EXEC sp_EmployeeSelect_IsNull NULL, NULL, 'Manager', NULL, NULL, NULL
EXEC sp_EmployeeSelect_Case NULL, NULL, 'Manager', NULL, NULL, NULL
EXEC sp_EmployeeSelect_Alternate NULL, NULL, 'Manager', NULL, NULL, NULL


