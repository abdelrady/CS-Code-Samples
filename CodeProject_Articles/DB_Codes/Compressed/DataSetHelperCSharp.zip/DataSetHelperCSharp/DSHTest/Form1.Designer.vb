<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
		Me.CheckBox1 = New System.Windows.Forms.CheckBox
		Me.Button2 = New System.Windows.Forms.Button
		Me.TextBox5 = New System.Windows.Forms.TextBox
		Me.Label10 = New System.Windows.Forms.Label
		Me.TextBox4 = New System.Windows.Forms.TextBox
		Me.Label9 = New System.Windows.Forms.Label
		Me.Label8 = New System.Windows.Forms.Label
		Me.Label7 = New System.Windows.Forms.Label
		Me.TextBox3 = New System.Windows.Forms.TextBox
		Me.Label6 = New System.Windows.Forms.Label
		Me.TextBox2 = New System.Windows.Forms.TextBox
		Me.Label5 = New System.Windows.Forms.Label
		Me.TextBox1 = New System.Windows.Forms.TextBox
		Me.Label3 = New System.Windows.Forms.Label
		Me.Label4 = New System.Windows.Forms.Label
		Me.Label2 = New System.Windows.Forms.Label
		Me.Label1 = New System.Windows.Forms.Label
		Me.Button1 = New System.Windows.Forms.Button
		Me.SuspendLayout()
		'
		'CheckBox1
		'
		Me.CheckBox1.AutoSize = True
		Me.CheckBox1.Location = New System.Drawing.Point(340, 114)
		Me.CheckBox1.Name = "CheckBox1"
		Me.CheckBox1.Size = New System.Drawing.Size(109, 17)
		Me.CheckBox1.TabIndex = 37
		Me.CheckBox1.Text = "Stored Procedure"
		Me.CheckBox1.UseVisualStyleBackColor = True
		'
		'Button2
		'
		Me.Button2.Location = New System.Drawing.Point(251, 238)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(96, 23)
		Me.Button2.TabIndex = 36
		Me.Button2.Text = "Execute Query"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'TextBox5
		'
		Me.TextBox5.Location = New System.Drawing.Point(75, 73)
		Me.TextBox5.Multiline = True
		Me.TextBox5.Name = "TextBox5"
		Me.TextBox5.Size = New System.Drawing.Size(374, 35)
		Me.TextBox5.TabIndex = 35
		Me.TextBox5.Text = "SELECT * FROM trDashBoard"
		'
		'Label10
		'
		Me.Label10.AutoSize = True
		Me.Label10.Location = New System.Drawing.Point(7, 73)
		Me.Label10.Name = "Label10"
		Me.Label10.Size = New System.Drawing.Size(35, 13)
		Me.Label10.TabIndex = 34
		Me.Label10.Text = "Query"
		'
		'TextBox4
		'
		Me.TextBox4.Location = New System.Drawing.Point(75, 32)
		Me.TextBox4.Multiline = True
		Me.TextBox4.Name = "TextBox4"
		Me.TextBox4.Size = New System.Drawing.Size(374, 35)
		Me.TextBox4.TabIndex = 33
		Me.TextBox4.Text = "Data Source=localhost,1433;Network Library=DBMSSOCN;Initial Catalog=DashBoard;Use" & _
			"r ID=sa;Password=qwerty1;"
		'
		'Label9
		'
		Me.Label9.AutoSize = True
		Me.Label9.Location = New System.Drawing.Point(7, 32)
		Me.Label9.Name = "Label9"
		Me.Label9.Size = New System.Drawing.Size(62, 13)
		Me.Label9.TabIndex = 32
		Me.Label9.Text = "Conn String"
		'
		'Label8
		'
		Me.Label8.AutoSize = True
		Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label8.Location = New System.Drawing.Point(6, 243)
		Me.Label8.Name = "Label8"
		Me.Label8.Size = New System.Drawing.Size(52, 13)
		Me.Label8.TabIndex = 31
		Me.Label8.Text = "Elapsed"
		'
		'Label7
		'
		Me.Label7.AutoSize = True
		Me.Label7.Location = New System.Drawing.Point(7, 215)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(26, 13)
		Me.Label7.TabIndex = 30
		Me.Label7.Text = "Sort"
		'
		'TextBox3
		'
		Me.TextBox3.Location = New System.Drawing.Point(75, 212)
		Me.TextBox3.Name = "TextBox3"
		Me.TextBox3.Size = New System.Drawing.Size(374, 20)
		Me.TextBox3.TabIndex = 29
		Me.TextBox3.Text = "LegalName DESC, State ASC"
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Location = New System.Drawing.Point(7, 178)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(29, 13)
		Me.Label6.TabIndex = 28
		Me.Label6.Text = "Filter"
		'
		'TextBox2
		'
		Me.TextBox2.Location = New System.Drawing.Point(75, 175)
		Me.TextBox2.Multiline = True
		Me.TextBox2.Name = "TextBox2"
		Me.TextBox2.Size = New System.Drawing.Size(374, 31)
		Me.TextBox2.TabIndex = 27
		Me.TextBox2.Text = "vendorid>2000"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Location = New System.Drawing.Point(7, 140)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(34, 13)
		Me.Label5.TabIndex = 26
		Me.Label5.Text = "Fields"
		'
		'TextBox1
		'
		Me.TextBox1.Location = New System.Drawing.Point(75, 137)
		Me.TextBox1.Multiline = True
		Me.TextBox1.Name = "TextBox1"
		Me.TextBox1.Size = New System.Drawing.Size(374, 32)
		Me.TextBox1.TabIndex = 25
		Me.TextBox1.Text = "LegalName,FileNumber,State,ReminderNote,VendorColor,VendorID,StatusID,Network,Use" & _
			"rID"
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label3.Location = New System.Drawing.Point(6, 118)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(38, 13)
		Me.Label3.TabIndex = 24
		Me.Label3.Text = "Rows"
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label4.Location = New System.Drawing.Point(156, 118)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(31, 13)
		Me.Label4.TabIndex = 23
		Me.Label4.Text = "Cols"
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(158, 7)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(31, 13)
		Me.Label2.TabIndex = 22
		Me.Label2.Text = "Cols"
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(8, 7)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(38, 13)
		Me.Label1.TabIndex = 21
		Me.Label1.Text = "Rows"
		'
		'Button1
		'
		Me.Button1.Location = New System.Drawing.Point(353, 238)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(96, 23)
		Me.Button1.TabIndex = 20
		Me.Button1.Text = "Select Distinct"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(458, 267)
		Me.Controls.Add(Me.CheckBox1)
		Me.Controls.Add(Me.Button2)
		Me.Controls.Add(Me.TextBox5)
		Me.Controls.Add(Me.Label10)
		Me.Controls.Add(Me.TextBox4)
		Me.Controls.Add(Me.Label9)
		Me.Controls.Add(Me.Label8)
		Me.Controls.Add(Me.Label7)
		Me.Controls.Add(Me.TextBox3)
		Me.Controls.Add(Me.Label6)
		Me.Controls.Add(Me.TextBox2)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.TextBox1)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.Button1)
		Me.Name = "Form1"
		Me.Text = "SelectDistint Demo (C#)"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
	Friend WithEvents Button2 As System.Windows.Forms.Button
	Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
	Friend WithEvents Label10 As System.Windows.Forms.Label
	Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
	Friend WithEvents Label9 As System.Windows.Forms.Label
	Friend WithEvents Label8 As System.Windows.Forms.Label
	Friend WithEvents Label7 As System.Windows.Forms.Label
	Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
	Friend WithEvents Label6 As System.Windows.Forms.Label
	Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
	Friend WithEvents Label5 As System.Windows.Forms.Label
	Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
	Friend WithEvents Label3 As System.Windows.Forms.Label
	Friend WithEvents Label4 As System.Windows.Forms.Label
	Friend WithEvents Label2 As System.Windows.Forms.Label
	Friend WithEvents Label1 As System.Windows.Forms.Label
	Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
