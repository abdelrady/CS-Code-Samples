Imports System.Data
Imports System.Data.SqlClient
Imports DataSetHelper

Public Class Form1
	Dim db As SqlConnection
	Dim sda As SqlDataAdapter
	Dim dsh As clsDSHcs
	Dim dt As DataTable

	Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
		If dsh IsNot Nothing Then dsh.Dispose()
		dsh = Nothing
		sda.Dispose()
		sda = Nothing
		db.Close()
		db = Nothing
	End Sub

	Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
		Button1.Enabled = False
		dsh = New clsDSHcs(dt)
		Dim dt2 As DataTable = dsh.SelectDistinct(dt, TextBox1.Text, TextBox2.Text, TextBox3.Text)
		Label8.Text = "Elapsed: " & dsh.ElapsedTime & " secs."
		If dt2 Is Nothing Then
			Label3.Text = "Rows: 0"
			Label4.Text = "Cols: 0"
		Else
			Label3.Text = "Rows: " & dt2.Rows.Count
			Label4.Text = "Cols: " & dt2.Columns.Count
		End If
		PrintTable(dt2)
		Button1.Enabled = True
	End Sub

	Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
		Button2.Enabled = False
		db = New SqlConnection
		dt = New DataTable
		db.ConnectionString = TextBox4.Text
		db.Open()
		Dim sql As String = TextBox5.Text
		sda = New SqlDataAdapter(sql, db)
		If CheckBox1.Checked Then
			sda.SelectCommand.CommandType = CommandType.StoredProcedure
		Else
			sda.SelectCommand.CommandType = CommandType.Text
		End If
		sda.Fill(dt)
		db.Close()
		Label1.Text = "Rows: " & dt.Rows.Count
		Label2.Text = "Cols: " & dt.Columns.Count
		PrintTable(dt)
		If dt IsNot Nothing Then Button1.Enabled = True
		Button2.Enabled = True
	End Sub

	Private Sub PrintTable(ByVal _dt As DataTable)
		PrintTable(_dt, False)
	End Sub

	Private Sub PrintTable(ByVal _dt As DataTable, ByVal ShowAll As Boolean)
		Dim i As Integer = 0
		If _dt Is Nothing Then
			Debug.WriteLine("TABLE: Nothing")
		Else
			Debug.WriteLine("TABLE: " & _dt.TableName)
		End If
		Debug.WriteLine("_________________________________")
		If _dt IsNot Nothing Then
			For Each dr As DataRow In _dt.Rows
				Debug.Write("Row " & i & ": ")
				For Each col As DataColumn In _dt.Columns
					If dr(col) Is DBNull.Value Then
						Debug.Write("null" & vbTab)
					Else
						Debug.Write(dr(col) & vbTab)
					End If
				Next
				Debug.Write(vbCrLf)
				i += 1
				If i >= 20 And Not ShowAll Then
					Debug.WriteLine("Omitting Remainder of Table... Too many records.")
					Exit For
				End If
			Next
		End If
		Debug.WriteLine("_______________END_______________")
	End Sub

	Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		Button1.Enabled = False
	End Sub
End Class
