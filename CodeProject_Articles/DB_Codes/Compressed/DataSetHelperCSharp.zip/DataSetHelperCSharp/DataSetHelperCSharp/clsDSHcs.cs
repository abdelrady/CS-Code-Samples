using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Diagnostics;
using System.Collections;	
	//Originally adopted from http://support.microsoft.com/kb/326176.
	//Translated and expanded into C# by Corey Vaden on 9/26/2007, 10/11/2007.

namespace DataSetHelper
{
	public class clsDSHcs
	{
		object[] _LastValues; // stores last values... used to determine distinct values
		DataTable _sourcetable; //stores the result table
		long _recordcount; //stores the number of distinct records
		decimal _elapsedtime; //stores the elapsed time of the request
		string[] _fields; //stores the columns to be returned

	#region ...ctor
		public clsDSHcs()
		{
			_recordcount = 0;
			_elapsedtime = 0;
			_sourcetable = null;
			_fields = null;
			_LastValues = null;
		}

		public clsDSHcs(DataTable dt)
		{
			_sourcetable = dt;
			_recordcount = 0;
			_elapsedtime = 0;
			_fields = null;
			_LastValues = null;
		}

		public clsDSHcs(DataTable dt, string[] fields)
		{
			_sourcetable = dt;
			_recordcount = 0;
			_elapsedtime = 0;
			_fields = fields;
			TrimFields(ref _fields);
			_LastValues = new object[_fields.Length];
		}

		public clsDSHcs(DataTable dt, string fields)
		{
			_sourcetable = dt;
			_recordcount = 0;
			_elapsedtime = 0;
			_fields = fields.Split(',');
			TrimFields(ref _fields);
			_LastValues = new object[_fields.Length];
		}

		public void Dispose()
		{
			_sourcetable = null;
			_recordcount = 0;
			_elapsedtime = 0;
			_fields = null;
			_LastValues = null;
		} 
	#endregion

	#region Properties
		public DataTable Sourcetable
		{
			get { return _sourcetable; }
			set { _sourcetable = value; }
		}

		public long RecordCount
		{
			get { return _recordcount; }
		}

		public decimal ElapsedTime
		{
			get { return _elapsedtime; }
		}

		public string[] Fields
		{
			get { return _fields; }
			set { _fields = value; }
		}
	#endregion

	#region Private Methods
		private DataTable RowsToTable(DataRow[] drs) //used to reassemble the table after selecting (drs())
		{
			DataTable dt = new DataTable();
			bool HasColumns = false;
			foreach (DataRow dr in drs)
			{
				if (!HasColumns)
				{
					if (_fields==null) _fields = GetFields(dr);
					foreach (string field in _fields)
					{
						dt.Columns.Add(field, dr.Table.Columns[field].DataType);
					}
					HasColumns = true;
				}
				dt.ImportRow(dr);
			}
			return dt;
		}
		
		private void TrimFields(ref string[] fields)
		{
			for (int a = 0;a < fields.Length; a++)
			{
				fields[a] = fields[a].Trim();
			}
		}

		private string[] GetFields(DataRow dr) //produces a comma delineated string of column names
		{
			int a=0;
			_fields = new string[dr.Table.Columns.Count];
			foreach (DataColumn col in dr.Table.Columns)
			{
				_fields[a] = col.ColumnName;
				a += 1;
			}
			return _fields;
		}

		private bool Exists(DataRow dr) // compares each column to field array
		{
			object oValue;
			int iIndex=0;
			bool bExists = true;
			if ((_LastValues==null)||(_LastValues.Length==0))
			{
				_LastValues = new object[_fields.Length];
				bExists = false;
			}
			foreach (string field in _fields)
			{
				oValue = dr[field];
				if (bExists) {
					if (oValue.GetType()==typeof(string)) {
						if (_LastValues[iIndex]==DBNull.Value||(!oValue.Equals(_LastValues[iIndex]))) bExists = false;
					} else {
						if (!oValue.Equals(_LastValues[iIndex])) bExists = false;
					}
				}
				_LastValues[iIndex] = oValue;
				iIndex += 1;
			}
			return bExists;
		}
	#endregion
		
	#region Public Methods
		//Internal Objects
		public DataTable SelectDistinct(string Filter, string Sort)
		{
			return SelectDistinct(_sourcetable, _fields, Filter, Sort);
		}

		public DataTable SelectDistinct(string[] Fields, string Filter, string Sort)
		{
			return SelectDistinct(_sourcetable, Fields, Filter, Sort);
		}

		public DataTable SelectDistinct(string[] Fields, string Sort)
		{
			return SelectDistinct(_sourcetable, Fields, "", Sort);
		}

		public DataTable SelectDistinct(string[] Fields)
		{
			return SelectDistinct(_sourcetable, Fields, "", "");
		}

		//Passed Objects and String
		public DataTable SelectDistinct(DataTable SourceTable, string Fields)
		{
			_fields = Fields.Split(",".ToCharArray());
			return SelectDistinct(SourceTable, _fields, "", "");
		}

		public DataTable SelectDistinct(DataTable SourceTable, string Fields, string Sort)
		{
			_fields = Fields.Split(",".ToCharArray());
			return SelectDistinct(SourceTable, _fields, "", Sort);
		}

		public DataTable SelectDistinct(DataTable SourceTable, string Fields, string Filter, string Sort)
		{
			_fields = Fields.Split(",".ToCharArray());
			return SelectDistinct(SourceTable, _fields, Filter, Sort);
		}

		//Passed Objects and Array
		public DataTable SelectDistinct(DataTable SourceTable, string[] Fields, string Sort)
		{
			return SelectDistinct(SourceTable, Fields, "", Sort);
		}

		public DataTable SelectDistinct(DataTable SourceTable, string[] Fields)
		{
			return SelectDistinct(SourceTable, Fields, "", "");
		}

		public DataTable SelectDistinct(DataTable SourceTable, string[] Fields, string Filter, string Sort) //master
		{
			long t = DateTime.Now.Ticks;
			DataTable dt = new DataTable();
			_fields = Fields;
			TrimFields(ref _fields);
			//sorting the table based on the desired columns
			try
			{
				//applying conditions/filter
				SourceTable = RowsToTable(SourceTable.Select(Filter));
			}
			catch (Exception ex)
			{
				Debug.WriteLine("SelectDistinct(src,fields[],filter,sort), " + ex.Message + "," + Filter);
				return null;
			}
			if (SourceTable.Columns.Count == 0 && SourceTable.Rows.Count == 0) return null;
			//select distinct happens here
			foreach (string field in _fields)
			{
				if (SourceTable.Columns[field.Trim()] == null)
				{
					dt.Columns.Add(field.Trim(), SourceTable.Columns[field.Trim()].DataType);
				}
			}
			foreach (DataRow dr in SourceTable.Rows)
			{
				if (!Exists(dr)) dt.ImportRow(dr);
			}
			try
			{
				//doing the final sort
				dt = RowsToTable(dt.Select("", Sort));
			}
			catch (Exception ex)
			{
				Debug.WriteLine("SelectDistinct(src,fields[],filter,sort), " + ex.Message);
			}
			_elapsedtime = Math.Round(Convert.ToDecimal(DateTime.Now.Ticks - t) / Convert.ToDecimal(10000000), 2);
			_recordcount = dt.Rows.Count;
			_sourcetable = dt;
			return _sourcetable;
		}

	#endregion
	}
}