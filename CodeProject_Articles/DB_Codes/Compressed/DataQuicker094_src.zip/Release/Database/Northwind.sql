USE Northwind

ALTER TABLE Suppliers ADD Email nvarchar(63) null
ALTER TABLE Suppliers ADD Range int null
ALTER TABLE Categories ADD IsValid bit

CREATE TABLE [dbo].[Replies] (
	[ReplyID] [char] (15) NOT NULL ,
	[MessageRefID] [char] (32) NOT NULL ,
	[Content] [nvarchar] (2047) NOT NULL ,
	[Author] [nvarchar] (63) NOT NULL ,
	[CreateDate] [datetime] NOT NULL 
) ON [PRIMARY]

CREATE TABLE [dbo].[Messages] (
	[MessageID] [char] (32) NOT NULL ,
	[Subject] [nvarchar] (63) NOT NULL ,
	[Content] [nvarchar] (2047) NOT NULL ,
	[Author] [nvarchar] (63) NOT NULL ,
	[CreateDate] [datetime] NOT NULL 
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Replies] WITH NOCHECK ADD 
	CONSTRAINT [PK_Replies] PRIMARY KEY  CLUSTERED 
	(
		[ReplyID]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[Messages] WITH NOCHECK ADD 
	CONSTRAINT [PK_Messages] PRIMARY KEY  CLUSTERED 
	(
		[MessageID]
	)  ON [PRIMARY] 
GO

