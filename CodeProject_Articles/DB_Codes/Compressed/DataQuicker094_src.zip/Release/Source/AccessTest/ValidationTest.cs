//// Product Name: DataQuicker (O/R Mapping)
//// Licensor: Eunge
//// Email: eudev.net@yeah.net
//// Blog: http://lovinger2000.cnblogs.com
//// 
//// Licensed under the Apache License, Version 2.0 (the "License");
//// you may not use this file except in compliance with the License.
//// You may obtain a copy of the License at
//// 
////     http://www.apache.org/licenses/LICENSE-2.0
//// 
//// Unless required by applicable law or agreed to in writing, software
//// distributed under the License is distributed on an "AS IS" BASIS,
//// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//// See the License for the specific language governing permissions and
//// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;


namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// 
	/// </summary>
	[TestFixture]
	public class Validation
	{
		[Test]
		public void RegularExpression()
		{
			//Regular expression is only allowed to set on FString property.
			Asset asset = new Asset();
			try
			{
				asset.Email += "ada1121";
				Assert.Fail("The Email Addess validation is invalid.");
			}
			catch(DQException)
			{
			}
		}

		[Test]
		public void ValueRange()
		{
			//As this example, we can set ValidateAttribute for any data type properties, including FDateTime, FDecimal, FDouble and so on.
			Asset asset = new Asset();
			try
			{
				asset.Amount += -1;
				Assert.Fail("The value range validation is invalid.");
			}
			catch(DQException)
			{
			}
		}

		[Test]
		public void MaxLength()
		{
			Asset asset = new Asset();
			try
			{
				asset.AssetName += "Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! Too long! ";
				Assert.Fail("The max length validation is invalid.");
			}
			catch(DQException)
			{
			}
		}

		[Test]
		public void ReuseDisposedObject()
		{
			Asset asset = new Asset();
			asset.Dispose();
			try
			{
				asset.AssetName += "DataQuicker";
				Assert.Fail("Disposed object cannot be reused");
			}
			catch(DQException)
			{
			}
		}

		[Test]
		public void SqlAttack()
		{
			//Simulate sql injection attack
			Asset asset = new Asset();
			string strAttackValue = "L\"iu's _^Jian%$#\\n\n";
			asset.AssetName += strAttackValue;
			asset.Owner += "Eunge";
			asset.Amount += 102;
			asset.Email += "eudev.net@yeah.net";
			
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(asset);
				string strAssetID = asset.AssetID;

				asset.Reset();

				asset.AssetID += strAssetID;
				provider.Retrieve(asset);

				Assert.AreEqual(strAttackValue, asset.AssetName.Value);
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void NullableColumnTest()
		{
			// In table Asset, column AssetName, Owner and Amount are necessary, cannot be null when creating.
			// So, the following source code will be thrown exception
			Asset asset = new Asset();
			asset.Owner += "Eunge";

			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(asset);
				Assert.Fail("The necessary columns cannot be null.");
			}
			catch(DQException)
			{
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void InvalidUpdate()
		{
			//Before update and delete, we have to ensure the entity has existed.
			Asset asset = new Asset();
			asset.AssetName += "DataQuicker";
			asset.Owner += "Eunge";
			asset.Amount += 1202;
			IProvider provider = Providers.GetProvider();
			try
			{
				provider.Update(asset);
				Assert.Fail("The update replys on exist entity.");
			}
			catch(DQException exp)
			{
				Assert.AreEqual("10025", exp.Code);
			}
		}
	}
}
