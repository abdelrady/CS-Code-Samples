// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// Summary description for FImageTest.
	/// </summary>
	[TestFixture]
	public class FImageTest
	{
		[Test]
		public void Write()
		{
			// Read array of bytes from files
			string strFileName = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "\\" + "AccessTest.dll";
			FileStream fs = new FileStream(strFileName, FileMode.Open);
			int fsLength = (int) fs.Length;
			byte[] content = new byte[fs.Length];
			fs.Read(content, 0, fsLength);
			fs.Close();

			EmployeeInfo employee = new EmployeeInfo();
			employee.FirstName += "Liu";
			employee.LastName += "Eunge";
			employee.Photo += content;

			// I don't know why we cannot return binary data from database in the following commented transaction.
			// If someone can solve the problems for us, thanks a lot.
			IProvider provider = Providers.GetProvider();
//			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(employee);
				int employeeId = employee.EmployeeID;

				employee = new EmployeeInfo(employeeId);
				Assert.IsTrue(employee.Photo.Value.Length==fsLength);

				provider.Delete(employee);
			}
			finally
			{
//				transaction.Rollback();
			}
		}
	}
}
