// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// Test database operations on entity Customers, insert, update, load, query and delete.
	/// </summary>
	[TestFixture]
	public class CustomersTest
	{
		[Test]
		public void Create()
		{
			Customers customer = new Customers();
			customer.CustomerID += "Lucy";
			customer.CompanyName += "Newegg";
			customer.ContactTitle += "Ms.";
			customer.PostalCode += "210011";
			customer.Phone += "13333333333";
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(customer);
				Assert.IsTrue(customer.Exist);
				Assert.IsFalse(customer.CustomerID.IsNull);
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void Retrieve()
		{
			Customers customer = new Customers("ALFKI");
			Assert.AreEqual("Berlin", customer.City.Value);
		}

		[Test]
		public void Update()
		{
			Customers customer = new Customers("ALFKI");
			customer.CompanyName += "Microsoft Company";
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Update(customer);
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void Delete()
		{
			Customers customer = new Customers();
			customer.CustomerID += "Lucy";
			customer.CompanyName += "Newegg";
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(customer);
				provider.Delete(customer);
			}
			finally
			{
				transaction.Rollback();
			}
		}
	}
}
