//// Product Name: DataQuicker (O/R Mapping)
//// Licensor: Eunge
//// Email: eudev.net@yeah.net
//// Blog: http://lovinger2000.cnblogs.com
//// 
//// Licensed under the Apache License, Version 2.0 (the "License");
//// you may not use this file except in compliance with the License.
//// You may obtain a copy of the License at
//// 
////     http://www.apache.org/licenses/LICENSE-2.0
//// 
//// Unless required by applicable law or agreed to in writing, software
//// distributed under the License is distributed on an "AS IS" BASIS,
//// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//// See the License for the specific language governing permissions and
//// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// Test database operations on entity Orders, insert, update, load, query and delete.
	/// </summary>
	[TestFixture]
	public class OrdersTest
	{
		[Test]
		public void Create()
		{
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			int lastId = 0;
			try
			{
				for(int i=0; i<10; i++)
				{
					Orders order = new Orders();
					order.EmployeeID += 2;
					order.CustomerID += "Eunge";
					order.OrderDate += DateTime.Now;
					order.RequiredDate += DateTime.Now.AddDays(-3);
					order.Freight += 24.88M;
					provider.Create(order);
					Assert.IsFalse(order.OrderID.IsNull);
					Assert.IsTrue(order.OrderID.Value>lastId);
					lastId = order.OrderID.Value;
				}
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void Retrieve()
		{
			Orders order = new Orders(1);
			Assert.IsTrue(order.Exist);
			order.Reset();

			order.OrderID += 1;
			order.AliasName = "myOrder";
			order.Freight.AliasName = "FreightCost";

			IProvider provider = Providers.GetProvider();
			provider.Retrieve(order);
			Assert.IsTrue(order.Exist);
			Assert.IsNotNull((order.Freight as FieldMapping).Value);
		}

		[Test]
		public void Update()
		{
			Orders order = new Orders(1);
			order.EmployeeID += 5;
			order.Freight += 24.88M;
			order.CustomerID += "HANAR";
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Update(order);
			}
			finally
			{
				transaction.Rollback();
			}
		}

		[Test]
		public void Query()
		{
			Orders order = new Orders();
			Employees employee = new Employees();

			Query query = new Query(order);
			query.Associations.Add(new FieldMapping[]{order.EmployeeID}, new FieldMapping[]{employee.EmployeeID});
			//RequiredDate be more than 1996-8-1
			query.Criteria.Add(order.RequiredDate, SqlOperator.MoreThan, new DateTime(1996, 8, 1));
			//ShipCity is London or Sao Paulo
			query.Criteria.Add(order.ShipCity, SqlOperator.In, "London", "Sao Paulo");

			//Combine the sql: (TitleOfCourtesy='Mr.' or TitleOfCourtesy='Ms.')
			CriteriaCollection collection = new CriteriaCollection();
			collection.Add(employee.TitleOfCourtesy, SqlOperator.Equal, "Mr.");
			collection.Add(SqlConnector.Or, employee.TitleOfCourtesy, SqlOperator.Equal, "Ms.");

			query.Criteria.Add(collection);

			IProvider provider = Providers.GetProvider();
			DataTable dtOrders = provider.Query(query);
			Assert.AreEqual(43, dtOrders.Rows.Count);
		}

		[Test]
		public void Delete()
		{
			Orders order = new Orders();
			order.EmployeeID += 2;
			order.CustomerID += "ALFKI";
			order.OrderDate += DateTime.Now;
			order.RequiredDate += DateTime.Now.AddDays(-3);
			order.Freight += 24.88M;
			IProvider provider = Providers.GetProvider();
			ITransaction transaction = provider.BeginTrans();
			try
			{
				provider.Create(order);
				Assert.IsTrue(order.OrderID>0);
				Assert.IsTrue(order.Exist);
				provider.Delete(order);
			}
			finally
			{
				transaction.Rollback();
			}
		}
	}
}
