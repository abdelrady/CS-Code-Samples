// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-8

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Jet
{
	[Serializable, PhysicalName("Replies"), Provider("NUnitTest")]
	public class Replies: TableMapping
	{
		public Replies(){}

		public Replies(Int32 replyID): base(replyID){}

		#region Properties
		private FString mAuthor = new FString();
		[PhysicalName("Author")]
		public FString Author
		{
			get
			{
				return this.mAuthor;
			}
			set
			{
				this.mAuthor.Replace(value);
			}
		}

		private FString mContent = new FString();
		[PhysicalName("Content")]
		public FString Content
		{
			get
			{
				return this.mContent;
			}
			set
			{
				this.mContent.Replace(value);
			}
		}

		private FDateTime mCreateDate = new FDateTime();
		[PhysicalName("CreateDate")]
		public FDateTime CreateDate
		{
			get
			{
				return this.mCreateDate;
			}
			set
			{
				this.mCreateDate.Replace(value);
			}
		}

		private FInt mReplyID = new FInt();
		[PhysicalName("ReplyID"), PrimaryKey(PrimaryKeyType.DQIncrease)]
		public FInt ReplyID
		{
			get
			{
				return this.mReplyID;
			}
			set
			{
				this.mReplyID.Replace(value);
			}
		}

		#endregion
	}
}