// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-6

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Jet
{
	[Serializable, PhysicalName("Employees"), Provider("NUnitTest")]
	public class EmployeeInfo: TableMapping
	{
		public EmployeeInfo(){}

		public EmployeeInfo(Int32 employeeID): base(employeeID){}

		#region Properties
		private FInt mEmployeeID = new FInt();
		[PhysicalName("EmployeeID"), PrimaryKey(PrimaryKeyType.None)]
		public FInt EmployeeID
		{
			get
			{
				return this.mEmployeeID;
			}
			set
			{
				this.mEmployeeID.Replace(value);
			}
		}

		private FString mLastName = new FString();
		[PhysicalName("LastName")]
		public FString LastName
		{
			get
			{
				return this.mLastName;
			}
			set
			{
				this.mLastName.Replace(value);
			}
		}

		private FString mFirstName = new FString();
		[PhysicalName("FirstName")]
		public FString FirstName
		{
			get
			{
				return this.mFirstName;
			}
			set
			{
				this.mFirstName.Replace(value);
			}
		}

		private FString mTitle = new FString();
		[PhysicalName("Title")]
		public FString Title
		{
			get
			{
				return this.mTitle;
			}
			set
			{
				this.mTitle.Replace(value);
			}
		}

		private FString mTitleOfCourtesy = new FString();
		[PhysicalName("TitleOfCourtesy")]
		public FString TitleOfCourtesy
		{
			get
			{
				return this.mTitleOfCourtesy;
			}
			set
			{
				this.mTitleOfCourtesy.Replace(value);
			}
		}

		private FDateTime mBirthDate = new FDateTime();
		[PhysicalName("BirthDate")]
		public FDateTime BirthDate
		{
			get
			{
				return this.mBirthDate;
			}
			set
			{
				this.mBirthDate.Replace(value);
			}
		}

		private FDateTime mHireDate = new FDateTime();
		[PhysicalName("HireDate")]
		public FDateTime HireDate
		{
			get
			{
				return this.mHireDate;
			}
			set
			{
				this.mHireDate.Replace(value);
			}
		}

		private FString mAddress = new FString();
		[PhysicalName("Address")]
		public FString Address
		{
			get
			{
				return this.mAddress;
			}
			set
			{
				this.mAddress.Replace(value);
			}
		}

		private FString mCity = new FString();
		[PhysicalName("City")]
		public FString City
		{
			get
			{
				return this.mCity;
			}
			set
			{
				this.mCity.Replace(value);
			}
		}

		private FString mRegion = new FString();
		[PhysicalName("Region")]
		public FString Region
		{
			get
			{
				return this.mRegion;
			}
			set
			{
				this.mRegion.Replace(value);
			}
		}

		private FString mPostalCode = new FString();
		[PhysicalName("PostalCode")]
		public FString PostalCode
		{
			get
			{
				return this.mPostalCode;
			}
			set
			{
				this.mPostalCode.Replace(value);
			}
		}

		private FString mCountry = new FString();
		[PhysicalName("Country")]
		public FString Country
		{
			get
			{
				return this.mCountry;
			}
			set
			{
				this.mCountry.Replace(value);
			}
		}

		private FString mHomePhone = new FString();
		[PhysicalName("HomePhone")]
		public FString HomePhone
		{
			get
			{
				return this.mHomePhone;
			}
			set
			{
				this.mHomePhone.Replace(value);
			}
		}

		private FString mExtension = new FString();
		[PhysicalName("Extension")]
		public FString Extension
		{
			get
			{
				return this.mExtension;
			}
			set
			{
				this.mExtension.Replace(value);
			}
		}

		private FString mNotes = new FString();
		[PhysicalName("Notes")]
		public FString Notes
		{
			get
			{
				return this.mNotes;
			}
			set
			{
				this.mNotes.Replace(value);
			}
		}

		private FInt mReportsTo = new FInt();
		[PhysicalName("ReportsTo")]
		public FInt ReportsTo
		{
			get
			{
				return this.mReportsTo;
			}
			set
			{
				this.mReportsTo.Replace(value);
			}
		}

		private FImage mPhoto = new FImage();
		[PhysicalName("Photo")]
		public FImage Photo
		{
			get
			{
				return this.mPhoto;
			}
			set
			{
				this.mPhoto.Replace(value);
			}
		}

		private FString mPhotoPath = new FString();
		[PhysicalName("PhotoPath")]
		public FString PhotoPath
		{
			get
			{
				return this.mPhotoPath;
			}
			set
			{
				this.mPhotoPath.Replace(value);
			}
		}

		#endregion
	}
}
