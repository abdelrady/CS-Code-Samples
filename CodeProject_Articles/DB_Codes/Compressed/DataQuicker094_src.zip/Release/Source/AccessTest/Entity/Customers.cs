// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-5

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Jet
{
	[Serializable, PhysicalName("Customers"), Provider("NUnitTest")]
	public class Customers: TableMapping
	{
		public Customers(){}

		public Customers(String customerID): base(customerID){}

		#region Properties
		private FString mCustomerID = new FString();
		[PhysicalName("CustomerID"), PrimaryKey(PrimaryKeyType.None)]
		public FString CustomerID
		{
			get
			{
				return this.mCustomerID;
			}
			set
			{
				this.mCustomerID.Replace(value);
			}
		}

		private FString mCompanyName = new FString();
		[PhysicalName("CompanyName")]
		public FString CompanyName
		{
			get
			{
				return this.mCompanyName;
			}
			set
			{
				this.mCompanyName.Replace(value);
			}
		}

		private FString mContactName = new FString();
		[PhysicalName("ContactName")]
		public FString ContactName
		{
			get
			{
				return this.mContactName;
			}
			set
			{
				this.mContactName.Replace(value);
			}
		}

		private FString mContactTitle = new FString();
		[PhysicalName("ContactTitle")]
		public FString ContactTitle
		{
			get
			{
				return this.mContactTitle;
			}
			set
			{
				this.mContactTitle.Replace(value);
			}
		}

		private FString mAddress = new FString();
		[PhysicalName("Address")]
		public FString Address
		{
			get
			{
				return this.mAddress;
			}
			set
			{
				this.mAddress.Replace(value);
			}
		}

		private FString mCity = new FString();
		[PhysicalName("City")]
		public FString City
		{
			get
			{
				return this.mCity;
			}
			set
			{
				this.mCity.Replace(value);
			}
		}

		private FString mRegion = new FString();
		[PhysicalName("Region")]
		public FString Region
		{
			get
			{
				return this.mRegion;
			}
			set
			{
				this.mRegion.Replace(value);
			}
		}

		private FString mPostalCode = new FString();
		[PhysicalName("PostalCode")]
		public FString PostalCode
		{
			get
			{
				return this.mPostalCode;
			}
			set
			{
				this.mPostalCode.Replace(value);
			}
		}

		private FString mCountry = new FString();
		[PhysicalName("Country")]
		public FString Country
		{
			get
			{
				return this.mCountry;
			}
			set
			{
				this.mCountry.Replace(value);
			}
		}

		private FString mPhone = new FString();
		[PhysicalName("Phone")]
		public FString Phone
		{
			get
			{
				return this.mPhone;
			}
			set
			{
				this.mPhone.Replace(value);
			}
		}

		private FString mFax = new FString();
		[PhysicalName("Fax")]
		public FString Fax
		{
			get
			{
				return this.mFax;
			}
			set
			{
				this.mFax.Replace(value);
			}
		}

		#endregion
	}
}
