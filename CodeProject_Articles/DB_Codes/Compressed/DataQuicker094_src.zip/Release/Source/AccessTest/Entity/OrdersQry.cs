// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-7

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Jet
{
	[Serializable, PhysicalName("Orders Qry"), Provider("NUnitTest")]
	public class OrdersQry: ViewMapping
	{
		public OrdersQry(){}

		#region Properties
		private FString mAddress = new FString();
		[PhysicalName("Address")]
		public FString Address
		{
			get
			{
				return this.mAddress;
			}
			set
			{
				this.mAddress.Replace(value);
			}
		}

		private FString mCity = new FString();
		[PhysicalName("City")]
		public FString City
		{
			get
			{
				return this.mCity;
			}
			set
			{
				this.mCity.Replace(value);
			}
		}

		private FString mCompanyName = new FString();
		[PhysicalName("CompanyName")]
		public FString CompanyName
		{
			get
			{
				return this.mCompanyName;
			}
			set
			{
				this.mCompanyName.Replace(value);
			}
		}

		private FString mCountry = new FString();
		[PhysicalName("Country")]
		public FString Country
		{
			get
			{
				return this.mCountry;
			}
			set
			{
				this.mCountry.Replace(value);
			}
		}

		private FString mCustomerID = new FString();
		[PhysicalName("CustomerID")]
		public FString CustomerID
		{
			get
			{
				return this.mCustomerID;
			}
			set
			{
				this.mCustomerID.Replace(value);
			}
		}

		private FInt mEmployeeID = new FInt();
		[PhysicalName("EmployeeID")]
		public FInt EmployeeID
		{
			get
			{
				return this.mEmployeeID;
			}
			set
			{
				this.mEmployeeID.Replace(value);
			}
		}

		private FDecimal mFreight = new FDecimal();
		[PhysicalName("Freight")]
		public FDecimal Freight
		{
			get
			{
				return this.mFreight;
			}
			set
			{
				this.mFreight.Replace(value);
			}
		}

		private FDateTime mOrderDate = new FDateTime();
		[PhysicalName("OrderDate")]
		public FDateTime OrderDate
		{
			get
			{
				return this.mOrderDate;
			}
			set
			{
				this.mOrderDate.Replace(value);
			}
		}

		private FInt mOrderID = new FInt();
		[PhysicalName("OrderID")]
		public FInt OrderID
		{
			get
			{
				return this.mOrderID;
			}
			set
			{
				this.mOrderID.Replace(value);
			}
		}

		private FString mPostalCode = new FString();
		[PhysicalName("PostalCode")]
		public FString PostalCode
		{
			get
			{
				return this.mPostalCode;
			}
			set
			{
				this.mPostalCode.Replace(value);
			}
		}

		private FString mRegion = new FString();
		[PhysicalName("Region")]
		public FString Region
		{
			get
			{
				return this.mRegion;
			}
			set
			{
				this.mRegion.Replace(value);
			}
		}

		private FDateTime mRequiredDate = new FDateTime();
		[PhysicalName("RequiredDate")]
		public FDateTime RequiredDate
		{
			get
			{
				return this.mRequiredDate;
			}
			set
			{
				this.mRequiredDate.Replace(value);
			}
		}

		private FString mShipAddress = new FString();
		[PhysicalName("ShipAddress")]
		public FString ShipAddress
		{
			get
			{
				return this.mShipAddress;
			}
			set
			{
				this.mShipAddress.Replace(value);
			}
		}

		private FString mShipCity = new FString();
		[PhysicalName("ShipCity")]
		public FString ShipCity
		{
			get
			{
				return this.mShipCity;
			}
			set
			{
				this.mShipCity.Replace(value);
			}
		}

		private FString mShipCountry = new FString();
		[PhysicalName("ShipCountry")]
		public FString ShipCountry
		{
			get
			{
				return this.mShipCountry;
			}
			set
			{
				this.mShipCountry.Replace(value);
			}
		}

		private FString mShipName = new FString();
		[PhysicalName("ShipName")]
		public FString ShipName
		{
			get
			{
				return this.mShipName;
			}
			set
			{
				this.mShipName.Replace(value);
			}
		}

		private FDateTime mShippedDate = new FDateTime();
		[PhysicalName("ShippedDate")]
		public FDateTime ShippedDate
		{
			get
			{
				return this.mShippedDate;
			}
			set
			{
				this.mShippedDate.Replace(value);
			}
		}

		private FString mShipPostalCode = new FString();
		[PhysicalName("ShipPostalCode")]
		public FString ShipPostalCode
		{
			get
			{
				return this.mShipPostalCode;
			}
			set
			{
				this.mShipPostalCode.Replace(value);
			}
		}

		private FString mShipRegion = new FString();
		[PhysicalName("ShipRegion")]
		public FString ShipRegion
		{
			get
			{
				return this.mShipRegion;
			}
			set
			{
				this.mShipRegion.Replace(value);
			}
		}

		private FInt mShipVia = new FInt();
		[PhysicalName("ShipVia")]
		public FInt ShipVia
		{
			get
			{
				return this.mShipVia;
			}
			set
			{
				this.mShipVia.Replace(value);
			}
		}

		#endregion
	}
}
