// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// Summary description for DQIncreaseTest.
	/// </summary>
	[TestFixture]
	public class DQIncreaseTest
	{
		[Test]
		public void InsertMessage()
		{
			IProvider provider = Providers.GetProvider();
			ITransaction trans = provider.BeginTrans();
			try
			{
				for(int i=0; i<20; i++)
				{
					Messages message = new Messages();
					message.Subject += "DataQuicker News";
					message.Author += "Eunge";
					message.Content += "The DataQuicker 0.9.2 Released!";
					message.CreateDate += DateTime.Now;
					provider.Create(message);

					Assert.IsTrue(message.Exist);
					Assert.IsNotNull(message.MessageID.Value);
					string strExpectID = (i+1).ToString();
					Assert.AreEqual(strExpectID, message.MessageID.Value);
				}
			}
			finally
			{
				trans.Rollback();
			}
		}

		[Test]
		public void InsertReply()
		{
			IProvider provider = Providers.GetProvider();
			ITransaction trans = provider.BeginTrans();
			try
			{
				for(int i=0; i<20; i++)
				{
					Replies reply = new Replies();
					reply.Author += "Eunge";
					reply.Content += "O/R Mapping Component";
					reply.CreateDate += DateTime.Now;
					provider.Create(reply);

					Assert.IsTrue(reply.Exist);
					Assert.IsNotNull(reply.ReplyID.Value);
					int intExpect = i + 1;
					Assert.AreEqual(intExpect, reply.ReplyID.Value);
				}
			}
			finally
			{
				trans.Rollback();
			}
		}

		[Test]
		public void RetrieveByUniqueKeys()
		{
			Employees employee = new Employees();
			employee.FirstName += "Davolio";
			employee.FirstName += "Nancy";
			IProvider provider = Providers.GetProvider();
			provider.Retrieve(employee);
			Assert.IsTrue(employee.Exist);
			Assert.IsNotNull(employee.EmployeeID.Value);
		}
	}
}
