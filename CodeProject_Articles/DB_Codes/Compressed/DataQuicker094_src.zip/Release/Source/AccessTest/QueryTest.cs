// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Jet
{
	/// <summary>
	/// Summary description for QueryTest.
	/// </summary>
	[TestFixture]
	public class QueryTest
	{
		[Test]
		public void Query1()
		{
			OrdersQry qry = new OrdersQry();
			Query query = new Query(qry);
			query.Criteria.Add(qry.Freight, SqlOperator.MoreThan, 100M);

			IProvider provider = Providers.GetProvider();
			DataTable dtbl = provider.Query(query);
			Assert.AreEqual(187, dtbl.Rows.Count);
		}

		[Test]
		public void Query2()
		{
			OrdersQry qry = new OrdersQry();
			Query query = new Query(qry);
			query.Criteria.Add(qry.Freight, SqlOperator.MoreThan, 100M);
			query.Criteria.Add(qry.ShipCountry, SqlOperator.Equal, "Mexico");
			query.OrderBy.Add(qry.CustomerID, false);

			IProvider provider = Providers.GetProvider();
			DataTable dtbl = provider.Query(query);
			Assert.AreEqual(1, dtbl.Rows.Count);
		}

		[Test]
		public void Query3()
		{
			Orders order = new Orders();
			Customers customer = new Customers();
			Query query = new Query(order);
			//Associate Orders with Customers
			query.Associations.Add(new FieldMapping[]{order.CustomerID}, AssociationType.Left, new FieldMapping[]{customer.CustomerID});
			query.Criteria.Add(order.Freight, SqlOperator.MoreThan, 10000);

			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}
	}
}
