// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Security.Cryptography;

namespace DataQuicker.Framework.Cryptography
{
	/// <summary>
	/// Cryptogram Arithmetic - Des.
	/// </summary>
	public class DES: ICryptography 
	{
		private readonly byte[] Key = new byte[]{42, 51, 13, 111, 233, 4, 218, 32};
		private readonly byte[] IV = new byte[]{55, 103, 221, 79, 36, 99, 99, 254};

		string ICryptography.Decrypt(string password)
		{
			System.Security.Cryptography.DESCryptoServiceProvider  des = new DESCryptoServiceProvider();
			byte[] content = Convert.FromBase64String(password);
			System.Security.Cryptography.ICryptoTransform transform = des.CreateDecryptor(this.Key, this.IV);

			MemoryStream  ms = new MemoryStream();
			System.Security.Cryptography.CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
			cs.Write(content, 0, content.Length);
			cs.FlushFinalBlock();
			cs.Close();

			string strResult = System.Text.Encoding.Unicode.GetString(ms.ToArray());
			ms.Close();

			return strResult;
		}

		string ICryptography.Encrypt(string password)
		{
			System.Security.Cryptography.DESCryptoServiceProvider  des = new DESCryptoServiceProvider();
			System.Security.Cryptography.ICryptoTransform transform = des.CreateEncryptor(this.Key, this.IV);

			byte[] content = System.Text.Encoding.Unicode.GetBytes(password);
			MemoryStream  ms = new MemoryStream();
			System.Security.Cryptography.CryptoStream cs = new CryptoStream(ms, transform, CryptoStreamMode.Write);
			cs.Write(content, 0, content.Length);
			cs.FlushFinalBlock();
			cs.Close();

			string strResult =  Convert.ToBase64String(ms.ToArray());
			ms.Close();

			return strResult;
		}
	}
}
