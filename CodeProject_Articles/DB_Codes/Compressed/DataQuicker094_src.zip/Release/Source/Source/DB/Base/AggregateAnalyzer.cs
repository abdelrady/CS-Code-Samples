// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Analyze for <seealso cref="Aggregate"/> object to parse sql.
	/// </summary>
	public class AggregateAnalyzer
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public AggregateAnalyzer(){}

		/// <summary>
		/// Parse <seealso cref="AggregateCollection"/> object to sql.
		/// </summary>
		/// <param name="collection"></param>
		/// <returns></returns>
		public virtual string Analyze(AggregateCollection collection)
		{
			StringBuilder sbSql = new StringBuilder();
			IEnumerator enumerator = collection.GetEnumerator();
			while(enumerator.MoveNext())
			{
				Aggregate aggregate = enumerator.Current as Aggregate;
				if(sbSql.Length != 0)
					sbSql.Append(", ");
				sbSql.Append(this.Analyze(aggregate));
				sbSql.Append(" AS ");

				string strAliasName;
				if(Kit.IsEmpty(aggregate.AliasName))
					strAliasName = Kit.BracketWord(System.Guid.NewGuid().ToString("N"));
				else
					strAliasName = Kit.BracketWord(aggregate.AliasName);

				sbSql.Append(strAliasName);
			}
			return sbSql.ToString();
		}


		/// <summary>
		/// Parse Aggregate object to sql without alias name.
		/// </summary>
		/// <param name="aggregate"></param>
		/// <returns></returns>
		protected internal virtual string Analyze(Aggregate aggregate)
		{
			Check.VerifyNotNull(aggregate);
			int operandsNum = this.GetOperandsNumber(aggregate.Type);
			string strExp = this.GetAggregateExpression(aggregate.Type);
			if(aggregate.Operands.Length != operandsNum)
				throw new DQException("10052");
			
			string[] strOperands = new string[operandsNum];
			for(int i=0; i<operandsNum; i++)
				strOperands[i] = this.CombineAggregate(aggregate.Operands[i]);

			return string.Format(strExp, strOperands);
		}


		/// <summary>
		/// Parse operand of aggregate object to sql.<br/>
		/// If arguement operand is Aggregate type, the method will call Analyze(Aggregate) to parse it.
		/// </summary>
		/// <param name="operand"></param>
		/// <returns></returns>
		protected internal virtual string CombineAggregate(object operand)
		{
			if(operand==null)
				return "*";

			string strFieldName = "";
			//if operand is Aggregate type, parse it circularly
			if(operand is Aggregate)
				strFieldName = this.Analyze(operand as Aggregate);
			//if operand is FieldMapping type, get its ColumnName
			else if(operand is FieldMapping)
				strFieldName = (operand as FieldMapping).ColumnName;
			else
			{
				//When operand is string or DateTime, quote the value with single quotation mark
				if(operand is string || operand is DateTime)
					strFieldName = "'" + operand.ToString() + "'";
				else
					strFieldName = operand.ToString();
			}
			return strFieldName;
		}


		/// <summary>
		/// Convert enum AggregateType to aggregate expression.
		/// </summary>
		/// <param name="aggregateType"></param>
		/// <returns></returns>
		protected internal virtual string GetAggregateExpression(AggregateType aggregateType)
		{
			string strExp = "";
			switch (aggregateType)
			{
				case AggregateType.Add:
					strExp = "{0}+{1}";
					break;
				case AggregateType.Average:
					strExp = "AVG({0})";
					break;
				case AggregateType.Count:
					strExp = "COUNT({0})";
					break;
				case AggregateType.Max:
					strExp = "MAX({0})";
					break;
				case AggregateType.Min:
					strExp = "MIN({0})";
					break;
				case AggregateType.Minus:
					strExp = "{0}-{1}";
					break;
				case AggregateType.Product:
					strExp = "{0}*{1}";
					break;
				case AggregateType.Sum:
					strExp = "SUM({0})";
					break;
				default:
					strExp = "";
					break;
			}
			return strExp;
		}


		/// <summary>
		/// Get the number of operands involved in the aggregate enumerative type.
		/// </summary>
		/// <param name="aggregateType"></param>
		/// <returns></returns>
		protected internal virtual int GetOperandsNumber(AggregateType aggregateType)
		{
			switch (aggregateType)
			{
				case AggregateType.Add:
					return 2;
				case AggregateType.Average:
					return 1;
				case AggregateType.Count:
					return 1;
				case AggregateType.Max:
					return 1;
				case AggregateType.Min:
					return 1;
				case AggregateType.Minus:
					return 2;
				case AggregateType.Product:
					return 2;
				case AggregateType.Sum:
					return 1;
				default:
					return -1;
			}
		}
	}
}