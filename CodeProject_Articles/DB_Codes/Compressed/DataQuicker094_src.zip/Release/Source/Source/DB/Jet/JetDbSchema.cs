// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Store database schema for Access
	/// </summary>
	public class JetDbSchema: DbSchema
	{
		/// <summary>
		/// Convert ole data type value to DQ type.
		/// </summary>
		/// <param name="dateType">OLE Data Type Value</param>
		/// <returns>DataQuicker Field Type</returns>
		public override Type DataTypeValue2DQType(int dateType)
		{
			Type type = null;
			switch (dateType)
			{
				//C# type: int
				case 2:
					goto case 3;
				case 3:
					type = typeof(DataQuicker.Framework.FInt);
					break;
				//C# type: bool
				case 11:
					type = typeof(DataQuicker.Framework.FBool);
					break;
				//C# type: DateTime
				case 7:
					type = typeof(DataQuicker.Framework.FDateTime);
					break;
				//C# type: double
				case 4:
					goto case 5;
				case 5:
					type = typeof(DataQuicker.Framework.FDouble);
					break;
				//C# type: decimal
				case 6:
					type = typeof(DataQuicker.Framework.FDecimal);
					break;
				//C# type: string
				case 129:
					goto case 130;
				case 130:
					type = typeof(DataQuicker.Framework.FString);
					break;
				//C# type: byte[]
				case 128:
					type = typeof(DataQuicker.Framework.FImage);
					break;

				default:
					type = typeof(object);
					break;
			}
			return type;
		}

		/// <summary>
		/// Get true the column is auto-increased by database.
		/// </summary>
		/// <param name="drow"></param>
		/// <returns></returns>
		protected internal override bool IsAutoIncrease(DataRow drow)
		{
			object columnFlags = drow["COLUMN_FLAGS"];
			object ordinalPosition = drow["ORDINAL_POSITION"];
			return (!Kit.IsEmpty(columnFlags) && columnFlags.ToString()=="90") && (!Kit.IsEmpty(ordinalPosition) && ordinalPosition.ToString()=="1");
		}

	}
}
