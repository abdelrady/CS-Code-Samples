// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Text;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// JetAnalyzer is used for Access. It derives from SqlAnalyzer and cope with the difference between T-SQL and JET-SQL
	/// This class if responsible for generating Sql string based on the design and setting of entities.
	/// However you use the persistence object, when it operates database, it should get the Sql string at first using this Analyzer.
	/// At last, it returns Sql string.
	/// </summary>
	[Serializable]
	public class JetAnalyzer: SqlAnalyzer
	{
		/// <summary>
		/// "@JET_PRIMARY_KEY_VARIABLE"
		/// </summary>
		internal const string PRIMARY_KEY_VARIABLE = "@JET_PRIMARY_KEY_VARIABLE";

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="provider"></param>
		public JetAnalyzer(Provider provider): base(provider)
		{
		}


		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for inserting.<br/>
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override IDbCommand Create(TableMapping entity)
		{
			IDbCommand command = this.Provider.Command;
			StringBuilder sbFields = new StringBuilder();
			StringBuilder sbFieldsValue = new StringBuilder();

			string strVariableName;
			IDataParameter parameter;
			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Value;
				//If the field is not auto-increased 
				if(field.IsAutoIncrease==false)	
				{
					//The field value is not null, and field is not primary key or it's manual type
					if(field.IsNull==false && (field.IsPrimaryKey==false || field.PrimaryKeyType==PrimaryKeyType.None))
					{
						if(sbFieldsValue.Length>0)
						{
							sbFields.Append(", ");
							sbFieldsValue.Append(", ");
						}
						sbFields.Append(Kit.BracketWord(field.PhysicalName));
						strVariableName = "@" + Kit.GetValidName(field.PhysicalName);
						sbFieldsValue.Append(strVariableName);

						parameter = this.Provider.CreateParameter(strVariableName, field.Value);
						command.Parameters.Add(parameter);
					}
					//The primary key is single when it need to be managed by DataQuicker or Database
					else if(field.IsPrimaryKey==true && field.PrimaryKeyType!=PrimaryKeyType.None)
					{
						if(sbFieldsValue.Length>0)
						{
							sbFields.Append(", ");
							sbFieldsValue.Append(", ");
						}

						sbFields.Append(Kit.BracketWord(field.PhysicalName));

						strVariableName = JetAnalyzer.PRIMARY_KEY_VARIABLE;
						sbFieldsValue.Append(strVariableName);

						parameter = this.Provider.CreateParameter(strVariableName);
						command.Parameters.Add(parameter);
					}
				}
			}

			string strFields = sbFields.ToString();
			string strFieldsValue = sbFieldsValue.ToString();
			string strSql = "INSERT INTO {0}({1}) VALUES({2})";
			strSql = string.Format(strSql, Kit.BracketWord(entity.PhysicalName), strFields, strFieldsValue);
			command.CommandText = strSql;

			return command;
		}
	}
}
