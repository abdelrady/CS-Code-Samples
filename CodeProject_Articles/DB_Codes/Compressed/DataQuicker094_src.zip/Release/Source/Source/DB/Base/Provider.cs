// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Text;

using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// <p>The base class for all SQL provider implementations. 
	/// Default implementations are provided for some of the methods.</p>
	/// <p>Inherit from this class when adding support for a new RDBMS.</p>
	/// </summary>
	public abstract class Provider: MarshalByRefObject, IProvider
	{
		private ProviderSection.Provider mProviderInfo;
		internal string mConnectionString;
		internal IDbConnection mConnection;
		internal Transaction mTransaction;
		internal IDbCommand mCommand;
		private bool mAutoCloseConnection = true;
		private Analyzer mAnalyzer;
		private StringBuilder mSql = new StringBuilder();

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="providerInfo">Provider name</param>
		protected Provider(ProviderSection.Provider providerInfo)
		{
			Check.VerifyNotNull(providerInfo);

			// Validate the provider name
			string strProviderTypeName = providerInfo.Type;
			if(Kit.IsEmpty(strProviderTypeName) || string.Compare(this.GetType().FullName, strProviderTypeName, true)!=0)
				throw new DQException("10037", providerInfo.Name, strProviderTypeName);

			this.mProviderInfo = providerInfo;
			this.mAnalyzer = Activator.CreateInstance(Type.GetType(providerInfo.AnalyzerType), new object[]{this}) as Analyzer;

			this.mConnectionString = this.ParseToConnectionString(providerInfo);
			// Initialize the database connection
			this.mConnection = this.Render(this.mConnectionString);
		}

		/// <summary>
		/// Destructor, pushing destroyed object into provider cache stack.
		/// </summary>
		~Provider()
		{
			ConfigurationManager.Instance.ProviderCache.Push(this.mProviderInfo.Name, this);
		}


		/// <summary>
		/// Get the sql has been executed in provider
		/// </summary>
		public string Sql
		{
			get
			{
				return this.mSql.ToString();
			}
		}


		/// <summary>
		/// Get information of provider
		/// </summary>
		public ProviderSection.Provider ProviderInfo
		{
			get
			{
				return this.mProviderInfo;
			}
		}


		/// <summary>
		/// Set/Get True when need auto-close connection after operating database.
		/// When the connection is open, change this value will raise an exception.
		/// </summary>
		public bool AutoCloseConnection
		{
			get
			{
				return this.mAutoCloseConnection;
			}
			set
			{
				ConnectionState state = this.ConnectionState;
				// When the state of connection is connecting, Executing, Fetching and Open, it's forbidden to change the property
				if(state == ConnectionState.Connecting || state == ConnectionState.Executing || state == ConnectionState.Fetching || state == ConnectionState.Open)
					throw new DQException("10014");

				this.mAutoCloseConnection = value;
			}
		}


		/// <summary>
		/// True when underlying connection and transaction object references exist. 
		/// When this property is true, clients has to call either Commit or Rollback to release the resources used.
		/// </summary>
		public bool IsTrans
		{
			get
			{ 
				return this.mTransaction!=null && this.mTransaction.Value!=null;
			}
		}


		/// <summary>
		/// Get <see cref="IDbConnection"/> entry
		/// </summary>
		protected internal IDbConnection Connection
		{
			get
			{
				if(this.mConnection == null)
					this.mConnection = this.Render(this.mConnectionString);

				return this.mConnection;
			}
		}


		/// <summary>
		/// Get a new <see cref="IDbCommand"/> entry
		/// </summary>
		protected internal IDbCommand Command
		{
			get
			{
				if(this.mCommand == null)
					this.mCommand = this.Connection.CreateCommand();
				else
				{
					this.mCommand.Transaction = null;
					this.mCommand.CommandText = "";
					this.mCommand.CommandType = CommandType.Text;
					this.mCommand.Parameters.Clear();
				}

				return this.mCommand;
			}
		}


		/// <summary>
		/// Set/Get <see cref="Transaction"/> entry
		/// </summary>
		protected internal Transaction Transaction
		{
			get
			{
				return this.mTransaction;
			}
			set
			{
				this.mTransaction = value;
			}
		}


		/// <summary>
		/// Get the state of connection
		/// </summary>
		protected internal ConnectionState ConnectionState
		{
			get
			{
				if(this.mConnection != null)
					return this.mConnection.State;
				else
					return ConnectionState.Closed;
			}
		}


		/// <summary>
		/// Log command
		/// </summary>
		/// <param name="command"></param>
		protected internal void LogCommand(IDbCommand command)
		{
			BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
			if(!section.TrackSQL) return;

			if(this.mSql.Length > 0)
				this.mSql.Append("\r\n\r\n");
			StringBuilder sbText = new StringBuilder();
			sbText.Append("Command Text: ");
			sbText.Append(command.CommandText);
			sbText.Append("\r\n");
			foreach(IDataParameter parameter in command.Parameters)
				sbText.AppendFormat("Parameter [{0}]: {1}\r\n", parameter.ParameterName, parameter.Value);

			this.mSql.Append(sbText.ToString());
		}


		/// <summary>
		/// Get the analyzer of entity
		/// </summary>
		protected internal Analyzer Analyzer
		{
			get
			{
				return this.mAnalyzer;
			}
		}


		#region Transaction Operation

		ITransaction IProvider.BeginTrans()
		{
			return this.BeginTrans();
		}

		/// <summary>
		/// Begin transaction and open provider connection
		/// </summary>
		public ITransaction BeginTrans()
		{
			return this.BeginTrans(IsolationLevel.ReadUncommitted);
		}


		ITransaction IProvider.BeginTrans(IsolationLevel il)
		{
			return this.BeginTrans(il);
		}
		/// <summary>
		/// Begin transaction and open provider connection
		/// </summary>
		/// <param name="il">Transaction Isolation Level</param>
		public ITransaction BeginTrans(IsolationLevel il)
		{
			if(!this.IsTrans)
			{
				this.Open();
				Transaction transaction = new Transaction(this.mConnection.BeginTransaction(il));
				this.mTransaction = transaction;
				this.mAutoCloseConnection = false;
				return transaction;
			}
			else
				throw new DQException("10024");
		}

		#endregion

		#region Database Connection
		/// <summary>
		/// Open provider connection. DataQuicker checks the state of connection automatically.
		/// </summary>
		protected internal void Open()
		{
			try
			{
				if(this.mConnection == null)	//if the connection object is null
				{
					this.mConnection = this.Render(this.mConnectionString);
				}
				else
				{
					try
					{
						ConnectionState state = this.mConnection.State;
						//The state of connection is opened, return immediately
						if(state == ConnectionState.Connecting || state == ConnectionState.Executing || state == ConnectionState.Fetching || state == ConnectionState.Open) return;
						if(state == ConnectionState.Broken) this.mConnection.Close();
					}
					catch(System.NullReferenceException)
					{
						this.mConnection = this.Render(this.mConnectionString);
					}
				}
				this.mConnection.Open();

				if(this.mCommand == null)
					this.mCommand = this.mConnection.CreateCommand();
			}
			catch(Exception exp)
			{
				string msg = "Cannot not open provider[{0}]";
				msg = string.Format(msg, this.mProviderInfo.Name);
				Log.Write(msg, exp);
				throw exp;
			}
		}


		/// <summary>
		/// Close database connection. DataQuicker checks the state of connection automatically.
		/// </summary>
		protected internal void Close()
		{
			if(this.IsTrans)
			{
				try
				{
					this.mTransaction.Commit();
				}
				catch(System.InvalidOperationException)
				{
				}
				this.mTransaction = null;
			}

			if(this.mConnection == null) return;

			if(this.mConnection.State != ConnectionState.Closed)
				this.mConnection.Close();
		}


		/// <summary>
		/// Render <see cref="IDbConnection"/> entry from derived class
		/// </summary>
		/// <param name="connectionString">Database connection string</param>
		/// <returns></returns>
		protected abstract IDbConnection Render(string connectionString);

		#endregion

		#region Database Operation 

		void IProvider.Update(TableMapping table)
		{
			this.Update(table);
		}

		/// <summary>
		/// Update an existing object by its primary keys. <br/>
		/// You should retrieve the entity object first, and ensure it exists.
		/// </summary>
		/// <param name="entity"><seealso cref="TableMapping"/> object</param>
		public virtual void Update(TableMapping entity)
		{
			Check.VerifyUpdateValid(entity);
			IDbCommand command = this.Analyzer.Update(entity);
			if (command == null) return;

			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				command.ExecuteNonQuery();
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}


		void IProvider.Create(TableMapping table)
		{
			this.Create(table);
		}

		/// <summary>
		/// <p>Insert an non-existing object.</p>
		/// <p>You should ensure that you have set the necessary fields and the object doesn't exist.</p>
		/// <p>After create, if successful, the property Exist will be true.</p>
		/// </summary>
		/// <param name="entity"></param>
		public virtual void Create(TableMapping entity)
		{
			Check.VerifyInsertValid(entity);

			IDbCommand command = this.Analyzer.Create(entity);
			if (command == null) return;

			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				
				//If the primary key is managed by DataQuicker/Database
				if(entity.PrimaryKeys.Count==1 && (entity.PrimaryKeys[0].IsAutoIncrease || entity.PrimaryKeys[0].PrimaryKeyType!=PrimaryKeyType.None))
				{
					object result = command.ExecuteScalar();
					if(result!=null && result!=DBNull.Value)
						entity.PrimaryKeys[0].Value = result;
				}
				else
					command.ExecuteNonQuery();

				entity.mExist = true;
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}


		void IProvider.Delete(TableMapping table)
		{
			this.Delete(table);
		}

		/// <summary>
		/// <p>Delete an existing object. </p>
		/// <p>There are two delete mode in DataQuicker based on your configuration in app.config. </p>
		/// <p>Logic delete: you should specialize the delete flag column name as int type. When delete, DQ will set the value of it to 0.</p>
		/// <p>Physical delete: DQ will remove an object from database permanently.</p>
		/// </summary>
		/// <param name="entity"></param>
		public virtual void Delete(TableMapping entity)
		{
			Check.VerifyDeleteValid(entity);
			IDbCommand command = this.Analyzer.Delete(entity);
			if(command == null) return;

			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				command.ExecuteNonQuery();
				entity.mExist = false;
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}


		DataTable IProvider.Query(Query query)
		{
			return this.Query(query);
		}

		/// <summary>
		/// <p>Query for datatable object</p>
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		public virtual DataTable Query(Query query)
		{
			Check.VerifyQueryValid(query);
			IDbCommand command = this.Analyzer.Query(query);
			if(command == null) return null;

			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				IDataReader reader = command.ExecuteReader();
				return Cast.Reader2Table(reader);
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}


		void IProvider.Retrieve(EntityMapping entity)
		{
			this.Retrieve(entity);
		}

		/// <summary>
		/// Retrieve the EntityMapping object.<br/>
		/// The retrieve based on values set on entity.<br/>
		/// If the value of primary key exists, the retrieve replys on it. Otherwise, it replys on whatever column has its value.
		/// </summary>
		/// <param name="entity"></param>
		public virtual void Retrieve(EntityMapping entity)
		{
			Check.VerifyRetrieve(entity);
			IDbCommand command = this.Analyzer.Retrieve(entity);
			if(command == null) return;

			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				IDataReader reader = command.ExecuteReader();
				DataTable dtbl = Cast.Reader2Table(reader);

				if(dtbl.Rows.Count>1)
					throw new DQException("10036");
				else if(dtbl.Rows.Count==0)
					entity.mExist = false;
				else
				{
					entity.mExist = true;
					for(int i=0; i<dtbl.Columns.Count; i++)
					{
						string strColumnName = dtbl.Columns[i].ColumnName;

						//Set the properties of entity circulately.
						IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
						while(enumerator.MoveNext())
						{
							FieldMapping field = enumerator.Value;
							string strFieldName = Kit.GetValidName(field.PhysicalName);
							if(string.Compare(strFieldName, strColumnName, true) == 0)
							{
								field.mValue = dtbl.Rows[0][i];
								break;
							}
						}
					}
				}
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}

		#endregion

		#region Database Command Parameters

		IDataParameter IProvider.CreateParameter()
		{
			return this.CreateParameter();
		}
		/// <summary>
		/// Create IDataParameter object (Parameter).
		/// </summary>
		/// <returns></returns>
		public IDataParameter CreateParameter()
		{
			IDataParameter param = null;
			if(this.mCommand!=null)
				param = this.mCommand.CreateParameter();
			return param;
		}


		IDataParameter IProvider.CreateParameter(string parameterName)
		{
			return this.CreateParameter(parameterName);
		}
		/// <summary>
		/// Create IDataParameter object (Parameter).
		/// </summary>
		/// <param name="parameterName"></param>
		/// <returns></returns>
		public IDataParameter CreateParameter(string parameterName)
		{
			Check.VerifyNotNull(parameterName);
			IDataParameter parameter = this.CreateParameter();
			parameter.ParameterName = parameterName;
			return parameter;
		}


		IDataParameter IProvider.CreateParameter(string parameterName, object value)
		{
			return this.CreateParameter(parameterName, value);
		}
		/// <summary>
		/// Create IDataParameter object (Parameter).
		/// </summary>
		/// <param name="parameterName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		public IDataParameter CreateParameter(string parameterName, object value)
		{
			Check.VerifyNotNull(parameterName);
			Check.VerifyNotNull(value);

			IDataParameter parameter = this.CreateParameter();
			parameter.ParameterName = parameterName;
			parameter.DbType = Cast.ToDbType(value.GetType());
			parameter.Value = value;
			return parameter;
		}

		#endregion

		#region Connection Parser
		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal abstract string ParseToConnectionString(ProviderSection.Provider providerInfo);
		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to ole connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal abstract string ParseToOleConnectionString(ProviderSection.Provider providerInfo);
		#endregion
	}
}