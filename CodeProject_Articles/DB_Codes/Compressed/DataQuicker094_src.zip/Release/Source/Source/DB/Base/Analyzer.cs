// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Text;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Sql Analyzer. Convert the setting of entity object to the relative structure query language.
	/// </summary>
	public abstract class Analyzer
	{
		private Provider mProvider;
		private QueryAnalyzer mQueryAnalyzer;

		/// <summary>
		/// Construct Analyzer.
		/// </summary>
		/// <param name="provider"></param>
		protected Analyzer(Provider provider)
		{
			this.mProvider = provider;
			AggregateAnalyzer aggregateAnalyzer = Activator.CreateInstance(Type.GetType(provider.ProviderInfo.AggregateAnalyzerType), null) as AggregateAnalyzer;
			this.mQueryAnalyzer = new QueryAnalyzer(this, aggregateAnalyzer);
		}


		/// <summary>
		/// Get the own provider object
		/// </summary>
		public Provider Provider
		{
			get
			{
				return this.mProvider;
			}
		}

		/// <summary>
		/// Get Query analyzer handler
		/// </summary>
		public QueryAnalyzer QueryAnalyzer
		{
			get
			{
				return this.mQueryAnalyzer;
			}
		}


		/// <summary>
		/// <p>Analyze the query object, and return IDbCommand object for querying.</p>
		/// </summary>
		/// <param name="query">Query object</param>
		/// <returns></returns>
		public abstract IDbCommand Query(Query query);

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for inserting.<br/>
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract IDbCommand Create(TableMapping entity);

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for updating.<br/>
		/// The update based on primary keys' value of TableMapping object. The precondition that we should ensure the primary key value isn't empty or null.
		/// And the update doesn't refer to the primary keys' value.<br/>
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract IDbCommand Update(TableMapping entity);

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for deleting.<br/>
		/// The delete based on primary keys' value of TableMapping object.
		/// The precondition that we should ensure the primary key value isn't empty or null.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract IDbCommand Delete(TableMapping entity);

		/// <summary>
		/// Analyze the EntityMapping object and return IDbCommand object for retrieving entity data.<br/>
		/// The retrieve based on values set on entity.<br/>
		/// If the value of primary key exists, the retrieve replys on it. Otherwise, it replys on whatever column has its value.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public abstract IDbCommand Retrieve(EntityMapping entity);
	}
}
