// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System.Data;

namespace DataQuicker.Framework
{
	/// <summary>
	/// The interface for operating database, such as CRUD (create, retrieve, update and delete), query and begin transaction.
	/// </summary>
	public interface IProvider
	{
		/// <summary>
		/// Query for <seealso cref="DataTable"/> object
		/// </summary>
		/// <param name="query"></param>
		DataTable Query(Query query);

		/// <summary>
		/// Update <seealso cref="TableMapping"/> object
		/// </summary>
		/// <param name="table"></param>
		void Update(TableMapping table);

		/// <summary>
		/// Create <seealso cref="TableMapping"/> object
		/// </summary>
		/// <param name="table"></param>
		void Create(TableMapping table);

		/// <summary>
		/// Retrieve <seealso cref="EntityMapping"/> object
		/// </summary>
		/// <param name="entity"></param>
		void Retrieve(EntityMapping entity);

		/// <summary>
		/// Delete <seealso cref="TableMapping"/> object
		/// </summary>
		/// <param name="table"></param>
		void Delete(TableMapping table);

		/// <summary>
		/// Begin transaction.
		/// </summary>
		/// <returns></returns>
		ITransaction BeginTrans();

		/// <summary>
		/// Begin transaction.
		/// </summary>
		/// <param name="il">Transaction level</param>
		/// <returns></returns>
		ITransaction BeginTrans(IsolationLevel il);

		/// <summary>
		/// Create <seealso cref="IDataParameter"/> entry
		/// </summary>
		/// <returns></returns>
		IDataParameter CreateParameter();

		/// <summary>
		/// Create <seealso cref="IDataParameter"/> entry
		/// </summary>
		/// <param name="parameterName"></param>
		/// <returns></returns>
		IDataParameter CreateParameter(string parameterName);

		/// <summary>
		/// Create <seealso cref="IDataParameter"/> entry
		/// </summary>
		/// <param name="parameterName"></param>
		/// <param name="value"></param>
		/// <returns></returns>
		IDataParameter CreateParameter(string parameterName, object value);

		/// <summary>
		/// Get the information of executed <seealso cref="IDbCommand"/> object.
		/// </summary>
		string Sql {get;}
	}
}
