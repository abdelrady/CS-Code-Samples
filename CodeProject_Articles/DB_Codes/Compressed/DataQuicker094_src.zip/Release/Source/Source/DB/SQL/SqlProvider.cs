// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// This class is an implementation of the <see cref="Provider"/> class for the Microsoft Sql Server RDBMS.
	/// </summary>
	public class SqlProvider: Provider 
	{
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="providerInfo"></param>
		public SqlProvider(ProviderSection.Provider providerInfo): base(providerInfo)
		{
		}


		/// <summary>
		/// Render SqlConnection <see cref="SqlConnection"/>
		/// </summary>
		/// <param name="connectionString">Database connection string</param>
		/// <returns></returns>
		protected override IDbConnection Render(string connectionString)
		{
			return new SqlConnection(connectionString);
		}

		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal override string ParseToConnectionString(ProviderSection.Provider providerInfo)
		{
			Check.VerifyNotNull(providerInfo);

			if(Kit.IsEmpty(this.mConnectionString))
			{
				string strDataSource = providerInfo.DataSource;
				if(Kit.IsEmpty(strDataSource))
					throw new DQException("10041", providerInfo.Name);
				string strConnection = "server={0}; UID={1}; pwd={2}; database={3};";
				this.mConnectionString = string.Format(strConnection, providerInfo.DataSource, providerInfo.UserID, providerInfo.Password, providerInfo.Category);
				return this.mConnectionString;
			}
			else
				return this.mConnectionString;
		}

		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to ole connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal override string ParseToOleConnectionString(ProviderSection.Provider providerInfo)
		{
			Check.VerifyNotNull(providerInfo);
			string strDataSource = providerInfo.DataSource;
			if(Kit.IsEmpty(strDataSource))
				throw new DQException("10041", providerInfo.Name);

			string strDbProvider = providerInfo.DbProvider;
			if(Kit.IsEmpty(strDbProvider))
				strDbProvider = "SQLOLEDB.1";

			string strConnection = "Data Source={0}; User ID={1}; Password={2}; Initial Catalog={3}; Provider={4};";
			return string.Format(strConnection, providerInfo.DataSource, providerInfo.UserID, providerInfo.Password, providerInfo.Category, strDbProvider);
		}
	}
}