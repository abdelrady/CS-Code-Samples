// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Xml;
using System.Data.SqlClient;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Accessional class library for executing complex sql sentence.
	/// </summary>
	/// <example>
	/// int result = DbHelper.ExecuteNonQuery(provider, CommandType.StoredProcedure, "PublishOrders");
	/// * The variable result represents the number of rows affected by the execution.
	/// </example>
    public sealed class DbHelper
    {
		private DbHelper(){}


        #region ExecuteNonQuery

		/// <summary>
		/// Execute a T-Sql command text (that returns no resultset and takes no parameters) against the database specified in DataQuicker provider
		/// </summary>
		/// <param name="provider">A valid DataQuicker provider</param>
		/// <param name="commandText">T-Sql command</param>
		/// <returns>An int representing the number of rows affected by the command</returns>
		/// <example>
		/// int result = ExecuteNonQuery(provider, "UPDATE TableName SET Status=0");
		/// </example>
		public static int ExecuteNonQuery(IProvider provider, string commandText)
		{
			// Pass through the call providing null for the set of IDbDataParameter
			return ExecuteNonQuery(provider, CommandType.Text, commandText, null);
		}

        /// <summary>
        /// Execute a command text (that returns no resultset and takes no parameters) against the database specified in DataQuicker provider
        /// </summary>
        /// <param name="provider">A valid DataQuicker provider for database connection</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <returns>An int representing the number of rows affected by the command</returns>
        /// <example>
        /// int result = ExecuteNonQuery(provider, CommandType.StoredProcedure, "PublishOrders");
        /// </example>
        public static int ExecuteNonQuery(IProvider provider, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of commandParameters
            return ExecuteNonQuery(provider, commandType, commandText, null);
        }

        /// <summary>
        /// Execute a command (that returns no resultset) against the database specified in DataQuicker provider using the provided parameters
        /// </summary>        
        /// <param name="provider">A valid provider for database connection</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <param name="commandParameters">An array of IDbDataParameter used to execute the command</param>
        /// <returns>An int representing the number of rows affected by the command</returns>
		/// <example>
		/// IDbDataParameter param = provider.CreateParameter();
		/// param.ParameterName = "@prodid";
		/// param.Size = 24;
		/// int result = ExecuteNonQuery(provider, CommandType.StoredProcedure, "PublishOrders", param);
		/// </example>
        public static int ExecuteNonQuery(IProvider provider, CommandType commandType, string commandText, params IDbDataParameter[] commandParameters)
        {
			Check.VerifyNotNull(provider);
			Provider objProvider = provider as Provider;
			try
			{
				objProvider.Open();

				IDbCommand command = objProvider.Command;
				command.CommandType = commandType;
				command.CommandText = commandText;
				if(commandParameters != null)
					foreach(IDbDataParameter commandParameter in commandParameters)
						command.Parameters.Add(commandParameter);

				if(objProvider.IsTrans)
					command.Transaction = objProvider.Transaction.Value;

				// Call the overload that execute operation
				int affected = command.ExecuteNonQuery();
				command.Parameters.Clear();

				return affected;
			}
			finally
			{
				if(objProvider.AutoCloseConnection == false)
					objProvider.Close();
			}
        }
        #endregion ExecuteNonQuery

        #region ExecuteDataTable

		/// <summary>
		/// Execute a T-Sql (that returns a resultset and takes no parameters) against the database specified in the provider
		/// </summary>
		/// <param name="provider">A valid DataQuicker provider</param>
		/// <param name="commandText">The T-Sql command</param>
		/// <returns>A dataset containing the resultset generated by the command</returns>
		/// <example>
		/// DataTable dt = ExecuteDataTable(provider, "SELECT * FROM TableName");
		/// </example>
		public static DataTable ExecuteDataTable(IProvider provider, string commandText)
		{
			// Pass through the call providing null for the set of IDataParameter
			return ExecuteDataTable(provider, CommandType.Text, commandText, (IDataParameter[])null);
		}

        /// <summary>
        /// Execute a command (that returns a resultset and takes no parameters) against the database specified in the provider
        /// </summary>
        /// <param name="provider">A valid DataQuicker provider</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <returns>A dataset containing the resultset generated by the command</returns>
        /// <example>
        /// DataTable dt = ExecuteDataTable(provider, CommandType.StoredProcedure, "GetOrders");
        /// </example>
        public static DataTable ExecuteDataTable(IProvider provider, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of IDataParameter
            return ExecuteDataTable(provider, commandType, commandText, (IDataParameter[])null);
        }


        /// <summary>
        /// Execute a command (that returns a resultset) against the database specified in the DataQuicker provider using the provided parameters.
        /// </summary>
        /// <param name="provider">A valid connection string for a SqlConnection</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <param name="commandParameters">An array of SqlParamters used to execute the command</param>
        /// <returns>A dataset containing the resultset generated by the command</returns>
        /// <example>
        /// IDataParameter param = provider.CreateParameter();
		/// param.ParameterName = "@prodid";
		/// param.Size = 24;
        /// ExecuteDataTable dt = ExecuteDataTable(provider, CommandType.StoredProcedure, "GetOrders", param);
        /// </example>
        public static DataTable ExecuteDataTable(IProvider provider, CommandType commandType, string commandText, params IDataParameter[] commandParameters)
        {
			Check.VerifyNotNull(provider);
			Provider objProvider = provider as Provider;

			try
			{
				objProvider.Open();
				IDbCommand command = objProvider.Command;
				command.CommandType = commandType;
				command.CommandText = commandText;
				if(commandParameters != null)
				{
					foreach(IDbDataParameter commandParameter in commandParameters)
					{
						command.Parameters.Add(commandParameter);
					}
				}

				if(objProvider.IsTrans)
					command.Transaction = objProvider.Transaction.Value;

				IDataReader reader = command.ExecuteReader();
				DataTable table = Cast.Reader2Table(reader);

				command.Parameters.Clear();

				// Call the overload that takes a connection in place of the connection string
				return table;
			}
			finally
			{
				if(objProvider.AutoCloseConnection)
					objProvider.Close();
			}
        }
        #endregion

        #region ExecuteScalar

		/// <summary>
		/// Execute a command (that returns a 1x1 resultset and takes no parameters) against the database specified in the DataQuicker provider
		/// </summary>
		/// <param name="provider">A valid DataQuicker provider</param>
		/// <param name="commandText">The T-Sql command</param>
		/// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
		/// <example>
		/// int orderCount = (int)ExecuteScalar(provider, "SELECT COUNT(*) FROM TableName");
		/// </example>
		public static object ExecuteScalar(IProvider provider, string commandText)
		{
			// Pass through the call providing null for the set of IDataParameter
			return ExecuteScalar(provider, CommandType.Text, commandText, (IDataParameter[])null);
		}
		
        /// <summary>
        /// Execute a command (that returns a 1x1 resultset and takes no parameters) against the database specified in the DataQuicker provider
        /// </summary>
        /// <param name="provider">A valid DataQuicker provider</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
        /// <example>
        /// int orderCount = (int)ExecuteScalar(provider, CommandType.StoredProcedure, "GetOrderCount");
        /// </example>
        public static object ExecuteScalar(IProvider provider, CommandType commandType, string commandText)
        {
            // Pass through the call providing null for the set of SqlParameters
            return ExecuteScalar(provider, commandType, commandText, (IDataParameter[])null);
        }

        /// <summary>
        /// Execute a command (that returns a 1x1 resultset) against the database specified in the DataQuicker provider using the provided parameters.
        /// </summary>
        /// <param name="provider">A valid DataQuicker provider</param>
        /// <param name="commandType">The CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">The stored procedure name or T-Sql command</param>
        /// <param name="commandParameters">An array of IDataParameter used to execute the command</param>
        /// <returns>An object containing the value in the 1x1 resultset generated by the command</returns>
        /// <example>
		/// IDataParameter param = provider.CreateParameter();
		/// param.ParameterName = "@prodid";
		/// param.Size = 24;
        /// int orderCount = (int)ExecuteScalar(provider, CommandType.StoredProcedure, "GetOrderCount", param);
        /// </example>
        public static object ExecuteScalar(IProvider provider, CommandType commandType, string commandText, params IDataParameter[] commandParameters)
        {
			Check.VerifyNotNull(provider);
			Provider objProvider = provider as Provider;

			try
			{
				objProvider.Open();
				IDbCommand command = objProvider.Command;
				command.CommandType = commandType;
				command.CommandText = commandText;
				if(commandParameters != null)
					foreach(IDbDataParameter commandParameter in commandParameters)
						command.Parameters.Add(commandParameter);

				if(objProvider.IsTrans==true)
					command.Transaction = objProvider.Transaction.Value;

				object retVal = command.ExecuteScalar();
				command.Parameters.Clear();
				return retVal;
			}
			finally
			{
				if(objProvider.AutoCloseConnection)
					objProvider.Close();
			}
        }
        #endregion ExecuteScalar	
    }
}
