// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// To analyze <seealso cref="Query"/> object and return IDbCommand entry.
	/// </summary>
	public class QueryAnalyzer
	{
		private Analyzer mAnalyzer;
		private AggregateAnalyzer mAggregateAnalyzer;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="analyzer"></param>
		/// <param name="aggregateAnalyzer"></param>
		public QueryAnalyzer(Analyzer analyzer, AggregateAnalyzer aggregateAnalyzer)
		{
			this.mAnalyzer = analyzer;
			this.mAggregateAnalyzer = aggregateAnalyzer;
		}


		/// <summary>
		/// Get <seealso cref="Analyzer"/> object composited in QueryAnalyzer.
		/// </summary>
		protected internal Analyzer Analyzer
		{
			get
			{
				return this.mAnalyzer;
			}
		}


		/// <summary>
		/// Get <seealso cref="AggregateAnalyzer"/> object composited in QueryAnalyzer.
		/// </summary>
		protected internal AggregateAnalyzer AggregateAnalyzer
		{
			get
			{
				return this.mAggregateAnalyzer;
			}
		}


		/// <summary>
		/// Analyze <seealso cref="Query"/> object to return IDbCommand object for querying.
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		public virtual IDbCommand Analyze(Query query)
		{
			Check.VerifyNotNull(query);
			IDbCommand command = this.Analyzer.Provider.Command;
			StringBuilder sbSql = new StringBuilder();
			sbSql.Append(this.Select(query));
			sbSql.Append(" ");

			string strAssociations = this.Associate(query.Associations);
			if(!Kit.IsEmpty(strAssociations))
			{
				sbSql.Append("FROM ");
				sbSql.Append(strAssociations);
				sbSql.Append(" ");
			}

			string strWhere = this.Where(query.Criteria, command);
			if(!Kit.IsEmpty(strWhere)) 
			{
				sbSql.Append("WHERE ");
				sbSql.Append(strWhere);
				sbSql.Append(" ");
			}

			string strOrderBy = this.OrderBy(query.OrderBy);
			if(!Kit.IsEmpty(strOrderBy))
			{
				sbSql.Append("ORDER BY ");
				sbSql.Append(strOrderBy);
				sbSql.Append(" ");
			}

			string strGroupBy = this.GroupBy(query.GroupBy);
			if(!Kit.IsEmpty(strGroupBy))
			{
				sbSql.Append("GROUP BY ");
				sbSql.Append(strGroupBy);
			}
			 
			command.CommandText = sbSql.ToString();
			return command;
		}


		/// <summary>
		/// Parse <seealso cref="Query"/> object to get select columns.
		/// The method analyzes the property Selects and Aggregates of Query object to get sql.
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		protected virtual string Select(Query query)
		{
			//When there is no select column in Query object and property None is set to true.
			if(query.Selects.Count==0 && query.Selects.None && query.Aggregates.Count==0)
				throw new DQException("10059");

			StringBuilder sbSql = new StringBuilder();
			sbSql.Append("SELECT ");
			
			//Append Distince/All
			string strDistinct = (query.Selects.Distinct==true)? "DISTINCT ": "";
			sbSql.Append(strDistinct);

			//Append TOP N
			string strTop = (query.Selects.Top <= 0)? "": "TOP "+ Convert.ToString(query.Selects.Top) + " ";
			sbSql.Append(strTop);

			bool exist = false;
			//Append columns in select section
			if(query.Selects.Count==0 && !query.Selects.None)
			{
				string strAllFields = this.GetAllFields(query);
				sbSql.Append(strAllFields);
				exist = true;
			}
			else if(!query.Selects.None)
			{
				string strPartialFields = this.GetPartialFields(query);
				sbSql.Append(strPartialFields);
				exist = true;
			}

			//Output aggregates collection
			string strAggregates = this.AggregateAnalyzer.Analyze(query.Aggregates);
			if(!Kit.IsEmpty(strAggregates)) 
			{
				if(exist)
					sbSql.Append(", ");
				sbSql.Append(strAggregates);
			}
			
			return sbSql.ToString();
		}


		/// <summary>
		/// Get all columns list instead of select *. 
		/// The method called only when there is no select columns specified and property None is false.
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		private string GetAllFields(Query query)
		{
			ArrayList collections = new ArrayList();
			collections.Add(query.Associations.MasterEntity);
			IEnumerator enumerator = query.Associations.GetEnumerator();
			//Get all destination tables/views found in query association
			while(enumerator.MoveNext())
			{
				Association association = enumerator.Current as Association;
				collections.Add(association.Destinations[0].ParentEntity);
			}

			//Begin to select all columns in associated entities 
			enumerator = collections.GetEnumerator();
			StringCollection scAliasNames = new StringCollection();
			StringBuilder sbSql = new StringBuilder();
			while(enumerator.MoveNext())
			{
				IMappingEnumerator fieldEnumerator = (enumerator.Current as EntityMapping).FieldList.GetEnumerator();
				while(fieldEnumerator.MoveNext())
				{
					FieldMapping field = fieldEnumerator.Value;
					string strAliasName = Kit.BracketWord(field.AliasName);

					//When clause hasn included this alias name, change it to another alias name auto-generated.
					if(scAliasNames.Contains(strAliasName))
					{
						strAliasName = Kit.GetValidName(field.ParentEntity.AliasName) + "_" + Kit.GetValidName(field.AliasName);
						int i = 1;
						while(scAliasNames.Contains(strAliasName)==true)
							strAliasName = Kit.GetValidName(field.ParentEntity.AliasName) + Convert.ToString(i++) + "_" + Kit.GetValidName(field.AliasName);
						//Set back the alias name on property AliasName
						field.AliasName = strAliasName;
					}

					if(sbSql.Length != 0)
						sbSql.Append(", ");
					sbSql.Append(field.ColumnName);
					sbSql.Append(" AS ");
					sbSql.Append(strAliasName);
					scAliasNames.Add(strAliasName);
				}
			}

			return sbSql.ToString();
		}


		/// <summary>
		/// Get sql composed of partial fields.
		/// The method called only when there are select columns specified.
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		private string GetPartialFields(Query query)
		{
			StringBuilder sbSql = new StringBuilder();
			StringCollection scAliasNames = new StringCollection();
			IEnumerator enumerator = query.Selects.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Current as FieldMapping;
				string strAliasName = Kit.BracketWord(field.AliasName);

				//When clause hasn included this alias name, change it to another alias name auto-generated.
				if(scAliasNames.Contains(strAliasName))
				{
					strAliasName = Kit.GetValidName(field.ParentEntity.AliasName) + "_" + Kit.GetValidName(field.AliasName);
					int i = 1;
					while(scAliasNames.Contains(strAliasName)==true)
						strAliasName = Kit.GetValidName(field.ParentEntity.AliasName) + Convert.ToString(i++) + "_" + Kit.GetValidName(field.AliasName);
				}
				
				if(sbSql.Length != 0) sbSql.Append(", ");
				sbSql.Append(field.ColumnName);
				sbSql.Append(" AS ");
				sbSql.Append(strAliasName);

				//Set back the alias name on property AliasName
				field.AliasName = strAliasName;
				scAliasNames.Add(strAliasName);
			}

			return sbSql.ToString();
		}


		/// <summary>
		/// Parse <seealso cref="AssociationCollection"/> object to get from tables/views.
		/// </summary>
		/// <param name="associations"></param>
		/// <returns></returns>
		protected virtual string Associate(AssociationCollection associations)
		{
			StringBuilder sbSql = new StringBuilder();
			//When there is no join table in the query
			if(associations.Count == 0)
			{
				sbSql.Append(Kit.BracketWord(associations.MasterEntity.AliasName));
			}
			else
			{
				//Using bracket to separate each joint.
				for(int i=0; i<associations.Count; i++)
					sbSql.Append("(");

				//Set master table of query
				sbSql.Append(Kit.BracketWord(associations.MasterEntity.AliasName));

				//Circulate all associations, push then into FROM sql serially
				IEnumerator enumerator = associations.GetEnumerator();
				while(enumerator.MoveNext())
				{
					Association association = enumerator.Current as Association;
					sbSql.Append(EnumCustomAttributeCache.GetCustomAttribute(association.Type));
					string strJoinTableName = Kit.BracketWord(association.Destinations[0].ParentEntity.AliasName);
					sbSql.Append(strJoinTableName);
					sbSql.Append(" ON ");
					for(int i=0; i<association.Currents.Length; i++)
					{
						if(i!=0)
							sbSql.Append(" AND ");
						sbSql.Append(association.Currents[i].ColumnName);
						sbSql.Append("=");
						sbSql.Append(association.Destinations[i].ColumnName);
					}
					sbSql.Append(")");
				}
			}
			return sbSql.ToString();
		}


		/// <summary>
		/// Parse <seealso cref="CriteriaCollection"/> object to get where sql.<br/>
		/// Arguement <b>command</b> has been initialized before transmit into this methods.
		/// </summary>
		/// <param name="conditions"></param>
		/// <param name="command"></param>
		/// <returns></returns>
		protected virtual string Where(CriteriaCollection conditions, IDbCommand command)
		{
			Check.VerifyNotNull(command);
			StringBuilder sbSql = new StringBuilder();

			StringBuilder sbFields = new StringBuilder();
			IEnumerator enumerator = conditions.GetEnumerator();
			while(enumerator.MoveNext())
			{
				string strConnector;
				//When child node is ConditionCollection object, it includes Condition objects
				if(enumerator.Current is CriteriaCollection)
				{
					CriteriaCollection childConditions = enumerator.Current as CriteriaCollection;
					if(sbSql.Length > 0)
					{
						strConnector = EnumCustomAttributeCache.GetCustomAttribute(childConditions.Connector);
						sbSql.Append(strConnector);
					}
					sbSql.Append("(");
					sbSql.Append(this.Where(childConditions, command));
					sbSql.Append(")");
				}
				//When it is Condition type. 
				//Because the children type of ConditionCollection object only can be ConditionCollection or Condition
				else
				{
					CriteriaCollection.Criteria condition = enumerator.Current as CriteriaCollection.Criteria;
					if(sbSql.Length > 0)
					{
						strConnector = EnumCustomAttributeCache.GetCustomAttribute(condition.Connector);
						sbSql.Append(strConnector);
					}
					sbSql.Append(condition.Field.ColumnName);

					//Ensure variable sbFields is always empty in circulation
					if(sbFields.Length != 0)
						sbFields.Remove(0, sbFields.Length);

					//Circulate all operands in condition
					foreach(object operand in condition.Values)
					{
						string strVariableName = "@" + System.Guid.NewGuid().ToString("N");
						if(sbFields.Length!=0) sbFields.Append(", ");
						sbFields.Append(strVariableName);

						IDataParameter parameter = this.Analyzer.Provider.CreateParameter(strVariableName, operand);
						command.Parameters.Add(parameter);
					}
					sbSql.AppendFormat(EnumCustomAttributeCache.GetCustomAttribute(condition.Operator), sbFields.ToString());
				}
			}

			return sbSql.ToString();
		}


		/// <summary>
		/// Parse <seealso cref="OrderByColumnCollection"/> object to get order by columns.
		/// </summary>
		/// <param name="orderByColumns"></param>
		/// <returns></returns>
		protected virtual string OrderBy(OrderByColumnCollection orderByColumns)
		{
			StringBuilder sbSql = new StringBuilder();
			IEnumerator enumerator = orderByColumns.GetEnumerator();
			while(enumerator.MoveNext())
			{
				if(sbSql.Length>9) sbSql.Append(", ");
				OrderByColumn column = enumerator.Current as OrderByColumn;
				string strOrder = column.Ascending? " ASC": " DESC";
				sbSql.Append(column.Column.ColumnName);
				sbSql.Append(strOrder);
			}

			return sbSql.ToString();
		}


		/// <summary>
		/// Parse <seealso cref="FieldCollection"/> object to get group by columns.
		/// </summary>
		/// <param name="groupByColumns"></param>
		/// <returns></returns>
		protected virtual string GroupBy(FieldCollection groupByColumns)
		{
			StringBuilder sbSql = new StringBuilder();
			IEnumerator enumerator = groupByColumns.GetEnumerator();
			while(enumerator.MoveNext())
			{
				if(sbSql.Length>9) sbSql.Append(", ");
				FieldMapping field = enumerator.Current as FieldMapping;
				sbSql.Append(field.ColumnName);
			}

			return sbSql.ToString();
		}
	}
}