// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Web.Caching;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Reflection;
using System.Collections;
using System.Threading;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Cached all providers registered in configuration, including relative connection string, provider type and name.<br/>
	/// Additional, we usually refer it to retrieve default <seealso cref="IProvider"/> entry, which is the command center between applications and database.
	/// </summary>
	/// <example>
	/// IProvider provider = Providers.GetProvider();<br/>
	/// If we get the <seealso cref="IProvider"/> entry without any arguements as above, DataQuicker refers to the default provider configured in DataQuicker.config.
	/// </example>
	[Serializable]
	public sealed class Providers
	{
		[ThreadStatic]
		private static Hashtable Cache = new Hashtable();
		private static object SyncObject = new object();

		private Providers()
		{
		}

		/// <summary>
		/// Return true when the provider exists
		/// </summary>
		/// <param name="providerName"></param>
		/// <returns></returns>
		internal static bool Contains(string providerName)
		{
			ProviderSection section = ConfigurationManager.Instance.GetConfig("ProviderSection", typeof(ProviderSection)) as ProviderSection;
			ProviderSection.Provider providerInfo = section.GetProvider(providerName);
			return providerInfo!=null;
		}


		/// <summary>
		/// Get <seealso cref="IProvider"/> entry
		/// </summary>
		/// <param name="providerName"></param>
		/// <returns></returns>
		public static IProvider GetProvider(string providerName)
		{
			ProviderSection section = ConfigurationManager.Instance.GetConfig("ProviderSection", typeof(ProviderSection)) as ProviderSection;
			string strProviderName = Kit.IsEmpty(providerName)? section.Default: providerName;

			IProvider provider = ConfigurationManager.Instance.ProviderCache.Pop(strProviderName);
			if(provider!=null) 
			{
				return provider;
			}
			else
			{
				ProviderSection.Provider providerInfo = section.GetProvider(strProviderName);
				if(providerInfo == null)
					throw new DQException("10062");

				Type type = Type.GetType(providerInfo.Type, true, true);
				return System.Activator.CreateInstance(type, new object[]{providerInfo}) as Provider;
			}
		}


		/// <summary>
		/// Get <seealso cref="IProvider"/> entry
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public static IProvider GetProvider(EntityMapping entity)
		{
			return Providers.GetProvider(entity.ProviderName);
		}


		/// <summary>
		/// Get <seealso cref="IProvider"/> entry
		/// </summary>
		/// <returns></returns>
		public static IProvider GetProvider()
		{
			return Providers.GetProvider("");
		}
	}
}