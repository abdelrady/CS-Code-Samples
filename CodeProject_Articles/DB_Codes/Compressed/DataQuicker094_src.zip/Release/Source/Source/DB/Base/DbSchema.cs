// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Threading;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Globalization;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Abstract class for caching database schema
	/// </summary>
	[Serializable]
	public abstract class DbSchema
	{
		private Hashtable mTables = new Hashtable();

		/// <summary>
		/// Get true when the schema has been initialized
		/// </summary>
		public bool Initialized 
		{
			get
			{
				return this.mTables.Count>0;
			}
		}


		/// <summary>
		/// Load and cache database schema. 
		/// </summary>
		/// <param name="oleDbConnectionString"></param>
		public virtual void LoadDbSchema(string oleDbConnectionString)
		{
			DataSet dst = DbSchema.GetOrignDbSchema(oleDbConnectionString);

			DataTable dt = dst.Tables["Tables"];
			for(int i=0; i<dt.Rows.Count; i++)
			{
				string strTableType = dt.Rows[i]["TABLE_TYPE"].ToString();
				if(strTableType.IndexOf("SYSTEM")!=-1 || strTableType.IndexOf("ACCESS")!=-1) continue;

				DbDataSet dbdst = new DbDataSet();
				dbdst.Name = dt.Rows[i]["TABLE_NAME"].ToString();
				dbdst.Type = dt.Rows[i]["TABLE_TYPE"].ToString();

				//Add primary keys
				DataTable dtPrimaryKeys = dst.Tables["Primary_Keys"];
				for(int j=0; j<dtPrimaryKeys.Rows.Count; j++)
				{
					if(Kit.IsEmpty(dtPrimaryKeys.Rows[j]["TABLE_NAME"]) || Kit.IsEmpty(dtPrimaryKeys.Rows[j]["COLUMN_NAME"])) continue;
					if(dbdst.Name != dtPrimaryKeys.Rows[j]["TABLE_NAME"].ToString()) continue;
					dbdst.PrimaryKeyCollection.Add(dtPrimaryKeys.Rows[j]["COLUMN_NAME"].ToString());
				}

				//Add columns
				DataTable dtColumns = dst.Tables["Columns"];
				for(int j=0; j<dtColumns.Rows.Count; j++)
				{
					if(Kit.IsEmpty(dtColumns.Rows[j]["TABLE_NAME"]) ||Kit.IsEmpty(dtColumns.Rows[j]["COLUMN_NAME"])) continue;
					if(dbdst.Name != dtColumns.Rows[j]["TABLE_NAME"].ToString()) continue;

					DataRow drow = dbdst.ColumnsCollection.NewRow();
					drow["ColumnName"] = dtColumns.Rows[j]["COLUMN_NAME"].ToString();
					drow["HasDefaultValue"] = !Kit.IsEmpty(dtColumns.Rows[j]["COLUMN_HASDEFAULT"]) && (bool)dtColumns.Rows[j]["COLUMN_HASDEFAULT"];
					drow["DefaultValue"] = dtColumns.Rows[j]["COLUMN_DEFAULT"];
					drow["IsAutoIncreased"] = this.IsAutoIncrease(dtColumns.Rows[j]);

					drow["Type"] = Kit.IsEmpty(dtColumns.Rows[j]["DATA_TYPE"]) ? 0 : (int) dtColumns.Rows[j]["DATA_TYPE"];

					//For digit type, its CHARACTER_MAXIMUM_LENGTH always be null. And I convert null to -1 saving in MaxLength field.
					if(Kit.IsEmpty(dtColumns.Rows[j]["CHARACTER_MAXIMUM_LENGTH"]))
						drow["MaxLength"] = -1;
					else
					{
						long maxLength = (long)dtColumns.Rows[j]["CHARACTER_MAXIMUM_LENGTH"];
						maxLength = (maxLength==0)?long.MaxValue:maxLength;
						drow["MaxLength"] = maxLength;
					}

					drow["IsNullable"] = !Kit.IsEmpty(dtColumns.Rows[j]["IS_NULLABLE"]) && (bool) dtColumns.Rows[j]["IS_NULLABLE"];
					dbdst.ColumnsCollection.Rows.Add(drow);
				}

				dbdst.ColumnsCollection.AcceptChanges();
				this.mTables.Add(dbdst.Name, dbdst);
			}
		}
		

		/// <summary>
		/// Get database schema
		/// </summary>
		/// <param name="oleDbConnectionString"></param>
		/// <returns>A DataSet object includes all objects in database</returns>
		private static DataSet GetOrignDbSchema(string oleDbConnectionString)
		{
			OleDbConnection connection = new OleDbConnection(oleDbConnectionString);
			try
			{
				connection.Open();
				DataSet dst = new DataSet("DbSchema");
				dst.Locale = CultureInfo.CurrentCulture;
				DataTable dt = null;

				dt = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
				dst.Tables.Add(dt);

				dt = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Columns, null);
				dst.Tables.Add(dt);

				dt = connection.GetOleDbSchemaTable(OleDbSchemaGuid.Primary_Keys, null);
				dst.Tables.Add(dt);

				return dst;
			}
			finally
			{
				connection.Close();
			}
		}


		/// <summary>
		/// Get true when the field is auto-increasement
		/// </summary>
		/// <param name="drow"></param>
		/// <returns></returns>
		protected internal abstract bool IsAutoIncrease(DataRow drow);

		/// <summary>
		/// Initialize entity with schema of database
		/// </summary>
		/// <param name="entity"></param>
		protected internal virtual void Initialize(EntityMapping entity)
		{
			if(this.Initialized == false)
				throw new DQException("11007", entity.ProviderName);

			object taken = this.mTables[entity.PhysicalName];
			if(taken == null)
				throw new DQException("11002", entity.ToString(), entity.PhysicalName);

			DbDataSet dbdst = taken as DbDataSet;
			this.ValidatePrimaryKey(entity, dbdst);

			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
				this.ValidateProperty(enumerator.Value, dbdst);
		}


		/// <summary>
		/// Validate design of entity's primary keys
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="dbdst"></param>
		private void ValidatePrimaryKey(EntityMapping entity, DbDataSet dbdst)
		{
			if(entity is ViewMapping) return;
			
			IEnumerator enumerator = entity.PrimaryKeys.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping primaryKey = enumerator.Current as FieldMapping;
				string strPhysicalName = primaryKey.PhysicalName;
				if(!dbdst.PrimaryKeyCollection.Contains(strPhysicalName))
					throw new DQException("11001", entity.ToString(), strPhysicalName);
			}
		}


		/// <summary>
		/// Validate field mapping name and load its database schema information
		/// </summary>
		/// <param name="field"></param>
		/// <param name="dbdst"></param>
		private void ValidateProperty(FieldMapping field, DbDataSet dbdst)
		{
			string strPhysicalName = field.PhysicalName;
			string strRowFilter = "ColumnName='{0}'";
			strRowFilter = string.Format(strRowFilter, strPhysicalName);

			DataRow[] drows = dbdst.ColumnsCollection.Select(strRowFilter);
			if(drows.Length < 1)
				throw new DQException("11003", field.ParentEntity.ToString(), strPhysicalName);
			else if(drows.Length > 1)
				throw new DQException("11004", field.ParentEntity.ToString(), strPhysicalName);
			else
			{
				field.mIsAutoIncrease = (bool) drows[0]["IsAutoIncreased"];
				field.mHasDefaultValue = (bool) drows[0]["HasDefaultValue"];
				field.mAllowNull =  (bool) drows[0]["IsNullable"];
				field.mMaxLength = (long) drows[0]["MaxLength"];
			}
		}


		/// <summary>
		/// Convert ole data type value to DQ type.
		/// </summary>
		/// <param name="dateType"></param>
		/// <returns></returns>
		public abstract Type DataTypeValue2DQType(int dateType);
	}
}