// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Data.OleDb;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// This class is an implementation of the <see cref="Provider"/> class for the Access RDBMS.
	/// </summary>
	public class JetProvider: Provider 
	{
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="providerInfo"></param>
		public JetProvider(ProviderSection.Provider providerInfo): base(providerInfo)
		{
		}

		/// <summary>
		/// Destructor
		/// </summary>
		~JetProvider()
		{
			this.mConnection = null;
			this.mCommand = null;
			this.mTransaction = null;
		}

		/// <summary>
		/// Render OleDbConnection <see cref="OleDbConnection"/>
		/// </summary>
		/// <param name="connectionString">Database connection string</param>
		/// <returns></returns>
		protected override IDbConnection Render(string connectionString)
		{
			return new OleDbConnection(connectionString);
		}

		/// <summary>
		/// <p>Insert an non-existing object.</p>
		/// <p>You should ensure that you have set the necessary fields and the object doesn't exist before insert.</p>
		/// </summary>
		public override void Create(TableMapping entity)
		{
			Check.VerifyInsertValid(entity);
			IDbCommand command = this.Analyzer.Create(entity);
			if (command == null) return;
			try
			{
				this.Open();
				this.LogCommand(command);
				if(this.IsTrans == true)
					command.Transaction = this.Transaction.Value;
				
				string strRequestPkSql = "";
				object objPkValue = null;

				//If the primary key is managed by DataQuicker/Database
				if(entity.PrimaryKeys.Count==1 && (entity.PrimaryKeys[0].IsAutoIncrease || entity.PrimaryKeys[0].PrimaryKeyType!=PrimaryKeyType.None))
				{
					if(entity.PrimaryKeys[0].PrimaryKeyType == PrimaryKeyType.DQIncrease)
					{
						if(entity.PrimaryKeys[0] is FString)
							strRequestPkSql = "SELECT IIf(IsNull(Max(IIf(IsNull({0}), 0, IIf(IsNumeric({0}),{0},0)))), 0, Max(IIf(IsNull({0}), 0, IIf(IsNumeric({0}),{0},0)))) +1 FROM {1}";
						else
							strRequestPkSql = "SELECT IIf(IsNull(Max({0})), 1, Max({0}) + 1) FROM {1}";

						string strPrimaryKeyName = Kit.BracketWord(entity.PrimaryKeys[0].PhysicalName);
						string strEntityMappingName = Kit.BracketWord(entity.PhysicalName);

						//Combine sql to get the max primary key value
						strRequestPkSql = string.Format(strRequestPkSql, strPrimaryKeyName, strEntityMappingName);
						IDbCommand pkCommand = this.Connection.CreateCommand();
						if(this.IsTrans == true)
							pkCommand.Transaction = this.Transaction.Value;
						pkCommand.CommandText = strRequestPkSql;
						pkCommand.CommandType = CommandType.Text;

						objPkValue = pkCommand.ExecuteScalar();
						(command.Parameters[JetAnalyzer.PRIMARY_KEY_VARIABLE] as IDataParameter).Value = objPkValue;
					}
					else if(entity.PrimaryKeys[0].PrimaryKeyType == PrimaryKeyType.Guid)
					{
						objPkValue = System.Guid.NewGuid().ToString("N");
						string strVariableName = JetAnalyzer.PRIMARY_KEY_VARIABLE;
						(command.Parameters[strVariableName] as IDataParameter).Value = objPkValue;
					}
				}

				//Execute command
				command.ExecuteNonQuery();
				
				//If the primary key is managed by database, the following code used to get the inserted primary key value.
				if(entity.PrimaryKeys.Count==1 && entity.PrimaryKeys[0].IsAutoIncrease)
				{
					strRequestPkSql = "SELECT Max({0}) AS PrimaryKeyName FROM {1}";
					string strPrimaryKeyName = Kit.BracketWord(entity.PrimaryKeys[0].PhysicalName);
					string strMappingName = Kit.BracketWord(entity.PhysicalName);
					strRequestPkSql = string.Format(strRequestPkSql, strPrimaryKeyName, strMappingName);

					command.CommandText = strRequestPkSql;
					objPkValue = command.ExecuteScalar();
				}

				if(objPkValue!=null && objPkValue!=DBNull.Value)
					entity.PrimaryKeys[0].Value = objPkValue;

				entity.mExist = true;
			}
			catch(Exception exp)
			{
				Log.Write(command, exp);
				throw exp;
			}
			finally
			{
				if(this.AutoCloseConnection == true)
					this.Close();
			}
		}

		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal override string ParseToConnectionString(ProviderSection.Provider providerInfo)
		{
			Check.VerifyNotNull(providerInfo);

			if(Kit.IsEmpty(this.mConnectionString))
			{
				string strDataSource = Kit.GetLocalPath(providerInfo.DataSource);
				if(Kit.IsEmpty(strDataSource))
					throw new DQException("10041", providerInfo.Name);
				string strDbProvider = providerInfo.DbProvider;
				if(Kit.IsEmpty(strDbProvider))
					strDbProvider = "Microsoft.Jet.OleDb.4.0";
				string strConnection = "Provider=\"{0}\"; Jet OLEDB:Database Password=\"{1}\";Data Source=\"{2}\";";
				this.mConnectionString = string.Format(strConnection, strDbProvider, providerInfo.Password, providerInfo.DataSource);
				return this.mConnectionString;
			}
			else
				return this.mConnectionString;
		}

		/// <summary>
		/// Parse <seealso cref="ProviderSection.Provider"/> to ole connection string
		/// </summary>
		/// <param name="providerInfo"></param>
		/// <returns></returns>
		protected internal override string ParseToOleConnectionString(ProviderSection.Provider providerInfo)
		{
			return this.ParseToConnectionString(providerInfo);
		}
	}
}
