// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Stores several DbSchemas for DataQuicker
	/// </summary>
	internal class DbSchemaCollection
	{
		private Hashtable mCollection = new Hashtable();

		/// <summary>
		/// Constructor
		/// </summary>
		public DbSchemaCollection()
		{	
		}

		/// <summary>
		/// Add a new DbSchema object
		/// </summary>
		/// <param name="providerName"></param>
		/// <param name="schema"></param>
		public void Add(string providerName, DbSchema schema)
		{
			if(this.mCollection.ContainsKey(providerName) == false)
				this.mCollection.Add(providerName, schema);
		}

		/// <summary>
		/// Get true when the collection contains the provider name
		/// </summary>
		/// <param name="providerName"></param>
		public bool Contains(string providerName)
		{
			return this.mCollection.ContainsKey(providerName);
		}

		/// <summary>
		/// Clear all DbSchemas
		/// </summary>
		public void Clear()
		{
			this.mCollection.Clear();
		}

		/// <summary>
		/// Set/Get DbSchema for argument provider name
		/// </summary>
		public DbSchema this[string providerName]
		{
			get
			{
				object schema = this.mCollection[providerName];
				if(schema!=null && schema is DbSchema)
					return schema as DbSchema;
				return null;
			}
			set
			{
				Check.VerifyNotNull(value);
				Check.VerifyNotNull(providerName);
				this.Add(providerName, value);
			}
		}

		/// <summary>
		/// Initialize entity with database schema
		/// </summary>
		/// <param name="entity"></param>
		public void Initialize(EntityMapping entity)
		{
			Check.VerifyNotNull(entity);
			string providerName = entity.ProviderName;
			DbSchema schema = this[providerName];
			if(schema == null)
				throw new DQException("10040", entity.ToString());
			schema.Initialize(entity);
		}
	}
}
