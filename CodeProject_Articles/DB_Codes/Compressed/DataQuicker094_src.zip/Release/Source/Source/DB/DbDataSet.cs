// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// The information structure for caching structure of database.
	/// </summary>
	[Serializable]
	internal class DbDataSet
	{
		private string mName;
		private string mType;
		private DataTable mColumnsCollection = new DataTable();
		private StringCollection mPrimaryKeyCollection = new StringCollection();

		/// <summary>
		/// Constructor
		/// </summary>
		public DbDataSet()
		{
			this.mColumnsCollection.Locale = System.Globalization.CultureInfo.CurrentCulture;
			this.mColumnsCollection.Columns.Add(new DataColumn("ColumnName", typeof(string)));
			this.mColumnsCollection.Columns.Add(new DataColumn("HasDefaultValue", typeof(bool)));
			this.mColumnsCollection.Columns.Add(new DataColumn("DefaultValue", typeof(string)));
			this.mColumnsCollection.Columns.Add(new DataColumn("IsAutoIncreased", typeof(bool)));
			this.mColumnsCollection.Columns.Add(new DataColumn("Type", typeof(int)));
			this.mColumnsCollection.Columns.Add(new DataColumn("MaxLength", typeof(long)));
			this.mColumnsCollection.Columns.Add(new DataColumn("IsNullable", typeof(bool)));
			this.mColumnsCollection.AcceptChanges();
		}

		/// <summary>
		/// Set/Get table/view name
		/// </summary>
		public string Name
		{
			get
			{
				return this.mName;
			}
			set
			{
				this.mName = value;
			}
		}

		/// <summary>
		/// Set/Get entity type
		/// </summary>
		public string Type
		{
			get
			{
				return this.mType;
			}
			set
			{
				this.mType = value;
			}
		}

		/// <summary>
		/// Get <seealso cref="DataTable"/> object for columns schema
		/// </summary>
		public DataTable ColumnsCollection
		{
			get
			{
				return this.mColumnsCollection;
			}
		}

		/// <summary>
		/// Get <seealso cref="StringCollection"/> object for primary keys
		/// </summary>
		public StringCollection PrimaryKeyCollection
		{
			get
			{
				return this.mPrimaryKeyCollection;
			}
		}
	}
}
