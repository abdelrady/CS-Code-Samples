// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Data;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// SqlAnalyzer is used for MS SQL Server. It derives from Analyzer and implements the sql analyzing operation.<br/>
	/// It transmits IDbCommand entry to <seealso cref="Provider"/> for executing.
	/// </summary>
	[Serializable]
	public class SqlAnalyzer: Analyzer 
	{
		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="provider"></param>
		public SqlAnalyzer(Provider provider): base(provider)
		{
		}


		#region Query
		/// <summary>
		/// Analyze the <seealso cref="Query"/> object, and return IDbCommand object for querying.<br/>
		/// </summary>
		/// <param name="query"></param>
		/// <returns></returns>
		public override IDbCommand Query(Query query)
		{
			return this.QueryAnalyzer.Analyze(query);
		}

		#endregion

		#region Update

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for updating.<br/>
		/// The update based on primary keys' value of TableMapping object. 
		/// The precondition that we should ensure the primary key value isn't empty or null.
		/// And the update doesn't refer to the primary keys' value.<br/>
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override IDbCommand Update(TableMapping entity)
		{
			IDbCommand command = this.Provider.Command;

			//Get updated columns
			string strUpdatedFields = this.GetUpdatedFields(entity, command);
			if(Kit.IsEmpty(strUpdatedFields))
				return null;

			StringBuilder sbSql = new StringBuilder();
			sbSql.Append("UPDATE ");
			sbSql.Append(Kit.BracketWord(entity.PhysicalName));
			sbSql.Append(" SET ");
			sbSql.Append(strUpdatedFields);

			sbSql.Append(" WHERE ");
			sbSql.Append(this.GetPrimaryKeys(entity, command));

			command.CommandText = sbSql.ToString();
            
			return command;
		}


		/// <summary>
		/// Get updated fields
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="command"></param>
		/// <returns></returns>
		private string GetUpdatedFields(EntityMapping entity, IDbCommand command)
		{
			string strVariableName;
			StringBuilder sbSql = new StringBuilder();
			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Value;
				//If its value isn't null and has been changed, and not primary key, and not auto-db-increased
				if(field.IsValueChanged==true && field.IsNull==false && field.IsPrimaryKey==false && field.IsAutoIncrease==false)
				{
					if(sbSql.Length != 0)
						sbSql.Append(", ");

					sbSql.Append(field.ColumnName);
					sbSql.Append("=");

					strVariableName = "@" + Kit.GetValidName(field.PhysicalName);
					//Append variable to IDbCommand object
					sbSql.Append(strVariableName);
					command.Parameters.Add(this.Provider.CreateParameter(strVariableName, field.Value));
				}
			}
			return sbSql.ToString();
		}


		#endregion

		#region Create

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for inserting.<br/>
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override IDbCommand Create(TableMapping entity)
		{
			IDbCommand command = this.Provider.Command;

			string strSql = this.GetCreateSql(entity, command);
			if(entity.PrimaryKeys.Count==1)
			{
				FieldMapping primaryKey = entity.PrimaryKeys[0];
				if(primaryKey.IsAutoIncrease == false)
				{
					//Used to return the primary key value.
					string strScale = "SELECT @" + Kit.GetValidName(primaryKey.PhysicalName) + "; ";

					if(primaryKey.PrimaryKeyType==PrimaryKeyType.DQIncrease && primaryKey is FString)	//Increased by DataQuiceker, it's FString
						strSql = SqlAnalyzer.GetTextIncreaseDeclaration(primaryKey) + strSql + strScale;
					else if (primaryKey.PrimaryKeyType==PrimaryKeyType.DQIncrease && primaryKey is FInt)	//Increased by DataQuiceker, it's FInt
						strSql = SqlAnalyzer.GetIntIncreaseDeclaration(primaryKey) + strSql + strScale;
					else if(primaryKey.PrimaryKeyType == PrimaryKeyType.Guid && primaryKey is FString)	//Set Guid NO. as primary key
						strSql = SqlAnalyzer.GetGuidDeclaration(primaryKey) + strSql + strScale;
				}
				//if the only one primary key is auto-database-increase column. After inserting, return the auto-increase value generated by database.
				else
				{
					strSql +="SELECT @@identity FROM " + Kit.BracketWord(entity.PhysicalName) + "; ";
				}
			}
			command.CommandText = strSql;
			return command;
		}


		/// <summary>
		/// Generate insert sql
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="command"></param>
		/// <returns></returns>
		private string GetCreateSql(EntityMapping entity, IDbCommand command)
		{
			StringBuilder sbFields = new StringBuilder();
			StringBuilder sbFieldsValue = new StringBuilder();

			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Value;
				string strVariableName;
				IDataParameter parameter;

				//When the column's value is not null, and it's not auto-database-increase column, and it's not primary key or its value is not managed by DataQuicker
				if(field.IsNull==false && field.IsAutoIncrease==false && (field.IsPrimaryKey==false || field.PrimaryKeyType==PrimaryKeyType.None))
				{
					if(sbFields.Length>0) 
					{
						sbFields.Append(", ");
						sbFieldsValue.Append(", ");
					}
					sbFields.Append(Kit.BracketWord(field.PhysicalName));

					//Insert a parameter to sql
					strVariableName = "@" + Kit.GetValidName(field.PhysicalName);

					sbFieldsValue.Append(strVariableName);

					parameter = this.Provider.CreateParameter(strVariableName, field.Value);
					command.Parameters.Add(parameter);
				}
				//When the column is DataQuicker-Managed column
				else if(field.IsAutoIncrease==false && field.IsPrimaryKey==true && field.PrimaryKeyType!=PrimaryKeyType.None)
				{
					if(sbFields.Length>0)
					{
						sbFields.Append(", ");
						sbFieldsValue.Append(", ");
					}

					sbFields.Append(Kit.BracketWord(field.PhysicalName));
					sbFieldsValue.AppendFormat("@{0}", Kit.GetValidName(field.PhysicalName));
				}
			}

			if(sbFields.Length==0)
				throw new DQException("10055");

			string strSql = "INSERT INTO {0}({1}) VALUES ({2}); ";
			strSql = string.Format(strSql, Kit.BracketWord(entity.PhysicalName), sbFields.ToString(), sbFieldsValue.ToString());
			return strSql;
		}


		/// <summary>
		/// Get variable declaration of string-increasement mode.
		/// </summary>
		/// <param name="primaryKey"></param>
		/// <returns></returns>
		private static string GetTextIncreaseDeclaration(FieldMapping primaryKey)
		{
			string strSql = "DECLARE @{0} AS INT; SET @{0}=ISNULL((SELECT MAX(CASE ISNUMERIC({1})WHEN 1 THEN CAST({1} AS int)WHEN 0 THEN 0 END) FROM {2}),0)+1; ";
			string strVariableName = Kit.GetValidName(primaryKey.PhysicalName);
			strSql = string.Format(strSql, strVariableName, Kit.BracketWord(primaryKey.PhysicalName), Kit.BracketWord(primaryKey.ParentEntity.PhysicalName));
			return strSql;
		}


		/// <summary>
		/// Get variable declaration of integer-increasement mode.
		/// </summary>
		/// <param name="primaryKey"></param>
		/// <returns></returns>
		private static string GetIntIncreaseDeclaration(FieldMapping primaryKey)
		{
			string strSql = "DECLARE @{0} AS INT; SET @{0}=ISNULL((SELECT MAX({1}) FROM {2}),0)+1; ";
			strSql = string.Format(strSql, Kit.GetValidName(primaryKey.PhysicalName), Kit.BracketWord(primaryKey.PhysicalName), Kit.BracketWord(primaryKey.ParentEntity.PhysicalName));
			return strSql;
		}


		/// <summary>
		/// Get variable declaration of Guid mode.
		/// </summary>
		/// <param name="primaryKey"></param>
		/// <returns></returns>
		private static string GetGuidDeclaration(FieldMapping primaryKey)
		{
			string strSql = "DECLARE @{0} AS char(32); SET @{0}='{1}'; ";
			strSql = string.Format(strSql, Kit.GetValidName(primaryKey.PhysicalName), System.Guid.NewGuid().ToString("N"));
			return strSql;
		}


		#endregion

		#region Delete

		/// <summary>
		/// Analyze the TableMapping object, and return IDbCommand object for deleting.<br/>
		/// The delete based on primary keys' value of TableMapping object.
		/// The precondition that we should ensure the primary key value isn't empty or null.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override IDbCommand Delete(TableMapping entity)
		{
			IDbCommand command = this.Provider.Command;

			string strSql = "DELETE FROM {0} WHERE {1}";

			//Get conditions composed of primary keys
			string strCondition = this.GetPrimaryKeys(entity, command);
			command.CommandText = string.Format(strSql, Kit.BracketWord(entity.PhysicalName), strCondition);
			return command;
		}


		#endregion

		#region Retrieve
		/// <summary>
		/// Analyze the EntityMapping object and return IDbCommand object for retrieving entity data.<br/>
		/// The retrieve based on values set on entity.<br/>
		/// If the value of primary key exists, the retrieve replys on it. Otherwise, it replys on whatever column has its value.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public override IDbCommand Retrieve(EntityMapping entity)
		{
			IDbCommand command = this.Provider.Command;

			bool byPrimaryKey = !entity.PrimaryKeys.IsNull;

			StringBuilder sbFields = new StringBuilder();
			StringBuilder sbConditions = new StringBuilder();
			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				//Select columns list
				FieldMapping field = enumerator.Value;
				if(sbFields.Length != 0)
					sbFields.Append(", ");
				sbFields.Append(Kit.BracketWord(field.PhysicalName));
				sbFields.Append(" AS ");
				sbFields.Append(Kit.BracketWord(field.PhysicalName));

				//Retrieve object by primary keys' value, or by any fields' value set on entity object
				if((byPrimaryKey && field.IsPrimaryKey) || (!byPrimaryKey && !field.IsNull))
				{
					if(sbConditions.Length != 0)
						sbConditions.Append(" AND ");
					sbConditions.Append(Kit.BracketWord(field.PhysicalName));
					sbConditions.Append("=");
					string strVariableName = "@" + Kit.GetValidName(field.PhysicalName);
					sbConditions.Append(strVariableName);

					IDataParameter parameter = this.Provider.CreateParameter(strVariableName, field.Value);
					command.Parameters.Add(parameter);
				}
			}

			string strSql = "SELECT {0} FROM {1} WHERE {2}";
			command.CommandText = string.Format(strSql, sbFields.ToString(), Kit.BracketWord(entity.PhysicalName), sbConditions.ToString());

			return command;
		}


		#endregion

		#region Common Methods

		/// <summary>
		/// Get conditions in "where" clause composed of primary keys.<br/>
		/// The precondition of this method calling is that each primary key value isn't null, otherwise it will throw exception.
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="command"></param>
		/// <returns></returns>
		private string GetPrimaryKeys(EntityMapping entity, IDbCommand command)
		{
			StringBuilder sbSql = new StringBuilder();
			FieldMapping primaryKey;
			IEnumerator enumerator = entity.PrimaryKeys.GetEnumerator();
			while(enumerator.MoveNext())
			{
				primaryKey = enumerator.Current as FieldMapping;
				if(!primaryKey.IsNull)
				{
					if(sbSql.Length != 0)
						sbSql.Append(" AND ");

					string physicalName = primaryKey.PhysicalName;
					sbSql.Append(physicalName);
					sbSql.Append("=");
					string strVariableName = "@" + Kit.GetValidName(physicalName);
					sbSql.Append(strVariableName);

					IDataParameter parameter = this.Provider.CreateParameter(strVariableName, primaryKey.Value);
					command.Parameters.Add(parameter);
				}
				else
					throw new DQException("10015");
			}
			return sbSql.ToString();
		}

		#endregion
	}
}