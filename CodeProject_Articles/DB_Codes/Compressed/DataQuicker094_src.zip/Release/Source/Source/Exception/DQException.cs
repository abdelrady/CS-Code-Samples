// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Globalization;
using System.Security.Permissions;
using System.Data;
using System.Runtime.Serialization;
using System.Web;
using System.Xml;

using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// The exception class of DataQuicker, implementing multi-language messages and handling exception or system message.
	/// The language setting based on Session level if you developing web application. Otherwise, it's a static field.
	/// </summary>
	/// <example>
	/// <br>DQException exp = new DQException("10001");	//It will read exception descrition from message xml file by code "10001"</br>
	/// <br>throw exp;	//Throw a exception, just like class Exception.</br>
	/// <br></br>
	/// <br>throw new DQException("10001", strYourDesc)</br>
	/// <br>//DQException class will use string strYourDesc instead of {x} of the corresponding description in xml file.</br>
	/// </example>
	[Serializable]
	public class DQException: ApplicationException 
	{
		[ThreadStatic]
		private string mCode;
		private string mDescription;


		/// <summary>
		/// Call base GetObjectData() function
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		[SecurityPermissionAttribute(SecurityAction.Demand, SerializationFormatter=true)]
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			base.GetObjectData (info, context);
		}


		#region Attributes: Code, Description and Message
		/// <summary>
		/// Get code of message
		/// </summary>
		public string Code
		{
			get
			{
				return this.mCode;
			}
		}

		/// <summary>
		/// Get description of message
		/// </summary>
		public string Description
		{
			get
			{
				return this.mDescription;
			}
		}

		/// <summary>
		/// Get message, combined with message code and its description
		/// </summary>
		public override string Message
		{
			get
			{
				return "(" + this.mCode + ") " + this.mDescription;
			}
		}
		#endregion

		#region Constructors
		/// <summary>
		/// Constructor
		/// </summary>
		public DQException(){}

		/// <summary>
		/// Constructor with parameter code
		/// </summary>
		/// <param name="code">Message code</param>
		public DQException(string code): this(code, new string[0]{})
		{
		}

		/// <summary>
		/// Constructor with message code and self-defined message
		/// </summary>
		/// <param name="code">Message code</param>
		/// <param name="msg">Self-defined message, instead of {X} in the message description</param>
		public DQException(string code, params string[] msg)
		{
			Check.VerifyNotNull(code);
			this.mCode = code;
			this.mDescription = DQException.GetDescription(code);
			if(msg!=null && msg.Length!=0)
				this.mDescription = string.Format(this.mDescription, msg);
			Log.Write(this.Message, this);
		}

		/// <summary>
		/// Constructor with an inner exception
		/// </summary>
		/// <param name="exp">Inner exception</param>
		public DQException(System.Exception exp): base("", exp)
		{					
			this.mCode = "InnerException";
			this.mDescription = exp.Message.ToString ();
			Log.Write(this);
		}

		/// <summary>
		/// Constructor with message code and an inner exception
		/// </summary>
		/// <param name="code">Message code</param>
		/// <param name="exp">Inner exception</param>
		public DQException(string code, System.Exception exp): this(code, exp, null)
		{
		}

		/// <summary>
		/// Constructor with message code, seld-defined message and inner exception
		/// </summary>
		/// <param name="code">Message code</param>
		/// <param name="exp">Inner exception</param>
		/// <param name="msg">Self-defined message, instead of {X} in the message description</param>
		public DQException(string code, System.Exception exp, params string[] msg): base(code, exp)
		{
			this.mCode = code;
			this.mDescription = DQException.GetDescription(code);
			if(msg!=null && msg.Length!=0)
				this.mDescription = string.Format(this.mDescription, msg);
			Log.Write(this.Message, this);
		}

		/// <summary>
		/// Constructor with message code
		/// </summary>
		/// <param name="msg"></param>
		/// <param name="isMsg">If true, the msg doesn't stand for message code but as the description of exception</param>
		public DQException(string msg, bool isMsg)
		{
			if(isMsg)
			{
				this.mCode = "Unknown";
				this.mDescription = msg;
			}
			else
			{
				this.mCode = msg;
				this.mDescription = DQException.GetDescription(msg);
			}
			Log.Write(this.Message);
		}
		
		/// <summary>
		/// Derived constructor
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected DQException(SerializationInfo info, StreamingContext context): base(info, context){}

		#endregion

		/// <summary>
		/// Return description of message by its code in specialized language
		/// </summary>
		/// <param name="code"></param>
		/// <returns></returns>
		public static string GetDescription(string code)
		{
			BasicSection basic = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
			MessageSection messages = ConfigurationManager.Instance.GetConfig("MessageSection", typeof(MessageSection)) as MessageSection;
			return messages.GetMessage(code, basic.Language);
		}
	}
}
