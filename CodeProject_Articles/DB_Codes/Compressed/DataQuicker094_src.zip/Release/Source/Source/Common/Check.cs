// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Series of validation functions
	/// </summary>
	[Serializable]
	public sealed class Check
	{
		private Check(){}


		/// <summary>
		/// Check whether the type of each element in array is equal to source. If not, return false
		/// </summary>
		/// <param name="source"></param>
		/// <param name="array"></param>
		/// <returns></returns>
		public static void AreEqual(object source, params object[] array)
		{
			for(int i=0; i<array.Length; i++)
				if(source.GetType() != array[i].GetType())
					throw new DQException("10008");
		}


		/// <summary>
		/// Check whether the type of each element in array is equal to each other.
		/// </summary>
		/// <param name="array"></param>
		/// <returns></returns>
		public static void AreEqual(params object[] array)
		{
			for(int i=0; i<array.Length-1; i++)
				if(array[i].GetType() != array[i+1].GetType())
					throw new DQException("10009");
		}


		/// <summary>
		/// Check the amount of array whether is suitable for operator
		/// </summary>
		/// <param name="op"></param>
		/// <param name="array"></param>
		/// <returns></returns>
		public static void CheckExpression(SqlOperator op, params object[] array)
		{
			if(op != SqlOperator.In && op != SqlOperator.NotIn && array.Length>1)
				throw new DQException("10010");
			if(array.Length <= 0)
				throw new DQException("10022");
		}


		/// <summary>
		/// This method is used to perform assertions. If arguement is null, it will throw DQException("10004")
		/// </summary>
		/// <param name="arguement"></param>
		public static void VerifyNotNull(object arguement)
		{
			if(arguement == null)
				throw new DQException("10004");
		}


		/// <summary>
		/// Verify the entity whether has been disposed, if so, it will throw exception
		/// </summary>
		/// <param name="entity"></param>
		public static void VerifyDisposed(EntityMapping entity)
		{
			if(entity.mHasDisposed == true)
				throw new DQException("10028");
		}


		/// <summary>
		/// Verify entity when update.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public static void VerifyUpdateValid(TableMapping entity)
		{
			Check.VerifyDisposed(entity);

			if(entity.Exist == false || entity.PrimaryKeys.IsNull)
				throw new DQException("10025");

			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Value as FieldMapping;

				if(field.mAllowNull == false && field.mHasDefaultValue == false && field.IsNull == true)
					throw new DQException("10027", field.ToString(), field.PhysicalName);
				else if(field.IsValid == false)
					throw new DQException("10027", field.ToString(), field.PhysicalName);
				else if(field.IsPrimaryKey==true && field.IsNull==true)
					throw new DQException("10027", field.ToString(), field.PhysicalName);
			}
		}


		/// <summary>
		/// Verify entity when insert.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public static void VerifyInsertValid(TableMapping entity)
		{
			Check.VerifyDisposed(entity);

			if(entity.Exist==true)
				throw new DQException("10017");

			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping field = enumerator.Value as FieldMapping;

				if(field.IsPrimaryKey==false && field.mAllowNull == false && field.mHasDefaultValue == false && field.IsNull == true)
					throw new DQException("10031", entity.ToString(), field.PhysicalName);
				else if(field.IsPrimaryKey==false && field.IsValid == false)
					throw new DQException("10031", entity.ToString(), field.PhysicalName);
			}
		}


		/// <summary>
		/// Verify <seealso cref="Query"/> object.
		/// </summary>
		/// <param name="query"></param>
		public static void VerifyQueryValid(Query query)
		{
			Check.VerifyNotNull(query);

			//There is no select column exists
			if(query.Selects.Count==0 && query.Selects.None==true && query.Aggregates.Count==0)
				throw new DQException("10021");
		}


		/// <summary>
		/// Verify entity when it needs to delete.
		/// </summary>
		/// <param name="entity"></param>
		public static void VerifyDeleteValid(TableMapping entity)
		{
			Check.VerifyDisposed(entity);

			if(entity.mExist==false || entity.PrimaryKeys.IsNull)
				throw new DQException("10032");
		}


		/// <summary>
		/// Verify entity is valid when retrieve it.
		/// </summary>
		/// <param name="entity"></param>
		public static void VerifyRetrieve(EntityMapping entity)
		{
			Check.VerifyDisposed(entity);

			if(entity.IsValueChanged==false)
				throw new DQException("10034");
		}


		/// <summary>
		/// Verify the design of primary keys
		/// </summary>
		/// <param name="entity"></param>
		public static void VerifyPrimaryKeyDesign(EntityMapping entity)
		{
			int count = entity.PrimaryKeys.Count;
			IEnumerator enumerator = entity.PrimaryKeys.GetEnumerator();
			while(enumerator.MoveNext())
			{
				FieldMapping primaryKey = enumerator.Current as FieldMapping;
				if(count>1 && (primaryKey.PrimaryKeyType!=PrimaryKeyType.None || primaryKey.IsAutoIncrease))
					throw new DQException("10020", entity.ToString());

				if(primaryKey.PrimaryKeyType==PrimaryKeyType.Guid && !(primaryKey is FString))
					throw new DQException("10047", entity.ToString());

				if(primaryKey.PrimaryKeyType==PrimaryKeyType.DQIncrease && !(primaryKey is FString || primaryKey is FInt))
					throw new DQException("10030", entity.ToString());
			}
		}


		/// <summary>
		/// Verify repeated columns' name in entity class
		/// </summary>
		/// <param name="entity"></param>
		public static void VerifyRepeatColumnName(EntityMapping entity)
		{
			StringCollection columnNames = new StringCollection();
			IMappingEnumerator enumerator = entity.FieldList.GetEnumerator();
			while(enumerator.MoveNext())
			{
				if(columnNames.Contains(Kit.GetValidName(enumerator.Value.PhysicalName)) == true)
					throw new DQException("10054", enumerator.Value.ParentEntity.ToString());
				else
					columnNames.Add(Kit.GetValidName(enumerator.Value.PhysicalName));
			}
		}
	}
}
