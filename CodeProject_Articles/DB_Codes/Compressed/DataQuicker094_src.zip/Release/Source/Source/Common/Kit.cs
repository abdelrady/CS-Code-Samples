// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Text;
using System.Data;
using System.Collections;
using System.Reflection;
using System.Globalization;
using System.Text.RegularExpressions;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Kit for common methods
	/// </summary>
	[Serializable]
	public sealed class Kit
	{
		private Kit(){}

		/// <summary>
		/// Return true when the string is empty or null.
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public static bool IsEmpty(string arg)
		{
			return arg==null || arg.Trim().Length ==0;
		}


		/// <summary>
		/// Return true when the arguement is empty or null.
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public static bool IsEmpty(object arg)
		{
			return arg==null || arg.ToString().Length ==0;
		}


		/// <summary>
		/// Get true when the field is text type
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		public static bool IsTextType(FieldMapping field)
		{
			return field is FString || field is FDateTime;
		}


		/// <summary>
		/// Transform string to a valid variable format.
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		public static string GetValidName(string text)
		{
			string strValidName = Kit.Trim(text, '[', ']', ' ', '\'', '.');
			strValidName = strValidName[0].ToString().ToUpper() + strValidName.Substring(1);
			return strValidName;
		}


		/// <summary>
		/// Bracket arguement taken to avoid reserved or petential invalid word.
		/// </summary>
		/// <param name="taken"></param>
		/// <returns></returns>
		public static string BracketWord(string taken)
		{
			return "[" + taken + "]";
		}


		/// <summary>
		/// Trim chars included in arguement oldValue.
		/// </summary>
		/// <param name="oldValue"></param>
		/// <param name="trimChars"></param>
		/// <returns></returns>
		public static string Trim(string oldValue, params char[] trimChars)
		{
			StringBuilder sbNewValue = new StringBuilder();
			foreach(char c in oldValue)
			{
				bool suited = false;
				foreach(char trimChar in trimChars)
				{
					if(c==trimChar) suited = true;
				}

				if(!suited) sbNewValue.Append(c);
			}
			return sbNewValue.ToString();
		}

		/// <summary>
		/// Return true when the argument is valid variable name.
		/// </summary>
		/// <param name="taken"></param>
		/// <returns></returns>
		public static bool IsValid(string taken)
		{
			Regex regex = new Regex(@"^[_|a-z|A-Z]+[\w|\40]*$");
			return regex.IsMatch(taken);
		}

		/// <summary>
		/// Get local file path
		/// </summary>
		/// <param name="path"></param>
		/// <returns></returns>
		public static string GetLocalPath(string path)
		{
			string strPath = path;
			if(!File.Exists(strPath))
			{
				strPath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "\\" + strPath;
				if(!File.Exists(strPath))
					return null;
			}
			return strPath;
		}

		/// <summary>
		/// Read physical file to array of byte.
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		public static byte[] ReadToBytes(string fileName)
		{
			FileStream fs = new FileStream(fileName, FileMode.Open);
			try
			{
				byte[] content = new byte[fs.Length];
				fs.Read(content, 0, (int) fs.Length);
				return content;
			}
			finally
			{
				fs.Close();
			}
		}
	}
}
