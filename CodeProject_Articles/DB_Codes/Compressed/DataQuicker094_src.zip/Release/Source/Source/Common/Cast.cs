// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Data;
using System.Globalization;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Convertion Methods Collection
	/// </summary>
	public sealed class Cast
	{
		private Cast()
		{
		}


		/// <summary>
		/// Convert Cshape basic type to DbType
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static DbType ToDbType(Type type)
		{
			DbType dbType = DbType.String;

			// string
			if (type == typeof(string))
				dbType = DbType.String;

				// boolean
			else if (type == typeof(bool))
				dbType = DbType.Boolean;

				// byte
			else if (type == typeof(sbyte))
				dbType = DbType.SByte;
			else if (type == typeof(byte))
				dbType = DbType.Byte;

				//byte[]
			else if (type == typeof(byte[]))
				dbType = DbType.Binary;

				// integer
			else if (type == typeof(short))
				dbType = DbType.Int16;
			else if (type == typeof(ushort))
				dbType = DbType.UInt16;
			else if (type == typeof(int))
				dbType = DbType.Int32;
			else if (type == typeof(uint))
				dbType = DbType.UInt32;
			else if (type == typeof(long))
				dbType = DbType.Int64;
			else if (type == typeof(ulong))
				dbType = DbType.UInt64;  

				// float
			else if (type == typeof(float))
				dbType = DbType.Double;
			else if (type == typeof(decimal))
				dbType = DbType.Decimal;
			else if (type == typeof(double))
				dbType = DbType.Double;

				// date
			else if (type == typeof(DateTime))
				dbType = DbType.DateTime;
			else if (type == typeof(bool))
				dbType = DbType.Boolean;

			else 
				dbType = DbType.Object;

			return dbType;
		}


		/// <summary>
		/// Cast FieldMapping type to C# type
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		public static Type ToCSharpType(FieldMapping field)
		{
			if(field is FString)
				return typeof(string);

			if(field is FInt)
				return typeof(int);

			if(field is FDecimal)
				return typeof(decimal);

			if(field is FDateTime)
				return typeof(DateTime);

			if(field is FBool)
				return typeof(bool);

			if(field is FDouble)
				return typeof(double);

			if(field is FImage)
				return typeof(byte[]);

			return typeof(string);
		}


		/// <summary>
		/// Cast object arg to bool type
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public static bool ToBool(object arg)
		{
			if(arg==null) return false;

			if(arg is bool) return (bool)arg;
			
			try
			{
				return (int)arg != 0;
			}
			catch(System.InvalidCastException)
			{
			}

			string strBool = arg.ToString().ToUpper();
			try
			{
				return bool.Parse(strBool);
			}
			catch(System.FormatException)
			{
				return false;
			}
		}


		/// <summary>
		/// Cast DataTable object to string
		/// </summary>
		/// <param name="dt"></param>
		/// <returns></returns>
		public static string DataTableToString(DataTable dt)
		{
			StringBuilder sbStr = new StringBuilder();
			for(int i=0; i<dt.Rows.Count; i++)
			{
				for(int j=0; j<dt.Columns.Count; j++)
				{
					sbStr.Append(dt.Rows[i][j].ToString());
					sbStr.Append("\t");
				}
				sbStr.Append("\r\n");
			}
			return sbStr.ToString();
		}


		/// <summary>
		/// Cast DataReader to DataTable. It will close DataReader object automatically after transformation.
		/// </summary>
		/// <param name="reader"></param>
		/// <returns></returns>
		public static DataTable Reader2Table(System.Data.IDataReader reader)
		{
			Check.VerifyNotNull(reader);
			DataTable dt = new DataTable();
			dt.Locale = CultureInfo.CurrentCulture;
			DataRowCollection drows = reader.GetSchemaTable().Rows;
			foreach(DataRow drow in drows)
			{
				DataColumn dcol = new DataColumn();
				dcol.ColumnName = drow["ColumnName"].ToString();
				dcol.Unique = Convert.ToBoolean(drow["IsUnique"]);
				dcol.AllowDBNull = Convert.ToBoolean(drow["AllowDBNull"]);
				dcol.ReadOnly = Convert.ToBoolean(drow["IsReadOnly"]);
				dcol.DataType = drow["DataType"] as Type;
				dt.Columns.Add(dcol);
			}

			while(reader.Read())
			{
				DataRow drow = dt.NewRow();
				foreach(DataColumn dcol in dt.Columns)
					drow[dcol] = reader[dcol.ColumnName];
				dt.Rows.Add(drow);
			}
			reader.Close();
			return dt;
		}

	}
}