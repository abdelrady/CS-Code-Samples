// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Association between two tables/views
	/// </summary>
	public class Association
	{
		private AssociationType mType = AssociationType.Inner;
		private FieldMapping[] mCurrents;
		private FieldMapping[] mDestinations;
	
		/// <summary>
		/// Create an association between two tables/views
		/// </summary>
		/// <param name="currents">The columns in current table/view</param>
		/// <param name="type">Joint type, the candidates are: Inner, Left and Right</param>
		/// <param name="destinations">The destination columns</param>
		public Association(FieldMapping[] currents, AssociationType type, FieldMapping[] destinations)
		{
			this.mCurrents = currents;
			this.mDestinations = destinations;
			this.mType = type;
		}

		/// <summary>
		/// Create an association between two tables/views, the default joint type is <b>Inner Joint</b>.
		/// </summary>
		/// <param name="currents"></param>
		/// <param name="destinations"></param>
		public Association(FieldMapping[] currents, FieldMapping[] destinations): this(currents, AssociationType.Inner, destinations)
		{
		}

		/// <summary>
		/// Get the association type between two tables/views.
		/// </summary>
		public AssociationType Type
		{
			get
			{
				return this.mType;
			}
		}

		/// <summary>
		/// Get the destination columns
		/// </summary>
		public FieldMapping[] Currents
		{
			get
			{
				return this.mCurrents;
			}
		}

		/// <summary>
		/// Get the destination columns
		/// </summary>
		public FieldMapping[] Destinations
		{
			get
			{
				return this.mDestinations;
			}
		}
	}
}