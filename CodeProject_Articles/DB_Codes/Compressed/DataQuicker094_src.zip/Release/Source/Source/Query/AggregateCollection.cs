// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// AggregateCollection, stores all aggregate columns when querying
	/// </summary>
	public class AggregateCollection
	{
		private ArrayList mAggregates = new ArrayList();

		/// <summary>
		/// Constructor
		/// </summary>
		public AggregateCollection()
		{
		}

		/// <summary>
		/// Get count of aggregate columns
		/// </summary>
		public int Count
		{
			get
			{
				return this.mAggregates.Count;
			}
		}

		/// <summary>
		/// Add aggregate function and expression
		/// </summary>
		/// <param name="type"></param>
		/// <param name="aliasName"></param>
		/// <param name="operands"></param>
		public void Add(AggregateType type, string aliasName, params object[] operands)
		{
			object[] objects = null;

			if(operands!=null)
			{
				if(operands[0] is Array)
				{
					Array array = operands[0] as Array;
					objects = new object[array.Length];
					for(int i=0; i<objects.Length; i++)
						objects[i] = array.GetValue(i);
				}
				else
					objects = operands;
			}

			Aggregate aggregate = new Aggregate(aliasName, type, objects);

			this.mAggregates.Add(aggregate);
		}

		/// <summary>
		/// Add aggregate function and expression
		/// </summary>
		/// <param name="type"></param>
		/// <param name="operands"></param>
		public void Add(AggregateType type, params object[] operands)
		{
			object[] objects = null;

			if(operands!=null)
			{
				if(operands[0] is Array)
				{
					Array array = operands[0] as Array;
					objects = new object[array.Length];
					for(int i=0; i<objects.Length; i++)
						objects[i] = array.GetValue(i);
				}
				else
					objects = operands;
			}

			Aggregate aggregate = new Aggregate(type, objects);

			this.mAggregates.Add(aggregate);
		}

		/// <summary>
		/// Clear all aggregate columns
		/// </summary>
		public void Clear()
		{
			this.mAggregates.Clear();
		}

		/// <summary>
		/// Remove aggregate column by indexer
		/// </summary>
		/// <param name="index"></param>
		public void RemoveAt(int index)
		{
			this.mAggregates.RemoveAt(index);
		}

		/// <summary>
		/// Get enumerator
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return this.mAggregates.GetEnumerator();
		}
	}
}
