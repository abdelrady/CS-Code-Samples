// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// OrderByColumnCollection, stores all order by columns in the query
	/// </summary>
	public class OrderByColumnCollection
	{
		private ArrayList mOrderByColumns = new ArrayList();

		/// <summary>
		/// Constructor
		/// </summary>
		public OrderByColumnCollection()
		{
		}

		/// <summary>
		/// Get count of order by columns
		/// </summary>
		public int Count
		{
			get
			{
				return this.mOrderByColumns.Count;
			}
		}

		/// <summary>
		/// Add order by column, the default order is ascending
		/// </summary>
		/// <param name="field"></param>
		public void Add(FieldMapping field)
		{
			this.Add(field, true);
		}

		/// <summary>
		/// Add order by column
		/// </summary>
		/// <param name="field"></param>
		/// <param name="ascending"></param>
		public void Add(FieldMapping field, bool ascending)
		{
			OrderByColumn orderBy = new OrderByColumn(field, ascending);
			this.mOrderByColumns.Add(orderBy);
		}

		/// <summary>
		/// Clear all order by columns
		/// </summary>
		public void Clear()
		{
			this.mOrderByColumns.Clear();
		}

		/// <summary>
		/// Remove order by column by indexer
		/// </summary>
		/// <param name="index"></param>
		public void RemoveAt(int index)
		{
			this.RemoveAt(index);
		}

		/// <summary>
		/// Get enumerator
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return this.mOrderByColumns.GetEnumerator();
		}
	}
}
