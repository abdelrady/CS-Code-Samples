// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Query, used to query database to get records collection, such as DataTable object
	/// </summary>
	[Serializable]
	public class Query
	{
		private EntityMapping mTarget;
		private SelectCollection mSelectColumns = new SelectCollection();
		private AssociationCollection mAssociations;
		private CriteriaCollection mCriteria = new CriteriaCollection();
		private AggregateCollection mAggregateColumns = new AggregateCollection();
		private OrderByColumnCollection mOrderByColumns = new OrderByColumnCollection();
		private FieldCollection mGroupByColumns = new FieldCollection();

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="entity"></param>
		public Query(EntityMapping entity)
		{
			Check.VerifyNotNull(entity);
			this.mTarget = entity;
			this.mAssociations = new AssociationCollection(entity);
		}

		/// <summary>
		/// Get <seealso cref="EntityMapping"/> target.
		/// </summary>
		public EntityMapping Target
		{
			get
			{
				return this.mTarget;
			}
		}

		/// <summary>
		/// Get order by column collection.<br/>
		/// Indicate the orders by column through setting the inner methods and properties of <seealso cref="OrderByColumnCollection"/>.
		/// </summary>
		public OrderByColumnCollection OrderBy
		{
			get
			{
				return this.mOrderByColumns;
			}
		}

		/// <summary>
		/// Get conditions collection.<br/>
		/// Indicate the query conditions through setting the inner methods and properties of <seealso cref="CriteriaCollection"/>.
		/// </summary>
		public CriteriaCollection Criteria
		{
			get
			{
				return this.mCriteria;
			}
		}

		/// <summary>
		/// Get group by column collection.<br/>
		/// Indicate the group by columns through setting the inner methods and properties of <seealso cref="FieldCollection"/>.
		/// </summary>
		public FieldCollection GroupBy
		{
			get
			{
				return this.mGroupByColumns;
			}
		}

		/// <summary>
		/// Get aggregate column collection.<br/>
		/// Indicate the aggregate columns through setting the inner methods and properties of <seealso cref="AggregateCollection"/>.
		/// </summary>
		public AggregateCollection Aggregates
		{
			get
			{
				return this.mAggregateColumns;
			}
		}

		/// <summary>
		/// Get select columns collection.<br/>
		/// Indicate the select columns through setting the inner methods and properties of <seealso cref="FieldCollection"/>.
		/// </summary>
		public SelectCollection Selects
		{
			get
			{
				return this.mSelectColumns;
			}
		}

		/// <summary>
		/// Get associations collection.<br/>
		/// Indicate the association on tables/views through setting the inner methods and properties of <seealso cref="AssociationCollection"/>.
		/// </summary>
		public AssociationCollection Associations
		{
			get
			{
				return this.mAssociations;
			}
		}
	}
}