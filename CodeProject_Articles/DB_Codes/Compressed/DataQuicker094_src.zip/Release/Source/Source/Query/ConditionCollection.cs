// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// ConditionCollection used to store condition settings on field, being analyzd by the IAnalyze when generating the SQL
	/// </summary>
	[Serializable]
	public class CriteriaCollection
	{
		private ArrayList mConditions = new ArrayList();
		private SqlConnector mConnector = SqlConnector.And;

		/// <summary>
		/// Constructor
		/// </summary>
		public CriteriaCollection()
		{
		}
		

		/// <summary>
		/// Get <seealso cref="SqlConnector"/> of current ConditionCollection object
		/// </summary>
		public SqlConnector Connector
		{
			get
			{
				return this.mConnector;
			}
		}

		/// <summary>
		/// Add a condition setting
		/// </summary>
		/// <param name="field"></param>
		/// <param name="connector"></param>
		/// <param name="op"></param>
		/// <param name="values"></param>
		public void Add(SqlConnector connector, FieldMapping field, SqlOperator op, params object[] values)
		{
			Check.VerifyNotNull(field);
			Check.VerifyNotNull(values);
			Check.AreEqual(values);

			if(values.Length == 0)
				throw new DQException("10049");

			object[] objects = null;

			if(values[0] is Array)
			{
				Array array = values[0] as Array;
				objects = new object[array.Length];
				for(int i=0; i<objects.Length; i++)
					objects[i] = array.GetValue(i);
			}
			else
				objects = values;

			Check.CheckExpression(op, objects);

			Criteria condition = new Criteria(connector, field, op, objects);
			this.mConditions.Add(condition);
		}

		/// <summary>
		/// Add a condition setting
		/// </summary>
		/// <param name="connector"></param>
		/// <param name="field"></param>
		/// <param name="op"></param>
		/// <param name="values"></param>
		public void Add(SqlConnector connector, FieldMapping field, SqlOperator op, params FieldMapping[] values)
		{
			this.Add(connector, field, op, values);
		}

		/// <summary>
		/// Add a condition setting. The arguement <b>conditions</b> takes as the child node of current conditions collection.
		/// </summary>
		/// <param name="connector"></param>
		/// <param name="conditions"></param>
		public void Add(SqlConnector connector, CriteriaCollection conditions)
		{
			conditions.mConnector = connector;
			this.mConditions.Add(conditions);
		}

		/// <summary>
		/// Add a condition setting
		/// </summary>
		/// <param name="field"></param>
		/// <param name="op"></param>
		/// <param name="values"></param>
		public void Add(FieldMapping field, SqlOperator op, params object[] values)
		{
			object[] objs = null;

			if(values[0] is Array)
			{
				Array array = values[0] as Array;
				objs = new object[array.Length];
				for(int i=0; i<objs.Length; i++)
					objs[i] = array.GetValue(i);
			}
			else
				objs = values;

			this.Add(SqlConnector.And, field, op, objs);
		}

		/// <summary>
		/// Add a condition setting
		/// </summary>
		/// <param name="field"></param>
		/// <param name="op"></param>
		/// <param name="values"></param>
		public void Add(FieldMapping field, SqlOperator op, params FieldMapping[] values)
		{
			this.Add(SqlConnector.And, field, op, values);
		}

		/// <summary>
		/// Add a condition setting. The arguement <b>conditions</b> takes as the child node of current conditions collection.
		/// </summary>
		/// <param name="conditions"></param>
		public void Add(CriteriaCollection conditions)
		{
			this.Add(SqlConnector.And, conditions);
		}

		/// <summary>
		/// Clear all conditions
		/// </summary>
		public void Clear()
		{
			this.mConditions.Clear();
		}

		/// <summary>
		/// Get IEnumerator interface
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return this.mConditions.GetEnumerator();
		}

		/// <summary>
		/// Get the count of elements
		/// </summary>
		public int Count
		{
			get
			{
				return this.mConditions.Count;
			}
		}


		/// <summary>
		/// Inner condition item of class ConditionCollection
		/// </summary>
		internal class Criteria
		{
			private FieldMapping mField;
			private SqlConnector mConnector;
			private SqlOperator mOperator;
			private object[] mValues;

			/// <summary>
			/// Constructor
			/// </summary>
			/// <param name="field"></param>
			/// <param name="connector"></param>
			/// <param name="op"></param>
			/// <param name="values"></param>
			public Criteria(SqlConnector connector, FieldMapping field, SqlOperator op, params object[] values)
			{
				this.mField = field;
				this.mConnector = connector;
				this.mOperator = op;
				this.mValues = values;
			}

			/// <summary>
			/// Get connector
			/// </summary>
			public SqlConnector Connector
			{
				get
				{
					return this.mConnector;
				}
			}

			/// <summary>
			/// Get first operand, FieldMapping type
			/// </summary>
			public FieldMapping Field
			{
				get
				{
					return this.mField;
				}
			}

			/// <summary>
			/// Get operator
			/// </summary>
			public SqlOperator Operator
			{
				get
				{
					return this.mOperator;
				}
			}

			/// <summary>
			/// Get operands
			/// </summary>
			public object[] Values
			{
				get
				{
					return this.mValues;
				}
			}
		}
	}
}
