// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Order by object
	/// </summary>
	internal class OrderByColumn
	{
		private FieldMapping mColumn;
		private bool mAscending;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="field"></param>
		/// <param name="ascending"></param>
		public OrderByColumn(FieldMapping field, bool ascending)
		{
			this.mColumn = field;
			this.mAscending = ascending;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="field"></param>
		public OrderByColumn(FieldMapping field)
		{
			this.mColumn = field;
		}

		/// <summary>
		/// Get field object
		/// </summary>
		public FieldMapping Column
		{
			get
			{
				return this.mColumn;
			}
		}

		/// <summary>
		/// Get true when the order is ascending
		/// </summary>
		public bool Ascending
		{
			get
			{
				return this.mAscending;
			}
		}
	}
}
