// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// FAggregate, wraps aggregate function on columns. 
	/// If we want to apply aggregate function on special columns, we should construct FAggregate object with FieldMapping object.
	/// </summary>
	public class Aggregate
	{
		private string mAliasName;
		private AggregateType mType = AggregateType.Add;
		private object[] mOperands;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="type">Aggregate function enumerative type</param>
		/// <param name="operands">Operands</param>
		public Aggregate(AggregateType type, params object[] operands)
		{
			this.mType = type;
			if(operands!=null)
			{
				object[] objects = null;

				if(operands[0] is Array)
				{
					Array array = operands[0] as Array;
					objects = new object[array.Length];
					for(int i=0; i<objects.Length; i++)
						objects[i] = array.GetValue(i);
				}
				else
					objects = operands;

				this.mOperands = objects;
			}
			else 
				this.mOperands = new object[1]{null};
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="aliasName"></param>
		/// <param name="type">Aggregate function enumerative type</param>
		/// <param name="operands">Operands</param>
		public Aggregate(string aliasName, AggregateType type, params object[] operands)
		{
			this.mType = type;
			this.AliasName = aliasName;
			if(operands!=null)
			{
				object[] objects = null;
				if(operands[0] is Array)
				{
					Array array = operands[0] as Array;
					objects = new object[array.Length];
					for(int i=0; i<objects.Length; i++)
						objects[i] = array.GetValue(i);
				}
				else
					objects = operands;

				this.mOperands = objects;
			}
			else 
				this.mOperands = new object[1]{null};
		}

		/// <summary>
		/// Get aggregate function
		/// </summary>
		public AggregateType Type
		{
			get
			{
				return this.mType;
			}
		}

		/// <summary>
		/// Get operands
		/// </summary>
		public object[] Operands
		{
			get
			{
				return this.mOperands;
			}
		}

		/// <summary>
		/// Set/Get alias name
		/// </summary>
		public string AliasName
		{
			get
			{
				return this.mAliasName;
			}
			set
			{
				Check.VerifyNotNull(value);
				this.mAliasName = value;
			}
		}
	}
}
