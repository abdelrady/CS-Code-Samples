// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// AssociationCollection, stores relation between two tables/views when querying.
	/// </summary>
	public class AssociationCollection
	{
		private ArrayList mAssociations = new ArrayList();
		private EntityMapping mMasterEntity;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="master"></param>
		public AssociationCollection(EntityMapping master)
		{
			this.mMasterEntity = master;
		}

		/// <summary>
		/// Create an association between two tables/views based on arguements <b>currents</b> and <b>destinations</b>.<br/>
		/// The arguement <b>currents</b> and <b>destinations</b> must match to each other completely.
		/// </summary>
		/// <param name="currents">The columns in current table/view</param>
		/// <param name="type">Joint type, the candidates are: Inner, Left and Right</param>
		/// <param name="destinations">The destination columns</param>
		public void Add(FieldMapping[] currents, AssociationType type, FieldMapping[] destinations)
		{
			Check.VerifyNotNull(currents);
			Check.VerifyNotNull(destinations);

			if(currents.Length==0 || currents.Length!=destinations.Length)
				throw new DQException("10053");

			//Ensure MasterEntity is the parent entity of all FieldMapping objects in arguement currents
			foreach(FieldMapping current in currents)
				if(current.ParentEntity != this.mMasterEntity)
					throw new DQException("10057");

			//Ensure each FieldMapping object in current matchs to destinations
			for(int i=0; i<currents.Length; i++)
			{
				if(currents[i].GetType() != destinations[i].GetType())
					throw new DQException("10053");
			}

			//The parent entity of all objects in arguement destinations should be same.
			foreach(FieldMapping field in destinations)
			{
				if(field.ParentEntity!=destinations[0].ParentEntity)
					throw new DQException("10056");
			}

			Association association;

			//The table/view name in query collection should be unique.
			IEnumerator enumerator = this.GetEnumerator();
			while(enumerator.MoveNext())
			{
				association = enumerator.Current as Association;
				if(association.Destinations[0].ParentEntity.AliasName==destinations[0].ParentEntity.AliasName)
					throw new DQException("10058");
			}

			association = new Association(currents, type, destinations);
			this.mAssociations.Add(association);
		}

		/// <summary>
		/// Create an association between two tables/views based on arguements <b>currents</b> and <b>destinations</b>.<br/>
		/// The default association type is <b>Inner Join</b>.<br/>
		/// The arguement <b>currents</b> and <b>destinations</b> must match to each other completely.
		/// </summary>
		/// <param name="currents">The columns in current table/view</param>
		/// <param name="destinations">The destination columns</param>
		public void Add(FieldMapping[] currents, FieldMapping[] destinations)
		{
			this.Add(currents, AssociationType.Inner, destinations);
		}

		/// <summary>
		/// Clear all associations.
		/// </summary>
		public void Clear()
		{
			this.mAssociations.Clear();
		}

		/// <summary>
		/// Remove association at position <b>index</b>.
		/// </summary>
		/// <param name="index"></param>
		public void RemoveAt(int index)
		{
			this.mAssociations.RemoveAt(index);
		}

		/// <summary>
		/// Get IEnumerator entry of current object.
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return this.mAssociations.GetEnumerator();
		}

		/// <summary>
		/// Get the association object based on <b>index</b>.
		/// </summary>
		public Association this[int index]
		{
			get
			{
				return this.mAssociations[index] as Association;
			}
		}

		/// <summary>
		/// Get count of association
		/// </summary>
		public int Count
		{
			get
			{
				return this.mAssociations.Count;
			}
		}

		/// <summary>
		/// Get master entity
		/// </summary>
		public EntityMapping MasterEntity
		{
			get
			{
				return this.mMasterEntity;
			}
		}
	}
}
