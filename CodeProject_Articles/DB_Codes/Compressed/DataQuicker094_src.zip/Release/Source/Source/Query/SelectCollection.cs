// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// SelectCollection, stores select columns in <seealso cref="Query"/> object.
	/// </summary>
	public class SelectCollection: FieldCollection
	{
		private bool mNone;
		private bool mDistinct;
		private int mTop = -1;

		/// <summary>
		/// Set/Get true when select nothing when querying. The default value is false.
		/// </summary>
		public bool None
		{
			get
			{
				return this.mNone;
			}
			set
			{
				this.mNone = value;
			}
		}

		/// <summary>
		/// Set/Get true to only select distinct records when query
		/// </summary>
		public bool Distinct
		{
			get
			{
				return this.mDistinct;
			}
			set
			{
				this.mDistinct = value;
			}
		}

		/// <summary>
		/// Set/Get top select records count
		/// </summary>
		public int Top
		{
			get
			{
				return this.mTop;
			}
			set
			{
				this.mTop = value;
			}
		}

		/// <summary>
		/// Constructor
		/// </summary>
		public SelectCollection()
		{
		}

		/// <summary>
		/// Add columns
		/// </summary>
		/// <param name="fields"></param>
		public void Add(params FieldMapping[] fields)
		{
			Check.VerifyNotNull(fields);
			foreach(FieldMapping field in fields)
			{
				Check.VerifyNotNull(field);
				base.Add(field);
			}
		}
	}
}
