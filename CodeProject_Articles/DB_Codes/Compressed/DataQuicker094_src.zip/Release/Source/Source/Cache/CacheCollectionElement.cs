// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Weak reference for object
	/// </summary>
	[Serializable]
	internal class CacheCollectionElement
	{
		private WeakReference mValue;

		/// <summary>
		/// Construct an element of cache
		/// </summary>
		/// <param name="value">Life time</param>
		public CacheCollectionElement(object value)
		{
			this.mValue = new WeakReference(value);
		}

		/// <summary>
		/// Set/Get cached object
		/// </summary>
		public object Value
		{
			get 
			{ 
				return this.mValue.Target; 
			}
		}

		/// <summary>
		/// Get the cache element whether has been collected by GC
		/// </summary>
		public bool IsCollected
		{
			get
			{
				return !this.mValue.IsAlive;
			}
		}

		/// <summary>
		/// Judge whether two element are equal
		/// </summary>
		/// <param name="obj"></param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			if(obj == null || this.IsCollected || !(obj is CacheCollectionElement))
				return false;

			CacheCollectionElement element = obj as CacheCollectionElement;

			return this.Value == element.Value;
		}

		/// <summary>
		/// Return the hash code of current element
		/// </summary>
		/// <returns></returns>
		public override int GetHashCode()
		{
			if(this.IsCollected)
				return int.MinValue;
			return this.Value.GetHashCode();
		}

	}
}
