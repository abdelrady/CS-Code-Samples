// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Threading;
using System.Reflection;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// This is an inner class to parse inner customer attribute set on enum type such as SqlOperator, SqlConnector and JointType
	/// </summary>
	[Serializable]
	internal sealed class EnumCustomAttributeCache
	{
		[ThreadStatic]
		private static Hashtable mEnumItems = new Hashtable();

		private EnumCustomAttributeCache()
		{
		}

		/// <summary>
		/// Add a group including enum item and its customer attributes
		/// </summary>
		/// <param name="arg"></param>
		/// <param name="attribute"></param>
		private static void Add(object arg, string attribute)
		{
			EnumCustomAttributeCache.mEnumItems[arg] = attribute;
		}

		/// <summary>
		/// Parse the customer attribute on enum item
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public static string GetCustomAttribute(object arg)
		{
			if(EnumCustomAttributeCache.mEnumItems.ContainsKey(arg))
				return EnumCustomAttributeCache.mEnumItems[arg] as string;
			else
			{
				string strCustomAttribute = EnumCustomAttributeCache.GetAttribute(arg);
				EnumCustomAttributeCache.Add(arg, strCustomAttribute);
				return strCustomAttribute;
			}
		}

		/// <summary>
		/// Get the value of customer attribute on enum item. (Arguement arg)
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		private static string GetAttribute(object arg)
		{
			Type type = arg.GetType();
			MemberInfo[] members = type.GetMember(arg.ToString());
			if(members == null || members.Length == 0)
				return "";
			MemberInfo member = members[0];
			object[] attributes = member.GetCustomAttributes(false);
			if(attributes==null || attributes.Length == 0)
				return "";
			foreach(object attribute in attributes)
			{
				if(attribute.GetType() == typeof(EnumAttribute))
				{
					return (attribute as EnumAttribute).Enum;
				}
			}
			return "";
		}
	}
}

