// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections.Specialized;
using System.Collections;
using System.Text;
using System.Threading;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// A general purpose in-memory cache that provides transient storage for any number of arbritrary objects.
	/// </summary>
	/// <remarks>
	/// One instance of this class is created per application domain, and it remains valid as 
	/// long as the application domain remains active.
	/// </remarks>
	/// <example>
	/// The following example illustrates inserting items into the cache, retrieving items from the cache and iterating over the cache:
	/// <code>
	/// void ExerciseCache()
	/// {
	///	string strName = "Eunge";
	///	int count = 2;
	///	CacheManagement.Instance.Insert(strName);
	///	CacheManagement.Instance.Insert(count);
	/// CacheManagement.ToString();	//ToString() will return the detail information of current Cache
	/// Cache.Instance.Clear(); // remove all items from cache
	/// }
	/// </code>
	/// </example>
	public sealed class CacheManagement : IEnumerable
	{
		// We use a public static readonly field for providing singleton access to the cache. This technique takes advantage 
		// of the fact the the CLR will only initialize readonly fields if they are called and also that the CLR guarantees 
		// thread synchronization for static type initialization.  The alternative is to use a static volatile (for thread safety)
		// instance field and a readonly Instance property that uses the common "double-check locking" pattern seen in most Java
		// implementations (although it actually works correctly in .NET).  
		private static readonly CacheManagement mInstance = new CacheManagement();
		private static int mMaxCacheObjectCount = 10000;
		private static bool mExplicitObjectCheck;
		private HybridDictionary mData;
		private ReaderWriterLock mReadAndWriteLock;

		private CacheManagement()
		{
			this.mData = new HybridDictionary();
			this.mReadAndWriteLock = new ReaderWriterLock();
		}


		/// <summary>Retrieves a cache enumerator used to iterate through the key settings and their values contained in the cache.</summary>
		/// <returns>An enumerator to iterate through the cache objects.</returns>
		public ICacheEnumerator GetEnumerator()
		{
			this.Purge();

			return new CacheEnumerator(mData.GetEnumerator());
		}


		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}


		internal ReaderWriterLock ReadAndWriteLock
		{
			get
			{
				return this.mReadAndWriteLock;
			}
		}


		/// <summary>
		/// Provides access to a singleton instance
		/// </summary>
		public static CacheManagement Instance
		{
			get
			{
				return CacheManagement.mInstance;
			}
		}


		/// <summary>
		/// Get/Set the max count of cached object
		/// </summary>
		public static int MaxCacheObjectCount
		{
			get
			{
				return CacheManagement.mMaxCacheObjectCount;
			}
			set
			{
				CacheManagement.mMaxCacheObjectCount = value;
			}
		}


		/// <summary>
		/// <Br>Set/Get whether open explicit object check when insert an object into cache list. </Br>
		/// <Br>If open, it will be safe but very slow. It will prevent inserting an repeated obejct, such as:</Br>
		/// <br>object obj = new object();</br>
		/// <br>CacheManagement.Instance.Insert(obj);</br>
		/// <br>CacheManagement.Instance.Insert(obj);</br>
		/// <br>//The second time insert obj won't be successful.</br>
		/// </summary>
		public static bool ExplicitObjectCheck
		{
			get
			{
				return CacheManagement.mExplicitObjectCheck;
			}
			set
			{
				CacheManagement.mExplicitObjectCheck = value;
			}
		}


		/// <summary>
		/// Get the count of types in current cache list.
		/// </summary>
		public int Count
		{
			get
			{
				return this.mData.Count;
			}
		}


		/// <summary>
		/// Inserts an item into the cache object
		/// </summary>
		/// <param name="value">The object to be inserted into the cache.</param>
		public void Insert(object value)
		{
			if (value != null)
			{
				Type type = value.GetType();

				BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
				mReadAndWriteLock.AcquireWriterLock(section.ThreadLockTime);
				try
				{
					ArrayList objList;
					if(!this.mData.Contains(type))	//Be sure the list of type exists
					{
						objList = new ArrayList();
						this.mData.Add(type, objList);
					}

					//Get the list of specialized type
					objList = this.mData[type] as ArrayList;	

					//Guarantee that the cached object won't exceed CacheManagement.MaxCacheObjectCount 
					if(objList.Count > CacheManagement.MaxCacheObjectCount)	
						return;

					//If allow explicit object check and the object has been inserted, then return.
					if(mExplicitObjectCheck && objList.Contains(value))	
						return;
					
					CacheCollectionElement element = new CacheCollectionElement(value);

					objList.Add(element);
				}
				finally
				{
					mReadAndWriteLock.ReleaseWriterLock();
				}
			}
			else
			{
				throw new DQException("The parameter of CacheManagement cannot be null.", true);
			}
		}


		/// <summary>
		/// Get the object of specialized type. If the object doesn't exist, this function will return null.
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public object GetObject(Type type)
		{
			if (type != null)
			{
				BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
				this.mReadAndWriteLock.AcquireReaderLock(section.ThreadLockTime);
				try
				{
					if(!this.mData.Contains(type))	//If list of type doesn't exist
						return null;

					ArrayList list = this.mData[type] as ArrayList;

					for(int i=0; i<list.Count; i++)
					{
						CacheCollectionElement element = list[i] as CacheCollectionElement;
						if(element.IsCollected == false)	//Exists now
						{
							// we're modifying the collection so upgrade to writer lock
							LockCookie lockCookie = this.mReadAndWriteLock.UpgradeToWriterLock(section.ThreadLockTime);
							try
							{
								object obj = element.Value;
								element = null;
								list.RemoveAt(i);
								return obj;
							}
							finally
							{
								this.mReadAndWriteLock.DowngradeFromWriterLock(ref lockCookie);	// done -- downgrade to reader lock
							}
						}
						else	//It has been collected
						{
							element = null;
							list.RemoveAt(i);
							i--;
						}
					}
					return null;
				}
				finally
				{
					// ReleaseLock is used in lieu of ReleaseWriterLock/ReleaseReaderLock due to the lock upgrade logic.
					// Since we don't need to support nested locks here this should be OK...
					this.mReadAndWriteLock.ReleaseLock();
				}
			}
			else
			{
				throw new DQException("The parameter of CacheManagement.Instance.GetObject cannot be null.", true);
			}
		}


		/// <summary>
		/// Removes the specified item from the cache object.
		/// </summary>
		/// <param name="type">The cache type of the item to remove.</param>
		public void Remove(Type type)
		{
			if (type != null)
			{
				BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
				mReadAndWriteLock.AcquireWriterLock(section.ThreadLockTime);
				try
				{
					if(this.mData.Contains(type))
					{
						this.mData.Remove(type);
					}
				}
				finally
				{
					mReadAndWriteLock.ReleaseWriterLock();
				}
			}
			else
			{
				throw new DQException("The parameter of CacheManagement.Instance.Remove cannot be null.", true);
			}
		}


		/// <summary>
		/// Removes all items from the cache object.
		/// </summary>
		public void Clear()
		{	
			BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
			mReadAndWriteLock.AcquireWriterLock(section.ThreadLockTime);
			try
			{
				if (this.mData.Count > 0)
				{
					this.mData.Clear();
				}
			}
			finally
			{
				mReadAndWriteLock.ReleaseWriterLock();
			}
		}


		/// <summary>
		/// Compresses the cache, removing references to collected items (if any).
		/// </summary>
		public void Purge()
		{
			IDictionaryEnumerator ide = this.mData.GetEnumerator();
			while(ide.MoveNext())
			{
				Type type = ide.Key as Type;
				this.Purge(type);
			}
		}


		/// <summary>
		/// Compresses the cache of specialized type, removing references to collected items (if any).
		/// </summary>
		public void Purge(Type type)
		{
			BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
			mReadAndWriteLock.AcquireWriterLock(section.ThreadLockTime);
			try
			{
				if(!this.mData.Contains(type))	//If list of type doesn't exist
					return;
				ArrayList objList = this.mData[type] as ArrayList;
				for(int i=objList.Count-1; i>=0; i--)
				{
					CacheCollectionElement element = objList[i] as CacheCollectionElement;
					if(element.IsCollected)
					{
						// we're modifying the collection so upgrade to writer lock
						LockCookie lockCookie = mReadAndWriteLock.UpgradeToWriterLock(section.ThreadLockTime);
					
						objList.RemoveAt(i);

						// done -- downgrade to reader lock
						mReadAndWriteLock.DowngradeFromWriterLock(ref lockCookie);
					}
				}
			}
			finally
			{
				mReadAndWriteLock.ReleaseWriterLock();
			}
		}


		/// <summary>
		/// Returns a string representation of the contents of the cache object.
		/// </summary>
		/// <returns>A string representation of the contents of the cache and the number of items in the cache.</returns>
		public override string ToString()
		{
			StringBuilder	sb = new StringBuilder();
			int typeCount = this.Count;

			if (typeCount > 0)
			{
				sb.AppendFormat("Total types in cache = {0:d}, contents:", typeCount);

				// manually iterate over enumerator because our implementation of GetEnumerator() first calls Purge() which
				// we've already done at this point...
				CacheEnumerator enumerator = new CacheEnumerator(this.mData.GetEnumerator());
				try
				{
					while (enumerator.MoveNext()) 
					{
						sb.AppendFormat("\r\nType: {0}, amount of ArrayList: {1}", enumerator.Key.ToString(), enumerator.Value.Count);
					}
				}
				finally
				{
					enumerator.Dispose();
				}
			}
			else
			{
				sb.Append("Cache is empty.");
			}

			return sb.ToString();
		}

	}
}
