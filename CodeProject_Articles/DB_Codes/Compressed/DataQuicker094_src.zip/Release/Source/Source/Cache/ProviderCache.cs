// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Caching <seealso cref="IProvider"/> entry
	/// </summary>
	public class ProviderCache
	{
		private Hashtable Cache = new Hashtable();
		private object SyncObject = new object();

		/// <summary>
		/// Constructor
		/// </summary>
		public ProviderCache()
		{
		}

		/// <summary>
		/// Push <seealso cref="IProvider"/> into cache stack
		/// </summary>
		/// <param name="providerName">Provider name</param>
		/// <param name="provider"></param>
		public void Push(string providerName, IProvider provider)
		{
			ProviderSection section = ConfigurationManager.Instance.GetConfig("ProviderSection", typeof(ProviderSection)) as ProviderSection;
			lock(this)
			{
				object cacheStack = this.Cache[providerName];
				Stack stack = null;
				if(cacheStack==null)
				{
					stack = new Stack();
					if(stack.Count>=section.Maximum) return;
					else stack.Push(provider);
					
					this.Cache.Add(providerName, stack);
				}
				else
				{
					stack = cacheStack as Stack;
					if(stack.Count>=section.Maximum) return;
					else (cacheStack as Stack).Push(provider);
				}
			}
		}

		/// <summary>
		/// Pop <seealso cref="IProvider"/> entry from cache stack
		/// </summary>
		/// <param name="providerName"></param>
		public IProvider Pop(string providerName)
		{
			lock(this)
			{
				object cacheStack = this.Cache[providerName];
				if(cacheStack == null || (cacheStack as Stack).Count==0)
					return null;
				else
				{
					Stack stack = cacheStack as Stack;
					object result = stack.Pop();
					if(result!=null)
						return result as IProvider;
					else
						return null;
				}
			}
		}
	}
}