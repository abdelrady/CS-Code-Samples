// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Maps to date type data column.
	/// </summary>
	/// <example>
	/// //We assume that there is a date column named CreateDate in MSSQL database, and the valid value should be from 2000-1-1 to 2005-1-1, the mapping property source code should be as following<br/>
	/// [Field("CreateDate")]<br/>
	///	public FDateTime CreateDate<br/>
	///	{<br/>
	///		get<br/>
	///		{<br/>
	///			return this.mCreateDate;<br/>
	///		}<br/>
	///		set<br/>
	///		{<br/>
	///			this.mCreateDate.Replace(value);<br/>
	///		}<br/>
	///	}<br/>
	/// </example>
	[Serializable]
	public sealed class FDateTime: FieldMapping  
	{

		/// <summary>
		/// Constructor
		/// </summary>
		public FDateTime()
		{
			this.Validator = new DateTimeValidator();
		}


		/// <summary>
		/// Set/Get field value.
		/// </summary>
		public new DateTime Value
		{
			get
			{
				if(base.Value != null)
					return DateTime.Parse(base.Value.ToString());
				else
					return DateTime.MinValue;
			}
			set
			{
				base.Value = new DateTime(value.Year, value.Month, value.Day, value.Hour, value.Minute, value.Second);
			}
		}


		/// <summary>
		/// Convert current field to DateTime implicitly.
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		/// <example>
		/// <p>FDateTime fReleaseDateTime = new FDateTime();</p>
		/// <p>...</p>
		/// <p>DateTime releaseDateTime = fReleaseDateTime;	//Here fAmount will convert to DateTime type implicitly.</p>
		/// <p>...</p>
		/// </example>
		public static implicit operator DateTime(FDateTime field)
		{
			return field.Value;
		}


		/// <summary>
		/// Overrides operator +
		/// </summary>
		/// <param name="field"></param>
		/// <param name="value">Field value</param>
		/// <returns></returns>
		/// <example>
		/// FDateTime fCreateTime = new FDateTime();<br/>
		/// fCreateTime.Value = DateTime.Now;<br/>
		/// The above sentence equals to the following, <br/>
		/// fCreateTime += DateTime.Now;
		/// </example>
		public static FDateTime operator +(FDateTime field, DateTime value)
		{
			field.Value = value;
			return field;
		}
	}
}
