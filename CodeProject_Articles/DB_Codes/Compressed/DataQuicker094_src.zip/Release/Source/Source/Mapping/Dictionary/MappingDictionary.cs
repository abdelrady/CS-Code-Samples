// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;
	
namespace DataQuicker.Framework
{
	/// <summary>
	/// Dictionary of PropertyName-FieldMapping object. 
	/// </summary>
	[Serializable]
	public class MappingDictionary: IEnumerable
	{
		private Hashtable mMappingObjects = new Hashtable();

		/// <summary>
		/// Constructor
		/// </summary>
		public MappingDictionary()
		{
		}


		/// <summary>
		/// Add a persistent property with property name and mapping object
		/// </summary>
		/// <param name="propertyName"></param>
		/// <param name="column"></param>
		public void Add(string propertyName, FieldMapping column)
		{
			if(this.mMappingObjects.ContainsKey(propertyName))
				return;
			this.mMappingObjects.Add(propertyName, column);
		}


		/// <summary>
		/// Remove the persistent property object by its name
		/// </summary>
		/// <param name="propertyName"></param>
		public void Remove(string propertyName)
		{
			if(!this.mMappingObjects.ContainsKey(propertyName))	
				return;
			this.mMappingObjects.Remove(propertyName);
		}


		/// <summary>
		/// Clear all element in mapping list
		/// </summary>
		public void Clear()
		{
			this.mMappingObjects.Clear();
		}


		/// <summary>
		/// Judge whether the mapping list contains the property name. If contains, return true.
		/// </summary>
		/// <param name="propertyName">Property name</param>
		public bool Contains(string propertyName)
		{
			return this.mMappingObjects.ContainsKey(propertyName);
		}


		/// <summary>
		/// Judge whether the mapping list contains the mapping object. If contains, return true.
		/// </summary>
		/// <param name="column">FieldMapping object</param>
		public bool Contains(FieldMapping column)
		{
			return this.mMappingObjects.ContainsValue(column);
		}


		/// <summary>
		/// Set/Get mapping object by its index value
		/// </summary>
		public FieldMapping this[string propertyName]
		{
			get
			{
				if(!this.mMappingObjects.ContainsKey(propertyName))	
					return null;
				else
					return this.mMappingObjects[propertyName] as FieldMapping;
			}
			set
			{
				this.mMappingObjects[propertyName] = value;
			}
		}


		/// <summary>
		/// Get the count of persistent properties object
		/// </summary>
		public int Count
		{
			get
			{
				return this.mMappingObjects.Count;
			}
		}


		IEnumerator IEnumerable.GetEnumerator()
		{
			return this.GetEnumerator();
		}


		/// <summary>
		/// Retrieves a cache enumerator used to iterate through the key settings and their values contained in the cache.
		/// </summary>
		/// <returns>An enumerator to iterate through the cache object.</returns>
		public IMappingEnumerator GetEnumerator()
		{
			return new MappingEnumerator(this.mMappingObjects.GetEnumerator());
		}


		/// <summary>
		/// Reset all fields stored in current dictionary
		/// </summary>
		public void Reset()
		{
			IMappingEnumerator enumerator = this.GetEnumerator();
			while(enumerator.MoveNext())
				enumerator.Value.Reset();
		}


		/// <summary>
		/// Deep clone, all FieldMapping objects included belong to argument entity.
		/// </summary>
		/// <param name="entity">The parent entity of all FieldMapping objects included in current dictionary</param>
		/// <returns></returns>
		public MappingDictionary Clone(EntityMapping entity)
		{
			MappingDictionary dictionary = new MappingDictionary();
			Type type = entity.GetType();
			IMappingEnumerator enumerator = this.GetEnumerator();
			while(enumerator.MoveNext())
			{
				string strPropertyName = enumerator.Key;
				PropertyInfo property = type.GetProperty(strPropertyName);
				FieldMapping field = property.GetValue(entity, null) as FieldMapping;
				field.ParentEntity = entity;
				enumerator.Value.CloneSchemaTo(field);
				dictionary.Add(enumerator.Key, field);
			}
			return dictionary;
		}
	}
}