// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using System.Collections.Specialized;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Abstract base class of table/view entity.
	/// </summary>
	[Serializable]
	public abstract class EntityMapping: Mapping, IDisposable, ICloneable
	{
		private MappingDictionary mFieldList = new MappingDictionary();
		private FieldCollection mPrimaryKeys = new FieldCollection();
		internal string mProviderName;
		internal bool mExist;
		internal bool mHasDisposed;

		/// <summary>
		/// Constructor
		/// </summary>
		protected EntityMapping()
		{
			PersistenceBuilder.Instance.Initialize(this);
		}


		/// <summary>
		/// Construct,  and retrieve object subsequently.
		/// </summary>
		/// <param name="args"></param>
		protected EntityMapping(params object[] args)
		{
			PersistenceBuilder.Instance.Initialize(this);

			IProvider provider = Providers.GetProvider(this.ProviderName);
			//Prepare to retrieve object by primary keys
			for(int i=0; i<this.PrimaryKeys.Count; i++)
				this.PrimaryKeys[i].Value = args[i];
			provider.Retrieve(this);
		}


		/// <summary>
		/// Get FieldMappong objects dictionary
		/// </summary>
		protected internal MappingDictionary FieldList
		{
			get
			{
				return this.mFieldList;
			}
		}


		/// <summary>
		/// Get true when object has been disposed
		/// </summary>
		public bool HasDisposed
		{
			get
			{
				return this.mHasDisposed;
			}
		}


		/// <summary>
		/// Get true when entity object exists
		/// </summary>
		public bool Exist
		{
			get
			{
				return this.mExist;
			}
		}


		/// <summary>
		/// Get the primary key collections of the entity
		/// </summary>
		protected internal FieldCollection PrimaryKeys
		{
			get
			{
				return this.mPrimaryKeys;
			}
		}


		/// <summary>
		/// Get the provider name of the entity
		/// </summary>
		public string ProviderName
		{
			get
			{
				return this.mProviderName;
			}
		}


		/// <summary>
		/// Get true when any fields of entity are changed
		/// </summary>
		public override bool IsValueChanged
		{
			get
			{
				IMappingEnumerator enumerator = this.FieldList.GetEnumerator();
				while(enumerator.MoveNext())
					if(enumerator.Value.IsValueChanged == true)
						return true;
				return false;
			}
		}


		/// <summary>
		/// Reset current entity
		/// </summary>
		public override void Reset()
		{
			this.mExist = false;
			this.mFieldList.Reset();
		}


		/// <summary>
		/// Dispose this object
		/// </summary>
		public void Dispose()
		{
			if(this.mHasDisposed == false)
			{
				this.mHasDisposed = true;
				CacheManagement.Instance.Insert(this);
			}
		}


		/// <summary>
		/// Replace this object with arguement entity
		/// </summary>
		/// <param name="entity"></param>
		public void Replace(EntityMapping entity)
		{
			//Because the entity type is definition, so the mapping name of two entities with same type are uniform.
			this.mFieldList = entity.mFieldList;
			this.mExist = entity.mExist;
			this.mHasDisposed = entity.mHasDisposed;
			this.AliasName = entity.AliasName;

			/************************************************************************************************************************************************
			 * The following fields is no necessary to be changed, as an identical entity type object, they are some
			 * mTableNames
			 * mProviderName
			 * mMappingName
			*************************************************************************************************************************************************/
		}

		object ICloneable.Clone()
		{
			return this.Clone();
		}

		/// <summary>
		/// Deep clone
		/// </summary>
		/// <returns></returns>
		public EntityMapping Clone()
		{
			EntityMapping entity = Activator.CreateInstance(this.GetType()) as EntityMapping;
			entity.mProviderName = this.PhysicalName;
			entity.AliasName = this.AliasName;
			entity.mFieldList = this.mFieldList.Clone(entity);

			//Clone primary key collection
			FieldCollection collection = new FieldCollection();
			IMappingEnumerator enumerator = entity.mFieldList.GetEnumerator();
			while(enumerator.MoveNext())
				if(enumerator.Value.IsPrimaryKey)
					collection.Add(enumerator.Value);
			entity.mPrimaryKeys = collection;

			entity.mProviderName = this.mProviderName;
			entity.mExist = this.mExist;
			entity.mHasDisposed = this.mHasDisposed;
			return entity;
		}
	}
}