// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// <p>The class indicates the entity maps to a view in database.</p>
	/// The difference between <seealso cref="TableMapping"/> and <seealso cref="ViewMapping"/> is, TableMapping supports Create, Update and Delete, but ViewMapping not.<br/>
	/// <p>ViewMapping object only supports retrieve and query.</p>
	/// </summary>
	[Serializable]
	public class ViewMapping: EntityMapping  
	{
		/// <summary>
		/// Constructor
		/// </summary>
		protected ViewMapping():base(){}

		/// <summary>
		/// Constructor with primary keys, to retrieve object subsequently.
		/// </summary>
		/// <param name="args"></param>
		protected ViewMapping(params object[] args):base(args){}
	}
}
