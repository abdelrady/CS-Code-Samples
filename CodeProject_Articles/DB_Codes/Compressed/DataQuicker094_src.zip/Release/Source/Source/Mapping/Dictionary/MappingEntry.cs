// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// The map between property name and mapping object
	/// </summary>
	[Serializable]
	public class MappingEntry
	{
		private string mPropertyName;
		private FieldMapping mMappingObject;

		/// <summary>
		/// Set/Get property name
		/// </summary>
		public string Key
		{
			get
			{
				return this.mPropertyName;
			}
			set
			{
				this.mPropertyName = value;
			}
		}

		/// <summary>
		/// Set/Get mapping object
		/// </summary>
		public FieldMapping Value
		{
			get
			{
				return this.mMappingObject;
			}
			set
			{
				this.mMappingObject = value;
			}
		}

		/// <summary>
		/// Returns a string representation of the key, value pair.
		/// </summary>
		public override string ToString()
		{
			return string.Format("Key = {0}, Value = {1}", this.mPropertyName, this.mMappingObject.ToString());
		}
	}
}
