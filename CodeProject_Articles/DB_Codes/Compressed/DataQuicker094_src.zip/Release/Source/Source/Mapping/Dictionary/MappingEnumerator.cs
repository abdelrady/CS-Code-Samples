// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	[Serializable]
	internal class MappingEnumerator: IMappingEnumerator
	{
		private IDictionaryEnumerator	mDictionaryEnumerator;

		/// <summary>
		/// Construct CacheEnumerator from IDictionaryEnumerator
		/// </summary>
		/// <param name="enumerator"></param>
		public MappingEnumerator(IDictionaryEnumerator enumerator)
		{
			mDictionaryEnumerator = enumerator;
		}

		/// <summary>
		/// Set/Get the cache entry
		/// </summary>
		public MappingEntry Entry
		{
			get
			{
				MappingEntry entry = new MappingEntry();
				entry.Key = this.mDictionaryEnumerator.Key.ToString();
				entry.Value = this.mDictionaryEnumerator.Value as FieldMapping;
				return entry;
			}
		}

		/// <summary>
		/// Key - Property Name
		/// </summary>
		public string Key
		{
			get 
			{ 
				return this.mDictionaryEnumerator.Key.ToString(); 
			}
		}

		/// <summary>
		/// FieldMapping Object
		/// </summary>
		public FieldMapping Value
		{
			get 
			{ 
				return this.mDictionaryEnumerator.Value as FieldMapping;
			}
		}

		public void Reset()
		{
			this.mDictionaryEnumerator.Reset();
		}

		public bool MoveNext()
		{
			return this.mDictionaryEnumerator.MoveNext();
		}

		public MappingEntry Current
		{
			get
			{ 
				return this.mDictionaryEnumerator.Current as MappingEntry;
			}
		}

		object IEnumerator.Current
		{
			get 
			{ 
				return this.Current; 
			}
		}
	}
}
