// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Maps to decimal type data column.
	/// </summary>
	/// <example>
	/// <p>How to use field Validator?</p>
	/// <p>The validator is used to check it is valid or not when setting field value.</p>
	/// <p>For example, there is a column named <b>Price</b> in database, and the valid value is from 100 to 200.</p>
	/// <p>In C# code using DataQuicker, we can declare that column as,</p>
	/// <p>
	/// [Field("Price"), Validate(100, 200)]
	/// public FDecimal Price
	/// {
	///		get
	///		{
	///			return this.mPrice;
	///		}
	///		set
	///		{
	///			this.mPrice.Replace(value);
	///		}
	/// }
	/// </p>
	/// </example>
	[Serializable]
	public sealed class FDecimal: FieldMapping
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FDecimal()
		{
			this.Validator = new DecimalValidator();
		}


		/// <summary>
		/// Set/Get field value.
		/// </summary>
		public new decimal Value
		{
			get
			{
				if(base.Value != null)
					return decimal.Parse(base.Value.ToString());
				else
					return decimal.MinValue;
			}
			set
			{
				base.Value = value;
			}
		}


		/// <summary>
		/// Convert current field to decimal implicitly.
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		/// <example>
		/// <p>FDecimal fAmount = new FDecimal();</p>
		/// <p>...</p>
		/// <p>decimal amount = fAmount;	//Here fAmount will convert to decimal type implicitly.</p>
		/// <p>...</p>
		/// </example>
		public static implicit operator decimal(FDecimal field)
		{
			Check.VerifyNotNull(field);
			return field.Value;
		}


		/// <summary>
		/// Overrides operator +
		/// </summary>
		/// <param name="field"></param>
		/// <param name="value">Field value</param>
		/// <returns></returns>
		/// <example>
		/// FDecimal fAmount = new FDecimal();<br/>
		/// fAmount.Value = 101.02D;<br/>
		/// The above sentence equals to the following, <br/>
		/// fAmount += 101.02D;
		/// </example>
		public static FDecimal operator +(FDecimal field, decimal value)
		{
			Check.VerifyNotNull(field);
			field.Value = value;
			return field;
		}
	}
}
