// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Maps to integer type data column.
	/// </summary>
	/// <example>
	/// <p>How to use field Validator?</p>
	/// <p>The validator is used to check it is valid or not when setting field value.</p>
	/// <p>For example, we have a column named <b>Amount</b> in database, and we only want to save valid value to it.</p>
	/// <p>In C# code using DataQuicker, we can declare that column as,</p>
	/// <p>
	/// //We assume that the valid value must be more than zero and less than 9999.
	/// [Field("Amount"), Validate(0, 9999)]
	/// public FInt Amount
	/// {
	///		get
	///		{
	///			return this.mAmount;
	///		}
	///		set
	///		{
	///			this.mAmount.Replace(value);
	///		}
	/// }
	/// </p>
	/// </example>
	[Serializable]
	public sealed class FInt: FieldMapping
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FInt()
		{
			this.Validator = new IntValidator();
		}


		/// <summary>
		/// Set/Get field value.
		/// </summary>
		public new int Value
		{
			get
			{
				if(base.Value != null)
					return int.Parse(base.Value.ToString());
				else
					return int.MinValue;
			}
			set
			{
				base.Value = value;
			}
		}


		/// <summary>
		/// Convert current field to int implicitly.
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		/// <example>
		/// <p>FInt fAmount = new FInt();</p>
		/// <p>...</p>
		/// <p>int amount = fAmount;	//Here fAmount will convert to int type implicitly.</p>
		/// <p>...</p>
		/// </example>
		public static implicit operator int(FInt field)
		{
			return field.Value;
		}


		/// <summary>
		/// Overrides operator +
		/// </summary>
		/// <param name="field"></param>
		/// <param name="value">Field value</param>
		/// <returns></returns>
		/// <example>
		/// FInt fAmount = new FInt();<br/>
		/// fAmount.Value = 101;<br/>
		/// The above sentence equals to the following, <br/>
		/// fAmount += 101;
		/// </example>
		public static FInt operator +(FInt field, int value)
		{
			field.Value = value;
			return field;
		}
	}
}
