// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Globalization;
using System.Web;
using System.IO;
using System.Configuration;
using System.Reflection;
using System.Collections;
using System.Collections.Specialized;
using System.Threading;
using System.Xml;
using System.Text.RegularExpressions;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Persistence builder, for building, analyzing and retrieving object. 
	/// </summary>
	[Serializable]
	public sealed class PersistenceBuilder
	{
		private readonly static PersistenceBuilder mInstance = new PersistenceBuilder();
		private ReaderWriterLock mReadAndWriteLock;
		private Hashtable mObjectList = new Hashtable();

		private PersistenceBuilder()
		{
			this.mReadAndWriteLock = new ReaderWriterLock();
		}


		/// <summary>
		/// Get the singleton instance of class PersistenceBuilder
		/// </summary>
		public static PersistenceBuilder Instance
		{
			get
			{
				return PersistenceBuilder.mInstance;
			}
		}


//		/// <summary>
//		/// Create an entity instance. The property <b>Exist</b> is false as default value.
//		/// </summary>
//		/// <param name="type"></param>
//		/// <returns></returns>
//		public EntityMapping CreateInstance(Type type)
//		{
//			return this.CreateInstance(type, null);
//		}
//
//
//		/// <summary>
//		/// <p>Create an entity instance, and retrieve it replys on primary keys value.</p>
//		/// <p>If retrieve successful, the property <b>Exist</b> should be true.</p>
//		/// </summary>
//		/// <param name="type"></param>
//		/// <param name="parameters"></param>
//		/// <returns></returns>
//		public EntityMapping CreateInstance(Type type, params object[] parameters)
//		{
//			Check.VerifyNotNull(type);
//
//			if(type.IsSubclassOf(typeof(EntityMapping)) == false)
//				throw new DQException("10005");	
//			
//			//Try to get the suitable object from cache stack
//			EntityMapping entity = null; //CacheManagement.Instance.GetObject(typeof(EntityMapping)) as EntityMapping;
//
//			//If gets nothing, re-constructs a new object, then analyze and initialize it.
//			if(entity == null)
//			{
//				string strTypeName = type.FullName;
//				EntityMapping cacheEntity = this.mObjectList[strTypeName] as EntityMapping;
//				if(cacheEntity==null)
//				{
//					BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
//					this.mReadAndWriteLock.AcquireWriterLock(section.ThreadLockTime);
//					try
//					{
//						cacheEntity = Activator.CreateInstance(type) as EntityMapping;
//						this.Initialize(cacheEntity);
//						this.mObjectList[strTypeName] = cacheEntity;
//					}
//					finally
//					{
//						this.mReadAndWriteLock.ReleaseWriterLock();
//					}
//				}
//				entity = cacheEntity.Clone() as EntityMapping;
//			}
//			else	//The object was poped from cache management. It will be reused.
//			{
//				entity.mHasDisposed  = false;
//				entity.Reset();
//			}
//
//			if(parameters == null || parameters.Length==0)
//				return entity;
//			else
//			{
//				IProvider provider = Providers.GetProvider(entity.ProviderName);
//				//Prepare to retrieve object by primary keys
//				for(int i=0; i<entity.PrimaryKeys.Count; i++)
//					entity.PrimaryKeys[i].Value = parameters[i];
//				provider.Retrieve(entity);
//				return entity;
//			}
//		}


		/// <summary>
		///  Initialize custom attribute of class EntityMapping. The function will initialize a template object by setting its customized attributes.
		/// </summary>
		/// <param name="entity"></param>
		/// <returns></returns>
		public void Initialize(EntityMapping entity)
		{
			Type type = entity.GetType();
			string strEntityMappingName = PersistenceBuilder.SetClass(entity);

			//Get all properties of current entity
			PropertyInfo[] properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance);
			//Circulate all properties
			foreach(PropertyInfo property in properties)
			{
				//The property type must derive from class Mapping.
				if(!property.PropertyType.IsSubclassOf(typeof(FieldMapping)))	 continue;

				//Get all attributes set on property
				Attribute[] attributes = Attribute.GetCustomAttributes(property, false);
				//If there is no custom attribute, continue circle.
				if(attributes == null || attributes.Length <= 0) continue;

				//The get property takes as key saved in MappingDictionary
				string strPropertyName = property.Name;

				FieldMapping field = property.GetValue(entity, null) as FieldMapping;
				entity.FieldList[strPropertyName] = field;
				//Set field's parent entity object
				field.ParentEntity = entity;

				//Circulate all attributes set on property
				foreach(Attribute attribute in attributes)
					PersistenceBuilder.SetPropertyAttribute(field, attribute);
			}

			//Validate the repeated columns' name
			Check.VerifyRepeatColumnName(entity);

			//It's forbidden to design data access layer without primary key
			if(entity is TableMapping && entity.PrimaryKeys.Count == 0)
				throw new DQException("10048", entity.ToString());

			ConfigurationManager.Instance.DbSchemaCache.Initialize(entity);

			//Validate the design of entity
			Check.VerifyPrimaryKeyDesign(entity);
		}


		/// <summary>
		/// Initialize entity object based on all custom attributes set on data access layer
		/// </summary>
		/// <param name="entity"></param>
		private static string SetClass(EntityMapping entity)
		{
			Type type = entity.GetType();
			object[] attributes = type.GetCustomAttributes(true);

			foreach(object attribute in attributes)
				PersistenceBuilder.SetClassAttribute(entity, attribute as Attribute);

			//Each persistence must have the ProviderAttribute declaration
			if(Kit.IsEmpty(entity.ProviderName) == true)
				throw new DQException("10018", entity.ToString());

			return entity.PhysicalName;
		}


		/// <summary>
		/// Initialize the field based on the customized attribute
		/// </summary>
		/// <param name="field"></param>
		/// <param name="attribute"></param>
		private static void SetPropertyAttribute(FieldMapping field, Attribute attribute)
		{
			//PhysicalNameAttribute, it's forbidden to set the same physical name on different property in a class.
			if(attribute is PhysicalNameAttribute)
			{
				string strPhysicalName = (attribute as PhysicalNameAttribute).PhysicalName;
				if(!Kit.IsValid(strPhysicalName))
					throw new DQException("10063", field.ParentEntity.ToString(), strPhysicalName, "PhysicalName");

				field.SetPhysicalName(strPhysicalName);
				if(Kit.IsEmpty(field.AliasName))
					field.AliasName = strPhysicalName;
			}

			//ValidateAttribute
			if(attribute is ValidateAttribute)	
			{
				if(field.Validator != null)
					field.Validator.Render((attribute as ValidateAttribute).Expressions);
			}

			//AliasNameAttribute
			if(attribute is AliasNameAttribute)
			{
				string strAliasNAme = (attribute as AliasNameAttribute).AliasName;
				if(!Kit.IsValid(strAliasNAme))
					throw new DQException("10063", field.ParentEntity.ToString(), strAliasNAme, "Alias");
				field.AliasName =strAliasNAme;
			}

			//PrimaryKeyAttribute
			if(attribute is PrimaryKeyAttribute)
			{
				field.mIsPrimaryKey = true;
				field.mPrimaryKeyType = (attribute as PrimaryKeyAttribute).Type;
				if(!field.ParentEntity.PrimaryKeys.Contains(field))
					field.ParentEntity.PrimaryKeys.Add(field);
			}
		}


		/// <summary>
		/// Initialize the entity based on custom attributes
		/// </summary>
		/// <param name="entity"></param>
		/// <param name="attribute"></param>
		private static void SetClassAttribute(EntityMapping entity, Attribute attribute)
		{
			//PhysicalNameAttribute
			if(attribute is PhysicalNameAttribute)
			{
				string strPhysicalName = (attribute as PhysicalNameAttribute).PhysicalName;
				if(!Kit.IsValid(strPhysicalName))
					throw new DQException("10064", entity.ToString(), strPhysicalName, "PhysicalName");
				entity.SetPhysicalName(strPhysicalName);
				if(Kit.IsEmpty(entity.AliasName))
					entity.AliasName = strPhysicalName;

				return;
			}

			//AliasNameAttribute
			if(attribute is AliasNameAttribute)
			{
				string strAliasNAme = (attribute as AliasNameAttribute).AliasName;
				if(!Kit.IsValid(strAliasNAme))
					throw new DQException("10063", entity.ToString(), strAliasNAme, "Alias");
				entity.AliasName =strAliasNAme;

				return; 
			}

			// ProviderAttribute: declare the provider name of table/view
			// Set provider on entity. Each entity should be have a provider to connect/operate database.<br/>
			// ***The method was called by SetClassDeclaration(EntityMapping)***
			if (attribute is ProviderAttribute)
			{
				string strProviderName = (attribute as ProviderAttribute).ProviderName;
				//The provider must be registered in DataQuicker.config
				if(Providers.Contains(strProviderName) == false)
					throw new DQException("10016", entity.ToString(), strProviderName);
				entity.mProviderName = strProviderName;

				return;
			}
		}
	}
}