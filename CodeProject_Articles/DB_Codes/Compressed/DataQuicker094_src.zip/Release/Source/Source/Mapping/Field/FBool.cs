// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Maps to boolean data column
	/// </summary>
	/// <example>
	/// <p>
	/// //We assume the column [IsValid] is boolean type, mapping property source code as following,
	/// [Field("IsValid")]
	/// public FBool IsValid
	/// {
	///		get
	///		{
	///			return this.mIsValid;
	///		}
	///		set
	///		{
	///			this.mIsValid.Replace(value);
	///		}
	/// }
	/// </p>
	/// </example>
	[Serializable]
	public sealed class FBool: FieldMapping  	
	{
		/// <summary>
		/// Constructor
		/// </summary>
		public FBool()
		{
		}


		/// <summary>
		/// Set/Get field value.
		/// </summary>
		public new bool Value
		{
			get
			{
				if(base.Value != null)
					return Cast.ToBool(base.Value);
				else
					return false;
			}
			set
			{
				base.Value = value?1:0;
			}
		}


		/// <summary>
		/// Convert current field to bool implicitly.
		/// </summary>
		/// <param name="field"></param>
		/// <returns></returns>
		/// <example>
		/// <p>FBool blActive = new FBool();</p>
		/// <p>...</p>
		/// <p>bool active = blActive;	//Here blActive will convert to bool type implicitly.</p>
		/// <p>...</p>
		/// </example>
		public static implicit operator bool(FBool field)
		{
			return field.Value;
		}


		/// <summary>
		/// Overrides operator +
		/// </summary>
		/// <param name="field"></param>
		/// <param name="value">Field value</param>
		/// <returns></returns>
		/// <example>
		/// FBool fInvalid = new FBool();<br/>
		/// fInvalid.Value = true;<br/>
		/// The above sentence equals to the following, <br/>
		/// fInvalid += true;
		/// </example>
		public static FBool operator +(FBool field, bool value)
		{
			field.Value = value;
			return field;
		}
	}
}
