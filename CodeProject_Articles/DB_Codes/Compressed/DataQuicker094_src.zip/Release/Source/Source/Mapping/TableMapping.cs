// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Reflection;

namespace DataQuicker.Framework
{
	/// <summary>
	/// <br>The class indicates the entity maps to data table.</br>
	/// The difference between <seealso cref="TableMapping"/> and <seealso cref="ViewMapping"/> is, TableMapping supports Create, Update and Delete, but ViewMapping not.
	/// </summary>
	/// <example>
	/// //The below section used to update the order information:
	/// Orders order = new Orders(1);
	/// order.EmployeeID += 5;
	/// order.Freight += 24.88M;
	/// order.CustomerID += "HANAR";
	/// IProvider provider = Providers.GetProvider();
	/// provider.Update(order);
	/// </example>
	[Serializable]
	public class TableMapping: EntityMapping 
	{
		/// <summary>
		/// Constructor
		/// </summary>
		protected TableMapping():base(){}

		/// <summary>
		/// Constructor with primary keys, to retrieve object subsequently.
		/// </summary>
		/// <param name="args"></param>
		protected TableMapping(params object[] args):base(args){}
	}
}