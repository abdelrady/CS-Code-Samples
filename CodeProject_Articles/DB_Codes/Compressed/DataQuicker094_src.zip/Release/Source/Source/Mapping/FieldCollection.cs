// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// FieldCollection, for <seealso cref="FieldMapping"/> objects
	/// </summary>
	public class FieldCollection
	{
		private ArrayList mColumns = new ArrayList();

		/// <summary>
		/// Constructor
		/// </summary>
		public FieldCollection()
		{
		}

		/// <summary>
		/// Get count of columns
		/// </summary>
		public int Count
		{
			get
			{
				return this.mColumns.Count;
			}
		}

		/// <summary>
		/// Get true when one field in collection is null at least.
		/// </summary>
		public bool IsNull
		{
			get
			{
				if(this.Count==0)
					return true;

				IEnumerator enumerator = this.mColumns.GetEnumerator();
				while(enumerator.MoveNext())
				{
					FieldMapping field = enumerator.Current as FieldMapping;
					if(field.IsNull) return true;
				}
				return false;
			}
		}
		/// <summary>
		/// Return true when the FieldCollection object contains arguement <b>column</b>.
		/// </summary>
		/// <param name="column"></param>
		/// <returns></returns>
		public bool Contains(FieldMapping column)
		{
			return this.mColumns.Contains(column);
		}

		/// <summary>
		/// Add a column
		/// </summary>
		/// <param name="field"></param>
		public void Add(FieldMapping field)
		{
			this.mColumns.Add(field);
		}

		/// <summary>
		/// Clear all columns
		/// </summary>
		public void Clear()
		{
			this.mColumns.Clear();
		}

		/// <summary>
		/// Remove columns by indexer
		/// </summary>
		/// <param name="index"></param>
		public void RemoveAt(int index)
		{
			this.mColumns.RemoveAt(index);
		}

		/// <summary>
		/// Get enumerator
		/// </summary>
		/// <returns></returns>
		public IEnumerator GetEnumerator()
		{
			return this.mColumns.GetEnumerator();
		}

		/// <summary>
		/// Get the FieldMapping object by indexer.
		/// </summary>
		public FieldMapping this[int index]
		{
			get
			{
				return this.mColumns[index] as FieldMapping;
			}
		}
	}
}
