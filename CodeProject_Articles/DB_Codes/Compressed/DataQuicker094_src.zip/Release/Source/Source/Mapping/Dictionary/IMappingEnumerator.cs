// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Enumerates the items of a cache
	/// <seealso cref="System.Collections.IEnumerator"/>
	/// </summary>
	/// <remarks>
	/// Enumerators only allow reading the data in the collection. Enumerators cannot be used to modify the underlying collection.
	/// <p>Initially, the enumerator is positioned before the first element in the collection. <see cref="System.Collections.IEnumerator.Reset"/> also brings the enumerator back 
	/// to this position. At this position, calling <see cref="System.Collections.IEnumerator.Current"/> throws an exception. Therefore, 
	/// you must call <see cref="System.Collections.IEnumerator.MoveNext"/> to advance the 
	/// enumerator to the first element of the collection before reading the value of <b>Current</b>.</p>
	/// <p><b>Current</b> returns the same object until either <b>MoveNext</b> or <b>Reset</b> is called. <b>MoveNext</b> sets <b>Current</b> to the next element.</p>
	/// <p>After the end of the collection is passed, the enumerator is positioned after the last element in the collection, and calling <b>MoveNext</b> returns <b>false</b>. 
	/// If the last call to <b>MoveNext</b> returned <b>false</b>, calling <b>Current</b> throws an exception. To set <b>Current</b> to the first element of the collection again, 
	/// you can call <b>Reset</b> followed by <b>MoveNext</b>.</p>
	/// <p>An enumerator remains valid as long as the collection remains unchanged. If changes are made to the collection, such as adding, modifying or deleting elements, 
	/// the enumerator is irrecoverably invalidated and the next call to <b>MoveNext</b> or <b>Reset</b> throws an <see cref="System.InvalidOperationException"/>. If the collection
	/// is modified between <b>MoveNext</b> and <b>Current</b>, <b>Current</b> will return the element that it is set to, even if the enumerator is already invalidated.</p>
	/// </remarks>
	public interface IMappingEnumerator: IEnumerator
	{
		/// <summary>
		/// When implemented by a class, gets both the key and the value of the current <see cref="MappingEntry"/> entry.
		/// </summary>
		MappingEntry Entry { get; }

		/// <summary>
		/// When implemented by a class, gets the key of the current PropertyName entry.
		/// </summary>
		string Key { get; }

		/// <summary>
		/// When implemented by a class, gets the value of the current <see cref="FieldMapping"/> entry.
		/// </summary>
		FieldMapping Value { get; }
	}
}
