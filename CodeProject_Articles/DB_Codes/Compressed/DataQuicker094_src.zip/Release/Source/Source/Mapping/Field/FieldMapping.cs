// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Text;
using System.Reflection;
using System.Collections.Specialized;
using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// FieldMapping is used to map data column.
	/// FieldMapping object stores schema of data column, such as max length, allow null, default value, customer validator and so on.
	/// Schema helps to validate value without connecting database.
	/// Any more, DataQuicker has the strict mechanism to chech data validation and integrality automatically, especially for class FieldMapping and EntityMapping.
	/// </summary>
	/// <example>
	/// <p>How to use column data Validator?</p>
	/// <p>The validator is used to check it is valid or not when setting column value.</p>
	/// <p>For example, we have a column named <b>EmailAddess</b> in database, and we only want to save valid email format string to it.</p>
	/// <p>In C# code using DataQuicker, we can declare that column as,</p>
	/// <p>
	/// //The regex expression \w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)* is used to verify the format of email string is correct or not.
	/// [Field("EmailAddress"), Validate("\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")]
	/// public FString EmailAddess
	/// {
	///		get
	///		{
	///			return this.mEmailAddess;
	///		}
	///		set
	///		{
	///			this.mEmailAddess.Replace(value);
	///		}
	/// }
	/// </p>
	/// </example>
	[Serializable]
	public abstract class FieldMapping: Mapping
	{
		internal bool mHasDefaultValue;	//True when has default value
		internal bool mAllowNull;	//Allowable
		internal long mMaxLength;	//Max Length
		internal bool mIsValueChanged;	//True when the value has been changed
		internal bool mIsPrimaryKey;	//True when the column is primary key
		internal bool mIsAutoIncrease;	//True when the column is auto-increase
		internal Validator mValidator;	//Column value validator
		internal object mValue;	//Column value
		internal PrimaryKeyType mPrimaryKeyType = PrimaryKeyType.None;	//If the column is primary key, save the primary key management type
		private EntityMapping mParentEntity;

		/// <summary>
		/// Constructor
		/// </summary>
		protected FieldMapping()
		{
		}


		/// <summary>
		/// Get full column name as format "[TableName].[ColumnName]"
		/// </summary>
		public string ColumnName
		{
			get
			{
				if(this.ParentEntity!=null)
					return Kit.BracketWord(this.ParentEntity.AliasName) + "." + Kit.BracketWord(this.PhysicalName);
				else 
					return Kit.BracketWord(this.PhysicalName);
			}
		}

		/// <summary>
		/// Set/Get parent entity
		/// </summary>
		protected internal EntityMapping ParentEntity
		{
			get
			{
				return this.mParentEntity;
			}
			set
			{
				this.mParentEntity = value;
			}
		}


		/// <summary>
		/// Set/Get DataQuicker primary-key management type.
		/// </summary>
		public PrimaryKeyType PrimaryKeyType
		{
			get
			{
				return this.mPrimaryKeyType;
			}
		}


		/// <summary>
		/// Set/Get field value. 
		/// </summary>
		public virtual object Value
		{
			get
			{
				if(this.mValue==null || this.mValue==DBNull.Value)
					return null;
				else
					return this.mValue;
			}
			set
			{
				Check.VerifyDisposed(this.ParentEntity);

				if(this.IsPrimaryKey == true)
					this.ParentEntity.mExist = false;

				this.mValue = value;
				this.mIsValueChanged = true;

				BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
				if(section.Validate)
					if(this.IsValid == false)
						throw new DQException("10039", value.ToString());
			}
		}


		/// <summary>
		/// Get max size of field, generally for FString type
		/// </summary>
		public long MaxLength
		{
			get
			{
				return this.mMaxLength;
			}
		}


		/// <summary>
		/// Get true when field is database auto-increase column
		/// </summary>
		public bool IsAutoIncrease
		{
			get
			{
				return this.mIsAutoIncrease;
			}
		}


		/// <summary>
		/// Get true when field is primary key
		/// </summary>
		public bool IsPrimaryKey
		{
			get
			{
				return this.mIsPrimaryKey;
			}
		}


		/// <summary>
		/// Set/Get field validator entry
		/// </summary>
		protected internal Validator Validator
		{
			get
			{
				return this.mValidator;
			}
			set
			{
				this.mValidator = value;
			}
		}


		/// <summary>
		/// Get true whether field has default value.
		/// </summary>
		public bool HasDefaultValue
		{
			get
			{
				return this.mHasDefaultValue;
			}
		}


		/// <summary>
		/// Get true when field is allowed null.
		/// </summary>
		public bool AllowNull
		{
			get
			{
				return this.mAllowNull;
			}
		}


		/// <summary>
		/// Get true when field value is null
		/// </summary>
		public bool IsNull
		{
			get
			{
				return this.Value==null;
			}
		}


		/// <summary>
		/// Get true when field value is valid to its schema
		/// </summary>
		public virtual bool IsValid
		{
			get
			{
				if(this.mValidator!=null && this.mValidator.IsInitialized == true && this.mValue!=null)
					return this.Validator.IsValidate(this.mValue);
				return true;
			}
		}


		/// <summary>
		/// Get true when field value is changed 
		/// </summary>
		public override bool IsValueChanged
		{
			get
			{
				return this.mIsValueChanged;
			}
		}


		/// <summary>
		/// Reset
		/// </summary>
		public override void Reset()
		{
			this.mValue = null;
			this.mIsValueChanged = false;
		}

		/// <summary>
		/// Deep clone, copying schema of current object to target argument
		/// </summary>
		/// <param name="field">The target FieldMapping object</param>
		/// <returns></returns>
		protected internal void CloneSchemaTo(FieldMapping field)
		{
			field.mHasDefaultValue = this.mHasDefaultValue;
			field.mAllowNull = this.mAllowNull;
			field.mMaxLength = this.mMaxLength;
			field.mIsValueChanged = this.mIsValueChanged;
			field.mIsPrimaryKey = this.mIsPrimaryKey;
			field.mIsAutoIncrease = this.mIsAutoIncrease;
			field.mValidator = this.mValidator;
			field.mValue = this.mValue;
			field.mPrimaryKeyType = this.mPrimaryKeyType;
		}


		/// <summary>
		/// Replace this object with arguement
		/// </summary>
		/// <param name="field"></param>
		public void Replace(FieldMapping field)
		{
			if(this!=field) throw new DQException("10029");
			this.Value = field.Value;
			this.mIsValueChanged = true;
		}
	}
}
