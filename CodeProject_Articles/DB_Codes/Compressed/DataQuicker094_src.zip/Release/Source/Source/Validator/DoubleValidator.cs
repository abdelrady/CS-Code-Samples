// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Validate value of fields with type FDouble
	/// </summary>
	[Serializable]
	public class DoubleValidator: Validator
	{
		private double mMin = double.MinValue;
		private double mMax = double.MaxValue;

		/// <summary>
		/// Construct double validator
		/// </summary>
		public DoubleValidator()
		{
		}

		/// <summary>
		/// Render validator expressions
		/// </summary>
		/// <param name="args"></param>
		public override void Render(params object[] args)
		{
			if(args.Length>= 1)
				this.mMin = (double) args[0];
			if(args.Length>= 2)
				this.mMax = (double)args[1];
			this.IsInitialized = true;
		}

		/// <summary>
		/// Return true when the double value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public override bool IsValidate(object arg)
		{
			Check.VerifyNotNull(arg);
			return this.IsValidate((int)arg);
		}


		/// <summary>
		/// Return true when the double value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public bool IsValidate(double arg)
		{
			return arg>=this.mMin && arg<=this.mMax;
		}
	}
}
