// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Validate value of fields with type FDateTime
	/// </summary>
	[Serializable]
	public sealed class DateTimeValidator: Validator 
	{
		private DateTime mBegin = DateTime.MinValue;
		private DateTime mEnd = DateTime.MaxValue;

		/// <summary>
		/// Construct datetime validator
		/// </summary>
		public DateTimeValidator()
		{
		}

		/// <summary>
		/// Render validator expressions
		/// </summary>
		/// <param name="args"></param>
		public override void Render(params object[] args)
		{
			if(args.Length>= 1)
				this.mBegin = DateTime.Parse(args[0].ToString());
			if(args.Length>= 2)
				this.mEnd = DateTime.Parse(args[1].ToString());
			this.IsInitialized = true;
		}

		/// <summary>
		/// Return true when the datetime value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public override bool IsValidate(object arg)
		{
			Check.VerifyNotNull(arg);
			return this.IsValidate(DateTime.Parse(arg.ToString()));
		}


		/// <summary>
		/// Return true when the datetime value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public bool IsValidate(DateTime arg)
		{
			return arg.CompareTo(this.mBegin) >=1 && arg.CompareTo(this.mEnd)<=1;
		}
	}
}
