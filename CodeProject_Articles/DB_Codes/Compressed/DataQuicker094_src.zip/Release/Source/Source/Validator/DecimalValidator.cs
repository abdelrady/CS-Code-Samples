// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Validate value of fields with type FDecimal
	/// </summary>
	[Serializable]
	public sealed class DecimalValidator: Validator 
	{
		private decimal mMin = decimal.MinValue;
		private decimal mMax = decimal.MaxValue;

		/// <summary>
		/// Construct decimal validator
		/// </summary>
		public DecimalValidator()
		{
		}

		/// <summary>
		/// Render validator expressions
		/// </summary>
		/// <param name="args"></param>
		public override void Render(params object[] args)
		{
			if(args.Length>= 1)
				this.mMin = (decimal)args[0];
			if(args.Length>= 2)
				this.mMax = (decimal)args[1];
			this.IsInitialized = true;
		}

		/// <summary>
		/// Return true when the decimal value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public override bool IsValidate(object arg)
		{
			Check.VerifyNotNull(arg);
			return this.IsValidate((decimal)arg);
		}


		/// <summary>
		/// Return true when the decimal value is valid
		/// </summary>
		/// <param name="arg"></param>
		/// <returns></returns>
		public bool IsValidate(decimal arg)
		{
			return arg>=this.mMin && arg<=this.mMax;
		}
	}
}
