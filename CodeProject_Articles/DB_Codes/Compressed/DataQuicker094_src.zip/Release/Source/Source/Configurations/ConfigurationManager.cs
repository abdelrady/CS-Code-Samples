// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Globalization;
using System.Collections;
using System.Reflection;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// Provides a facade to configuration settings from defined storage in a specified configuration section. 
	/// </summary>
	public sealed class ConfigurationManager
	{
		private static object mSyncObject = new object();
		private static ConfigurationManager mInstance;
		private ConfigurationBuilder Builder;
		private DbSchemaCollection mDbSchemaCache;
		private ProviderCache mProviderCache;

		private ConfigurationManager()
		{
			this.Builder = new ConfigurationBuilder();
			this.mDbSchemaCache = new DbSchemaCollection();
			this.mProviderCache = new ProviderCache();
		}


		/// <summary>
		/// Get <seealso cref="ConfigurationManager"/> singleton instance
		/// </summary>
		public static ConfigurationManager Instance
		{
			get
			{
				if(ConfigurationManager.mInstance == null)
				{
					lock(ConfigurationManager.mSyncObject)
					{
						if(ConfigurationManager.mInstance == null)
						{
							ConfigurationManager.mInstance = new ConfigurationManager();
							ConfigurationManager.Instance.InitailizeProviderInformation();
						}
					}
				}
				return ConfigurationManager.mInstance;
			}
		}


		/// <summary>
		/// Get database schema caching collection
		/// </summary>
		internal DbSchemaCollection DbSchemaCache
		{
			get
			{
				return this.mDbSchemaCache;
			}
		}


		/// <summary>
		/// Get <seealso cref="IProvider"/> caching list
		/// </summary>
		internal ProviderCache ProviderCache
		{
			get
			{
				return this.mProviderCache;
			}
		}


		/// <summary>
		/// Initialize provider relative information, etc, DbSchema, Analyzer and so on.
		/// </summary>
		private void InitailizeProviderInformation()
		{
			lock(ConfigurationManager.mSyncObject)
			{
				ProviderSection providers = this.GetConfig("ProviderSection", typeof(ProviderSection)) as ProviderSection;
				foreach(ProviderSection.Provider providerInfo in providers.Providers)
				{
					Provider provider = null;
					DbSchema schema = null;
					string strAssemblyName = null;
					if(!Kit.IsEmpty(providerInfo.ExternalAssembly))
					{
						strAssemblyName = Kit.GetLocalPath(providerInfo.ExternalAssembly);
						if(!Kit.IsEmpty(strAssemblyName))
						{
							Assembly assembly = Assembly.LoadFrom(strAssemblyName);
							provider = assembly.CreateInstance(providerInfo.Type, true, BindingFlags.Public|BindingFlags.CreateInstance, null, new object[]{providerInfo}, CultureInfo.CurrentCulture, null) as Provider;
							schema= assembly.CreateInstance(providerInfo.DbSchemaType) as DbSchema;
						}
						else
							continue;
					}
					else
					{
						provider = System.Activator.CreateInstance(Type.GetType(providerInfo.Type), new object[]{providerInfo}) as Provider;
						schema= System.Activator.CreateInstance(Type.GetType(providerInfo.DbSchemaType), null) as DbSchema;
					}

					if(provider==null || schema==null)
						throw new DQException("10002", providerInfo.Name);

					if(this.DbSchemaCache.Contains(providerInfo.Name))
						throw new DQException("10019");
					schema.LoadDbSchema(provider.ParseToOleConnectionString(providerInfo));
					// The schema added into cache is global singleton object
					this.DbSchemaCache.Add(providerInfo.Name, schema);
				}
			}
		}


		/// <summary>
		/// Get configuration persist object
		/// </summary>
		/// <param name="sectionName"></param>
		/// <param name="type"></param>
		/// <returns></returns>
		public object GetConfig(string sectionName, Type type)
		{
			Check.VerifyNotNull(sectionName);
			Check.VerifyNotNull(type);
			return this.Builder.GetConfig(sectionName, type);
		}

	}
}