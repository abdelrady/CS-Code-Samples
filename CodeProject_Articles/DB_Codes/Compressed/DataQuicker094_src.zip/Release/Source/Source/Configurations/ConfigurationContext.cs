// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// Provides a context to configuration file.
	/// </summary> 
	internal class ConfigurationContext : IDisposable
	{
		private const string ConfigurationSectionValue = "DataQuicker.Framework";
		private string mCurrentConfigFileName;
		private XmlDocument mConfigurationDocument;
		private ConfigurationChangeWacther mWatch;

		/// <summary>
		///  Initialize a new instance of the <see cref="ConfigurationManager"/> class with a configuration file.
		/// </summary>
		public ConfigurationContext()
		{
			this.InitializeApplicationConfiguration();
			this.mWatch = new ConfigurationChangeWacther(this.mCurrentConfigFileName, new ConfigurationChangedEventHandler(LoadConfiguration));
			this.LoadConfiguration();
		}


		/// <summary>
		/// Get xml document
		/// </summary>
		public XmlDocument ConfigurationDocument
		{
			get
			{
				return this.mConfigurationDocument;
			}
		}

		/// <summary>
		/// Get current configuration file path.
		/// </summary>
		public string CurrentConfigFileName
		{
			get
			{
				return this.mCurrentConfigFileName;
			}
		}

		/// <summary>
		/// Load configuration
		/// </summary>
		private void LoadConfiguration()
		{
			this.mWatch.StopWatching();
			this.mConfigurationDocument = new XmlDocument();
			this.mConfigurationDocument.Load(this.mCurrentConfigFileName);
			this.mWatch.StartWatching();
		}


		/// <summary>
		/// Load DataQuicker configuration file path from application configuraion.
		/// </summary>
		/// <returns>DataQuicker configuration file path</returns>
		private void InitializeApplicationConfiguration()
		{
			string strSettings = ConfigurationSettings.AppSettings[ConfigurationContext.ConfigurationSectionValue];
			if(Kit.IsEmpty(strSettings))
				throw new DQException("10067");

			strSettings = Kit.GetLocalPath(strSettings);
			if(Kit.IsEmpty(strSettings))
				throw new DQException("10067");

			this.mCurrentConfigFileName = strSettings;
		}
        

		/// <summary>
		/// Releases resources occupied by <seealso cref="ConfigurationBuilder"/>
		/// </summary>
		public void Dispose()
		{
			this.mWatch.Dispose();
		}
	}
}