// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Threading;
using System.ComponentModel;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// Summary description for ConfigurationWacther.
	/// </summary>
	internal class ConfigurationChangeWacther: IDisposable
	{
		private const int PollDelayMilliseconds = 30000;
		private string mConfigurationFileName;
		private Thread mPollingThread;
		private DateTime mLastWriteTime;
		private bool mPolling;
		private object mSyncObject = new object();
		private ConfigurationChangedEventHandler mOnConfigurationChanged;

		public ConfigurationChangeWacther(string configurationFileName, ConfigurationChangedEventHandler handler)
		{
			this.mConfigurationFileName = configurationFileName;
			this.mOnConfigurationChanged = handler;
		}

		~ConfigurationChangeWacther()
		{
			this.StopWatching();
		}

		/// <summary>
		/// Dispose
		/// </summary>
		public void Dispose()
		{
			this.StopWatching();
		}

		/// <summary>
		/// <para>Starts watching the configuration file.</para>
		/// </summary>
		public void StartWatching()
		{
			lock (this.mSyncObject)
			{
				if (this.mPollingThread == null)
				{
					this.mPolling = true;
					this.mPollingThread = new Thread(new ThreadStart(Poller));
					this.mPollingThread.IsBackground = true;
					this.mPollingThread.Name = "DataQuickerConfigurationChangeWacther";
					this.mPollingThread.Start();
				}
			}
		}

		/// <summary>
		/// <para>Stops watching the configuration file.</para>
		/// </summary>
		public void StopWatching()
		{
			lock (this.mSyncObject)
			{
				if(this.mPollingThread != null)
				{
					this.mPolling = false;
					this.mPollingThread = null;
				}
			}
		}

		/// <summary>
		/// Poll to watch change of configuration file.
		/// </summary>
		private void Poller()
		{
			this.mLastWriteTime = DateTime.MinValue;
			DateTime currentLastWriteTime = DateTime.MinValue;
			while (this.mPolling)
			{
				currentLastWriteTime = GetCurrentLastWriteTime();
				if (currentLastWriteTime != DateTime.MinValue)
				{
					if (this.mLastWriteTime.Equals(DateTime.MinValue))
					{
						this.mLastWriteTime = currentLastWriteTime;
					}
					else
					{
						if (this.mLastWriteTime.Equals(currentLastWriteTime) == false)
						{
							this.mLastWriteTime = currentLastWriteTime;
							this.mOnConfigurationChanged();
						}
					}
				}
				Thread.Sleep(ConfigurationChangeWacther.PollDelayMilliseconds);		
			}
		}

		/// <summary>
		/// <para>Returns the <see cref="DateTime"/> of the last change of the information watched</para>
		/// <para>The information is retrieved using the watched file modification timestamp</para>
		/// </summary>
		/// <returns>The <see cref="DateTime"/> of the last modificaiton, or <code>DateTime.MinValue</code> if the information can't be retrieved</returns>
		private DateTime GetCurrentLastWriteTime()
		{
			if (File.Exists(this.mConfigurationFileName) == true)
			{
				return File.GetLastWriteTime(this.mConfigurationFileName);
			}
			else
			{
				return DateTime.MinValue;
			}
		}
	}
}
