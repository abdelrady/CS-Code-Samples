// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// Persist message collection in configuration
	/// </summary>
	public class MessageSection
	{
		/// <summary>
		/// Array of <seealso cref="DataQuicker.Framework.Configuration.MessageSection.Message"/>
		/// </summary>
		public Message[] Messages;

		/// <summary>
		/// Get message by id
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public Message GetMessageByID(string id)
		{
			if(this.Messages == null)
				return null;

			foreach(Message message in this.Messages)
				if(string.Compare(message.ID, id, true) == 0)
					return message;
			return null;
		}

		/// <summary>
		/// Get message
		/// </summary>
		/// <param name="id"></param>
		/// <param name="language"></param>
		/// <returns></returns>
		public string GetMessage(string id, string language)
		{
			Message message = this.GetMessageByID(id);
			if(string.Compare(language, "CH", true)==0)
				return message.CH;
			if(string.Compare(language, "EN", true)==0)
				return message.EN;
			return "Unknown";
		}

		/// <summary>
		/// Persist message information in configuration
		/// </summary>
		public class Message
		{
			/// <summary>
			/// Message ID
			/// </summary>
			public string ID;
			/// <summary>
			/// Chinese information
			/// </summary>
			public string CH;
			/// <summary>
			/// English information
			/// </summary>
			public string EN;
		}
	}
}
