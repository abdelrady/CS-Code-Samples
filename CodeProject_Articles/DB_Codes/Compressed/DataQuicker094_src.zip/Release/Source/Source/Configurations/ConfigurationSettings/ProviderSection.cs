// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Reflection;
using DataQuicker.Framework.Cryptography;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// Persist provider collection in configuration
	/// </summary>
	[Serializable]
	public class ProviderSection
	{
		/// <summary>
		/// Array of <seealso cref="DataQuicker.Framework.Configuration.ProviderSection.Provider"/>
		/// </summary>
		public Provider[] Providers;
		/// <summary>
		/// Default provider name
		/// </summary>
		public string Default;

		/// <summary>
		/// Maximum caching object
		/// </summary>
		public long Maximum;

		/// <summary>
		/// Get <seealso cref="ProviderSection.Provider"/> by its provider name
		/// </summary>
		/// <param name="providerName"></param>
		/// <returns></returns>
		public Provider GetProvider(string providerName)
		{
			foreach(ProviderSection.Provider provider in this.Providers)
			{
				if(string.Compare(providerName, provider.Name, true)==0)
					return provider;
			}
			return null;
		}

		/// <summary>
		/// Persist provider information in configuration
		/// </summary>
		[Serializable]
		public class Provider
		{
			/// <summary>
			/// Provider name
			/// </summary>
			public string Name;
			/// <summary>
			/// External assembly file relative path.
			/// </summary>
			public string ExternalAssembly;
			/// <summary>
			/// Provider type
			/// </summary>
			public string Type;
			/// <summary>
			/// DbSchema type name
			/// </summary>
			public string DbSchemaType;
			/// <summary>
			/// Analyzer type name
			/// </summary>
			public string AnalyzerType;
			/// <summary>
			/// Aggregate analyzer type name
			/// </summary>
			public string AggregateAnalyzerType;

			#region ConnectionString
			/// <summary>
			/// Database connection provider name
			/// </summary>
			public string DbProvider;
			/// <summary>
			/// Data source
			/// </summary>
			public string DataSource;
			/// <summary>
			/// Database category, usually for server-client database
			/// </summary>
			public string Category;
			/// <summary>
			/// User ID
			/// </summary>
			public string UserID;
			
			private string mPassword;
			/// <summary>
			/// Password
			/// </summary>
			public string Password
			{
				get
				{
					if(this.Cryptography)
					{
						object decryptor = null;
						try
						{
							if(!Kit.IsEmpty(this.CryptographyAssemblyPath))
							{
								string strAssemblyFileName = Kit.GetLocalPath(this.CryptographyAssemblyPath);
								Assembly assembly = Assembly.LoadFrom(strAssemblyFileName);
								decryptor= assembly.CreateInstance(this.CryptographyType);
							}
							else
							{
								Type cryptographyType = System.Type.GetType(this.CryptographyType);
								decryptor = Activator.CreateInstance(cryptographyType);
							}
						}
						catch
						{
							throw new DQException("10043");
						}

						if(!(decryptor is ICryptography))
							throw new DQException("10042", this.CryptographyType);

						return (decryptor as ICryptography).Decrypt(this.mPassword);
					}
					else 
						return this.mPassword;
				}
				set
				{
					this.mPassword = value;
				}
			}
			/// <summary>
			/// Extra information
			/// </summary>
			public string Extra;

			/// <summary>
			/// True for decrypting password
			/// </summary>
			public bool Cryptography;

			/// <summary>
			/// Loading external assembly for decrypting password
			/// </summary>
			public string CryptographyAssemblyPath;

			/// <summary>
			/// Decryptor type
			/// </summary>
			public string CryptographyType;
			#endregion
		}
	}
}
