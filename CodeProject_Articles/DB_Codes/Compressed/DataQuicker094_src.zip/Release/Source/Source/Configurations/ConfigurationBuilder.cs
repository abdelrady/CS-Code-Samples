// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;

namespace DataQuicker.Framework.Configuration
{
	/// <summary>
	/// ConfigurationBuilder
	/// </summary> 
	public class ConfigurationBuilder
	{
		private ConfigurationContext mContext;
		private Hashtable Cache = new Hashtable();

		/// <summary>
		/// Constructor
		/// </summary>
		public ConfigurationBuilder()
		{
			this.mContext = new ConfigurationContext();
		}

		/// <summary>
		/// Get configuration persist object
		/// </summary>
		/// <param name="sectionName"></param>
		/// <param name="type"></param>
		/// <returns></returns>
		public object GetConfig(string sectionName, Type type)
		{
			if(this.Cache.Contains(sectionName))
				return this.Cache[sectionName];
			else
			{
				XmlNodeList nodes = this.mContext.ConfigurationDocument.SelectNodes("//" + sectionName);
				if(nodes==null || nodes.Count==0) return null;
				XmlNode node = nodes[0];
				XmlSerializer serializer = new XmlSerializer(type);
				StringReader sr = new StringReader(node.OuterXml);
				object result = serializer.Deserialize(sr);
				this.Cache.Add(sectionName, result);
				return result;
			}
		}
	}
}