// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Sql Operator
	/// </summary>
	[Serializable]
	public enum SqlOperator
	{
		/// <summary>
		/// =
		/// </summary>
		[Enum(" = {0}")]
		Equal,
		/// <summary>
		/// &lt;&gt;
		/// </summary>
		[Enum(" <> {0}")]
		Unequal,
		/// <summary>
		/// &lt;
		/// </summary>
		[Enum(" < {0}")]
		LessThan,
		/// <summary>
		/// &lt;=
		/// </summary>
		[Enum(" <= {0}")]
		LessThanEqual,
		/// <summary>
		/// &gt;
		/// </summary>
		[Enum(" > {0}")]
		MoreThan,
		/// <summary>
		/// &gt;=
		/// </summary>
		[Enum(" >= {0}")]
		MoreThanEqual,
		/// <summary>
		/// IN
		/// </summary>
		[Enum(" IN ({0})")]
		In,
		/// <summary>
		/// NOT IN
		/// </summary>
		[Enum(" NOT IN ({0})")]
		NotIn,
		/// <summary>
		/// LIKE 'Variable'
		/// </summary>
		[Enum(" LIKE {0}")]
		Like,
		/// <summary>
		/// NOT LIKE 'Variable'
		/// </summary>
		[Enum(" NOT LIKE {0}")]
		Unlike,
	}
}
