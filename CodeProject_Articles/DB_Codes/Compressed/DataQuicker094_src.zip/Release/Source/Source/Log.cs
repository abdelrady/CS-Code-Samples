// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Text;
using System.IO;

using DataQuicker.Framework.Configuration;

namespace DataQuicker.Framework
{
	/// <summary>
	/// Log management
	/// </summary>
	public sealed class Log
	{
		[ThreadStatic]
		private static string mHeader;

		private Log(){}

		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="msg"></param>
		public static void Write(string msg)
		{
			Log.Write("", msg, null);
		}

		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="clientId"></param>
		/// <param name="msg"></param>
		public static void Write(string clientId, string msg)
		{
			Log.Write(clientId, msg, null);
		}

		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="msg"></param>
		/// <param name="exp"></param>
		public static void Write(string msg, Exception exp)
		{
			Log.Write("", msg, exp);
		}


		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="exp"></param>
		public static void Write(Exception exp)
		{
			Log.Write("", "", exp);
		}

		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="clientId"></param>
		/// <param name="msg"></param>
		/// <param name="exp"></param>
		public static void Write(string clientId, string msg, Exception exp)
		{
			string strFileName = Log.LogFileName;
			StreamWriter sw = new StreamWriter(Log.LogFileName, true, Encoding.Unicode);
			try
			{
				string severity = "";
				if(exp != null)
				{
					if(exp is DQException)
						severity = "Manual";
					else
						severity = "Hign";
				}

				string content = string.Format(Log.Header, severity, clientId, msg);
				if(exp != null)
				{
					content += "\r\nExcetion Message: ";
					content += exp.Message;
					content += "\r\nException Source: ";
					content += exp.Source;
					content += "\r\nException StackTrace: ";
					content += exp.StackTrace;
				}
				sw.Write(content);
			}
			finally
			{
				sw.Close();
			}
		}

		/// <summary>
		/// Write log content
		/// </summary>
		/// <param name="command"></param>
		/// <param name="exp"></param>
		public static void Write(IDbCommand command, Exception exp)
		{
			string message = "";
			message += "SQL: " + command.CommandText + "\r\n";
			int index = 0;
			foreach(IDataParameter parameter in command.Parameters)
				message += Convert.ToString(++index) + "Parameter Name: " + parameter.ParameterName + "; Value: " + parameter.Value.ToString() + "\r\n";
			Log.Write(message, exp);
		}

		/// <summary>
		/// Get current log file name.
		/// </summary>
		public static string LogFileName
		{
			get
			{
				DateTime dtm = DateTime.Now;
				BasicSection section = ConfigurationManager.Instance.GetConfig("BasicSection", typeof(BasicSection)) as BasicSection;
				string strFileName = section.LogPath;
				strFileName += "\\DQLog_" + Convert.ToString(dtm.Year)+ Convert.ToString(dtm.Month).PadLeft(2, '0') + Convert.ToString(dtm.Day).PadLeft(2, '0') + ".txt";
				return strFileName;
			}
		}

		/// <summary>
		/// Get header segment of log
		/// </summary>
		public static string Header
		{
			get
			{
				if(Kit.IsEmpty(Log.mHeader))
				{
					StringBuilder sbLog = new StringBuilder();
					sbLog.Append("\r\n\r\n");
					sbLog.Append("Log Date Time: ");
					sbLog.Append(DateTime.Now.ToString());
					sbLog.Append("\r\n");
					sbLog.Append("Severity: \r\n{0}");
					sbLog.Append("\r\n");
					sbLog.Append("Client ID: \r\n{1}");
					sbLog.Append("\r\n");
					sbLog.Append("Content: \r\n{2}\r\n");
					sbLog.Append("----------------------------Exception Description-----------------------------\r\n");
					Log.mHeader = sbLog.ToString();
				}
				return Log.mHeader;
			}
		}
	}
}
