// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Sql
{
	/// <summary>
	/// Summary description for QueryTest.
	/// </summary>
	[TestFixture]
	public class QueryTest
	{
		/// <summary>
		/// Query records which its sales is more than 100000
		/// </summary>
		[Test]
		public void Query1()
		{
			CategorySalesFor1997 category = new CategorySalesFor1997();
			Query query = new Query(category);
			query.Criteria.Add(category.CategorySales, SqlOperator.MoreThan, 100000);

			IProvider provider = Providers.GetProvider();
			DataTable dtbl = provider.Query(query);
			Assert.AreEqual(2, dtbl.Rows.Count);
		}

		/// <summary>
		/// Query records which its sales is more than 100000 and its category name is  Beverages or Confections
		/// </summary>
		[Test]
		public void Query2()
		{
			CategorySalesFor1997 category = new CategorySalesFor1997();
			Query query = new Query(category);
			//Conditions
			query.Criteria.Add(category.CategoryName, SqlOperator.In, "Beverages", "Confections");
			query.Criteria.Add(category.CategorySales, SqlOperator.MoreThan, 100000);

			//Order by CategoryName, descending
			query.OrderBy.Add(category.CategoryName, false);

			IProvider provider = Providers.GetProvider();
			DataTable dtbl = provider.Query(query);
			Assert.AreEqual(1, dtbl.Rows.Count);
		}

		[Test]
		public void Query3()
		{
			Orders order = new Orders();
			Customers customer = new Customers();
			Query query = new Query(order);
			//Associate Orders with Customers
			query.Associations.Add(new FieldMapping[]{order.CustomerID}, AssociationType.Left, new FieldMapping[]{customer.CustomerID});
			query.Criteria.Add(order.Freight, SqlOperator.MoreThan, 10000);

			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}
	}
}
