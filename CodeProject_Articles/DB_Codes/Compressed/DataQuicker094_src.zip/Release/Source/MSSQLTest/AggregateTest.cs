// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Sql
{
	/// <summary>
	/// Test database operations on entity Customers, insert, update, load, query and delete.
	/// </summary>
	[TestFixture]
	public class AggregateTest
	{
		/// <summary>
		/// Test add aggregate function
		/// </summary>
		[Test]
		public void AddAggregate()
		{
			Employees employee = new Employees();
			Query query = new Query(employee);
			query.Selects.None = true;

			// Combine Aggregate Expression: FirstName + ' ' + LastName AS FullName
			Aggregate aggregate = new Aggregate(AggregateType.Add, employee.FirstName, " ");
			query.Aggregates.Add(AggregateType.Add, "FullName", aggregate, employee.LastName);

			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}

		/// <summary>
		/// Test Count(*) aggregate function
		/// </summary>
		[Test]
		public void CountAggregate()
		{
			Employees employee = new Employees();
			Query query = new Query(employee);
			query.Selects.None = true;
			query.Aggregates.Add(AggregateType.Count, "Count", null);
			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}

		[Test]
		public void SumAggregate()
		{
			CategorySalesFor1997 sales = new CategorySalesFor1997();
			Query query = new Query(sales);
			query.Selects.None = true;
			query.Aggregates.Add(AggregateType.Sum, "Sales", sales.CategorySales);
			query.GroupBy.Add(sales.CategorySales);
			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}

		/// <summary>
		/// To get the sql similiar with: "SELECT OrderDate, sum(Freight) FROM Orders GROUP BY OrderDate"
		/// </summary>
		[Test]
		public void StatisticAggregate()
		{
			Orders order = new Orders();
			Query query = new Query(order);
			query.Selects.Add(order.OrderDate);
			query.Aggregates.Add(AggregateType.Sum, "TotalFreight", order.Freight);
			query.GroupBy.Add(order.OrderDate);
			IProvider provider = Providers.GetProvider();
			provider.Query(query);
		}
	}
}