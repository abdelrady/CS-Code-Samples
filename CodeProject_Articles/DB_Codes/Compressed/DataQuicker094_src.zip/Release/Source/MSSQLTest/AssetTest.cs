// Product Name: DataQuicker (O/R Mapping)
// Licensor: Eunge
// Email: eudev.net@yeah.net
// Blog: http://lovinger2000.cnblogs.com
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Data;
using System.Collections;
using DataQuicker.Framework;
using NUnit.Framework;

namespace DataQuicker.Demo.Sql
{
	/// <summary>
	/// Summary description for AssetTest.
	/// </summary>
	[TestFixture]
	public class AssetTest
	{
		[Test]
		public void Create()
		{
			Asset asset = new Asset();
			asset.AssetName += "DataQuicker";
			asset.Owner += "Eunge";
			asset.Amount += 102;
			asset.Email += "eudev.net@yeah.net";
			IProvider provider = Providers.GetProvider();
			ITransaction trans = provider.BeginTrans();
			try
			{
				provider.Create(asset);
				Assert.IsFalse(asset.AssetID.IsNull);
				Assert.IsTrue(asset.Exist);
			}
			finally
			{
				trans.Rollback();
			}
		}

		[Test]
		public void Delete()
		{
			Asset asset = new Asset();
			asset.AssetName += "DataQuicker";
			asset.Owner += "Eunge";
			asset.Amount += 102;
			asset.Email += "eudev@yeah.net";
			IProvider provider = Providers.GetProvider();
			ITransaction trans = provider.BeginTrans();
			try
			{
				provider.Create(asset);
				Assert.IsFalse(asset.AssetID.IsNull);
				Assert.IsTrue(asset.Exist);
				
				string strAssetId = asset.AssetID.Value;

				// * Pay attention:
				// It's forbidden to retrieve object using "asset = Asset.CreateInstance(strAssetId);" here.
				// Because the transaction opened by provider locks the Asset. 
				// The above sentence will create a inner new provider, and it retrieves the data from data table. 
				// But the table has been locked by the old provider, so, it will be failed.
				asset = new Asset();
				asset.AssetID += strAssetId;
				provider.Retrieve(asset);

				provider.Delete(asset);
			}
			finally
			{
				trans.Rollback();
			}
		}
	}
}
