// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-6

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Sql
{
	[Serializable, PhysicalName("Asset"), Provider("NUnitTest")]
	public class Asset: TableMapping
	{
		public Asset(){}

		public Asset(String assetID): base(assetID){}

		#region Properties
		private FString mAssetID = new FString();
		[PhysicalName("AssetID"), PrimaryKey(PrimaryKeyType.Guid)]
		public FString AssetID
		{
			get
			{
				return this.mAssetID;
			}
			set
			{
				this.mAssetID.Replace(value);
			}
		}

		private FString mAssetName = new FString();
		[PhysicalName("AssetName")]
		public FString AssetName
		{
			get
			{
				return this.mAssetName;
			}
			set
			{
				this.mAssetName.Replace(value);
			}
		}

		private FInt mAmount = new FInt();
		/// <summary>
		/// Set/Get amount. The value should be more than zero.
		/// </summary>
		[PhysicalName("Amount"), Validate(0)]
		public FInt Amount
		{
			get
			{
				return this.mAmount;
			}
			set
			{
				this.mAmount.Replace(value);
			}
		}

		private FString mOwner = new FString();
		[PhysicalName("Owner")]
		public FString Owner
		{
			get
			{
				return this.mOwner;
			}
			set
			{
				this.mOwner.Replace(value);
			}
		}

		private FString mEmail = new FString();
		/// <summary>
		/// Set/Get Email Address. DataQuicker will validtae the value of property.
		/// </summary>
		[PhysicalName("Email"), Validate(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*")]
		public FString Email
		{
			get
			{
				return this.mEmail;
			}
			set
			{
				this.mEmail.Replace(value);
			}
		}

		private FString mPhone = new FString();
		[PhysicalName("Phone")]
		public FString Phone
		{
			get
			{
				return this.mPhone;
			}
			set
			{
				this.mPhone.Replace(value);
			}
		}

		#endregion
	}
}
