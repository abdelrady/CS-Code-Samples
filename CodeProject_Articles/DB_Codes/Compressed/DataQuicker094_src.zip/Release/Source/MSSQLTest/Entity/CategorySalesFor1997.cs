// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-5

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Sql
{
	[Serializable, PhysicalName("Category Sales for 1997"), Provider("NUnitTest")]
	public class CategorySalesFor1997: ViewMapping
	{
		public CategorySalesFor1997(){}

		#region Properties
		private FString mCategoryName = new FString();
		[PhysicalName("CategoryName")]
		public FString CategoryName
		{
			get
			{
				return this.mCategoryName;
			}
			set
			{
				this.mCategoryName.Replace(value);
			}
		}

		private FDecimal mCategorySales = new FDecimal();
		[PhysicalName("CategorySales")]
		public FDecimal CategorySales
		{
			get
			{
				return this.mCategorySales;
			}
			set
			{
				this.mCategorySales.Replace(value);
			}
		}

		#endregion
	}
}
