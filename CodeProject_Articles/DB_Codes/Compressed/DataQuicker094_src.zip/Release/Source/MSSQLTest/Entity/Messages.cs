// Data Access Layer Replies on Project DataQuicker
// All source code generated automatically
// Date: 2005-9-8

using System;
using DataQuicker.Framework;

namespace DataQuicker.Demo.Sql
{
	[Serializable, PhysicalName("Messages"), Provider("NUnitTest")]
	public class Messages: TableMapping
	{
		public Messages(){}

		public Messages(String messageID){}

		#region Properties
		private FString mAuthor = new FString();
		[PhysicalName("Author")]
		public FString Author
		{
			get
			{
				return this.mAuthor;
			}
			set
			{
				this.mAuthor.Replace(value);
			}
		}

		private FString mContent = new FString();
		[PhysicalName("Content")]
		public FString Content
		{
			get
			{
				return this.mContent;
			}
			set
			{
				this.mContent.Replace(value);
			}
		}

		private FDateTime mCreateDate = new FDateTime();
		[PhysicalName("CreateDate")]
		public FDateTime CreateDate
		{
			get
			{
				return this.mCreateDate;
			}
			set
			{
				this.mCreateDate.Replace(value);
			}
		}

		private FString mMessageID = new FString();
		[PhysicalName("MessageID"), PrimaryKey(PrimaryKeyType.DQIncrease)]
		public FString MessageID
		{
			get
			{
				return this.mMessageID;
			}
			set
			{
				this.mMessageID.Replace(value);
			}
		}

		private FString mSubject = new FString();
		[PhysicalName("Subject")]
		public FString Subject
		{
			get
			{
				return this.mSubject;
			}
			set
			{
				this.mSubject.Replace(value);
			}
		}

		#endregion
	}
}
