// AsyncDatabase.cpp : implementation file
//
//***************************************************************************
// Asynchronous database
//***************************************************************************
#include "stdafx.h"
#include "afxconv.h"
#include "AsyncDatabase.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAsyncDatabase

CAsyncDatabase::CAsyncDatabase()
{
}

CAsyncDatabase::~CAsyncDatabase()
{
}

HSTMT CAsyncDatabase::ExecuteSQLAsync(LPCTSTR lpszSQL)
{
	USES_CONVERSION;
	RETCODE nRetCode;
	HSTMT hstmt = NULL;

	ASSERT_VALID(this);
	ASSERT(AfxIsValidString(lpszSQL));

	AFX_SQL_SYNC(::SQLAllocStmt(m_hdbc, &hstmt));
	if(!Check(nRetCode))
		AfxThrowDBException(nRetCode, this, hstmt);

	TRY
	{
		OnSetOptions(hstmt);

		// Give derived CDatabase classes option to use parameters
		BindParameters(hstmt);

		nRetCode = ::SQLExecDirect(hstmt, (UCHAR*)T2A((LPTSTR)lpszSQL), SQL_NTS);

		// check retcode
		switch (nRetCode)
		{
			case SQL_SUCCESS_WITH_INFO:
			case SQL_SUCCESS:
			case SQL_NO_DATA_FOUND:
			case SQL_STILL_EXECUTING:
				break;
			default:
				AfxThrowDBException(nRetCode, this, hstmt);
		}
	}
	CATCH_ALL(e)
	{
		::SQLCancel(hstmt);
		AFX_SQL_SYNC(::SQLFreeStmt(hstmt, SQL_DROP));
		THROW_LAST();
	}
	END_CATCH_ALL

	//AFX_SQL_SYNC(::SQLFreeStmt(hstmt, SQL_DROP));
	CString strHstmt;
	
	// We must remember our SQL query 
	// in order to call SQLExecDirect() again with the same parameters!
	strHstmt.Format("%ld", hstmt);
	m_mapHstmtToQuery[strHstmt] = lpszSQL;

	return hstmt;
}

BOOL CAsyncDatabase::SQLStillExecuting(HSTMT hstmt)
{
	USES_CONVERSION;

	CString strQuery;
	CString strHstmt;
	strHstmt.Format("%ld", hstmt);

	if(m_mapHstmtToQuery.Lookup(strHstmt, strQuery))
	{
		RETCODE nRetCode = ::SQLExecDirect(hstmt, (UCHAR*)T2A((LPTSTR)(LPCTSTR)strQuery), SQL_NTS);

		// ckeck retcode
		switch (nRetCode)
		{
			case SQL_SUCCESS_WITH_INFO:
			case SQL_SUCCESS:
			case SQL_NO_DATA_FOUND:
			case SQL_STILL_EXECUTING:
				break;
			default:
				//AfxThrowDBException(nRetCode, this, hstmt);
				break;
		}

		BOOL bRet = (nRetCode == SQL_STILL_EXECUTING);

		if(!bRet)
		{
			AFX_SQL_SYNC(::SQLFreeStmt(hstmt, SQL_DROP));
		}

		return bRet;
	}

	return FALSE;
}

void CAsyncDatabase::OnSetOptions(HSTMT hstmt)
{
	CDatabase::OnSetOptions(hstmt);

	RETCODE nRetCode = ::SQLSetStmtOption(hstmt, SQL_ASYNC_ENABLE, SQL_ASYNC_ENABLE_ON);
	if(!Check(nRetCode))
	{
		TRACE("Warning! Can not set SQL_ASYNC_ENABLE option.");
		::AfxThrowDBException(nRetCode, this, hstmt);
	}
}

void CAsyncDatabase::Cancel(HSTMT hstmt)
{
	ASSERT_VALID(this);
	ASSERT(m_hdbc != SQL_NULL_HDBC);
	RETCODE nRetCode;
	
	nRetCode = ::SQLCancel(hstmt);
	if(!Check(nRetCode))
	{
		TRACE("SQLcancel failed.");
		//::AfxThrowDBException(nRetCode, this, hstmt);
	}
}
