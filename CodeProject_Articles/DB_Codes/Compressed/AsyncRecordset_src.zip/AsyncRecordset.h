// AsyncRecordset.h : header file
/////////////////////////////////////////////////////////////////////////////
// CAsyncRecordset recordset
// 
//
/////////////////////////////////////////////////////////////////////////////
#include "DynamicRecordset.h"

class CAsyncRecordset : public CDynamicRecordset
{
public:
	CAsyncRecordset(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CAsyncRecordset)

// Field/Param Data
	//{{AFX_FIELD(CAsyncRecordset, CDynamicRecordset)
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAsyncRecordset)
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	virtual BOOL OpenAsync(UINT nOpenType = AFX_DB_USE_DEFAULT_TYPE, LPCTSTR lpszSQL = NULL, DWORD dwOptions = none);
	
	virtual void OnSetOptions(HSTMT hstmt);
	
	BOOL StillExecuting();

protected:

	void PrepareAndExecute();

private:
	BOOL m_bUnbound;
};
