// AsyncDatabase.h : header file
//
//***************************************************************************
// Asynchronous database
// performs asynchronous query execution 
// 
// SAMPLE:
// CAsyncDatabase * pDB = new CAsyncDatabase;
// pDB->OpenEx(....);
// HSTMT hstmt = pDB->ExecuteSQLAsync("SELECT * FROM SOMEWHERE");
// while(pDB->SQLStillExecuting(hstmt))
// {
//		... do something here ...
// }
// 
// do not call SQLFreeStmt() if you are using SQLStillExecuting() loop
// 
// WARNING: according to MSDN documentation asynchronous execution must be 
// done in working threads only!
// fortunately MS SQL Server works around this problem
//***************************************************************************

#ifndef _ASYNC_DATABASE_H_
#define _ASYNC_DATABASE_H_

class CAsyncDatabase : public CDatabase
{
// Construction
public:
	CAsyncDatabase();

// Attributes
public:

// Operations
public:

// Implementation
public:
	virtual ~CAsyncDatabase();
	
	HSTMT ExecuteSQLAsync(LPCTSTR lpszSQL);

	BOOL SQLStillExecuting(HSTMT hstmt);

	virtual void OnSetOptions(HSTMT hstmt);
	virtual void Cancel(HSTMT hstmt);

	// Generated message map functions
protected:
	CMapStringToString m_mapHstmtToQuery;
};

/////////////////////////////////////////////////////////////////////////////
#endif // _ASYNC_DATABASE_H_