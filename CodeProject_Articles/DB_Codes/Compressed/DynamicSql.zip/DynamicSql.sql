/* Create's the Table tblEmployees */
CREATE TABLE tblEmployees
(
	EmployeeID    SMALLINT IDENTITY(1001,1) NOT NULL,
	EmployeeName  NVARCHAR(100) NOT NULL,
	Department    NVARCHAR(50) NOT NULL,
	Designation   NVARCHAR(50) NOT NULL,
	JoiningDate   DATETIME NOT NULL,
	Salary	      DECIMAL(10,2) NOT NULL,
	[Description] NVARCHAR(1000) NULL 
)

/* Inserts sample records in to the tblEmployee */
INSERT INTO tblEmployees(EmployeeName, Department, Designation, JoiningDate, Salary, [Description]) 
VALUES	('John Smith', 'IT Research', 'Research Analyst', '02/08/2005', 23000.00, 'John Smith is involved in the Research and Development since 2005')

INSERT INTO tblEmployees(EmployeeName, Department, Designation, JoiningDate, Salary, [Description]) 
VALUES	('John Micheal', 'IT Operations', 'Manager', '07/15/2007', 15000.00, NULL)

INSERT INTO tblEmployees(EmployeeName, Department, Designation, JoiningDate, Salary, [Description]) 
VALUES	('Will Smith', 'IT Support', 'Manager', '05/20/2006', 13000.00, 'Joined this year as IT Support Manager')

/* Using EXECUTE Command - Example 1.0 */

/* Variable Declaration */
DECLARE @EmpID AS SMALLINT
DECLARE @SQLQuery AS NVARCHAR(500)

/* Build and Execute a Transact-SQL String with a single parameter value Using EXECUTE Command */
SET @EmpID = 1001
SET @SQLQuery = 'SELECT * FROM tblEmployees WHERE EmployeeID = ' + CAST(@EmpID AS NVARCHAR(10))
Print @SQLQuery 
EXECUTE(@SQLQuery)


/* Using sp_executesql - Example 1.1 */

/* Variable Declaration */
DECLARE @EmpID AS SMALLINT
DECLARE @SQLQuery AS NVARCHAR(500)
DECLARE @ParameterDefinition AS NVARCHAR(100)

/* Build and Execute a Transact-SQL String with a single parameter value Using sp_executesql Command */
SET @EmpID = 1001
SET @SQLQuery = 'SELECT * FROM tblEmployees WHERE EmployeeID = @EmpID' 

/* Specify Parameter Format */
SET @ParameterDefinition =  '@EmpID SMALLINT'

EXECUTE sp_executesql @SQLQuery, @ParameterDefinition, @EmpID



/* Create Stored Procedure 'sp_EmployeeSelect'. Example 2.0  */ 
Create Procedure sp_EmployeeSelect
	@EmployeeName NVarchar(100),
	@Department NVarchar(50),
	@Designation NVarchar(50),
	@StartDate DateTime,
	@EndDate DateTime,
	@Salary	Decimal(10,2)
	    
AS
  
	Set NoCount ON
  
	Declare @SQLQuery AS NVarchar(4000)
	Declare @ParamDefinition AS NVarchar(2000) 
  
	Set @SQLQuery = 'Select * From tblEmployees where (1=1) ' 
  
	If @EmployeeName Is Not Null 
	     Set @SQLQuery = @SQLQuery + ' And (EmployeeName = @EmployeeName)'

	If @Department Is Not Null
	     Set @SQLQuery = @SQLQuery + ' And (Department = @Department)' 
  
	If @Designation Is Not Null
	     Set @SQLQuery = @SQLQuery + ' And (Designation = @Designation)'
  
	If (@StartDate Is Not Null) AND (@EndDate Is Not Null)
	     Set @SQLQuery = @SQLQuery + ' And (JoiningDate BETWEEN @StartDate AND @EndDate)'

	If @Salary Is Not Null
	     Set @SQLQuery = @SQLQuery + ' And (Salary >= @Salary)'
	
	Set @ParamDefinition = '@EmployeeName NVarchar(100),
				@Department NVarchar(50),
				@Designation NVarchar(50),
				@StartDate DateTime,
				@EndDate DateTime,
				@Salary	Decimal(10,2)'

	Exec sp_Executesql 	@SQLQuery, 
				@ParamDefinition, 
				@EmployeeName, 
				@Department, 
				@Designation, 
				@StartDate, 
				@EndDate,
				@Salary
				
	If @@ERROR <> 0 GoTo ErrorHandler
	Set NoCount OFF
	Return(0)
  
ErrorHandler:
	Return(@@ERROR)
GO


/* 1. Search for specific Employee Detail with the Name say 'John Smith'. */
EXEC sp_EmployeeSelect 'John Smith', NULL, NULL, NULL, NULL, NULL


/* 2. List of Employees in a specific Department. AND 3. List of Employees in a specific Designation. */
/* Say Department = 'IT Operations'  AND  Designation = 'Manager'*/
EXEC sp_EmployeeSelect NULL, 'IT Operations', 'Manager', NULL, NULL, NULL



/* Using Like Operator , IN Operator and Order By In Dynamic SQL */
/* Using sp_executesql */

/* Example 3.0 use LIKE operator to select the list of Employee's with the Name 'John' */
/* Variable Declaration */
DECLARE @EmpName AS NVARCHAR(50)
DECLARE @SQLQuery AS NVARCHAR(500)

/* Build and Execute a Transact-SQL String with a single parameter value Using sp_executesql Command */
SET @EmpName = 'John' 
SET @SQLQuery = 'SELECT * FROM tblEmployees WHERE EmployeeName LIKE '''+ '%' + @EmpName + '%' + '''' 
PRINT @SQLQuery
EXECUTE sp_executesql @SQLQuery


/* Example 3.1 use IN operator to select the Employee ID = 1001, 1003 */
/* Variable Declaration */
DECLARE @EmpID AS NVARCHAR(50)
DECLARE @SQLQuery AS NVARCHAR(500)

/* Build and Execute a Transact-SQL String with a single parameter value Using sp_executesql Command */
SET @EmpID = '1001,1003' 
SET @SQLQuery = 'SELECT * FROM tblEmployees WHERE EmployeeID IN(' + @EmpID + ')'
EXECUTE sp_executesql @SQLQuery


/* Example 3.2 sorts the Employee reocrds by "Department" column. */
/* Variable Declaration */
DECLARE @OrderBy AS NVARCHAR(50)
DECLARE @SQLQuery AS NVARCHAR(500)

/* Build and Execute a Transact-SQL String with a single parameter value Using sp_executesql Command */
SET @OrderBy = 'Department' 
SET @SQLQuery = 'SELECT * FROM tblEmployees Order By ' + @OrderBy

EXECUTE sp_executesql @SQLQuery






