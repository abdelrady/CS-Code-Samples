using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Net.NetworkInformation;
using System.Net;
using System.Runtime.InteropServices;

namespace arpscan
{
    public partial class Form1 : Form
    {
        [DllImport("iphlpapi.dll", ExactSpelling = true)]
        public static extern int SendARP(int DestIP, int SrcIP, [Out] byte[] pMacAddr, ref int PhyAddrLen);
        static int x = 0;

        static string y, z;
        bool ok = false;
        static int i = 0;
        static int h = 0;
        static int g = 0;
        string[] list = new string[16777216];

        int l, m, n, o, p, q2, az;

        public Form1()
        {
            InitializeComponent();
        }

        private void getmac()
        {
            while (ok == true && list[i] != null)
            {

                IPAddress dst = IPAddress.Parse(list[i]); // the destination IP address

                byte[] ab = new byte[6];
                int len = ab.Length;

                // This Function Used to Get The Physical Address
                //int r = SendARP(int(TempA.Address), 0, ab, ref len );
                int r = SendARP((int)dst.Address, 0, ab, ref len);
                string mac = BitConverter.ToString(ab, 0, 6);

                string mac2 = mac.Replace("-", "");
                string xe = list[i] + "    " + mac2 + "\n";
                this.richTextBox1.AppendText(xe);
                i++;

            }

            timer1.Stop();
            label9.Text = "IP addresses scanned" + g + "..";

        }


        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            int h = 0;
            int g = 0;
            ok = false;
            bool x1 = false;
            bool x2 = false;
            y = textBox9.Text;
            z = textBox10.Text;


            string a1, a2, a3, a4;
            string b1, b2, b3, b4;
            try
            {
                x1 = AddressParser.ParseIpAddress(y);
                x2 = AddressParser.ParseIpAddress(z);

            }
            catch (Exception e1)
            {

                MessageBox.Show("Invalid IPaddress\n" + e1.Message + "...", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }

            if (x1 == true && x2 == true)
            {
                string[] strtRange = y.Split('.');
                string[] endRange = z.Split('.');

                a1 = strtRange[0];
                a2 = strtRange[1];
                a3 = strtRange[2];
                a4 = strtRange[3];

                b1 = endRange[0];
                b2 = endRange[1];
                b3 = endRange[2];
                b4 = endRange[3];




                if ((a1.Equals("10") | a1.Equals("172") | a1.Equals("192")) && (b1.Equals("10") | b1.Equals("172") | b1.Equals("192")) == true)
                {
                    if ((a1.Equals("10")) | (a1.Equals("192") && a2.Equals("168")) | (a1.Equals("172") && a2.Equals("16") | a2.Equals("17") | a2.Equals("18") | a2.Equals("19") | a2.Equals("20") | a2.Equals("21") | a2.Equals("22") | a2.Equals("23") | a2.Equals("24") | a2.Equals("25") | a2.Equals("26") | a2.Equals("27") | a2.Equals("28") | a2.Equals("29") | a2.Equals("30") | a2.Equals("31")) && (b1.Equals("10")) | (b1.Equals("192") && b2.Equals("168")) | (b1.Equals("172") && b2.Equals("16") | b2.Equals("17") | b2.Equals("18") | b2.Equals("19") | b2.Equals("20") | b2.Equals("21") | b2.Equals("22") | b2.Equals("23") | b2.Equals("24") | b2.Equals("25") | b2.Equals("26") | b2.Equals("27") | b2.Equals("28") | b2.Equals("29") | b2.Equals("30") | b2.Equals("31")) == true)
                    {

                        switch (Convert.ToInt32(a1))
                        {

                            case 10:
                            case 172:
                                if (Convert.ToInt32(b2) == Convert.ToInt32(a2))
                                {
                                    if (Convert.ToInt32(b3) == Convert.ToInt32(a3))
                                    {
                                        if (Convert.ToInt32(b4) >= Convert.ToInt32(a4))
                                        {
                                            // b2a2b3a3 = true;
                                            ok = true;

                                        }
                                        else goto default;

                                    }
                                    else
                                    {
                                        if (Convert.ToInt32(b3) > Convert.ToInt32(a3))
                                        {
                                            ok = true;// b3la3 = true;
                                        }
                                        else goto default;
                                    }


                                }
                                else
                                {
                                    if (Convert.ToInt32(b2) > Convert.ToInt32(a2))
                                    {
                                        // bool b2la2 = true;
                                        ok = true;
                                    }
                                    else goto default;
                                }
                                break;



                            case 192:
                                if (Convert.ToInt32(b3) == Convert.ToInt32(a3))
                                {
                                    if (Convert.ToInt32(b4) >= Convert.ToInt32(a4))
                                    {
                                        //bool b3a3 = true;
                                        ok = true;

                                    }
                                    else goto default;

                                }
                                else
                                {
                                    if (Convert.ToInt32(b3) > Convert.ToInt32(a3))
                                    {
                                        ok = true;
                                        // bool b3la3 = true;
                                    }
                                    else goto default;
                                }
                                break;
                            default:
                                MessageBox.Show("ERROR: IP Range not valid..\n start IP must be lower than end IP address", "WARNING", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                                break;
                        }


                    }
                    else
                    {
                        MessageBox.Show("ERROR: not private IP address(es)", "warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }

                else
                {
                    MessageBox.Show("ERROR: not private IP address(es)", "warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }


                if (ok == true)
                {

                    az = Convert.ToInt32(a1);

                    l = Convert.ToInt32(a2);
                    m = Convert.ToInt32(b2);

                    n = Convert.ToInt32(a3);
                    o = Convert.ToInt32(b3);

                    p = Convert.ToInt32(a4);
                    q2 = Convert.ToInt32(b4);


                    /* //code for class D network scan (removed now)
                     * for (; l <= m; l++)
                     {
                         if (n > o)
                         { zz = true; }
                         for (; n <= o;n++ )
                         {
                             if (p > q2)
                             {zzz = true;
                        
                             }
                             for (; p <= q2||p<=255 ;p++ )
                             {
                           
                                 richTextBox2.AppendText(a1 + "." + Convert.ToString(l) + "." + Convert.ToString(n) + "." + Convert.ToString(p) + "\n");
                                 /*try
                                 {
                                     list[h] = a1 + "." + Convert.ToString(l) + "." + Convert.ToString(n) + "." + Convert.ToString(p);
                                     h++;
                                 }
                                 catch 
                                 { }
                                 if ( p==255&& zzz == true)
                                 {
                                     p = 1;
                                     zzz = false;
                            
                                 }

                             }

                        

                         }
                         if (n == o)
                         n = 1;
                            
                           
                     }*/
                    int ai1 = Convert.ToInt32(a1);
                    int ai2 = Convert.ToInt32(a2);
                    int ai3 = Convert.ToInt32(a3);
                    int ai4 = Convert.ToInt32(a4);

                    int bi1 = Convert.ToInt32(b1);
                    int bi2 = Convert.ToInt32(b2);
                    int bi3 = Convert.ToInt32(b3);
                    int bi4 = Convert.ToInt32(b4);

                    int i1, i2, i3, i4;
                    i1 = bi1 - ai1;
                    i2 = bi2 - ai2;
                    i3 = bi3 - ai3;
                    i4 = bi4 - ai4;


                    if (i1 >= 0)
                    {

                        //check if  i2 is more than zero     
                        //if  i2 more than zero iterate ip ranges and store in array until it becomes zero
                        //if i2 was zero check if i3 is more than zero ,if more than zero iterate ip ranges and store in array until it becomes zero
                        if (i2 > 0)
                        {
                            while (ai2 <= bi2)
                            {

                                //richTextBox2.AppendText(a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4) + "\n");
                                list[h] = a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4);
                                h++;
                                ai4++;
                                if (ai2 == bi2)
                                {

                                    if (ai3 >= bi3 && ai4 > bi4)
                                    {
                                        break;
                                    }

                                }
                                if (ai4 == 255)
                                {
                                    ai3++;
                                    ai4 = 1;
                                }
                                else
                                    if (ai3 == 255)
                                    {
                                        ai2++;
                                        ai3 = 1;
                                    }
                            }
                        }

                        if (i3 > 0)
                        {

                            while (ai3 <= bi3)
                            {
                                //richTextBox2.AppendText(a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4) + "\n");
                                list[h] = a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4);
                                h++;
                                ai4++;
                                if (ai3 == bi3)
                                {

                                    if (ai4 > bi4)
                                    {
                                        break;
                                    }

                                }
                                if (ai4 == 255)
                                {
                                    ai3++;
                                    ai4 = 1;
                                }

                            }
                        }
                        if (i2 == 0 && i3 == 0)
                        {

                            while (ai4 <= bi4)
                            {
                                //richTextBox2.AppendText(a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4) + "\n");
                                list[h] = a1 + "." + Convert.ToString(ai2) + "." + Convert.ToString(ai3) + "." + Convert.ToString(ai4);
                                h++;
                                ai4++;
                            }

                        }
                    }

                }





            }

           
            

            
            timer1.Start();
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (ok == true)
            {
                getmac();
                
                g++;
            }
            else
                timer1.Stop();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true)
                MessageBox.Show("stopped by user", "warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            timer1.Stop();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

       


        private void dynamicgui(object sender, EventArgs e)
        {
            x = Convert.ToInt32(trackBar1.Value);
            timer1.Interval = x;
            label8.Text = "scan at " + x + " milisec per IP";
        }


    }
    
}