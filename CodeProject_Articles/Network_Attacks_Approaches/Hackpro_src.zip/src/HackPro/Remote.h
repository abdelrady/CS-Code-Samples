
#ifndef REMOTE_H
#define REMOTE_H

#include "stdafx.h"
#include "HackPro.h"
#include "Remote.h"

static DWORD  RemoteFunction (REMOTE_INFO* Param);
static void  DummyFunc (void);

#endif