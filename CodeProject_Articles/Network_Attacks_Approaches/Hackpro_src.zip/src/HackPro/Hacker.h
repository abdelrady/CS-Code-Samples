//========================================
#include "stdafx.h"
#include "resource.h"
#include "HackPro.h"
#include "HackProdlg.h"
#ifndef HACKER_H
#define HACKER_H



#endif

//========================================