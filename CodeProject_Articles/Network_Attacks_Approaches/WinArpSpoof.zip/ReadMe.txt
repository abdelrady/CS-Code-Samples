                                 Windows ARP Spoofer
                           Version 0.1  Readme.txt
                                   March 2004

-----------------------------------------------------------------------------
Contents

   1. Overview
   2. System Requirement
   3. What's New
   4. Getting Started
   5. Revision History

-----------------------------------------------------------------------------

1. Overview
------------------------------------

Windows ARP Spoofer is a program that can scan computers including network device 
and can spoof their ARP table on local area network.

Windows ARP Spoofer has the following features:
 
 -. To scan and show active hosts on LAN.
 -. To spoof and recover ARP table in remote hosts.
 -. While spoofing, to act as a router on LAN, that is, ip-forwarder

2. System Requirement.
------------------------------------

 -. Local : All Windows Platform
 -. Remote : All computers including network devices
 -. WinPcap driver must be needed. You must install the latest WinPcap driver
 
3. What's New
------------------------------------
 
 - WinARpSpoofer version 0.1 is released.

4. Getting Started
------------------------------------

  -. Firtly, install the latest WinPcap driver.
  -. second, just run WinArpSpoofer.exe
  -. click scan button and spoof button
  -. look at arp information on remote computer with "arp -a"


5. Revision History
------------------------------------

= bug fixed
+ improvement/modification

[Start of Versions History]

Version 0.1 ( Mar. 18, 2004)
--------------------------------
 This program is released.

[End of Versions History]
