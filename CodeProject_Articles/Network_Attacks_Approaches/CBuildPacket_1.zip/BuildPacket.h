//
//  Copyright (C) 2004 Gordon Ahn (tachyon@nextsecurity.net)
//  All rights reserved. May not be sold for profit.
//
//     Name    : CBuildPacket
//     Desc.   : A Class to build a network packet.
//                  for example, arp packet etc.,
//          
//     O.S     : Windows 9x/Me/NT/2000/XP
//     Author  : Gordon Ahn
//     Date    : Since 1st Feb. 2004
//
//  Revision History - 
//  1st Feb, 2004   : First version begins to be coded.
//

#pragma once

#include <if_arp.h>
#include <ethertype.h>
#include <packet32.h>
#include <Ntddndis.h>
#include "IPHlpApi.h"
#include "IPExport.h"	// Added by ClassView

/* Adapter parameters */
#define ADAPTER_NAMES_SIZE 4096
#define MAX_ADAPTER_NUM 16

class CBuildPacket
{
public:
	CBuildPacket(void);
	~CBuildPacket(void);
protected:

	LPPACKET  lpPacket;
	LPADAPTER lpAdapter; // An adapter to throw a packet
	ARPPKT	  arpPacket;  // A packet for ARP

public:
	// To build a packet for ARP
	int BuildARP(	
		UCHAR	*dEtherAddr, // Destination Ethernet Address
		UCHAR	*sEtherAddr, // Source Ethernet Address
		int		arp_op,		 // ARP Operation
		UCHAR	*arp_SHA,	 // ARP Source Hardware Address
		IPAddr	arp_SIP,	 // ARP Source IP Address
		UCHAR	*arp_THA,	 // ARP Target Hardware Address
		IPAddr	arp_TIP);	 // ARP Target IP Address

	int BuildARP(
		CString	cs_dEtherAddr, // Destination Ethernet Address
		CString	cs_sEtherAddr, // Source Ethernet Address
		int		arp_op,		 // ARP Operation
		CString	cs_arp_SHA,	 // ARP Source Hardware Address
		CString	cs_arp_SIP,	 // ARP Source IP Address
		CString	cs_arp_THA,	 // ARP Target Hardware Address
		CString	cs_arp_TIP); // ARP Target IP Address

	int ConvertMACAddrStrToHex(CString csMACAddr, UCHAR* hxMACAddr);

	LPADAPTER OpenAdapter(LPCTSTR AdapterName);
	void CloseAdapter(void);

	// To send a ARP packet
	int SendPacket(void);
};
