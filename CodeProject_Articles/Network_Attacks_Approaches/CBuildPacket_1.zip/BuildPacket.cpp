//
//  Copyright (C) 2004 Gordon Ahn (tachyon@nextsecurity.net)
//  All rights reserved. May not be sold for profit.
//
//     Name    : CBuildPacket
//     Desc.   : A Class to build a network packet.
//                  for example, arp packet etc.,
//          
//     O.S     : Windows 9x/Me/NT/2000/XP
//     Author  : Gordon Ahn
//     Date    : Since 1st Feb. 2004
//
//  Revision History - 
//  1st Feb, 2004   : First version begins to be coded.
//

#include "stdafx.h"
#include ".\buildpacket.h"

CBuildPacket::CBuildPacket(void)
{
	// Initialize....
	memset(&arpPacket, 0, sizeof(ARPPKT));
}

CBuildPacket::~CBuildPacket(void)
{
	if (!lpPacket)  PacketFreePacket(lpPacket);
	if (!lpAdapter) PacketCloseAdapter(lpAdapter);
}

// To build a packet for ARP
int CBuildPacket::BuildARP(
	UCHAR	*dEtherAddr, // Destination Ethernet Address
	UCHAR	*sEtherAddr, // Source Ethernet Address
	int		arp_op,		 // ARP Operation
	UCHAR	*arp_SHA,	 // ARP Source Hardware Address
	IPAddr	arp_SIP,	 // ARP Source IP Address
	UCHAR	*arp_THA,	 // ARP Target Hardware Address
	IPAddr	arp_TIP)	 // ARP Target IP Address
{
	/* Set ethernet header */
	memcpy(arpPacket.eth_daddr, dEtherAddr, ETH_ADD_LEN);      
	memcpy(arpPacket.eth_saddr, sEtherAddr, ETH_ADD_LEN);
	arpPacket.eth_type = htons(ETHERTYPE_ARP);  

	/* Set ARP header */
	arpPacket.ar_hrd = htons(ARPHRD_ETHER);
	arpPacket.ar_pro = htons(ETHERTYPE_IP);
	arpPacket.ar_hln = ARP_ETH_ADDR_SPACE;
	arpPacket.ar_pln = ARP_IP_ADDR_SPACE;
	arpPacket.ar_op  = htons(arp_op);

	memcpy(  arpPacket.ar_sha,   arp_SHA, ARP_ETH_ADDR_SPACE);
	memcpy(&(arpPacket.ar_sip), &arp_SIP, ARP_IP_ADDR_SPACE);
	memcpy(  arpPacket.ar_tha,   arp_THA, ARP_ETH_ADDR_SPACE);
	memcpy(&(arpPacket.ar_tip), &arp_TIP, ARP_IP_ADDR_SPACE);
	
	/* Set ethernet padding */
	memset(arpPacket.eth_pad, 32, ARP_ETH_PADDING);	

	/* Allocate PACKET structure */

	if((lpPacket = PacketAllocatePacket()) == NULL) {
		AfxMessageBox("Error : failed to allocate the LPPACKET structure");
		PacketCloseAdapter(lpAdapter);
		return(-1);
	}    

	/* Init packet */
	PacketInitPacket(lpPacket, &arpPacket, sizeof(arpPacket));

	return 0;
}

int CBuildPacket::BuildARP(
	CString	cs_dEtherAddr, // Destination Ethernet Address
	CString	cs_sEtherAddr, // Source Ethernet Address
	int		arp_op,		 // ARP Operation
	CString	cs_arp_SHA,	 // ARP Source Hardware Address
	CString	cs_arp_SIP,	 // ARP Source IP Address
	CString	cs_arp_THA,	 // ARP Target Hardware Address
	CString	cs_arp_TIP)	 // ARP Target IP Address
{
	UCHAR  dEtherAddr[ETH_ADD_LEN],sEtherAddr[ETH_ADD_LEN];
	UCHAR  arp_SHA[ETH_ADD_LEN],	  arp_THA[ETH_ADD_LEN];
	IPAddr arp_SIP, arp_TIP;

	ConvertMACAddrStrToHex(cs_dEtherAddr,dEtherAddr);
	ConvertMACAddrStrToHex(cs_sEtherAddr,sEtherAddr);
	ConvertMACAddrStrToHex(cs_arp_SHA,arp_SHA);
	ConvertMACAddrStrToHex(cs_arp_THA,arp_THA);

	arp_SIP = inet_addr( cs_arp_SIP.operator LPCTSTR() );
	arp_TIP = inet_addr( cs_arp_TIP.operator LPCTSTR() );

	return BuildARP(dEtherAddr,sEtherAddr,arp_op,arp_SHA,arp_SIP,arp_THA, arp_TIP);

} // End of BuildARP


LPADAPTER CBuildPacket::OpenAdapter(LPCTSTR AdapterName)
{
	/* ASCII strings for WIN9x */
	char  AdapterNameA[ADAPTER_NAMES_SIZE];
	char  *TmpAdapterA;
	char  *AnotherTmpAdapterA; 
  
	/* UNICODE strings for WINNT */
	WCHAR  AdapterNameU[ADAPTER_NAMES_SIZE];
	WCHAR  *TmpAdapterU;
	WCHAR  *AnotherTmpAdapterU; 
  
	/* Others */
	char  AdapterList[MAX_ADAPTER_NUM][ADAPTER_NAMES_SIZE];
	int   AdapterNum=0;
	//int   i = 0;
	int   SelectedAdapter=0;
	ULONG AdapterLength = ADAPTER_NAMES_SIZE;
	DWORD Version;
	DWORD WindowsMajorVersion;

	/* Get operating system version */
	Version = GetVersion();
	WindowsMajorVersion = (DWORD)(LOBYTE(LOWORD(Version)));

	/* Get adapter names */
	if(!(Version >= 0x80000000 && WindowsMajorVersion >= 4))
	{
		// Windows NT
		if(PacketGetAdapterNames((PTSTR)AdapterNameU, &AdapterLength) == FALSE)
		{
			/* "Unable to retrieve the list of adapters!\n" */

			return ((LPADAPTER) -1);
		}

		TmpAdapterU = AdapterNameU;
		AnotherTmpAdapterU = AdapterNameU;

		while((*TmpAdapterU != '\0') || (*(TmpAdapterU - 1) != '\0')) 
		{
			if(*TmpAdapterU == '\0') 
			{
				memcpy(AdapterList[AdapterNum], AnotherTmpAdapterU, (TmpAdapterU - AnotherTmpAdapterU ) * 2);
				AdapterList[AdapterNum][(TmpAdapterU - AnotherTmpAdapterU ) * 2] = '\0';
				AnotherTmpAdapterU = TmpAdapterU + 1;

				//Select the specifield adapter by AdapterName
				// Replaced out by using WinPcap 3.1b
				//if ( wcsstr( (WCHAR*)AdapterList[AdapterNum],SChar2WChar( (const char *) AdapterName)) )
				if ( strstr( AdapterList[AdapterNum], AdapterName) )
					SelectedAdapter = AdapterNum;
				
				AdapterNum++;  // Next Adapter
			}
				
			TmpAdapterU ++;    // Next Character
		} /* end of while */

	}		
	else 
	{   // Windows 9X
		if(PacketGetAdapterNames((PTSTR)AdapterNameA, &AdapterLength) == FALSE) {
			/* "Unable to retrieve the list of adapters!\n" */

			return ((LPADAPTER) -1);
		}

		TmpAdapterA = AdapterNameA;
		AnotherTmpAdapterA = AdapterNameA;
			
		while((*TmpAdapterA != '\0') || (*(TmpAdapterA - 1) != '\0')) 
		{
			if(*TmpAdapterA == '\0') 
			{				
				memcpy(AdapterList[AdapterNum], AnotherTmpAdapterA, sizeof(AnotherTmpAdapterA));
				AdapterList[AdapterNum][TmpAdapterA - AnotherTmpAdapterA] = '\0';
				AnotherTmpAdapterA = TmpAdapterA + 1;

				//Select the specifield adapter by AdapterName
				if ( strstr( AdapterList[AdapterNum],AdapterName) )
					SelectedAdapter = AdapterNum;

				AdapterNum++;  // Next Adapter
			} 
				
			TmpAdapterA++;    // Next Character
		}	/* end of while */
	}

	lpAdapter = PacketOpenAdapter(AdapterList[SelectedAdapter]);

	return lpAdapter;

} // End of OpenAdapter

void CBuildPacket::CloseAdapter(void)
{
	PacketCloseAdapter(lpAdapter);
} // End of CloseAdapter

// To send a ARP packet
int CBuildPacket::SendPacket(void)
{
	/* Set number of packets to send */
	if(PacketSetNumWrites(lpAdapter, 1) == FALSE) 
	{
		AfxMessageBox("Warning : unable to send more than one packet in a single write");
		return (-1);
	}

	if(PacketSendPacket(lpAdapter, lpPacket, TRUE) == FALSE)
	{
		AfxMessageBox("\nError : unable to send the packets");	        
		PacketFreePacket(lpPacket);
		PacketCloseAdapter(lpAdapter);
		return(-1);
	}

	PacketFreePacket(lpPacket);

	return(EXIT_SUCCESS);
} // End of SendARP

// Description : To convert a CString MAC address into a hexed MAC address
int CBuildPacket::ConvertMACAddrStrToHex(CString csMACAddr, UCHAR* hxMACAddr)
{
	int i = 0,j = 0;
	bool shift=false;
    char ch;
	//Cant convert.......
	if (csMACAddr.GetLength() == 0) return false;

	while ( csMACAddr.GetLength() > i )
	{
		if ( isalnum(ch = csMACAddr.GetAt(i++) ) )
		{
			if ( isalpha(ch) ){
				if   ( !shift ){ 
					hxMACAddr[j]    = (toupper(ch) - 'A'+10) << 4;	
					shift = true;
				}
				else {               
					hxMACAddr[j++] |= toupper(ch) - 'A'+10;
					shift = false;
				}
			}
			else { // if ch is numeric,
				if   ( !shift) {
					hxMACAddr[j]    = (ch - '0') << 4;
					shift = true;
				}
				else {               
					hxMACAddr[j++] |= ch - '0';
					shift = false;
				}
			}
		}
	} // End of while

	return true;
} // End of convertMACAddrStrToHex()