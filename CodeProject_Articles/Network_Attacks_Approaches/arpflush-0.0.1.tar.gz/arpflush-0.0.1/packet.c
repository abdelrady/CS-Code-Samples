/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#include "packet.h"

u_int8_t arp_reply[]=
	"\x00\x12\x34\x56\x78\x9a"
	"\x00\x13\x24\x57\x68\x9b"
	"\x08\x06"
	"\x00\x01\x08\x00\x06\x04"
	"\x00\x02"
	"\x00\x13\x24\x57\x68\x9b"
	"\xc0\xa8\x00\x01"
	"\x00\x12\x34\x56\x78\x9a"
	"\xc0\xa8\x00\x02"
	"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";

void build_pkt(struct ether_packet_arp *pkt,char *t_mac,char *t_ip,char *s_mac,char *s_ip){
	struct ether_addr *ea;
	struct in_addr ip_addr;
	
	ea=ether_aton(t_mac);
	memcpy(&(pkt->eh.ether_dhost),&(ea->ether_addr_octet),ETHER_ADDR_LEN);
	
	ea=ether_aton(s_mac);
	memcpy(&(pkt->eh.ether_shost),&(ea->ether_addr_octet),ETHER_ADDR_LEN);

	pkt->eh.ether_type=htons(ETHERTYPE_ARP);/* 0x0806 */
	pkt->arp.ea_hdr.ar_hrd=htons(ARPHRD_ETHER);/* 0x0001 */
	pkt->arp.ea_hdr.ar_pro=htons(0x0800); /*?*/
	pkt->arp.ea_hdr.ar_hln=ETHER_ADDR_LEN;/* 6; */
	pkt->arp.ea_hdr.ar_pln=4;
	if(1){
	pkt->arp.ea_hdr.ar_op=htons(ARPOP_REPLY); /* 0x0002 */
	}
	else{
	pkt->arp.ea_hdr.ar_op=htons(ARPOP_REQUEST); /* 0x0001 */
	}

	memcpy(&(pkt->arp.arp_sha),&(pkt->eh.ether_shost),ETHER_ADDR_LEN);

	/*pkt.arp.arp_spa=*/
	inet_aton(s_ip,&ip_addr);
	memcpy(&(pkt->arp.arp_spa),&(ip_addr.s_addr),4);

	memcpy(&(pkt->arp.arp_tha),&(pkt->eh.ether_dhost),ETHER_ADDR_LEN);

	/*pkt.arp.arp.tpa*/
	inet_aton(t_ip,&ip_addr);
	memcpy(&(pkt->arp.arp_tpa),&(ip_addr.s_addr),4);
	
	/*dump_pkt(&pkt,sizeof(pkt));*/
}

void dump_pkt(void *buf,int len){
	unsigned char *p=buf;
	int i;
	for(i=0;i<len;i++){
		printf("%02x:",p[i]);
	}
}
