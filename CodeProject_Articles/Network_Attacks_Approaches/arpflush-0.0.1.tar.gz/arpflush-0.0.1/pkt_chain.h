/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef _pkt_chain_h_
#define _pkt_chain_h_

struct pkt_chain{
	void *data;
	int len;
	struct pkt_chain *next;
};

void pchain_add(void *data,int len);
void pchain_free(void);
void pchain_dump(void);

#endif /* pkt_chain.h */
