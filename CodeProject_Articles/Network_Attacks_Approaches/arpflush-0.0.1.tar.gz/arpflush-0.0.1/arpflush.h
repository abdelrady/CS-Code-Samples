/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef _arpflush_h_
#define _arpflush_h_

#include "pkt_chain.h"
#include "s_chain.h"

extern int s_rate,s_interval;
extern char device[32];
extern struct send_chain *s_chain;
extern struct pkt_chain *p_chain;

#endif /* arpflush.h */
