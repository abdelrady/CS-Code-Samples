/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef _s_chain_h_
#define _s_chain_h_

struct send_desc{
	char *to;
	char *mac;
	char *host;
	char *at;
};

struct send_chain{
	struct send_desc desc;
	struct send_chain *next;
};

void schain_add(char *to,char *mac,char *host,char *at);
void schain_free(void);
void schain_dump(void);

#endif /* s_chain.h */
