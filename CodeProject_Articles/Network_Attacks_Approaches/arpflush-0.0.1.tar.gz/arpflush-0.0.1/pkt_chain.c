/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/* printf */
#include <stdio.h>

/* memset */
#include <string.h>

#include <stdlib.h>

#include "pkt_chain.h"
#include "arpflush.h"

void pchain_add(void *data,int len){
	struct pkt_chain *pc=malloc(sizeof(struct pkt_chain));

	if(!pc){
		puts("no enough memory!\n");
		exit(1);
	}

	pc->data=malloc(len);

	if(!pc->data){
		puts("no enough memory!\n");
		exit(1);
	}

	memcpy(pc->data,data,len);
	pc->len=len;
	pc->next=NULL;

	/* append to chain */	
	if(p_chain){
		struct pkt_chain *p=p_chain;
		while(p->next)p=p->next;
		p->next=pc;
	}
	else{
		p_chain=pc;
	}
}

void pchain_free(){
#ifdef DEBUG
	puts("enter pcain_free\n");
#endif
	struct pkt_chain *next;
	while(p_chain){
		next=p_chain->next;
		free(p_chain->data);
		free(p_chain);
		p_chain=next;
	}
#ifdef DEBUG
	puts("leave pcain_free\n");
#endif
}

void pchain_dump(){
#ifdef DEBUG
	puts("enter pcain_dump\n");
#endif
	struct pkt_chain *p=p_chain;
	while(p){
		printf("pkt %08X data %08X len %d\n",(int)p,(int)p->data,p->len);

		unsigned char *pd=p->data;
		int i;
		for(i=0;i<p->len;i++){
			printf("%02x%s",pd[i],i%16==15?"\n":" ");
		}

		putchar('\n');
		p=p->next;
	}
#ifdef DEBUG
	puts("leave pchain_dump\n");
#endif
}
