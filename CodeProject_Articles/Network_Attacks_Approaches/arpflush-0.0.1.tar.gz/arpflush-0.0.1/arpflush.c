/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/* printf */
#include <stdio.h>

/* memset */
#include <string.h>

/* signal */
#include <signal.h>

#include <stdlib.h>

#include "io.h"
#include "packet.h"
#include "parse_rc.h"
#include "pkt_chain.h"
#include "s_chain.h"
#include "sighandler.h"
#include "arpflush.h"

/* default arp timing is 1 packet every 150 seconds */
int s_rate=1;
int s_interval=150;

/* default send packets from dev eth0 */
char device[32]="eth0";

struct ether_packet_arp *pkt;


struct send_chain *s_chain;
struct pkt_chain *p_chain;

int main(int argc,char **argv){
	if(argc!=2){
		printf("Usage: %s <cmdfile>\n",argv[0]);
		return 1;
	}

#ifdef DEBUG
	printf("assign signals\n");
#endif

	signal(SIGINT,sig_handler);
	signal(SIGHUP,sig_handler);

	/* stdout is unbeffered now */
	setvbuf(stdout,NULL,_IONBF,BUFSIZ);
	
init:
	
	/* build s_chain */
	parse_rc(argv[1]);
#ifdef DEBUG
	schain_dump();
#endif

	/* build p_chain */
	pkt=malloc(sizeof(struct ether_packet_arp));
	if(!pkt){
		puts("no enough memory!\n");
		exit(1);
	}
	struct send_chain *sp=s_chain;
	while(sp){
		build_pkt(pkt,sp->desc.mac,sp->desc.to,sp->desc.at,sp->desc.host);
		pchain_add(pkt,sizeof(*pkt));
		sp=sp->next;
	}
	free(pkt);
#ifdef DEBUG
	pchain_dump();
#endif
/*
	return 0;
	*/

/*
	printf("%x\n",hton(1));*/
	char m[4]="-\\|/";
	/*char m[3]=".oO";*/
	int k=0;
	int i,c=10;
	
#ifdef DEBUG
	printf("opening device %s\n",device);
#endif
	if(!io_open(device)){
		printf("cannot open device %s\n",device);
		return 1;
	}
#ifdef DEBUG
	printf("device %s opened\n",device);
#endif

	printf("arpflush running on dev %s rate %d interval %d\n",device,s_rate,s_interval);
	
	for(i=0;;i++){
		struct pkt_chain *pc=p_chain;
		while(pc){
			io_write((u_int8_t *)pc->data,pc->len);
			pc=pc->next;
		}
		
		/*
		putchar('.');
		fflush(stdout);
		*/
		putchar(m[k++%sizeof(m)]);
		putchar('\xd');
		usleep(1000000*s_interval/s_rate);
		
		if(sig_hup_received)break;
		if(sig_int_received)break;
	}
		
	io_close();
		
	schain_free();
	pchain_free();

	if(sig_int_received){
		printf("user interrupted(%d) at %d:%d/%d\n",sig_int_received,i,s_rate,s_interval);
	}

	if(sig_hup_received){
		sig_hup_received=0;
		goto init;
	}

	return 0;
}
