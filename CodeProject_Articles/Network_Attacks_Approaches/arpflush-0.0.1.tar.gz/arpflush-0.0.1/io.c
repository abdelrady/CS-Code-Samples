/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/* socket */
#include <sys/socket.h>

#include <net/ethernet.h>
#include <netinet/ether.h>

/* htons() */
#include <netinet/in.h>

/* inet_aton() */
#include <arpa/inet.h>

/* sockaddr_ll */
#include <netpacket/packet.h>

/* SIOCGIFINDEX */
#include <sys/ioctl.h>

/* ETH_P_ALL ETH_P_ARP */
#include <linux/if_ether.h>

/* ifreq */
#include <net/if.h>

#include <stdlib.h>
#include <string.h>
#include "io.h"

int fd; /* file descriptor of packet device */
struct sockaddr_ll sa;

int io_open(char *device){
	struct ifreq ifr;

	fd=socket(PF_PACKET,SOCK_RAW,htons(ETH_P_ALL));
	/*
	fd = socket(PF_INET, SOCK_PACKET, htons(ETH_P_ALL));
	*/

	if(fd==-1){
		return 0;
	}
	
	memset(&ifr,0,sizeof(ifr));
	strncpy(ifr.ifr_name,device,sizeof(ifr.ifr_name)-1);
	ifr.ifr_name[sizeof(ifr.ifr_name)-1]='\0';

	if(ioctl(fd,SIOCGIFINDEX,&ifr)==-1){
		return 0;
	}
 
	/*struct sockaddr_ll sa;*/

	memset(&sa,0,sizeof(sa));
	sa.sll_family=AF_PACKET;
	sa.sll_ifindex=ifr.ifr_ifindex;
	sa.sll_protocol=htons(ETH_P_ALL);

	return 1;
}

int io_write(u_int8_t *pkt,u_int32_t size){
	int c;

	c=sendto(fd,pkt,size,0,(struct sockaddr *)&sa,sizeof(sa));

	return c;
}

int io_close(){
	shutdown(fd,SHUT_RDWR);
	
	if(close(fd)==0) /* no error */
		return 1;
	else
		return 0;
}
