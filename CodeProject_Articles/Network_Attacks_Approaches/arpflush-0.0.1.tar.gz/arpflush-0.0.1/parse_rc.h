/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef _parse_rc_h_
#define _parse_rc_h_

void set_interval(char* p);
void set_rate(char* p);
int parse_rc(char *file);

#endif /* parse_rc.h */
