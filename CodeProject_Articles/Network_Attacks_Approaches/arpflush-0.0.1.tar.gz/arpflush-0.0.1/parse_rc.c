/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parse_rc.h"
#include "arpflush.h"

void set_interval(char* p){
	int v=atoi(p);
	if(v>0){
		s_interval=v;
	}
#ifdef DEBUG
	printf("set_interval: s_interval=%d\n",s_interval);
#endif
}

void set_rate(char* p){
	int v=atoi(p);
	if(v>0){
		s_rate=v;
	}
#ifdef DEBUG
	printf("set_rate: s_rate=%d\n",s_rate);
#endif
}

void set_device(char *p){
	strncpy(device,p,sizeof(device)-1);
#ifdef DEBUG
	printf("set_device: s_device=%s\n",device);
#endif
}

int parse_rc(char *file){
#ifdef DEBUG
	printf("enter parse_rc\n");
#endif
	FILE *fp=fopen(file,"rb");
	if(!fp){
		return 0;
	}
	char *line=NULL;
	int len=0,alen;
	char *t;
	while(1){
		alen=getdelim(&line,&len,';',fp);
		if(alen==-1){
			free(line);
			break;
		}
#ifdef DEBUG
		printf("input: len=%d data=%s\n",alen,line);
#endif
		if(t=strtok(line," \t\r\n;")){
			if(t[0]=='#'){/* comment */
			}
			else
			if(strcmp(t,"set")==0){
				while(t=strtok(NULL," \t\r\n;")){
					if(strcmp(t,"rate")==0){
						if(t=strtok(NULL," \t\r\n;")){
							set_rate(t);
#ifdef DEBUG
							printf("parsed: set rate %s;\n",t);
#endif
						}
						else{
							printf("unknown rate!\n");
						}
					}
					else
					if(strcmp(t,"interval")==0){
						if(t=strtok(NULL," \t\r\n;")){
							set_interval(t);
#ifdef DEBUG
							printf("parsed: set interval %s;\n",t);
#endif
						}
						else{
							printf("unknown interval!\n");
						}
					}
					else
					if(strcmp(t,"dev")==0){
						if(t=strtok(NULL," \t\r\n;")){
							set_device(t);
#ifdef DEBUG
							printf("parsed: set dev %s;\n",t);
#endif
						}
						else{
							printf("unknown rate!\n");
						}
					}
					else{
						printf("unknown set cmd: %s!\n",t);
					}
				}
			}
			else
			if(strcmp(t,"send")==0){
				char *to=NULL,*mac=NULL,*host=NULL,*at=NULL;
				while(t=strtok(NULL," \t\r\n;")){
					if(strcmp(t,"to")==0){
						if(t=strtok(NULL," \t\r\n;")){
							to=t;
						}
						else{
							printf("unknown send!\n");
						}
					}
					else
					if(strcmp(t,"mac")==0){
						if(t=strtok(NULL," \t\r\n;")){
							mac=t;
						}
						else{
							printf("unknown send!\n");
						}
					}
					else
					if(strcmp(t,"host")==0){
						if(t=strtok(NULL," \t\r\n;")){
							host=t;
						}
						else{
							printf("unknown send!\n");
						}
					}
					else
					if(strcmp(t,"at")==0){
						if(t=strtok(NULL," \t\r\n;")){
							at=t;
						}
						else{
							printf("unknown send!\n");
						}
					}
					else{
						printf("unknown send token %s!\n",t);
					}
				}
				schain_add(to,mac,host,at);
#ifdef DEBUG
				printf("parsed: send to %s mac %s host %s at %s;\n",to,mac,host,at);
#endif
			}
			else{
				printf("unknown token: %s!\n",t);
			}
		}
		len=alen+1;
	}
	fclose(fp);
#ifdef DEBUG
	puts("leave parse_rc\n");
#endif
}
