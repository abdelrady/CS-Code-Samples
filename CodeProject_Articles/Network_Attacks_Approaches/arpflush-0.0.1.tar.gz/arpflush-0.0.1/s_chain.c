/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

/* printf */
#include <stdio.h>

/* memset */
#include <string.h>

#include <stdlib.h>

#include "s_chain.h"
#include "arpflush.h"

void schain_add(char *to,char *mac,char *host,char *at){
	struct send_chain *sc=malloc(sizeof(struct send_chain));

	if(!sc){
		puts("no enough memory!\n");
		exit(1);
	}

	sc->desc.to=malloc(1+strlen(to));
	sc->desc.mac=malloc(1+strlen(mac));
	sc->desc.host=malloc(1+strlen(host));
	sc->desc.at=malloc(1+strlen(at));

	if(!sc->desc.to||!sc->desc.mac||!sc->desc.host||!sc->desc.at){
		puts("no enough memory!\n");
		exit(1);
	}

	strcpy(sc->desc.to,to);
	strcpy(sc->desc.mac,mac);
	strcpy(sc->desc.host,host);
	strcpy(sc->desc.at,at);

	sc->next=NULL;
	
	/* append to chain */
	if(s_chain){
		struct send_chain *p=s_chain;
		while(p->next)p=p->next;
		p->next=sc;
	}
	else{
		s_chain=sc;
	}
}

void schain_free(){
	struct send_chain *next;
	while(s_chain){
		next=s_chain->next;
		free(s_chain->desc.to);
		free(s_chain->desc.mac);
		free(s_chain->desc.host);
		free(s_chain->desc.at);
		free(s_chain);
		s_chain=next;
	}
}

void schain_dump(){
#ifdef DEBUG
	printf("enter chain_dump\n");
#endif
	struct send_chain *p=s_chain;
	while(p){
		printf("s_chain %08X: send to %s mac %s host %s at %s;\n",(int)p,p->desc.to,p->desc.mac,p->desc.host,p->desc.at);
		p=p->next;
	}
#ifdef DEBUG
	printf("leave chain_dump\n");
#endif
}
