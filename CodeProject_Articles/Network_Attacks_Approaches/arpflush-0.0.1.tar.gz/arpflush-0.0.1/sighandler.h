/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#ifndef _sighandler_h_
#define _sighandler_h_

extern int sig_int_received;/* ctrl-c pressed */
extern int sig_hup_received;/* rcfile changed, restart */

void sig_handler(int sig);

#endif /* sighandler.h */
