/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#include <signal.h>
#include "sighandler.h"

int sig_int_received=0;/* ctrl-c pressed */
int sig_hup_received=0;/* rcfile changd, restart */

void sig_handler(int sig){
	switch(sig){
	case SIGINT:
		sig_int_received++;
		break;
	case SIGHUP:
		sig_hup_received++;
		break;
	}
}
