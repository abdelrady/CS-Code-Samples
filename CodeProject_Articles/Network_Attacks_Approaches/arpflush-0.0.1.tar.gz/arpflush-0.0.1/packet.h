/* Copyright (C) 2009, phpsmithlin <phpsmithlin@googlemail.com>

   This file is released under the terms of the GNU GENERAL PUBLIC LICENSE VERSION 2.1(GNU GPLv2.1)

   NO WARRANTY; NOT even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

#include <stdio.h>
#include <string.h>

/* socket */
#include <sys/socket.h>

#include <net/ethernet.h>
#include <netinet/ether.h>

/* htons() */
#include <netinet/in.h>

/* inet_aton() */
#include <arpa/inet.h>

/* sockaddr_ll */
#include <netpacket/packet.h>

/* SIOCGIFINDEX */
#include <sys/ioctl.h>

/* ETH_P_ALL ETH_P_ARP */
#include <linux/if_ether.h>

/* ifreq */
#include <net/if.h>


#ifndef _packet_h_
#define _packet_h_

struct ether_packet_arp{
	struct ether_header eh;
	struct ether_arp arp;
};

void build_pkt(struct ether_packet_arp *pkt,char *t_mac,char *t_ip,char *s_mac,char *s_ip);
void dump_pkt(void *buf,int len);

#endif /* packet.h */
